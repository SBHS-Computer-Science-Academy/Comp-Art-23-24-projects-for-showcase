function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
}

function draw() {

  fill(255, 255, 255);
  rect(100, 100, 200, 200);
  fill(255);
  rect(100, 250, 200, 50);
  stroke(0);
  strokeWeight(2);
  line(110, 250, 190, 250);
  line(210, 250, 290, 250);
  fill(255);
  ellipse(130, 150, 40, 40);
  ellipse(270, 150, 40, 40);
}
