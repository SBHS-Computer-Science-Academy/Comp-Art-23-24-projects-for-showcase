function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  gridWidth = width
  gridHeight = height
  hexagonSize = width / 10

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}


function draw() {
  clear();
  stroke('black')

  makeGrid();
  drawFlowerandvase();

  drawMouseLines("green");
}

function drawFlowerandvase() {

  beginShape();
  fill("green")
  vertex(191, 239);
  vertex(211, 516);
  vertex(249, 517);
  vertex(210, 230);
  vertex(190, 238);
  endShape();

  beginShape();
  vertex(351, 519);
  vertex(621, 297);
  vertex(631, 318);
  vertex(400, 529);
  vertex(350, 521);
  endShape();

  fill('purple')
  beginShape();
  vertex(180, 177);
  vertex(86, 53);
  vertex(170, 15);
  vertex(210, 158);
  vertex(237, 19);
  vertex(335, 52);
  vertex(249, 171);
  vertex(436, 69);
  vertex(472, 137);
  vertex(260, 186);
  vertex(449, 165);
  vertex(453, 221);
  vertex(262, 214);
  endShape();

  beginShape();
  vertex(176, 185);
  vertex(31, 130);
  vertex(21, 203);
  vertex(172, 205);
  vertex(16, 248);
  vertex(37, 300);
  vertex(182, 231);
  vertex(96, 296);
  vertex(161, 351);
  vertex(203, 245);
  vertex(231, 415);
  vertex(308, 395);
  vertex(238, 243);
  vertex(341, 372);
  vertex(366, 296);
  vertex(254, 231);
  vertex(374, 278);
  vertex(390, 243);
  vertex(257, 231);
  endShape();

  beginShape();
  vertex(644, 258);
  vertex(566, 79);
  vertex(513, 186);
  vertex(629, 271);
  vertex(461, 293);
  vertex(473, 363);
  vertex(621, 304);
  vertex(524, 444);
  vertex(597, 483);
  vertex(621, 306);
  vertex(644, 520);
  vertex(710, 511);
  vertex(680, 343);
  vertex(769, 508);
  vertex(796, 433);
  vertex(700, 329);
  vertex(790, 337);
  vertex(787, 263);
  vertex(709, 284);
  vertex(792, 57);
  vertex(703, 43);
  vertex(676, 254);
  vertex(666, 13);
  vertex(594, 29);
  vertex(650, 257);
  endShape();

  fill('yellow')
  ellipse(218, 203, 90, 90)
  ellipse(666, 299, 90, 90)

  beginShape();
  fill("PowderBlue")
  vertex(190, 762);
  vertex(188, 712);
  vertex(220, 711);
  vertex(220, 744);
  vertex(252, 746);
  vertex(250, 761);
  vertex(190, 762);
  endShape();

  beginShape();
  fill("DodgerBlue")
  vertex(187, 712);
  vertex(185, 634);
  vertex(288, 633);
  vertex(219, 712);
  vertex(187, 712);
  endShape();

  beginShape();
  fill("SkyBlue")
  vertex(250, 761);
  vertex(378, 762);
  vertex(378, 701);
  vertex(220, 743);
  vertex(252, 746);
  vertex(250, 759);
  endShape();

  beginShape();
  fill("PaleTurquoise")
  vertex(220, 742);
  vertex(220, 713);
  vertex(337, 577);
  vertex(416, 607);
  vertex(378, 702);
  endShape();

  beginShape();
  fill("DodgerBlue")
  vertex(379, 761);
  vertex(459, 761);
  vertex(453, 677);
  vertex(378, 703);
  vertex(379, 760);
  endShape();

  beginShape();
  fill("LightSkyBlue")
  vertex(185, 634);
  vertex(185, 565);
  vertex(288, 633);
  vertex(185, 633);
  endShape();

  beginShape();
  fill("PowderBlue")
  vertex(337, 576);
  vertex(288, 633);
  vertex(184, 564);
  vertex(337, 577);
  endShape();

  beginShape();
  vertex(378, 701);
  vertex(453, 521);
  vertex(494, 520);
  vertex(502, 760);
  vertex(460, 761);
  vertex(453, 676);
  vertex(378, 702);
  endShape();

  beginShape();
  fill("DodgerBlue")
  vertex(185, 565);
  vertex(185, 514);
  vertex(337, 576);
  vertex(185, 564);
  endShape();

  beginShape();
  fill("MediumBlue")
  vertex(337, 576);
  vertex(453, 521);
  vertex(417, 607);
  vertex(338, 577);
  endShape();

  beginShape();
  fill("CornflowerBlue")
  vertex(186, 514);
  vertex(495, 511);
  vertex(494, 520);
  vertex(452, 520);
  vertex(336, 575);
  vertex(186, 517);
  endShape();


}




// Source: https://www.gorillasun.de/blog/a-guide-to-hexagonal-grids-in-p5js/


function drawHexagon(cX, cY, r) {
  beginShape()
  for (let a = 0; a < 360; a += 360 / 6) {
    vertex(cX + r * cos(a), cY + r * sin(a))
  }
  endShape(CLOSE)
}

function makeGrid() {

  let colorlist = ['Burlywood', 'Sienna', 'DarkGoldenrod', 'Peru']
  count = 0
  for (y = 0; y < gridHeight; y += hexagonSize / 2.3) {
    for (x = 0; x < gridWidth; x += hexagonSize * 1.5) {
      noLoop();
      fill(random(colorlist));
      drawHexagon(x + hexagonSize * (count % 2 == 0) * 0.75, y, hexagonSize / 2)
    }
    count++
  }
}
