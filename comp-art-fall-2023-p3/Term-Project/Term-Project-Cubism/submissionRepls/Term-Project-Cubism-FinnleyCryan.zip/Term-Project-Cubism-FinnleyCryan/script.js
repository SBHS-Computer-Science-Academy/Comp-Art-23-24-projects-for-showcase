let numSquares = 0
let iffer = 0

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  frameRate(30)
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white"); 
  outerLines(16)
  drawOuterSquares(10, 260, 0, 5, 6.125)
  //drawOuterSquares(5, 0, 20, 6.125, 5)
  outerSquares(20)
  if (iffer < 360/4.9) {
    numSquares += 1.077 //should take about a minute per full revolution, if computer fast
  } else if (iffer >= 360/4.9 & iffer < 720/4.9) {
    numSquares -= 1
  } else iffer = 0
  iffer += 1
  
  

  drawMouseLines("black")
}

function outerLines(numLines) {
  push()
  translate(width / 2, height / 2) //translates coordinate plane to center
  for (let i = 0; i < numLines; i++) {
    line(width / 2, height / 2, width / 3.5, height / 3.5)
    rotate(360 / numLines) //rotates by an appropriate amount depending on numLines
  }
  pop()
}

function outerSquares(dist = 100, rot = 15) {
  push()
  //numSquares = 360/rot
  translate(width / 2, height / 2)
  for (let i = 0; i < numSquares; i++) {
    square(dist, 0, 40)
    rotate(rot)
  }
  pop()
}

function drawOuterSquares(numRings, startDist, endDist, startRot, endRot) {
  changingDist = startDist
  changingRot = startRot
  for (i = 0; i <= numRings; i++) {
    outerSquares(changingDist, changingRot)
    changingDist -= (startDist - endDist) / numRings
    changingRot -= (startRot - endRot) / numRings
  }
}