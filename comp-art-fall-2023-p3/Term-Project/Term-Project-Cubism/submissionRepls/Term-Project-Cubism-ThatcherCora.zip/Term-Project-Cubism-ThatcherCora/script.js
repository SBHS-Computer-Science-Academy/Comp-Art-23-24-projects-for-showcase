function setup() {
  let myCanvas = createCanvas(500, 500);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  noStroke()
  let color1 = color(255, 255, 0, 100)
  let color2 = color(126, 58, 166, 100)
  gradientVertical(color1, color2)
  drawMouseLines("black");
  drawLine()
  drawLine2()
  drawLine3()
  drawLine4()
  drawLine1()
  drawLine5()
  drawLine6()
  drawRed()
  drawPink()
  drawGreen()
  drawRed2()
  drawLine111()
  drawW2()
  drawLine00()
  drawPinks()
  drawAque()
  drawLavender()
  drawE()
  drawLol()
  drawDeep()
  drawLime()
  drawBig()
  drawEye()
  drawEYY()



  //fill("black");
  //text("Create art in the cubist style using the techniques you've learned this term.", 500, 400);

  drawMouseLines("black")
}
function drawShape() {
  // fill("black");
  beginShape();
  curveVertex(190, 78); // control point
  curveVertex(190, 78);
  curveVertex(139, 83);
  curveVertex(163, 170);
  curveVertex(163, 170); // control point
  endShape();
}

function drawLine() {
  fill("red");
  beginShape();
  curveVertex(291, 156); // control point
  curveVertex(291, 156);
  curveVertex(266, 110);
  curveVertex(218, 217);
  curveVertex(218, 217); // control point
  endShape();
}

function drawLine2() {
  fill("blue");
  beginShape();
  curveVertex(292, 156); // control point
  curveVertex(292, 156);
  curveVertex(330, 110);
  curveVertex(363, 215);
  curveVertex(363, 215); // control point
  endShape();
}

function drawLine3() {
  fill("purple");
  beginShape();
  curveVertex(363, 214); // control point
  curveVertex(363, 214);
  curveVertex(375, 267);
  curveVertex(327, 312);
  curveVertex(327, 312); // control point
  endShape();
}

function drawLine4() {
  fill("orange");
  beginShape();
  curveVertex(218, 216); // control point
  curveVertex(218, 216);
  curveVertex(198, 267);
  curveVertex(222, 300);
  curveVertex(222, 300); // control point
  endShape();
}

function drawLine1() {
  fill("blue");
  beginShape();
  vertex(221, 299);
  vertex(249, 324);
  endShape();
}

function drawLine5() {
  fill("black");
  beginShape();
  vertex(327, 312);
  vertex(310, 332);
  endShape();
}
function drawLine6() {
  fill("blue");
  beginShape();
  curveVertex(246, 322); // control point
  curveVertex(246, 322);
  curveVertex(274, 342);
  curveVertex(284, 344);
  curveVertex(288, 344);
  curveVertex(308, 332);
  curveVertex(308, 332); // control point
  endShape();
}
function drawRed() {
  fill("red");
  beginShape();
  vertex(218, 217);
  vertex(256, 263);
  vertex(255, 322);
  endShape();
}

function drawPink() {
  fill("pink");
  beginShape();
  vertex(218, 220);
  vertex(222, 299);
  vertex(245, 321);
  vertex(254, 323);
  vertex(219, 220);
  endShape();
}
function drawGreen() {
  fill("green");
  beginShape();
  vertex(362, 215);
  vertex(316, 245);
  vertex(329, 309);
  endShape();
}
function drawRed2() {
  fill("red");
  beginShape();
  vertex(335, 289);
  vertex(326, 253);
  vertex(354, 231);
  endShape();
}
function drawLine111() {
  fill("black");
  beginShape();
  vertex(310, 331);
  vertex(307, 332);
  endShape();
}
function drawW2() {
  fill("orange");
  beginShape();
  vertex(256, 262);
  vertex(284, 266);
  vertex(293, 331);
  endShape();
}
function drawLine00() {
  fill("purple");
  beginShape();
  vertex(256, 265);
  vertex(256, 323);
  vertex(291, 329);
  vertex(257, 264);
  endShape();
}


function drawPinks() {
  fill("pink");
  beginShape();
  vertex(314, 244);
  vertex(284, 267);
  vertex(292, 329);
  endShape();
}
function drawAque() {
  fill("red");
  beginShape();
  vertex(315, 245);
  vertex(328, 308);
  vertex(312, 329);
  vertex(309, 332);
  vertex(291, 329);
  vertex(314, 245);
  vertex(317, 249);
  endShape();
}
function drawLavender() {
  fill("orange");
  beginShape();
  vertex(360, 213);
  vertex(285, 214);
  vertex(284, 264);
  endShape();
}
function drawE() {
  fill("blue");
  beginShape();
  vertex(361, 215);
  vertex(286, 264);
  vertex(296, 235);
  vertex(324, 223);
  vertex(360, 215);
  endShape();
}
function drawLol() {
  fill("SlateBlue	");
  beginShape();
  vertex(285, 213);
  vertex(258, 213);
  vertex(249, 227);
  vertex(257, 236);
  vertex(252, 241);
  vertex(251, 256);
  endShape();
} function drawDeep() {
  fill("DeepPink");
  beginShape();
  vertex(284, 214);
  vertex(283, 265);
  vertex(256, 263);
  vertex(252, 256);
  vertex(283, 215);
  vertex(284, 216);
  endShape();
}
function drawLime() {
  fill("Lime");
  beginShape();
  vertex(258, 214);
  vertex(218, 216);
  vertex(252, 255);
  vertex(251, 242);
  vertex(256, 237);
  vertex(250, 228);
  vertex(257, 215);
  endShape();
}
function drawBig() {
  fill("red");
  beginShape();
  vertex(290, 156);
  vertex(220, 215);
  vertex(359, 212);
  vertex(293, 156);
  vertex(288, 156);
  endShape();
}

function drawEye() {
  fill("black");
  beginShape();
  curveVertex(268, 189); // control point
  curveVertex(268, 189);
  curveVertex(263, 190);
  curveVertex(260, 195);
  curveVertex(264, 198);
  curveVertex(270, 197);
  curveVertex(268, 189);
  curveVertex(268, 189); // control point
  endShape();
}
function drawEYY() {
  fill("black");
  beginShape();
  curveVertex(307, 188); // control point
  curveVertex(307, 188);
  curveVertex(304, 190);
  curveVertex(305, 196);
  curveVertex(311, 196);
  curveVertex(312, 193);
  curveVertex(308, 188);
  curveVertex(308, 188); // control point
  endShape();
}
function gradientVertical(color1, color2, steps = 100) {
  let stepSize = width / steps;
  for (let i = 0; i <= width; i += stepSize) {
    fill(lerpColor(color1, color2, i / width))
    rect(i, 0, stepSize, height)





  }
}

