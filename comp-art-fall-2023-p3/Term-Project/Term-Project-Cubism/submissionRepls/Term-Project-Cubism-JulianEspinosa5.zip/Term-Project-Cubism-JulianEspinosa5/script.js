function setup() {
  let myCanvas = createCanvas(700, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  drawbackground()
  drawShape()
  draweye()
  drawShadow()
  drawbody()



  fill("black");
  drawMouseLines("black")
}
function drawbackground() {
  for (y = 0; y < 700; y += 100) {
    for (x = 0; x < 700; x += 100) {
      // fill("mediumvioletred")
      // square(x, y, 100)
      // square(x+100,y+100,100)
      // fill("deeppink")
      // square(x + 100, y, 100)
      // square(x,y+100,100)

      if ((x + y) / 100 % 2 == 0) fill("mediumvioletred")
      else fill("deeppink")
      square(x, y, 100)
  


    }
  }
}

function drawShape() {
  fill("gold");
  beginShape();
  vertex(175, 156);
  vertex(135, 214);
  vertex(214, 207);
  vertex(321, 220);
  vertex(353, 238);
  vertex(272, 309);
  vertex(202, 339);
  vertex(158, 348);
  vertex(148, 321);
  vertex(146, 323);
  vertex(154, 349);
  vertex(179, 383);
  vertex(307, 322);
  vertex(373, 231);
  vertex(337, 209);
  vertex(223, 188);
  vertex(198, 188);
  vertex(175, 154);
  vertex(175, 155);
  endShape();
}
function draweye() {
  fill("white");
  beginShape();
  vertex(166, 211);
  vertex(145, 224);
  vertex(135, 235);
  vertex(127, 247);
  vertex(122, 261);
  vertex(120, 268);
  vertex(120, 276);
  vertex(121, 282);
  vertex(122, 286);
  vertex(124, 290);
  vertex(127, 296);
  vertex(128, 300);
  vertex(131, 306);
  vertex(139, 312);
  vertex(143, 316);
  vertex(147, 320);
  vertex(150, 323);
  vertex(164, 332);
  vertex(169, 336);
  vertex(173, 339);
  vertex(179, 341);
  vertex(182, 342);
  vertex(184, 343);
  vertex(202, 339);
  vertex(273, 309);
  vertex(353, 238);
  vertex(320, 220);
  vertex(214, 207);
  vertex(163, 212);
  endShape();
  fill("blue")
  ellipse(182, 270, 40, 100)
  fill("black")
  ellipse(172, 270, 20, 50)
}
function drawShadow() {
  fill("black");
  beginShape();
  vertex(149, 323);
  vertex(158, 347);
  vertex(184, 343);
  vertex(173, 340);
  vertex(156, 326);
  vertex(149, 322);
  endShape();
  beginShape();
  vertex(135, 215);
  vertex(146, 223);
  vertex(164, 212);
  vertex(135, 214);
  endShape();

}
function drawbody() {
  fill("tan");
  beginShape();
  vertex(307, 323);
  vertex(241, 373);
  vertex(229, 385);
  vertex(228, 388);
  vertex(229, 392);
  vertex(230, 394);
  vertex(233, 397);
  vertex(235, 399);
  vertex(239, 400);
  vertex(242, 400);
  vertex(247, 400);
  vertex(250, 400);
  vertex(254, 400);
  vertex(259, 399);
  vertex(263, 398);
  vertex(286, 398);
  vertex(292, 398);
  vertex(294, 398);
  vertex(295, 398);
  vertex(298, 396);
  vertex(300, 394);
  vertex(302, 391);
  vertex(303, 388);
  vertex(303, 385);
  vertex(303, 383);
  vertex(303, 381);
  vertex(301, 377);
  vertex(299, 374);
  vertex(299, 373);
  vertex(296, 372);
  vertex(295, 371);
  vertex(294, 371);
  vertex(308, 323);
  endShape();
  fill("green");
  beginShape();
  vertex(217, 365);
  vertex(150, 429);
  vertex(241, 373);
  vertex(307, 323);
  vertex(213, 367);
  endShape();
  fill("orange");
  beginShape();
  vertex(175, 153);
  vertex(345, 192);
  vertex(387, 214);
  vertex(374, 231);
  vertex(337, 209);
  vertex(223, 189);
  vertex(198, 188);
  vertex(175, 153);
  endShape();
  fill("pink");
  beginShape();
  vertex(334, 286);
  vertex(545, 284);
  vertex(480, 357);
  vertex(297, 361);
  vertex(308, 320);
  vertex(334, 285);
  endShape();
  fill("limegreen");
  beginShape();
  vertex(303, 385);
  vertex(564, 381);
  vertex(546, 284);
  vertex(480, 358);
  vertex(297, 361);
  endShape();
  beginShape();
  vertex(298, 361);
  vertex(294, 371);
  vertex(300, 374);
  vertex(299, 362);
  endShape();
  fill("white")
  circle(450, 300, 100)
  fill("darkviolet")
  ellipse(450, 301, 30, 50)
  fill("black")
  ellipse(450, 301, 15, 25)
  fill("cyan");
  beginShape();
  vertex(250, 169);
  vertex(284, 77);
  vertex(289, 72);
  vertex(296, 67);
  vertex(311, 65);
  vertex(321, 72);
  vertex(323, 84);
  vertex(320, 99);
  vertex(301, 182);
  vertex(320, 131);
  vertex(433, 192);
  vertex(431, 197);
  vertex(488, 266);
  vertex(471, 253);
  vertex(450, 249);
  vertex(430, 254);
  vertex(413, 265);
  vertex(403, 282);
  vertex(402, 285);
  vertex(334, 286);
  vertex(385, 212);
  vertex(346, 191);
  vertex(249, 170);
  endShape();
  fill("teal");
  beginShape();
  vertex(382, 164);
  vertex(427, 80);
  vertex(446, 200);
  vertex(485, 135);
  vertex(500, 247);
  vertex(527, 26);
  vertex(547, 285);
  vertex(499, 285);
  vertex(469, 243);
  vertex(431, 197);
  vertex(432, 191);
  vertex(382, 164);
  endShape();
  fill("tan");
  beginShape();
  vertex(295, 399);
  vertex(280, 418);
  vertex(267, 425);
  vertex(265, 428);
  vertex(264, 430);
  vertex(263, 432);
  vertex(263, 435);
  vertex(263, 437);
  vertex(263, 438);
  vertex(264, 438);
  vertex(267, 439);
  vertex(272, 440);
  vertex(326, 440);
  vertex(337, 440);
  vertex(342, 440);
  vertex(351, 438);
  vertex(356, 437);
  vertex(363, 435);
  vertex(372, 433);
  vertex(377, 430);
  vertex(384, 427);
  vertex(395, 423);
  vertex(401, 419);
  vertex(407, 416);
  vertex(411, 414);
  vertex(414, 412);
  vertex(410, 442);
  vertex(405, 450);
  vertex(399, 457);
  vertex(389, 464);
  vertex(380, 469);
  vertex(367, 473);
  vertex(354, 475);
  vertex(340, 477);
  vertex(325, 479);
  vertex(313, 480);
  vertex(300, 479);
  vertex(263, 476);
  vertex(256, 481);
  vertex(256, 487);
  vertex(258, 491);
  vertex(260, 494);
  vertex(265, 497);
  vertex(269, 498);
  vertex(286, 506);
  vertex(289, 513);
  vertex(290, 522);
  vertex(292, 532);
  vertex(296, 540);
  vertex(302, 544);
  vertex(317, 547);
  vertex(327, 548);
  vertex(344, 548);
  vertex(360, 549);
  vertex(387, 552);
  vertex(391, 558);
  vertex(393, 562);
  vertex(395, 566);
  vertex(395, 569);
  vertex(395, 574);
  vertex(395, 580);
  vertex(567, 577);
  vertex(564, 381);
  vertex(304, 385);
  vertex(302, 392);
  vertex(295, 399);
  endShape();
  fill("red");
  beginShape();
  vertex(281, 418);
  vertex(299, 417);
  vertex(341, 415);
  vertex(390, 403);
  vertex(443, 394);
  vertex(437, 431);
  vertex(429, 461);
  vertex(381, 490);
  vertex(335, 501);
  vertex(295, 504);
  vertex(282, 504);
  vertex(259, 494);
  vertex(256, 481);
  vertex(263, 476);
  vertex(312, 479);
  vertex(377, 471);
  vertex(402, 454);
  vertex(410, 439);
  vertex(414, 413);
  vertex(379, 430);
  vertex(349, 439);
  vertex(301, 440);
  vertex(272, 440);
  vertex(264, 438);
  vertex(262, 432);
  vertex(266, 425);
  vertex(282, 417);
  endShape();
  fill("tomato");
  beginShape();
  vertex(284, 441);
  vertex(285, 477);
  vertex(312, 479);
  vertex(376, 471);
  vertex(401, 455);
  vertex(410, 439);
  vertex(414, 414);
  vertex(375, 431);
  vertex(344, 440);
  vertex(284, 440);
  endShape();
}




