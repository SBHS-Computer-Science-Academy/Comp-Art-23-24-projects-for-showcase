
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
}

function draw() {
  rectGradient(0, 0, width, 800, "Orange", "Coral"); // sky with sunset

  drawShape()
  Spiderweb(100,100)
  Spiderweb(300,100)
  Spiderweb(500,100)
  Spiderweb(700,100)
  Spiderweb(900,100)
  fill("Sienna");
  beginShape();
  vertex(193, 797);
  vertex(422, 800);
  vertex(374, 431);
  vertex(264, 432);
  vertex(193, 797);
  endShape();
  fill("SaddleBrown")
  triangle(244, 541,390, 548,264, 433)
  fill("Chocolate")
triangle(245, 541,409, 708,389, 548)
  fill("Peru")
  triangle(244, 542,207, 722,408, 707)
  fill("Brown")
 triangle(409, 708,296, 799,421, 799)
 
  drawMouseLines("black")
}
function drawShape() {
   fill("black");
  beginShape();
  curveVertex(374, 431); // control point
  curveVertex(374, 431);
  curveVertex(434, 398);
  curveVertex(470, 303);
  curveVertex(456, 279);
  curveVertex(438, 286);
  curveVertex(422, 334);
  curveVertex(409, 331);
  curveVertex(425, 268);
  curveVertex(419, 216);
  curveVertex(390, 190);
  curveVertex(369, 198);
  curveVertex(384, 215);
  curveVertex(401, 258);
  curveVertex(383, 321);
  curveVertex(353, 308);
  curveVertex(351, 242);
  curveVertex(356, 190);
  curveVertex(358, 155);
  curveVertex(341, 140);
  curveVertex(331, 150);
  curveVertex(325, 166);
  curveVertex(322, 203);
  curveVertex(324, 271);
  curveVertex(325, 302);
  curveVertex(288, 300);
  curveVertex(283, 222);
  curveVertex(269, 194);
  curveVertex(260, 160);
  curveVertex(235, 151);
  curveVertex(219, 157);
  curveVertex(220, 165);
  curveVertex(239, 179);
  curveVertex(240, 196);
  curveVertex(246, 218);
  curveVertex(251, 244);
  curveVertex(260, 280);
  curveVertex(262, 297);
  curveVertex(242, 318);
  curveVertex(234, 354);
  curveVertex(202, 336);
  curveVertex(200, 300);
  curveVertex(217, 272);
  curveVertex(203, 257);
  curveVertex(183, 258);
  curveVertex(167, 291);
  curveVertex(169, 340);
  curveVertex(204, 378);
  curveVertex(231, 411);
  curveVertex(266, 432);
  curveVertex(372, 430);
  curveVertex(372, 430); // control point
  endShape();
}
function Spiderweb(x,y){
  push()
  translate(x, y);
  translate(-100,-60)
for(let i = 0 ; i < 10; i++){
  line(0, 60,100, 60)
  noFill()
  beginShape();
  vertex(27,7);
  vertex(39, 38);
  vertex(10, 60);
  endShape();
  beginShape();
  vertex(57, 60);
  vertex(68, 50);
  vertex(63, 33);
  endShape();
  translate(100,60)
  rotate(360/10)
  translate(-100,-60)
}
pop()
  
}