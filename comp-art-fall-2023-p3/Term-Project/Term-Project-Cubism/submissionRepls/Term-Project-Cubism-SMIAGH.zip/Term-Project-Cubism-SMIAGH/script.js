function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  drawShape()
  drawMouseLines("black")
}

function drawShape() {
  // fill("black");
  beginShape();
  vertex(88, 205);
  vertex(96, 323);
  vertex(236, 321);
  vertex(226, 201);
  vertex(87, 203);
  vertex(149, 123);
  vertex(225, 199);
  vertex(388, 200);
  vertex(402, 318);
  vertex(235, 321);
  vertex(226, 198);
  vertex(149, 122);
  vertex(382, 122);
  vertex(388, 198);
  endShape();
}