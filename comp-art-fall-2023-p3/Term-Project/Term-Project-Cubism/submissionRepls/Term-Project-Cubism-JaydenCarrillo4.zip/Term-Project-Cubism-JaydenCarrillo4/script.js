function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("teal");

     fill("SlateBlue");
    beginShape();
    vertex(474, 799);
    vertex(410, 560);
    vertex(629, 461);
    vertex(730, 495);
    vertex(646, 799);
  endShape();
  triangle(999,1,999,367,461,3)
  triangle(999, 798,998, 599,926, 574)
  triangle(226, 799,102, 413,0, 799)
  triangle(217, 51,199, -1,7, -1)
  
  
  beginShape();
  fill("purple")
  vertex(630, 461);
  vertex(999, 368);
  vertex(459, 0);
  vertex(630, 461);
  vertex(410, 562);
  vertex(198, -3);
  vertex(461, 0);
  triangle(649, 799,999, 799,925, 573)
  triangle(411, 565,1, 364,218, 48)
  endShape();
  fill("Indigo")
  triangle(629,463,646,798,474,798)
  triangle(924, 573,730, 499,647, 800)
  triangle(228, 799,411, 562,474, 799)
  triangle(103, 416,0, 363,0, 795)
  fill("DarkOrchid")
  triangle(632,464,473,798,460,4)
  triangle(632,462,999,368,999,600)
  triangle(102, 415,411, 563,229, 798)
  triangle(1, 365,1, 0,218, 51)

  fill("LightGray")
  beginShape();
  vertex(412, 560);
  vertex(409, 344);
  vertex(466, 410);
  vertex(468, 535);
  vertex(413, 561);

  vertex(468, 412);
  vertex(468, 414);
  vertex(521, 356);
  vertex(560, 406);
  vertex(593, 364);
  vertex(632, 463);
  vertex(475, 795);
  
  vertex(632, 467);
  vertex(646, 796);
  vertex(474, 798);
  vertex(631, 462);

  vertex(629, 463);
  vertex(467, 535);
  vertex(473, 790);
  vertex(631, 465);

  

  endShape();

triangle(395, 798,412, 561,474, 797)
  triangle(413, 563,473, 788,468, 536)
  
  
  

  drawMouseLines("black")
}