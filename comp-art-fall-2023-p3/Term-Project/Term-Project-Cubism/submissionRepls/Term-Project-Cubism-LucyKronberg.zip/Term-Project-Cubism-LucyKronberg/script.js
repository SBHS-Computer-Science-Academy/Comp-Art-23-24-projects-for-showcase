let sunAngle = 0;

function setup() {

  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

}



function draw() {
  rectGradient(0, 0, 800, 430, "lightblue", "cornflower");
  //background("lightblue")
  let lilboatY = 440+10*sin(millis()/4)
  let bigboatY = 500+18*sin(millis()/6+180)
  drawSand();
  drawOcean();
  drawSun();
  drawTree1();
  drawLeaves();
  drawCoconuts();
  drawShips(144, lilboatY, 0.6);
  drawShips(470, bigboatY);
  drawShadow();
  drawSeagulls();
  drawClouds();
  fill("black");
  //text("Create art in the cubist style using the techniques you've learned this term.", 500, 400);

  

  drawMouseLines("black")

}
function drawSand() {
  noStroke();
  fill(245, 236, 157);
  rect(0, 600, 800, 200);

  fill(227, 220, 154);
  beginShape();
  vertex(-2, 661);
  vertex(152, 601);
  vertex(379, 667);
  vertex(232, 753);
  vertex(0, 661);
  endShape();

  fill(252, 247, 194);
  beginShape();
  vertex(78, 739);
  vertex(242, 687);
  vertex(331, 705);
  vertex(403, 657);
  vertex(618, 667);
  vertex(643, 702);
  vertex(557, 792);
  vertex(479, 782);
  vertex(378, 753);
  vertex(251, 780);
  vertex(135, 778);
  vertex(76, 738);
  endShape();

  fill(237, 234, 171);
  beginShape();
  vertex(-1, 636);
  vertex(246, 800);
  vertex(0, 800);
  vertex(-1, 635);
  endShape();

  fill(230, 225, 129);
  beginShape();
  vertex(197, 794);
  vertex(284, 736);
  vertex(409, 749);
  vertex(488, 798);
  vertex(190, 799);
  vertex(199, 794);
  endShape();

  beginShape();
  vertex(761, 621);
  vertex(735, 621);
  vertex(718, 633);
  vertex(769, 645);
  vertex(789, 651);
  vertex(790, 629);
  vertex(788, 615);
  vertex(766, 612);
  vertex(758, 620);
  endShape();

  fill(252, 248, 154);
  beginShape();
  vertex(315, 646);
  vertex(454, 621);
  vertex(542, 676);
  vertex(252, 673);
  vertex(316, 646);
  endShape();

  fill(217, 212, 104);
  beginShape();
  vertex(241, 688);
  vertex(268, 651);
  vertex(453, 689);
  vertex(241, 688);
  endShape();

  fill(196, 191, 84);
  beginShape();
  vertex(489, 643);
  vertex(556, 609);
  vertex(584, 620);
  vertex(603, 664);
  vertex(642, 683);
  vertex(640, 718);
  vertex(488, 643);
  endShape();

  fill(207, 202, 95);
  beginShape();
  vertex(-7, 749);
  vertex(106, 662);
  vertex(222, 709);
  vertex(272, 768);
  vertex(125, 787);
  vertex(-2, 747);
  endShape();

  fill(207, 203, 130);
  beginShape();
  vertex(248, 741);
  vertex(351, 681);
  vertex(458, 682);
  vertex(474, 727);
  vertex(404, 767);
  vertex(323, 757);
  vertex(229, 751);
  vertex(250, 740);
  endShape();

  beginShape();
  vertex(553, 726);
  vertex(617, 682);
  vertex(655, 688);
  vertex(698, 695);
  vertex(733, 721);
  vertex(718, 732);
  vertex(686, 732);
  vertex(677, 750);
  vertex(652, 763);
  vertex(620, 761);
  vertex(569, 782);
  vertex(532, 749);
  vertex(554, 727);
  endShape();
}
function drawOcean() {
  fill(62, 118, 158);
  beginShape();
  vertex(0, 430);
  vertex(397, 600);
  vertex(0, 600);
  endShape();

  fill(88, 151, 199);
  beginShape();
  vertex(0, 430);
  vertex(215, 430);
  vertex(168, 502);
  vertex(1, 431);
  endShape();

  fill(72, 134, 181);
  beginShape();
  vertex(193, 458);
  vertex(289, 554);
  vertex(167, 503);
  vertex(196, 459);
  endShape();

  fill(84, 163, 209);
  beginShape();
  vertex(215, 430);
  vertex(312, 430);
  vertex(194, 461);
  endShape();

  fill(77, 148, 189);
  beginShape();
  vertex(311, 430);
  vertex(289, 554);
  vertex(194, 461);
  vertex(310, 430);
  endShape();

  fill(68, 133, 171);
  beginShape();
  vertex(302, 478);
  vertex(415, 430);
  vertex(289, 554);
  endShape();

  fill(88, 168, 214);
  beginShape();
  vertex(310, 430);
  vertex(416, 430);
  vertex(302, 478);
  vertex(310, 430);
  endShape();

  fill(75, 135, 179);
  beginShape();
  vertex(414, 430);
  vertex(675, 546);
  vertex(288, 555);
  vertex(414, 430);
  endShape();

  fill(62, 106, 138);
  beginShape();
  vertex(395, 600);
  vertex(674, 546);
  vertex(292, 555);
  vertex(394, 599);
  endShape();

  fill(64, 112, 148);
  beginShape();
  vertex(673, 544);
  vertex(800, 600);
  vertex(395, 600);
  vertex(674, 546);
  endShape();

  fill(126, 182, 224);
  beginShape();
  vertex(415, 430);
  vertex(636, 430);
  vertex(566, 498);
  vertex(416, 430);
  endShape();

  fill(97, 148, 186);
  beginShape();
  vertex(636, 430);
  vertex(674, 546);
  vertex(566, 498);
  vertex(636, 430);
  endShape();

  fill(85, 136, 173);
  beginShape();
  vertex(636, 431);
  vertex(799, 600);
  vertex(673, 545);
  vertex(636, 431);
  endShape();

  fill(67, 121, 161);
  beginShape();
  vertex(630, 430);
  vertex(800, 430);
  vertex(800, 600);
  vertex(629, 430);
  endShape();

  fill(54, 107, 143);
  beginShape();
  vertex(1, 598);
  vertex(189, 513);
  vertex(158, 600);
  vertex(0, 599);
  endShape();

  fill(49, 94, 125);
  beginShape();
  vertex(187, 513);
  vertex(395, 600);
  vertex(158, 600);
  vertex(190, 513);
  endShape();

  push()
    for (let i = 0; i < 15; i += 1) {
      fill(92, 147, 189);
      beginShape();
      vertex(1, 431);
      vertex(8, 417);
      vertex(16, 410);
      vertex(28, 409);
      vertex(34, 413);
      vertex(26, 416);
      vertex(24, 420);
      vertex(26, 424);
      vertex(34, 428);
      vertex(43, 430);
      endShape();
      translate(105, 0);
    }
  pop()
}

function drawSun() {

  fill(255, 236, 112, 90);
  beginShape();
  vertex(91, 26);
  vertex(51, 27);
  vertex(26, 53);
  vertex(9, 80);
  vertex(22, 122);
  vertex(54, 144);
  vertex(95, 138);
  vertex(133, 143);
  vertex(152, 123);
  vertex(178, 109);
  vertex(156, 77);
  vertex(155, 48);
  vertex(116, 23);
  vertex(91, 26);
  endShape();

  fill(237, 212, 45);
  beginShape();
  vertex(69, 59);
  vertex(55, 69);
  vertex(47, 95);
  vertex(76, 121);
  vertex(126, 96);
  vertex(117, 70);
  vertex(82, 80);
  vertex(69, 59);
  endShape();

  fill(250, 184, 52);
  beginShape();
  vertex(70, 60);
  vertex(95, 55);
  vertex(116, 70);
  vertex(82, 80);
  vertex(69, 61);
  endShape();

  push();
  translate(88, 87);
  rotate(sunAngle);
  translate(-88, -87);
  sunAngle += 2;

  fill(250, 184, 52)


  beginShape();
  vertex(50, 112);
  vertex(60, 119);
  vertex(50, 124);
  vertex(37, 122);
  vertex(47, 113);
  vertex(49, 112);
  endShape();

  beginShape();
  vertex(43, 68);
  vertex(39, 84);
  vertex(24, 76);
  vertex(30, 69);
  vertex(43, 67);
  endShape();

  beginShape();
  vertex(71, 46);
  vertex(71, 29);
  vertex(78, 31);
  vertex(86, 43);
  vertex(71, 47);
  endShape();

  beginShape();
  vertex(115, 54);
  vertex(123, 59);
  vertex(131, 48);
  vertex(129, 39);
  vertex(115, 47);
  vertex(114, 55);
  endShape();

  beginShape();
  vertex(133, 81);
  vertex(134, 94);
  vertex(142, 98);
  vertex(151, 92);
  vertex(141, 74);
  vertex(134, 82);
  endShape();

  beginShape();
  vertex(119, 120);
  vertex(130, 115);
  vertex(134, 132);
  vertex(119, 122);
  endShape();

  beginShape();
  vertex(88, 131);
  vertex(97, 128);
  vertex(96, 144);
  vertex(86, 142);
  vertex(79, 136);
  vertex(89, 131);
  endShape();

  pop();
}

function drawTree1() {
  fill(179, 147, 75);
  beginShape();
  vertex(601, 647);
  vertex(647, 526);
  vertex(692, 491);
  vertex(689, 558);
  vertex(601, 648);
  endShape();

  fill(158, 128, 62);
  beginShape();
  vertex(601, 647);
  vertex(689, 558);
  vertex(708, 644);
  vertex(601, 647);
  endShape();

  fill(163, 139, 75);
  beginShape();
  vertex(648, 528);
  vertex(591, 428);
  vertex(691, 492);
  vertex(648, 528);
  endShape();

  fill(186, 159, 97);
  beginShape();
  vertex(591, 428);
  vertex(639, 323);
  vertex(638, 459);
  vertex(591, 429);
  endShape();

  fill(148, 124, 59);
  beginShape();
  vertex(603, 402);
  vertex(526, 288);
  vertex(628, 350);
  vertex(603, 402);
  endShape();

  beginShape();
  vertex(515, 293);
  vertex(552, 283);
  vertex(512, 236);
  vertex(515, 292);
  endShape();

}

function drawCoconuts() {
  fill(107, 86, 31)
  beginShape();
  vertex(438, 193);
  vertex(430, 197);
  vertex(430, 203);
  vertex(429, 210);
  vertex(446, 212);
  vertex(454, 202);
  vertex(449, 189);
  vertex(436, 193);
  endShape();

  beginShape();
  vertex(458, 208);
  vertex(448, 213);
  vertex(444, 220);
  vertex(452, 230);
  vertex(471, 231);
  vertex(477, 217);
  vertex(460, 205);
  vertex(457, 209);
  endShape();

  beginShape();
  vertex(461, 183);
  vertex(461, 191);
  vertex(467, 193);
  vertex(475, 190);
  vertex(474, 178);
  vertex(465, 178);
  vertex(461, 182);
  endShape();

  beginShape();
  vertex(562, 274);
  vertex(558, 278);
  vertex(559, 283);
  vertex(564, 284);
  vertex(571, 278);
  vertex(564, 274);
  endShape();

  beginShape();
  vertex(567, 254);
  vertex(560, 256);
  vertex(559, 263);
  vertex(562, 268);
  vertex(572, 268);
  vertex(577, 261);
  vertex(574, 255);
  vertex(567, 254);
  endShape();
}

function drawLeaves() {
  fill(34, 139, 34);
  beginShape();
  vertex(499, 232);
  vertex(443, 228);
  vertex(458, 234);
  vertex(378, 254);
  vertex(405, 252);
  vertex(347, 304);
  vertex(396, 275);
  vertex(335, 349);
  vertex(400, 289);
  vertex(398, 314);
  vertex(422, 280);
  vertex(424, 305);
  vertex(464, 260);
  vertex(482, 265);
  vertex(498, 233);
  endShape();

  beginShape();
  vertex(505, 237);
  vertex(510, 188);
  vertex(511, 205);
  vertex(577, 148);
  vertex(560, 187);
  vertex(623, 140);
  vertex(579, 192);
  vertex(598, 194);
  vertex(553, 223);
  vertex(563, 227);
  vertex(507, 235);
  endShape();

  fill(31, 122, 31)
  beginShape();
  vertex(506, 234);
  vertex(555, 212);
  vertex(542, 231);
  vertex(617, 230);
  vertex(590, 239);
  vertex(654, 256);
  vertex(592, 257);
  vertex(603, 271);
  vertex(550, 268);
  vertex(543, 280);
  vertex(521, 246);
  vertex(507, 254);
  vertex(507, 235);
  endShape();

  beginShape();
  vertex(494, 267);
  vertex(457, 289);
  vertex(493, 279);
  vertex(492, 267);
  endShape();

  beginShape();
  vertex(485, 211);
  vertex(475, 167);
  vertex(495, 201);

  endShape();

  beginShape();
  vertex(482, 215);
  vertex(472, 203);
  vertex(488, 207);
  vertex(482, 215);
  endShape();

  beginShape();
  vertex(498, 233);
  vertex(465, 261);
  vertex(482, 265);
  vertex(499, 231);
  endShape();

}

function drawShips(x, y, scaling = 1) {
  push();
  translate(x, y);
  scale(scaling);
  translate(-144, -430);

  fill(240, 240, 240);
  beginShape();
  vertex(140, 383);
  vertex(140, 423);
  vertex(121, 423);
  vertex(140, 384);
  endShape();

  fill(217, 215, 215);
  beginShape();
  vertex(147, 392);
  vertex(147, 422);
  vertex(163, 422);
  vertex(147, 393);
  endShape();

  fill(133, 108, 77);
  beginShape();
  vertex(114, 425);
  vertex(172, 425);
  vertex(155, 441);
  vertex(128, 441);
  vertex(115, 426);
  endShape();

  beginShape();
  vertex(142, 428);
  vertex(142, 370);
  vertex(145, 370);
  vertex(145, 428);
  vertex(142, 428);
  endShape();


  pop();
}

function drawShadow() {
  fill(145, 137, 67);
  beginShape();
  vertex(603, 647);
  vertex(705, 671);
  vertex(721, 691);
  vertex(775, 710);
  vertex(784, 697);
  vertex(785, 696);
  vertex(757, 664);
  vertex(719, 658);
  vertex(707, 644);
  vertex(601, 647);
  endShape();

  fill(163, 155, 85);
  beginShape();
  vertex(759, 672);
  vertex(799, 684);
  vertex(774, 692);
  vertex(761, 674);
  endShape();

  beginShape();
  vertex(782, 694);
  vertex(798, 753);
  vertex(738, 694);
  endShape();

  fill(171, 163, 99)
  beginShape();
  vertex(793, 750);
  vertex(776, 757);
  vertex(781, 786);
  vertex(794, 751);
  endShape();

  beginShape();
  vertex(762, 783);
  vertex(745, 755);
  vertex(636, 773);
  vertex(761, 783);
  endShape();

  beginShape();
  vertex(753, 771);
  vertex(767, 777);
  vertex(740, 796);
  vertex(750, 769);
  vertex(756, 772);
  endShape();

  beginShape();
  vertex(717, 783);
  vertex(730, 787);
  vertex(702, 800);
  vertex(717, 784);
  endShape();

  beginShape();
  vertex(755, 743);
  vertex(750, 747);
  vertex(754, 757);
  vertex(766, 761);
  vertex(769, 755);
  vertex(766, 744);
  vertex(753, 743);
  endShape();

  beginShape();
  vertex(737, 735);
  vertex(733, 736);
  vertex(733, 740);
  vertex(735, 743);
  vertex(739, 743);
  vertex(742, 740);
  vertex(741, 736);
  vertex(737, 734);
  endShape();

  beginShape();
  vertex(736, 766);
  vertex(753, 779);
  vertex(699, 800);
  vertex(735, 766);
  endShape();

  beginShape();
  vertex(690, 781);
  vertex(696, 786);
  vertex(667, 795);
  vertex(690, 781);
  endShape();

  beginShape();
  vertex(714, 747);
  vertex(696, 739);
  vertex(704, 747);
  vertex(713, 746);
  endShape();
}

function drawSeagulls() {
  fill("white");
  beginShape();
  vertex(623, 53);
  vertex(579, 35);
  vertex(550, 43);
  vertex(565, 40);
  vertex(597, 53);
  vertex(624, 55);
  vertex(659, 34);
  vertex(692, 40);
  vertex(678, 49);
  vertex(654, 40);
  vertex(631, 53);
  vertex(619, 57);
  endShape();

  beginShape();
  vertex(656, 70);
  vertex(667, 65);
  vertex(676, 70);
  vertex(685, 65);
  vertex(697, 71);
  vertex(692, 74);
  vertex(685, 70);
  vertex(674, 76);
  vertex(666, 69);
  vertex(656, 73);
  vertex(654, 70);
  endShape();

  fill(130, 129, 122);
  beginShape();
  vertex(665, 43);
  vertex(679, 37);
  vertex(692, 40);
  vertex(678, 51);
  vertex(664, 44);
  endShape();

  beginShape();
  vertex(580, 35);
  vertex(567, 42); 
  vertex(552, 42);
  vertex(577, 35);
  endShape();

  beginShape();
  vertex(689, 72);
  vertex(693, 69);
  vertex(697, 72);
  vertex(692, 75);
  vertex(689, 72);
  endShape();

  beginShape();
  vertex(659, 69);
  vertex(660, 73);
  vertex(654, 73);
  vertex(658, 69);
  endShape();
}

function drawClouds() {
  fill(250, 251, 252, 100);
  beginShape();
  vertex(342, 91);
  vertex(294, 111);
  vertex(208, 147);
  vertex(269, 204);
  vertex(381, 154);
  vertex(483, 136);
  vertex(459, 80);
  vertex(339, 92);
  endShape();

  beginShape();
  vertex(397, 61);
  vertex(361, 61);
  vertex(286, 70);
  vertex(251, 82);
  vertex(240, 139);
  vertex(329, 143);
  vertex(381, 90);
  vertex(397, 62);
  endShape();

  beginShape();
  vertex(247, 106);
  vertex(215, 107);
  vertex(157, 146);
  vertex(125, 152);
  vertex(137, 174);
  vertex(181, 180);
  vertex(239, 163);
  vertex(300, 172);
  vertex(355, 144);
  vertex(319, 116);
  vertex(247, 106);
  endShape();

  beginShape();
  vertex(721, 125);
  vertex(691, 116);
  vertex(632, 156);
  vertex(620, 184);
  vertex(731, 190);
  vertex(781, 168);
  vertex(765, 125);
  vertex(720, 126);
  endShape();

  fill(255, 255, 255, 150);
  beginShape();
  vertex(7, 257);
  vertex(33, 239);
  vertex(83, 243);
  vertex(114, 265);
  vertex(151, 264);
  vertex(167, 280);
  vertex(143, 298);
  vertex(78, 295);
  vertex(14, 295);
  vertex(4, 264);
  vertex(5, 256);
  endShape();

  beginShape();
  vertex(692, 153);
  vertex(657, 143);
  vertex(621, 164);
  vertex(604, 174);
  vertex(601, 191);
  vertex(652, 203);
  vertex(698, 189);
  vertex(731, 182);
  vertex(693, 153);
  endShape();


}



//function isoHorizTri(x,y,w,h) {

 // let bottomY = y+h
 // let rightX = x+w
// let rightY = y+h / 2
//triangle(x,y, x, bottomY, rightX,rightY)
  //  }