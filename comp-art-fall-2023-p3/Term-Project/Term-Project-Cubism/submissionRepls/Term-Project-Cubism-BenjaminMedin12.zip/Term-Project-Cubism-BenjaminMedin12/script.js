function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  drawS();
  
  
  
  


 
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('Darkorange'), color('Crimson'), "horizontal", 400); }// for details, see "gradient.js" file  


function drawS() {
	
	let startX = 100;
	let startY = 100;

	let xSpacing = 100;
	let ySpacing = 150;
	
	let numRows = 3;
	let numCols = 6;
	
	push(); // save the current transforms
	for (let y = 0; y < numRows; y++) { // outer for loop
		push(); // save the current transforms
		for (let x = 0; x < numCols; x++) { // inner for loop
			rect(startX, startY, 50, 50);
			translate(xSpacing, 0); // move over between each rectangle
		}
		pop(); // load the saved transforms
		translate(0, ySpacing); // move down between each row
	}
	pop(); // load the saved transforms
}

