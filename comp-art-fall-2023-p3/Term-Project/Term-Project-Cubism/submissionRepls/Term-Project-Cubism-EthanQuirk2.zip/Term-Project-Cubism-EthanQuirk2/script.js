function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  
  drawRoyalBlueTriangle()
  drawMaroonTriangle()
  drawForestGreenRectangle()
  drawDarkOrchidTriangle()
  drawCrimsonKite()
  drawTomatoNoNameShape()
  drawLightGrayRectangle()
  drawTurquoiseNoNameShape()
  drawBurlywoodTriangle()
  drawLightGreenNoNameShape()
  drawThistleRectangle()
  drawGoldRectangle()
  
   noFill()
    stroke("black")
  strokeWeight(4)
  circle(400, 125,50);
  drawLeftBody()
    drawRightBody()
  drawRightWing()
  drawLeftWing()
  
  drawMouseLines("black")
}
function drawLeftBody() {
  noFill()
  stroke("black")
  beginShape();
  curveVertex(400, 150); // control point
  curveVertex(400, 150);
  curveVertex(360, 240);
  curveVertex(350, 360);
  curveVertex(360, 440);
  curveVertex(400, 520);
  curveVertex(400, 520); // control point
  endShape();
}
function drawRightBody() {
  
  beginShape();
  curveVertex(405, 150); // control point
  curveVertex(405, 150);
  curveVertex(430, 220);
  curveVertex(440, 300);
  curveVertex(430, 400);
  curveVertex(400, 520);
  curveVertex(400, 520); // control point
  endShape();
}
function drawRightWing() {
  // fill("black");
  beginShape();
  curveVertex(430, 220); // control point
  curveVertex(430, 220);
  curveVertex(507, 138);
  curveVertex(592, 89);
  curveVertex(726, 131);
  curveVertex(722, 276);
  curveVertex(647, 315);
  curveVertex(568, 379);
  curveVertex(613, 486);
  curveVertex(648, 540);
  curveVertex(642, 615);
  curveVertex(539, 647);
  curveVertex(459, 591);
  curveVertex(419, 533);
  curveVertex(405, 501);
  curveVertex(405, 501); // control point
  endShape();
}
function drawLeftWing() {
  // fill("black");
  beginShape();
  curveVertex(366, 219); // control point
  curveVertex(366, 219);
  curveVertex(290, 140);
  curveVertex(207, 94);
  curveVertex(123, 94);
  curveVertex(71, 154);
  curveVertex(95, 246);
  curveVertex(169, 276);
  curveVertex(203, 325);
  curveVertex(204, 374);
  curveVertex(105, 456);
  curveVertex(80, 553);
  curveVertex(107, 631);
  curveVertex(219, 680);
  curveVertex(326, 605);
  curveVertex(389, 500);
  curveVertex(389, 500); // control point
  endShape();
}
function drawRoyalBlueTriangle() {
  noStroke()
   fill("RoyalBlue");
  beginShape();
  vertex(0, 0);
  vertex(148, 140);
  vertex(0, 439);
  vertex(0, 0);
  endShape();
}
function drawMaroonTriangle() {
   fill("Maroon");
  beginShape();
  vertex(148, 140);
  vertex(400, 0);
  vertex(0, 0);
  endShape();
}
function drawForestGreenRectangle() {
   fill("ForestGreen");
  beginShape();
  vertex(148, 140);
  vertex(95, 247);
  vertex(407, 316);
  vertex(420, 186);
  vertex(148, 140);
  endShape();
}
function drawDarkOrchidTriangle() {
   fill("DarkOrchid");
  beginShape();
  vertex(148, 140);
  vertex(400, 0);
  vertex(528, 206);
  vertex(148, 140);
  endShape();
}
function drawCrimsonKite() {
   fill("Crimson");
  beginShape();
  vertex(0, 439);
  vertex(95, 247);
  vertex(303, 293);
  vertex(256, 654);
  vertex(0, 439);
  endShape();
}
function drawTomatoNoNameShape() {
   fill("Tomato");
  beginShape();
  vertex(0, 439);
  vertex(0, 793);
  vertex(268, 793);
  vertex(256, 654);
  vertex(0, 435);
  endShape();
}
function drawLightGrayRectangle() {
   fill("LightGray");
  beginShape();
  vertex(407, 316);
  vertex(420, 187);
  vertex(805, 253);
  vertex(805, 406);
  vertex(407, 316);
  endShape();
}
function drawTurquoiseNoNameShape() {
   fill("Turquoise");
  beginShape();
  vertex(400, 0);
  vertex(805, 0);
  vertex(805, 255);
  vertex(528, 206);
  vertex(400, 0);
  endShape();
}
function drawBurlywoodTriangle() {
   fill("Burlywood");
  beginShape();
  vertex(256, 654);
  vertex(590, 357);
  vertex(303, 293);
  vertex(256, 655);
  endShape();
}
function drawLightGreenNoNameShape() {
   fill("LightGreen");
  beginShape();
  vertex(256, 655);
  vertex(805, 672);
  vertex(805, 405);
  vertex(589, 357);
  vertex(255, 655);
  endShape();
}
function drawThistleRectangle() {
  fill("Thistle");
  beginShape();
  vertex(256, 655);
  vertex(268, 793);
  vertex(562, 794);
  vertex(555, 663);
  vertex(256, 655);
  endShape();
}
function drawGoldRectangle() {
   fill("Gold");
  beginShape();
  vertex(555, 664);
  vertex(805, 672);
  vertex(804, 797);
  vertex(561, 794);
  vertex(555, 664);
  endShape();
}