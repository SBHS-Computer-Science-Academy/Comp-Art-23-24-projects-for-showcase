function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  background("darkolivegreen");
  rectGradient(0, 0, width, 200, "darkblue", "royalblue"); 
  drawstars()
}

function draw() {
  
  drawbackgroundmountains()
  drawcresentmoon()
  drawcitybackground()
  drawstreet()
  drawtree()
  drawleaves()
  drawline()
  drawtrunk()
  drawtreeleaves()
  drawlightpost()
  drawlight()
  drawtreetrunk()
  drawtreeleaves2()
  
  
  
  
  fill("black");

  drawMouseLines("black")
}
function drawbackgroundmountains() {
  fill("darkolivegreen");
  beginShape();
  vertex(2, 195);
  vertex(59, 176);
  vertex(96, 174);
  vertex(159, 176);
  vertex(187, 186);
  vertex(227, 177);
  vertex(259, 163);
  vertex(284, 158);
  vertex(360, 184);
  vertex(406, 200);
  vertex(444, 189);
  vertex(480, 175);
  vertex(534, 168);
  vertex(632, 186);
  vertex(780, 178);
  vertex(818, 160);
  vertex(884, 157);
  vertex(945, 171);
  vertex(1000, 203);
  vertex(1000, 337);
  vertex(3, 342);
  vertex(-3, 337);
  vertex(-3, 197);
  vertex(2, 195);
  endShape();
}
function drawcresentmoon() {
  fill(255, 217, 0);
  beginShape();
  vertex(85, 27);
  vertex(66, 27);
  vertex(51, 36);
  vertex(41, 47);
  vertex(42, 60);
  vertex(55, 72);
  vertex(78, 76);
  vertex(59, 52);
  vertex(67, 43);
  vertex(77, 38);
  vertex(89, 32);
  vertex(85, 28);
  endShape();
}
function drawcitybackground() {
  fill(97, 153, 205);
  beginShape();
  vertex(2, 293);
  vertex(30, 301);
  vertex(33, 257);
  vertex(78, 261);
  vertex(78, 292);
  vertex(98, 295);
  vertex(98, 279);
  vertex(132, 279);
  vertex(133, 294);
  vertex(151, 294);
  vertex(156, 254);
  vertex(196, 259);
  vertex(199, 321);
  vertex(226, 329);
  vertex(225, 280);
  vertex(263, 281);
  vertex(262, 317);
  vertex(289, 326);
  vertex(290, 292);
  vertex(319, 291);
  vertex(316, 323);
  vertex(342, 322);
  vertex(342, 262);
  vertex(376, 260);
  vertex(378, 311);
  vertex(403, 311);
  vertex(403, 277);
  vertex(434, 277);
  vertex(433, 322);
  vertex(440, 320);
  vertex(445, 255);
  vertex(473, 256);
  vertex(478, 318);
  vertex(489, 318);
  vertex(492, 276);
  vertex(543, 277);
  vertex(545, 317);
  vertex(583, 316);
  vertex(580, 268);
  vertex(628, 272);
  vertex(630, 314);
  vertex(646, 312);
  vertex(646, 247);
  vertex(685, 261);
  vertex(683, 327);
  vertex(710, 327);
  vertex(712, 278);
  vertex(744, 279);
  vertex(745, 331);
  vertex(812, 326);
  vertex(814, 278);
  vertex(865, 279);
  vertex(866, 323);
  vertex(878, 322);
  vertex(880, 295);
  vertex(934, 299);
  vertex(933, 322);
  vertex(957, 322);
  vertex(956, 273);
  vertex(1000, 276);
  vertex(999, 386);
  vertex(-1, 396);
  vertex(1, 292);
  endShape();
}
function drawstreet() {
  fill("gray");
  beginShape();
  vertex(192, 787);
  vertex(516, 391);
  vertex(520, 391);
  vertex(824, 791);
  vertex(834, 799);
  vertex(190, 800);
  vertex(182, 799);
  vertex(192, 787);
  endShape();
}
function drawtree() {
  fill(108, 70, 24);
  beginShape();
  vertex(131, 465);
  vertex(124, 412);
  vertex(112, 380);
  vertex(127, 382);
  vertex(140, 412);
  vertex(164, 405);
  vertex(171, 414);
  vertex(143, 430);
  vertex(155, 461);
  vertex(131, 465);
  vertex(124, 410);
  vertex(116, 390);
  endShape();
}
function drawleaves() {
  fill("darkgreen");
  beginShape();
  vertex(126, 423);
  vertex(77, 419);
  vertex(64, 364);
  vertex(92, 359);
  vertex(89, 340);
  vertex(146, 348);
  vertex(150, 369);
  vertex(175, 358);
  vertex(205, 366);
  vertex(199, 414);
  vertex(171, 414);
  endShape();
}
function drawline() {
  fill("black");
  beginShape();
  vertex(126, 423);
  vertex(168, 415);
  vertex(169, 415);
  endShape();
}
function drawtrunk() {
 fill(108, 70, 24);
  beginShape();
  vertex(235, 549);
  vertex(239, 488);
  vertex(226, 475);
  vertex(240, 468);
  vertex(256, 481);
  vertex(277, 467);
  vertex(293, 476);
  vertex(274, 492);
  vertex(271, 547);
  vertex(236, 548);
  endShape();
}
function drawtreeleaves() {
  fill("darkgreen");
  beginShape();
  vertex(274, 491);
  vertex(316, 497);
  vertex(342, 468);
  vertex(340, 386);
  vertex(277, 380);
  vertex(256, 397);
  vertex(250, 386);
  vertex(204, 413);
  vertex(193, 464);
  vertex(225, 495);
  vertex(238, 496);
  vertex(239, 489);
  vertex(228, 474);
  vertex(242, 468);
  vertex(255, 481);
  vertex(276, 467);
  vertex(294, 476);
  vertex(274, 492);
  endShape();
}
function drawlightpost() {
  fill(196, 196, 196);
  beginShape();
  vertex(824, 649);
  vertex(823, 393);
  vertex(701, 394);
  vertex(701, 421);
  vertex(793, 427);
  vertex(782, 647);
  vertex(825, 649);
  endShape();
}
function drawlight() {
  fill('gold');
  beginShape();
  vertex(712, 421);
  vertex(711, 402);
  vertex(763, 406);
  vertex(761, 424);
  vertex(712, 422);
  endShape();
}
function drawstars(){
fill('white')
noStroke()
 for(let i=0 ; i<=150 ; i++){
   
                        
  square(random(1000), random(170), 5)}
  stroke('black')
  

}
function drawtreetrunk() {
  fill(108, 70, 24);
  beginShape();
  vertex(399, 417);
  vertex(395, 392);
  vertex(369, 376);
  vertex(378, 368);
  vertex(399, 384);
  vertex(412, 368);
  vertex(421, 373);
  vertex(405, 389);
  vertex(407, 418);
  vertex(399, 416);
  endShape();
}
function drawtreeleaves2() {

  fill("darkgreen");
  beginShape();
  vertex(410, 383);
  vertex(437, 385);
  vertex(437, 348);
  vertex(400, 332);
  vertex(395, 351);
  vertex(371, 339);
  vertex(359, 382);
  vertex(394, 395);
  vertex(395, 392);
  vertex(369, 376);
  vertex(379, 368);
  vertex(399, 384);
  vertex(413, 368);
  vertex(421, 373);
  vertex(411, 383);
  endShape();
}









































































































































