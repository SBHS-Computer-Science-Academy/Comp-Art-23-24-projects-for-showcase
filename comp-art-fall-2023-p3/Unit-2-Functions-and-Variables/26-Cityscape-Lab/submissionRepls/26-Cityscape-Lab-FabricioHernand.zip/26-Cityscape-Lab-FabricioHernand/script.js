function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

6
  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {

  clear();
  background(32, 28, 53);
  noStroke();
  let numStars = 100;
  let starX = {}
  let starY = {}

  drawBuilding1()
  drawBuilding2()
  
  
  text("Create a cityscape using for loops and variables.", 500, 400)
  fill(161, 155, 145)
  ellipse(700, 100, 160, 160)
  fill(171, 165, 156)
  ellipse(700, 100, 140, 140)
  fill(189, 185, 178)
  ellipse(700, 100, 120, 120)
  fill(192, 188, 181)
  ellipse(700, 100, 100, 100)
  drawMouseLines("black");

 
   function drawBuilding2() {
     // fill("black");
     beginShape();
     vertex(112, 232);
     vertex(167, 231);
     vertex(168, 154);
     vertex(174, 147);
     vertex(185, 143);
     vertex(193, 144);
     vertex(189, 77);
     vertex(209, 76);
     vertex(207, 9);
     vertex(214, 4);
     vertex(221, 10);
     vertex(223, 75);
     vertex(245, 75);
     vertex(246, 140);
     vertex(261, 141);
     vertex(271, 146);
     vertex(274, 222);
     vertex(322, 220);
     vertex(337, 797);
     vertex(129, 796);
     vertex(124, 229);
     endShape();
   }
 



  
  function drawBuilding1() {
    fill("black");
    beginShape();
    vertex(2, 601);
    vertex(1, 195);
    vertex(42, 196);
    vertex(43, 139);
    vertex(32, 139);
    vertex(33, 134);
    vertex(54, 134);
    vertex(54, 75);
    vertex(60, 75);
    vertex(59, 133);
    vertex(82, 133);
    vertex(81, 141);
    vertex(62, 141);
    vertex(63, 198);
    vertex(123, 197);
    vertex(128, 799);
    vertex(1, 799);
    vertex(2, 198);
    endShape();
  }

}
