//global variables at top of code can be used anywhere 
//variables declared in a function are scoped to that function 
let numStars = 100
let starX = [];
let starY = [];
let starD = [];


function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  makeStars()
}

function draw() {
  clear();
  noStroke();
  background(19, 7, 54);
   let color1 = color(252, 3, 219, 150)
 let color2 = color(252, 252, 3)
  drawStars()
  circleGradient(width / 10, 300, 150, "grey", "silver"); // sun
  rectGradient(0, 400, width, 200, color(19, 7, 54), color1) 
  rectGradient(0, 600, width, 200, color1, color2); // sky with sunset
  
  
  drawBuildings();

// gradientHorizontal (color1, color2)


  drawMouseLines("green");
}

function gradientHorizontal (clrStart, clrEnd, steps = 100){
  let stepSize = height/steps;
  for (let i = 0; i<= height; i += stepSize) {
    fill(lerpColor(clrStart, clrEnd, i / height))
    rect(0,i, width, stepSize)
  }
}


function drawBuildings() {
  push();
  let numBuildings = 5;
  for (let i = 0; i < numBuildings; i += 1) {
    fill("silver");
    rect(80, 600, 100, 200);
    drawWindows(90, 620, 20, 30, 3, 5);
    translate(150, 0);
  }
  pop();
}

function drawWindows(x, y, size, spacing, numCols, numRows) {
  push();
  for (let i = 0; i < numCols; i += 1) {
    push();
    for (let i = 0; i < numRows; i += 1) {
      fill("yellow");
      square(x, y, size);
      translate(0, spacing);
    }
    pop();
    translate(spacing,0);
  }
  pop();
}




function makeStars() {
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width)); //push adds a new number to the end of the list
    starY.push(random(500));
    starD.push(random(3, 8)); //size of each star
  }
}

//call this in draw function to run every frame
function drawStars() {
  for (let i = 0; i < starX.length; i += 1) {

    fill("yellow");
    circle(starX[i], starY[i], starD[i]);
  }
}

function gradientHorizontal (clrStart, clrEnd, steps = 100){
  let stepSize = height/steps;
  for (let i = 0; i<= height; i += stepSize) {
    fill(lerpColor(clrStart, clrEnd, i / height))
    rect(0,i, width, stepSize)
  }
}