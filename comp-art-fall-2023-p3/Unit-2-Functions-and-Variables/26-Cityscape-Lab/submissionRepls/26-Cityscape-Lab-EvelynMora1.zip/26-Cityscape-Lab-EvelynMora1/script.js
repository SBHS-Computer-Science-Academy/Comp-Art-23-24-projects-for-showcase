function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("black");
  noStroke();

  let numStars = 100
  for (let i = 0; i < numStars; i += 1){

    fill("white");
    circle(random(width), random(height), 5)
           }

  drawMouseLines("black");
}


function drawStars(){
for (let i = 0; i < numStars; i += 1){

  fill("white");
  circle(starX[i], starY[i], starD[i]);
}

}

function makeStars(){
numStars = random(30, 200);
for (let i = 0; i < numStars i += 1){
starX.push(random(width));
starY.push(random(hieght));
starD.push(random(3,10));//size of each star 
}
  
}

