//global variables at the top of the code can be used anywhere
//variables declared in a function are scoped to that function
let numStars;
let starX = []
let starY = []
let starD = []

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  makeStars()
}

function draw() {
  clear();
  background("black");
  noStroke()
  //noLoop()
  drawBackgroundBuildings()

  drawStars()

  drawSkyScraper()

  drawBank()

  drawBuildings()

  drawOffices()

  drawAirplane()

  drawWings()

  drawMouseLines("white");


}

function drawBuildings() {
  push()
  let = numBuildings = 5;

  for (let i = 0; i < numBuildings; i += 1) {
    fill('grey')

    rect(80, 600, 100, 200)

    drawWindows(90, 620, 20, 30, 3, 5)

    translate(170, 0)
  }

  pop()

}

function drawWindows(x, y, size, spacing, numCols, numRows) {
  push()

  for (let i = 0; i < numCols; i += 1) {
    push()

    for (let i = 0; i < numRows; i += 1) {
      fill('yellow')
      square(x, y, size)
      translate(0, spacing)
    }
    pop()
    translate(spacing, 0)
  }
  pop()
}



function drawSkyScraper() {
  fill("silver");
  beginShape();
  vertex(138, 798);
  vertex(137, 424);
  vertex(299, 334);
  vertex(293, 800);
  vertex(140, 799);
  endShape();
}

function drawBank() {
  fill(145, 145, 142);
  beginShape();
  vertex(400, 800);
  vertex(400, 190);
  vertex(500, 190);
  vertex(500, 800);
  vertex(400, 800);
  endShape();

 drawWindows(410, 200, 20, 30, 3, 20)
}

function drawOffices() {
  fill(117, 115, 115);
  beginShape();
  vertex(280, 480);
  vertex(420, 480);
  vertex(420, 800);
  vertex(280, 800);
  vertex(280, 480);
  endShape();
   drawWindows(290, 500, 20, 35, 4, 8)
}





function makeStars() {
  numStars = random(30, 200);
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(height));
    starD.push(random(3, 10));
  }
}

function drawStars() {

  for (let i = 0; i < numStars; i += 1) {


    fill('white')
    circle(starX[i], starY[i], starD[i])
  }
}


function drawBackgroundBuildings() {
  fill(56, 52, 52);
  beginShape();
  vertex(-1, 574);
  vertex(96, 572);
  vertex(95, 494);
  vertex(167, 491);
  vertex(171, 562);
  vertex(165, 381);
  vertex(251, 377);
  vertex(257, 480);
  vertex(296, 481);
  vertex(296, 435);
  vertex(341, 434);
  vertex(345, 475);
  vertex(359, 473);
  vertex(351, 414);
  vertex(403, 408);
  vertex(401, 471);
  vertex(446, 469);
  vertex(448, 418);
  vertex(506, 417);
  vertex(507, 398);
  vertex(570, 376);
  vertex(567, 447);
  vertex(585, 446);
  vertex(583, 408);
  vertex(637, 407);
  vertex(633, 448);
  vertex(640, 533);
  vertex(677, 530);
  vertex(676, 493);
  vertex(724, 494);
  vertex(725, 542);
  vertex(760, 541);
  vertex(755, 456);
  vertex(800, 455);
  vertex(804, 535);
  vertex(840, 535);
  vertex(839, 491);
  vertex(925, 488);
  vertex(930, 573);
  vertex(971, 572);
  vertex(970, 608);
  vertex(998, 606);
  vertex(999, 789);
  vertex(999, 798);
  vertex(0, 799);
  vertex(2, 573);
  endShape();
}

function drawAirplane() {
  fill("white");
  beginShape();
  vertex(820, 138);
  vertex(775, 167);
  vertex(922, 161);
  vertex(979, 103);
  vertex(946, 108);
  vertex(924, 133);
  vertex(819, 137);
  endShape();
}

function drawWings() {
  fill("white");
  beginShape();
  vertex(832, 152);
  vertex(914, 196);
  vertex(877, 148);
  vertex(831, 151);
  endShape();
}