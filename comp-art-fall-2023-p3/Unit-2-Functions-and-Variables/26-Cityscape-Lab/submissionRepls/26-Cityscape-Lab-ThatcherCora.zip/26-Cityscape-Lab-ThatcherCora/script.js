
let numStars = 200;
let starX = [];
let starY = [];
let starD = [];
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  makeStars()
}

function draw() {
  clear();
  
  drawBackground()
  background("black");
  fill("white")
  drawStars()
  circle(700, 100, 100)
  drawtallbuilding()
  // text("Create a cityscape using for loops and variables.", 500, 400)
  drawbuildings();
  drawMouseLines("black");

}



function drawBackground() {

  rectGradient(0, 0, width, height, color('red'), color('black'), "horizontal", 400); 
  circleGradient(width / 2, 100, 150, "orange", "red"); // moon

}

function drawtallbuilding(){
push(); 
  let numBuildings = 9;
  for (let i = 0; i < numBuildings; i+=1) {
    fill("gray")
    rect(30,300,100,500);
    push();
    let numCols = 3;
    for (let i = 0; i < numCols; i += 1) {

      push();
      let numRows = 10;
      for (let i = 0; i < numRows; i += 1) {
        fill("yellow");
        square(44, 317, 15)
        translate(0, 40);
      }
      pop();
      translate(30, 0);
    }
    pop();

     translate(120,0);
    
}
  pop();
}
function drawbuildings() {
  push();
  let numBuildings = 8;

  for (let i = 0; i < numBuildings; i += 1) {
    fill("silver")
    rect(80, 600, 100, 200);



    push();
    let numCols = 3;
    for (let i = 0; i < numCols; i += 1) {

      push();
      let numRows = 4;
      for (let i = 0; i < numRows; i += 1) {
        fill("yellow");
        square(90, 620, 20)
        translate(0, 50);
      }
      pop();
      translate(30, 0);
    }
    pop();

    translate(150, 0);
  }
  pop();
}

function makeStars() {
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(height))// push adds new number to end
    starD.push(random(3, 10));
  }
}
function drawStars() {
  for (let i = 0; i < numStars; i += 1) {
    fill("white")
    circle(starX[i], starY[i], starD[i]);



  }

}


