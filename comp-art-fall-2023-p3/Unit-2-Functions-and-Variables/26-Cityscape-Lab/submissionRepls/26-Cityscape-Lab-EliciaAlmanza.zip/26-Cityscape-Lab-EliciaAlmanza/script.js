

let numStars;

let starX = [];
let starY = [];
let starD = [];

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  makeStars();
}

function draw() {
  clear();
  background("black");
  noStroke()  
  
  drawStars();

  

  drawBuildings();
  drawSkyscraper();
  drawBuildings();
  
  
  
  drawMouseLines("white");
}



function makeStars(){
  numStars = random(30,200);
  for (let i = 0; i < numStars; i+= 1){
    starX.push(random(width));
    starY.push(random(height));
    starD.push(random(3,10));
  }
}

function drawStars() {

  for (let i = 0; i < numStars; i += 1) {

    fill("white");
    circle(starX[i],starY[i], starD[i]);
  }
}

//function drawBuildings() {
  //fill("white");