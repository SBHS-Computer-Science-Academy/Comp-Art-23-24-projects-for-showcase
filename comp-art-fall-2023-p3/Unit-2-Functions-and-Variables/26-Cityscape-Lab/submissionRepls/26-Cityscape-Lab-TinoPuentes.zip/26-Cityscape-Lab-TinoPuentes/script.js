// global variables at top of code can be used anywhere
// variables declared in a function are scoped to that function
let numStars; // this is set using the random function in makeStars
// the brackets [] mean it's an array or list of things
let starX = [];
let starY = [];
let starD = [];

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  makeStars();
}

function draw() {
  clear();
  background("darkblue");
  noStroke();
  drawStars();
  drawmoon()
  drawcrater()
  drawcrater2()
  drawcrater3()
  drawBuildings();
  drawcitybackground()
  drawcloud()
  drawcloud2()





  drawMouseLines("black");
}

// call this in setup function to run once
function makeStars() {
  numStars = random(100, 550);
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width)); // push adds a new number to the end of the list
    starY.push(random(height));
    starD.push(random(3, 8));  //size of each star
  }
}

// call this in draw function to run every frame
function drawStars() {
  for (let i = 0; i < numStars; i += 1) {

    fill("white");
    circle(starX[i], starY[i], starD[i]);

  }
}
function drawmoon() {
  fill("lightgray");
  beginShape();
  vertex(155, 43);
  vertex(129, 45);
  vertex(105, 57);
  vertex(80, 70);
  vertex(63, 97);
  vertex(69, 132);
  vertex(87, 165);
  vertex(114, 174);
  vertex(159, 183);
  vertex(119, 138);
  vertex(117, 108);
  vertex(131, 87);
  vertex(143, 67);
  vertex(183, 51);
  vertex(154, 44);
  endShape();
}
function drawcrater() {
  fill("gray");
  beginShape();
  vertex(90, 85);
  vertex(82, 91);
  vertex(78, 97);
  vertex(77, 106);
  vertex(82, 111);
  vertex(87, 108);
  vertex(92, 101);
  vertex(96, 93);
  vertex(96, 85);
  vertex(89, 85);
  endShape();
}
function drawcrater2() {
  //fill("black");
  beginShape();
  vertex(103, 117);
  vertex(97, 127);
  vertex(99, 136);
  vertex(108, 147);
  vertex(112, 139);
  vertex(112, 122);
  vertex(102, 116);
  endShape();
}
function drawcrater3() {
  fill("gray");
  beginShape();
  vertex(123, 59);
  vertex(114, 62);
  vertex(106, 68);
  vertex(105, 75);
  vertex(111, 80);
  vertex(122, 80);
  vertex(127, 76);
  vertex(133, 66);
  vertex(125, 60);
  vertex(122, 59);
  endShape();
}


function drawBuildings() {
  push()
  let numBuildings = 6

  for (let i = 0; i < numBuildings; i += 1) {
    fill('gray')
    rect(80, 600, 100, 200); //building

    push();
    let numCols = 3;
    for (let i = 0;i <numCols; i += 1) {
      push(); let numRows = 5;
      for (let i = 0; i < numRows; i += 1) {
        fill('gold')
        square(90, 620, 20); //window
        translate(0, 30);
      }
      pop();

      translate(30, 0);
    }
    pop();

    translate(150, 0);
  }
  pop();
}
function drawcitybackground() {
  fill(75, 96, 146);
  beginShape();
  vertex(0, 478);
  vertex(23, 478);
  vertex(24, 431);
  vertex(47, 434);
  vertex(49, 478);
  vertex(59, 478);
  vertex(61, 454);
  vertex(95, 456);
  vertex(96, 482);
  vertex(114, 483);
  vertex(113, 406);
  vertex(156, 407);
  vertex(156, 486);
  vertex(165, 486);
  vertex(166, 440);
  vertex(213, 440);
  vertex(215, 494);
  vertex(227, 493);
  vertex(227, 402);
  vertex(248, 401);
  vertex(249, 481);
  vertex(259, 480);
  vertex(261, 439);
  vertex(307, 439);
  vertex(308, 485);
  vertex(316, 484);
  vertex(318, 453);
  vertex(353, 454);
  vertex(352, 488);
  vertex(362, 488);
  vertex(363, 423);
  vertex(398, 425);
  vertex(397, 490);
  vertex(407, 492);
  vertex(407, 446);
  vertex(452, 446);
  vertex(455, 491);
  vertex(473, 493);
  vertex(473, 402);
  vertex(509, 405);
  vertex(513, 490);
  vertex(530, 488);
  vertex(528, 434);
  vertex(550, 435);
  vertex(552, 493);
  vertex(581, 493);
  vertex(579, 415);
  vertex(616, 396);
  vertex(618, 488);
  vertex(634, 489);
  vertex(633, 419);
  vertex(663, 436);
  vertex(662, 502);
  vertex(676, 503);
  vertex(676, 457);
  vertex(710, 458);
  vertex(709, 504);
  vertex(719, 503);
  vertex(740, 504);
  vertex(742, 404);
  vertex(770, 404);
  vertex(769, 501);
  vertex(779, 502);
  vertex(779, 449);
  vertex(801, 449);
  vertex(804, 505);
  vertex(819, 507);
  vertex(818, 434);
  vertex(847, 434);
  vertex(845, 508);
  vertex(861, 505);
  vertex(861, 460);
  vertex(883, 461);
  vertex(883, 504);
  vertex(899, 505);
  vertex(899, 430);
  vertex(955, 431);
  vertex(956, 504);
  vertex(967, 505);
  vertex(968, 462);
  vertex(1000, 461);
  vertex(998, 797);
  vertex(931, 798);
  vertex(930, 600);
  vertex(829, 599);
  vertex(829, 798);
  vertex(780, 800);
  vertex(780, 598);
  vertex(678, 599);
  vertex(679, 799);
  vertex(630, 799);
  vertex(630, 600);
  vertex(530, 599);
  vertex(530, 799);
  vertex(480, 798);
  vertex(481, 600);
  vertex(379, 600);
  vertex(379, 796);
  vertex(379, 800);
  vertex(329, 798);
  vertex(331, 601);
  vertex(331, 599);
  vertex(229, 600);
  vertex(229, 800);
  vertex(179, 798);
  vertex(181, 602);
  vertex(181, 600);
  vertex(82, 600);
  vertex(80, 601);
  vertex(80, 798);
  vertex(1, 795);
  vertex(1, 479);
  endShape();
}
function drawcloud() {
  fill("lightgray");
  beginShape();
  vertex(322, 237);
  vertex(363, 241);
  vertex(400, 242);
  vertex(434, 240);
  vertex(437, 219);
  vertex(425, 198);
  vertex(414, 190);
  vertex(401, 197);
  vertex(388, 186);
  vertex(371, 183);
  vertex(357, 191);
  vertex(344, 205);
  vertex(332, 196);
  vertex(320, 201);
  vertex(311, 213);
  vertex(303, 232);
  vertex(326, 238);
  endShape();
}
function drawcloud2() {
  fill("lightgray");
  beginShape();
  vertex(610, 193);
  vertex(691, 197);
  vertex(825, 195);
  vertex(816, 166);
  vertex(804, 151);
  vertex(780, 148);
  vertex(769, 158);
  vertex(760, 143);
  vertex(743, 139);
  vertex(736, 141);
  vertex(719, 159);
  vertex(698, 141);
  vertex(688, 141);
  vertex(677, 147);
  vertex(672, 153);
  vertex(660, 139);
  vertex(648, 141);
  vertex(634, 149);
  vertex(626, 162);
  vertex(613, 152);
  vertex(594, 157);
  vertex(587, 164);
  vertex(572, 184);
  vertex(613, 194);
  endShape();
}




































