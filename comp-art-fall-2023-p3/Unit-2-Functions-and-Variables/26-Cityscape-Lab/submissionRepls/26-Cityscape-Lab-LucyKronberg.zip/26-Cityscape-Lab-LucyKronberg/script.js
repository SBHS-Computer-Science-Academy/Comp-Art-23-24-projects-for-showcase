
let starX = [];
let starY = [];
let starD = [];


function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  //makeStars()
}

function draw() {

  clear();
  rectGradient(0, 0, 800, 400, "indigo", "salmon");
  rectGradient(0, 400, 800, 400, "salmon", "orange");
  noStroke();
  noLoop();
  let numStars = 100;
  for (let i = 0; i < numStars; i += 1) {
    fill("white");
    circle(random(width), random(height), random(2,8));
  }

  


  drawCityClose();
  drawMoon();
  push()
for (let i = 0; i < 5; i += 1) { //streetlamps
  fill('yellow');
    circle(48,761,5);
  stroke('lightgray');
  strokeWeight(2);
    line(46,761,27,761);
  line(27,761,27,800);
  noStroke();
  fill(255,255,255,43);
  circle(48,761,20);
  translate(160,0)
  
  }
  pop()
  
  
  drawMouseLines("black");
}

function makeStars() {
  numStars = random(30, 200);
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(height));
    starD.push(random())
  }
}

function drawCityClose() {
  fill("black");
  beginShape();
  vertex(0, 493);
  vertex(148, 492);
  vertex(150, 800);
  vertex(1, 800);
  endShape();

  beginShape();
  vertex(148, 657);
  vertex(235, 657);
  vertex(236, 800);
  vertex(149, 800);
  endShape();

  beginShape();
  vertex(235, 690);
  vertex(296, 690);
  vertex(297, 800);
  vertex(236, 800);
  endShape();

  beginShape();
  vertex(296, 692);
  vertex(296, 431);
  vertex(387, 431);
  vertex(387, 800);
  vertex(296, 800);
  endShape();

  beginShape();
  vertex(386, 579);
  vertex(452, 579);
  vertex(452, 800);
  vertex(386, 800);
  endShape();

  beginShape();
  vertex(452, 669);
  vertex(493, 669);
  vertex(493, 800);
  vertex(452, 800);
  endShape();

  beginShape();
  vertex(493, 560);
  vertex(570, 560);
  vertex(570, 800);
  vertex(493, 800);
  endShape();

  beginShape();
  vertex(569, 715);
  vertex(621, 715);
  vertex(621, 800);
  vertex(569, 800);
  endShape();

  beginShape();
  vertex(621, 696);
  vertex(698, 696);
  vertex(698, 800);
  vertex(621, 800);
  endShape();

  beginShape();
  vertex(800, 573);
  vertex(697, 573);
  vertex(697, 800);
  vertex(800, 800);
  endShape();

  beginShape();
  vertex(322, 431);
  vertex(322, 380);
  vertex(364, 380);
  vertex(364, 433);
  endShape();

  beginShape();
  vertex(332, 381);
  vertex(332, 354);
  vertex(355, 354);
  vertex(355, 381);
  endShape();

  beginShape();
  vertex(567, 687);
  vertex(585, 687);
  vertex(585, 717);
  vertex(568, 718);
  endShape();

  beginShape();
  vertex(145, 618);
  vertex(183, 618);
  vertex(183, 659);
  vertex(147, 661);
  endShape();
}

function drawMoon() {
circleGradient(100,120,100,"white", "lightgray")
}
//text("Create a cityscape using for loops and variables.", 500, 400)

function drawStars() {
  for (let i = 0; i < numStars; i += 1) {

    fill('white');
    circle(starX[i], starY[i], starD[i]);
  }
}


