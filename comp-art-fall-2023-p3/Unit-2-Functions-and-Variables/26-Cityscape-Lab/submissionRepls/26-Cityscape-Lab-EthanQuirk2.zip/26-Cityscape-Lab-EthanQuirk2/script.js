function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
}

function draw() {
  
  clear();
  background("white");

  text("Create a cityscape using for loops and variables.", 500, 400)
  
  drawMouseLines("black");
}
let numStar;
let starX = []
let starY = []
let starS = []
let bcolor = ['silver', '#964B00']
let windowColors = ['yellow', 'black']
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  parameter()

}
function parameter() {
  numStar = random(200, 200)
  for (let v = 0; v <= numStar; v += 1) {
    starS.push(random(3, 10));
    starX.push(random(width));
    starY.push(random(height));
  }
}

function star() {
  noStroke()
  for (let v = 0; v < numStar; v += 1) {
    fill('white')
    circle(starX[v], starY[v], starS[v])
  }
}

function draw() {
  clear();
  background("black");

  star()
  drawRectangle();
  drawRectangle2()
  drawRectangle3()
  drawRectangle4()
  drawRectangle5()
  tower()
  drawMouseLines("white");


}
function drawRectangle() {
   fill("DarkOrchid");
  beginShape();
  vertex(-1, 557);
  vertex(121, 555);
  vertex(123, 799);
  vertex(122, 800);
  vertex(-1, 800);
  vertex(-1, 557);
  endShape();
}
function drawRectangle2() {
   fill("MediumOrchid");
  beginShape();
  vertex(120, 580);
  vertex(251, 580);
  vertex(255, 800);
  vertex(120, 800);
  vertex(120, 580);
  endShape();
}
function drawRectangle3() {
  // fill("black");
  beginShape();
  vertex(443, 543);
  vertex(449, 800);
  vertex(560, 800);
  vertex(560, 543);
  vertex(443, 543);
  endShape();
}
function drawRectangle4() {
   fill("DarkOrchid");
  beginShape();
  vertex(616, 580);
  vertex(751, 580);
  vertex(758, 798);
  vertex(758, 800);
  vertex(621, 800);
  vertex(616, 580);
  endShape();
}
function drawRectangle5() {
  // fill("black");
  beginShape();
  vertex(900, 516);
  vertex(906, 799);
  vertex(980, 799);
  vertex(977, 516);
  vertex(900, 516);
  endShape();
}
function tower() {
  push();
  let numbuild = 7;
  for (let i = 0; i < numbuild; i += 1) {
    fill('purple');
    rect(80, 600, 100, 200);
    push();
    let Ncol = 3;
    for (let i = 0; i < Ncol; i += 1) {
      push();
      let nRow = 5;
      for (let i = 0; i < nRow; i += 1) {
        fill('yellow')
        //fill('black')
        square(90, 620, 20)
        translate(0, 30)
      }
      pop();
      translate(30, 0)
    }
    pop();
    translate(150, 0)
  }
  pop();
}