let numStars
let starX = []
let starY = []
let starWidth = []

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  noLoop(); // runs slow without this, pc becomes unusable
  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  strokeWeight(0);
  makeStars()
}

function draw() {
  clear();
  background("black");
  circleGradient(width, 0, width * 1.75, color(0), color(100), 0, 1000)
  //circleGradient(width, 0, width * 0.75, color(60, 60, 0, 1.5), color(150, 150, 150, 0), 0, 500)

  drawStars()
  drawMoon()
  drawBuilding()
  rect(465, 465, 800, 800)
  drawGrads(4, 5, 20, 450, 75, 40, 90, 60)
  drawGrads(4, 3, 505, 520, 83.75, 50, 100, 80)

  drawMouseLines("black");
}

function makeStars() {
  numStars = random(45, 500)
  for (let i = 0; i < numStars; i++) {
    starX.push(random(width))
    starY.push(random(height))
    starWidth.push(random(1.5, 10))
  }
}

function drawMoon() {
  fill(200);
  circle(width - 30, 30, 140)
}

function drawBuilding() {
  fill(60);
  beginShape();
  vertex(1, 294);
  vertex(300, 372);
  vertex(300, height);
  vertex(0, height);
  endShape();
  fill(0)
  strokeWeight(3);
  line(0, 380, 270, 420)
  strokeWeight(2);
  line(270, 420, 270, height)
  strokeWeight(0);
  fill(80)
}

function drawStars() {
  for (let i = 0; i < numStars; i++) {
    rectGradient(starX[i], starY[i], starWidth[i], starWidth[i], color(0, 0, 0, 0), color(255, 255, 215, 255), "center", 8);
  }
}

function drawRows(nuero, startx, y, spacing, size, alpha, backg) {
  for (let i = 0; i < nuero; i++) {
      circleGradient(startx + spacing * i, y, size, color(backg, backg, backg, alpha), color(255, 255, 0, alpha))
    }
}

function drawGrads(rows, columns, startx, starty, spacing, size, alpha, backgroundColor) {
  for (let i = 0; i < columns; i++) {
    drawRows(rows, startx, starty + spacing * i, spacing, size, alpha, backgroundColor)
  }
}