let stars = [];
let buildings = [];

function setup() {
  createCanvas(1000, 800);

  // Create a random number of stars
  let numStars = 100;
  for (let i = 0; i < numStars; i++) {
    let x = random(width);
    let y = random(height);
    stars.push(createVector(x, y));
  }

  // Create buildings
  let numBuildings = 20;
  let buildingWidth = width / numBuildings;

  for (let i = 0; i < numBuildings; i++) {
    let x = i * buildingWidth;
    let buildingHeight = random(200, 600); // Adjusted for varying heights
    buildings.push(new Building(x, buildingHeight, buildingWidth));
  }
}

function draw() {
  background(0); // Set the background color to black

  // Draw the moon (crescent shape with gradient)
  noStroke();
  let moonColor1 = color(255, 255, 0); // Yellow
  let moonColor2 = color(255); // White
  gradientMoon(100, 100, 80, moonColor1, moonColor2);

  // Draw the buildings
  for (let i = 0; i < buildings.length; i++) {
    buildings[i].display();
  }

  fill(255); // Set the fill color to white for stars
  for (let i = 0; i < stars.length; i++) {
    ellipse(stars[i].x, stars[i].y, 5, 5); // Draw stars
  }
}

class Building {
  constructor(x, buildingHeight, width) {
    this.x = x;
    this.buildingHeight = buildingHeight;
    this.width = width;
  }

  display() {
    let buildingColor = color(random(50, 200), random(50, 200), random(50, 200));
    fill(buildingColor);
    rect(this.x, height - this.buildingHeight, this.width, this.buildingHeight);
    
    // Add windows
    let numWindows = int(this.buildingHeight / 20);
    let windowWidth = this.width / 4;
    let windowHeight = this.buildingHeight / numWindows;

    for (let i = 0; i < numWindows; i++) {
      for (let j = 0; j < 3; j++) {
        fill(255, 255, 0); // Yellow windows
        rect(this.x + j * windowWidth + 10, height - this.buildingHeight + i * windowHeight + 5, 10, 10);
      }
    }
  }
}

function gradientMoon(x, y, diameter, c1, c2) {
  let radius = diameter / 2;
  for (let r = radius; r > 0; r--) {
    let inter = map(r, 0, radius, 0, 1);
    let c = lerpColor(c1, c2, inter);
    fill(c);
    ellipse(x, y, r * 2, diameter);
  }
}

