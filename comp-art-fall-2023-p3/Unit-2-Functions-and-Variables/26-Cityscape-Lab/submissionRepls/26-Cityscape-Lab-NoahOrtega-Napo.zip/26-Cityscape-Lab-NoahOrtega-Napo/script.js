function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("navy");

  text("Create a cityscape using for loops and variables.", 500, 400)

  
  fill("black");
  beginShape();
  vertex(34, 794);
  vertex(31, 489);
  vertex(130, 490);
  vertex(138, 795);
  endShape();
  beginShape();
  vertex(195, 799);
  vertex(194, 348);
  vertex(306, 347);
  vertex(307, 800);
  endShape();
  beginShape();
  vertex(382, 799);
  vertex(376, 95);
  vertex(630, 94);
  vertex(644, 798);
  endShape();
  beginShape();
  vertex(42, 494);
  vertex(63, 434);
  vertex(110, 436);
  vertex(129, 495);
  endShape();
  beginShape();
  vertex(196, 352);
  vertex(196, 317);
  vertex(213, 321);
  vertex(213, 353);
  endShape();
  beginShape();
  vertex(208, 359);
  vertex(262, 323);
  vertex(304, 349);
  endShape();
  beginShape();
  vertex(694, 796);
  vertex(692, 684);
  vertex(747, 686);
  vertex(749, 794);
  endShape();
  beginShape();
  beginShape();
  vertex(783, 794);
  vertex(776, 591);
  vertex(837, 593);
  vertex(845, 796);
  endShape();
  beginShape();
  vertex(907, 798);
  vertex(899, 302);
  vertex(995, 305);
  vertex(995, 792);
  endShape();
  beginShape();
  vertex(899, 305);
  vertex(995, 236);
  vertex(995, 308);
  endShape();
  beginShape();
  vertex(900, 303);
  vertex(902, 245);
  vertex(922, 247);
  vertex(922, 296);
  endShape();
  beginShape();
  vertex(379, 102);
  vertex(495, 11);
  vertex(629, 94);
  endShape();
  beginShape();
  vertex(41, 278);
  vertex(59, 277);
  vertex(68, 285);
  vertex(85, 275);
  vertex(99, 276);
  endShape();
  beginShape();
  vertex(128, 227);
  vertex(151, 226);
  vertex(164, 235);
  vertex(174, 227);
  vertex(195, 226);
  endShape();
  beginShape();
  vertex(655, 224);
  vertex(672, 224);
  vertex(682, 235);
  vertex(690, 224);
  vertex(710, 222);
  endShape();
  beginShape();
  vertex(758, 236);
  vertex(779, 239);
  vertex(788, 254);
  vertex(797, 238);
  vertex(819, 239);
  endShape();

  
  fill("blue")
  beginShape();
  vertex(507, 112);
  vertex(407, 303);
  vertex(441, 303);
  vertex(475, 229);
  vertex(519, 229);
  vertex(550, 294);
  vertex(585, 294);
  vertex(508, 111);
  endShape();
fill("black")
  beginShape();
  vertex(481, 211);
  vertex(515, 212);
  vertex(498, 180);
  vertex(479, 214);
  endShape();
 circleGradient(100, 100, 200, "white", "DimGray"); 
   DrawWindows(51, 523, 20, 27, 3, 8)
DrawWindows(213, 381, 20, 27, 3,  12)
DrawWindows(396, 321, 20, 27, 9, 14)
DrawWindows(702, 704, 20, 27, 2, 14)
DrawWindows(787, 617, 20, 27, 2, 8)
DrawWindows(912, 318, 20, 27 , 3, 16)
drawMouseLines("black");
}

function DrawWindows(x, y, size, spacing, numCols, numRows) {
  push();

  for (let i = 0; i < numCols; i += 1) {

    push();

    for (let i = 0; i < numRows; i += 1) {
      fill("yellow");
      square(x, y, size);
      translate(0, spacing);

    }
  pop();
  translate(spacing, 0);
 }
pop();
}

