

let numStars;

let starX = [];
let starY = [];
let starD = [];

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  makeStars();
}

function draw() {
  clear();
  background("black");
  noStroke();
  
  drawWindows();
  drawStars();

  bigBuilding();
  drawSkyscraper(); 
  drawbuildings();
  
  
  drawMouseLines("white")
}



function drawbuildings(){
  push();
  let numBuildings = 6;

  for (let i = 0; i < numBuildings; i += 1){
    fill ("silver")
    rect(80,600,100,200)

    drawWindows(90,620,20,30,3,5)

    translate(150,0)
    }
    pop();
    
  }
 
function drawWindows(x,y,size,spacing, numCols, numRows) {
  push();

  for (let i = 0; i < numCols; i += 1){

    push();

     for (let i = 0; i < numRows; i += 1){
        fill("yellow");
      square(x,y,size);
      translate(0,spacing);
     }
    pop();
    translate(spacing, 0);
  }
pop();
}
  
  
  function makeStars() {
  numStars = random(30,200);
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(height));
    starD.push(random(3, 10));
  }
}


  function drawStars() {
  for (let i = 0; i < numStars; i += 1) {
    
  fill ("white")
  circle(starX[i], starY[i], starD[i]);

  }
}

function bigBuilding(){
  fill("gray");
  beginShape();
  vertex(158, 800);
  vertex(160, 528);
  vertex(263, 368);
  vertex(375, 521);
  vertex(376, 800);
  vertex(154, 800);
  endShape();

  drawWindows(172,540,15,22,9,10)
}

function drawSkyscraper(){
  fill("gray")
  rect(500,200,100,600)
  drawWindows(507,210,10,15,6,37)
  fill("DarkGray")
  circle(60,60,200)
  fill("lightgray")
  circle(31,38,50)
  circle(120,70,50)
  circle(49, 104,50)
  fill("Gainsboro")
  ellipse(402, 64,400,120)
   ellipse(599, 67,400,120)
  ellipse(209, 190,400,120)
  ellipse(302, 125,400,120)
   ellipse(803, 135,400,120)
   ellipse(892, 64,400,120)
  ellipse(534, 175,400,120)
}

