

let numStar;
let starX = []
let starY = []
let starS = []
let bcolor = ['silver', '#964B00']
let windowColors = ['yellow', 'black']
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  parameter()

}
function parameter() {
  numStar = random(300, 400)
  for (let v = 0; v <= numStar; v += 1) {
    starS.push(random(3, 10));
    starX.push(random(width));
    starY.push(random(height));
  }
}

function star() {
  noStroke()
  for (let v = 0; v < numStar; v += 1) {
    fill('white')
    circle(starX[v], starY[v], starS[v])
  }
}

function draw() {
  clear();
  background("black");

  star()
  tower()
  drawMouseLines("purple");


}

function tower() {
  push();
  let numbuild = 7;
  for (let i = 0; i < numbuild; i += 1) {
    fill('silver');
    rect(80, 600, 100, 200);
    push();
    let Ncol = 3;
    for (let i = 0; i < Ncol; i += 1) {
      push();
      let nRow = 5;
      for (let i = 0; i < nRow; i += 1) {
        fill('yellow')
        //fill('black')
        square(90, 620, 20)
        translate(0, 30)
      }
      pop();
      translate(30, 0)
    }
    pop();
    translate(150, 0)
  }
  pop();
}

