// global variables at top of code can be used anywhere
// variables declared in a function are scoped to that function
let numStars; // this is set using the random function in makeStars
// the brackets [] mean it's an array or list of things
let starX = [];
let starY = [];
let starD = [];

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  createConsole("Lines");
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  makeStars();
}
function draw() {
  clear();
  background("black");
  noStroke();
  drawStars();
  airplanes()
  circleGradient(width / 10,  89, 180, "white", "grey"); // sun
fill("grey")
  circle(130, 69,50)
  fill("darkGrey")
    circle(71, 136,30)
  beginShape();
  curveVertex(56, 36); // control point
  curveVertex(56, 36);
  curveVertex(37, 46);
  curveVertex(30, 59);
  curveVertex(44, 61);
  curveVertex(70, 51);
  curveVertex(79, 31);
  curveVertex(53, 37);
  curveVertex(53, 37); // control point
  endShape();
 
  
 drawBackBuildings();
  drawBuildings();
  
 
  drawMouseLines("green");
}
function drawBuildings() {
  push(); // save the current coordinate system
  let numBuildings = 7;
  for (let i = 0; i < numBuildings; i += 1) {
    fill("silver");
    rect(80, 600, 100, 200); // building


   DrawWindows(90, 620, 20, 30, 3, 5)


    translate(150, 0); // move over between each butlding
  }
  
  pop(); // get the coordinate system back
}

// call this in setup function to run once
function makeStars() {

  numStars = random(30, 200);

  for (let i = 0; i < numStars; i += 1) {

    starX.push(random(width)); // push adds a new number to the end of the list

    starY.push(random(height));

    starD.push(random(3, 10)); //size of each star

  }
}
// call this in draw function to run every frame
function drawStars() {

  for (let i = 0; i < numStars; i += 1) {

    fill("white");
    circle(starX[i], starY[i], starD[i]);
  }
}
function drawBackBuildings(){
  push(); // save the current coordinate system
  let numBuildings = 7;
  for (let i = 0; i < numBuildings; i += 1) {
      fill("grey");
  beginShape();
  vertex(132, 800);
  vertex(131, 616);
  vertex(68, 521);
  vertex(13, 613);
  vertex(14, 800);
  endShape();
  


DrawWindows(24, 622,15,30,3,5);
   



    translate(150, 0); // move over between each butlding
  }
  
  pop(); // get the coordinate system back
}
function DrawWindows(x,y,size,spacing,numCols,numRows){
 push(); // save where each building is
   
    for (let i = 0; i < numCols; i += 1) {
      push(); // save where each column is
      
      for (let i = 0; i < numRows; i += 1) {
        fill("yellow")
        square(x, y, size); // window
        translate(0, spacing); // move over between each row
      }
      pop(); // go back to start of column

      translate(spacing, 0); // move over between each column
    }
    pop(); // go back to start of building
}
function airplanes(){
fill("egg");
beginShape();
curveVertex(346, 177); // control point
curveVertex(346, 177);
curveVertex(321, 187);
curveVertex(415, 191);
curveVertex(490, 193);
curveVertex(492, 152);
curveVertex(470, 174);
curveVertex(364, 172);
curveVertex(341, 178);
curveVertex(341, 178); // control point
endShape();
  beginShape();
  curveVertex(377, 182); // control point
  curveVertex(377, 182);
  curveVertex(430, 207);
  curveVertex(418, 183);
  curveVertex(378, 181);
  curveVertex(378, 181); // control point
  endShape();

   beginShape();
  curveVertex(475, 188); // control point
  curveVertex(475, 188);
  curveVertex(500, 205);
  curveVertex(486, 184);
  curveVertex(486, 184); // control point
  endShape();
  fill("lightBlue");
  rect(359, 177, 5, 5, 60);
    rect(377, 178, 5, 5, 60);
    rect(398, 179, 5, 5, 60);
    rect(419, 180, 5, 5, 60);
    rect(438, 180, 5, 5, 60);
     rect(455, 181, 5, 5, 60);
     rect(478, 182, 5, 5, 60);
}