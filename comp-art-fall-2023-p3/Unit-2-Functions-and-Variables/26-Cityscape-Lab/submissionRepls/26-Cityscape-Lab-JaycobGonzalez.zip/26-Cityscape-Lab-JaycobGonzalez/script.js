function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("black");

  drawShape()
  drawShape2()
  drawShape3()
  
  
  
  
  drawMouseLines("white");
  
  
}




function drawShape() {
   fill("silver");
  beginShape();
  vertex(229, 800);
  vertex(233, 605);
  vertex(321, 604);
  vertex(319, 800);
  endShape();
}
function drawShape2() {
   fill("silver");
  beginShape();
  vertex(65, 800);
  vertex(70, 600);
  vertex(155,600);
  vertex(151, 800);
  endShape();
}

function drawShape3() {
   fill("silver");
  beginShape();
  vertex(412, 800);
  vertex(408, 425);
  vertex(525, 425);
  vertex(530, 800);
  vertex(413, 800);
  endShape();
}


