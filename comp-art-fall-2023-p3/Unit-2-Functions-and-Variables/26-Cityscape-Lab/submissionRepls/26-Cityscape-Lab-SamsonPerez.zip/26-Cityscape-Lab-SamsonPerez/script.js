function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("black");
drawShape()
drawShape2()   
drawShape3()
drawShape4() 
  

  text("Create a cityscape using for loops and variables.", 500, 400)
  
  drawMouseLines("yellow");                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
}
function drawShape() {
   fill("grey");
  beginShape();
  vertex(27, 796);
  vertex(36, 362);
  vertex(166, 365);
  vertex(159, 798);
  vertex(24, 799);
  endShape();
}

function drawShape2() {
  // fill("grey");
  beginShape();
  vertex(193, 798);
  vertex(196, 213);
  vertex(213, 185);
  vertex(229, 185);
  vertex(243, 152);
  vertex(254, 180);
  vertex(268, 181);
  vertex(282, 208);
  vertex(287, 794);
  endShape();
}

function drawShape3() {
  // fill("grey");
  beginShape();
  vertex(316, 796);
  vertex(313, 502);
  vertex(366, 501);
  vertex(372, 475);
  vertex(396, 500);
  vertex(402, 789);
  endShape();
}
function drawShape4() {
  // fill("grey");
  beginShape();
  vertex(436, 799);
  vertex(434, 278);
  vertex(451, 279);
  vertex(451, 262);
  vertex(464, 262);
  vertex(499, 263);
  vertex(499, 275);
  vertex(520, 276);
  vertex(522, 793);
  endShape();
}







