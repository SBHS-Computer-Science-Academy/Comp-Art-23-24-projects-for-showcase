

function setup() {
  let myCanvas = createCanvas(750, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("midnightblue");
drawlightning()
drawbuilding1()
drawbuilding2()
drawbuilding3()
drawbuilding4()
drawbuilding5()
drawbuilding6()
drawShape()

  
  drawMouseLines("black");
}
function drawWindows(x,y,size,spacing,numCols,numRows) {
push();

for(let i = 0; i < numCols; i += 1) {  

  push();

for(let i = 0; i < numRows; i += 1) {  

fill("")
square(x,y,size);
translate(0, size + spacing);
}
pop();
  translate(size + spacing,0);
}
  pop();
}
function drawlightning() {
   fill("yellow");
  beginShape();
  vertex(80, 2);
  vertex(36, 94);
  vertex(98, 96);
  vertex(31, 265);
  vertex(144, 68);
  vertex(89, 68);
  vertex(120, 1);
  vertex(81, 1);
  endShape();
   beginShape();
  vertex(113, 124);
  vertex(220, 124);
  vertex(174, 222);
  vertex(243, 222);
  vertex(176, 422);
  vertex(191, 255);
  vertex(101, 257);
  vertex(149, 168);
  vertex(87, 169);
  vertex(112, 123);
  endShape();
   beginShape();
  vertex(523, 3);
  vertex(599, 77);
  vertex(485, 79);
  vertex(581, 183);
  vertex(534, 101);
  vertex(669, 100);
  vertex(574, 0);
  vertex(521, 0);
  endShape();
  beginShape();
  vertex(602, 101);
  vertex(604, 197);
  vertex(549, 334);
  vertex(593, 305);
  vertex(551, 490);
  vertex(627, 277);
  vertex(583, 295);
  vertex(634, 188);
  vertex(632, 100);
  vertex(603, 100);
  endShape();
}
function drawbuilding1() {
   fill("black");
  beginShape();
  vertex(0, 484);
  vertex(98, 484);
  vertex(100, 800);
  endShape();
   beginShape();
  vertex(1, 487);
  vertex(2, 799);
  vertex(100, 798);
  endShape();
  drawWindows(9,505,5,19,4,11)
}
function drawbuilding2() {
   fill("black");
  beginShape();
  vertex(99, 754);
  vertex(131, 754);
  vertex(127, 372);
  vertex(140, 372);
  vertex(135, 359);
  vertex(146, 359);
  vertex(138, 333);
  vertex(192, 333);
  vertex(185, 359);
  vertex(195, 359);
  vertex(190, 374);
  vertex(203, 373);
  vertex(207, 800);
  vertex(101, 800);
  vertex(100, 755);
  endShape();
  drawWindows(139, 392,5,19,3,16)
}
  function drawbuilding3() {
   fill("black");
  beginShape();
  vertex(207, 756);
  vertex(225, 756);
  vertex(223, 639);
  vertex(299, 638);
  vertex(300, 799);
  vertex(207, 799);
  vertex(207, 758);
  endShape();
    drawWindows(236, 655,5,19,3,5)
}
function drawbuilding4() {
   fill("black");
  beginShape();
  vertex(301, 758);
  vertex(310, 758);
  vertex(302, 264);
  vertex(316, 264);
  vertex(316, 249);
  vertex(329, 249);
  vertex(329, 234);
  vertex(341, 234);
  vertex(349, 214);
  vertex(359, 214);
  vertex(367, 234);
  vertex(381, 234);
  vertex(381, 250);
  vertex(395, 250);
  vertex(395, 265);
  vertex(409, 265);
  vertex(412, 799);
  vertex(300, 799);
  vertex(300, 759);
  endShape();
  drawWindows(321, 295,5,19,4,20)
}
function drawbuilding5() {
   fill("black");
  beginShape();
  vertex(413, 760);
  vertex(463, 760);
  vertex(463, 550);
  vertex(601, 549);
  vertex(604, 799);
  vertex(412, 798);
  vertex(413, 762);
  endShape();
  drawWindows(481, 573,5,19,5,8)
  
  
}
function drawbuilding6() {
   fill("black");
  beginShape();
  vertex(604, 761);
  vertex(630, 762);
  vertex(628, 410);
  vertex(633, 404);
  vertex(630, 395);
  vertex(652, 395);
  vertex(648, 404);
  vertex(652, 409);
  vertex(663, 409);
  vertex(663, 404);
  vertex(673, 404);
  vertex(673, 395);
  vertex(683, 395);
  vertex(691, 386);
  vertex(699, 386);
  vertex(707, 395);
  vertex(719, 395);
  vertex(719, 405);
  vertex(729, 405);
  vertex(729, 412);
  vertex(735, 412);
  vertex(741, 798);
  vertex(604, 799);
  vertex(604, 761);
  vertex(641, 761);
  vertex(630, 678);
  endShape();
  beginShape();
  vertex(635, 678);
  vertex(593, 679);
  vertex(591, 764);
  vertex(646, 768);
  vertex(642, 680);
  endShape();
   drawWindows(648, 440,5,19,4,14)
}
function drawShape() {
   fill("black");
  beginShape();
  vertex(741, 767);
  vertex(764, 767);
  vertex(764, 609);
  vertex(800, 610);
  vertex(800, 799);
  vertex(741, 800);
  vertex(740, 768);
  endShape();
}
function drawShape() {
   fill("lightblue");
  beginShape();
  vertex(360, 47);
  vertex(390, 59);
  vertex(394, 65);
  vertex(399, 76);
  vertex(399, 80);
  vertex(399, 83);
  vertex(399, 88);
  vertex(398, 92);
  vertex(396, 97);
  vertex(394, 101);
  vertex(391, 104);
  vertex(383, 109);
  vertex(367, 120);
  vertex(386, 97);
  vertex(365, 108);
  vertex(378, 91);
  vertex(370, 96);
  vertex(377, 88);
  vertex(352, 80);
  vertex(371, 77);
  vertex(361, 75);
  vertex(372, 68);
  vertex(336, 64);
  vertex(366, 63);
  vertex(347, 60);
  vertex(369, 57);
  vertex(326, 48);
  vertex(363, 48);
  endShape();
   fill("red");
  beginShape();
  vertex(367, 69);
  vertex(337, 69);
  vertex(337, 75);
  vertex(366, 73);
  vertex(371, 69);
  vertex(296, 68);
  vertex(265, 73);
  vertex(266, 78);
  vertex(298, 75);
  vertex(302, 82);
  vertex(303, 87);
  vertex(286, 85);
  vertex(285, 92);
  vertex(291, 92);
  vertex(293, 91);
  vertex(313, 92);
  vertex(311, 77);
  vertex(338, 76);
  endShape();
   beginShape();
  vertex(333, 77);
  vertex(316, 81);
  vertex(317, 86);
  vertex(338, 79);
  vertex(336, 76);
  vertex(331, 78);
  endShape();
    fill("yellow");
  beginShape();
  vertex(332, 69);
  vertex(305, 63);
  vertex(301, 65);
  vertex(296, 66);
  vertex(283, 64);
  vertex(261, 49);
  vertex(254, 47);
  vertex(260, 51);
  vertex(255, 55);
  vertex(261, 57);
  vertex(257, 59);
  vertex(265, 59);
  vertex(260, 62);
  vertex(266, 64);
  vertex(263, 66);
  vertex(272, 67);
  vertex(302, 69);
  vertex(336, 69);
  endShape();
  fill("blue");
  beginShape();
  vertex(265, 75);
  vertex(257, 84);
  vertex(257, 86);
  vertex(258, 86);
  vertex(261, 83);
  vertex(268, 79);
  vertex(266, 74);
  endShape();
   beginShape();
  vertex(286, 87);
  vertex(278, 96);
  vertex(280, 98);
  vertex(282, 97);
  vertex(289, 91);
  vertex(287, 86);
  endShape();
  fill("salmon")
  circle(336, 69,15)
}


