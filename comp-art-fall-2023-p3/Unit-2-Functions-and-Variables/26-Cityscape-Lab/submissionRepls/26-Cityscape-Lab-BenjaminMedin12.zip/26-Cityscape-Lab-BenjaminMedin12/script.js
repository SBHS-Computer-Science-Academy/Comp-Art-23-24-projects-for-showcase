//global variables at top of code can be used anywhere
//variables declared in a function are scoped to that function
let numStars;// this is set using the random function in makeStars
// the brackets[] mean its an array or list of things
let starX = [];
let starY = [];
let starD = [];

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  makeStars()
}

function draw() {
  clear();
  background("MidnightBlue");
  noStroke();
  drawMoon();
  drawMountain();
  drawSnow();
  drawMoresnow();
  drawStars();



  drawBigbuilding();
  drawSkyscraper();
  drawBuildings();

  drawMouseLines("green")
}
function drawBuildings() {
  push();//save the current coordinate system
  let numBuildings = 5;

  for (let i = 0; i < numBuildings; i += 1) {
    fill("grey");
    rect(80, 600, 100, 300);//building

    drawWindows(90, 620, 20, 30, 3, 5);

    translate(150, 0);//move over each building
  }
  pop();//get the coordinate system back

}

function drawWindows(x, y, size, spacing, numCols, numRows) {
  push();//save where each building is

  for (let i = 0; i < numCols; i += 1) {

    push();// save where each column is

    for (let i = 0; i < numRows; i += 1) {
      fill("Deepskyblue");
      square(x, y, size);//window
      translate(0, spacing);//move down between each row
    }
    pop();// go back to start of column
    translate(spacing, 0);//move over between each column
  }
  pop();//go back to start of building
}

//call this in setup function to run once
function makeStars() {
  numStars = random(1000, 2000);
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(height));
    starD.push(random(3, 10));
  }
}
function drawMountain() {
  fill("lightgrey")
  beginShape();
  vertex(998, 620);
  vertex(879, 414);
  vertex(840, 508);
  vertex(817, 458);
  vertex(771, 531);
  vertex(631, 800);
  vertex(999, 799);
  endShape();

}
function drawSnow() {
  fill("white")
  beginShape();
  vertex(785, 510);
  vertex(806, 494);
  vertex(821, 511);
  vertex(834, 496);
  vertex(818, 459);
  vertex(785, 511);
  endShape();
}
function drawMoresnow() {
  fill("white")
  beginShape();
  vertex(851, 483);
  vertex(865, 474);
  vertex(870, 484);
  vertex(889, 492);
  vertex(891, 463);
  vertex(916, 496);
  vertex(913, 472);
  vertex(877, 415);
  vertex(851, 485);
  endShape();
}
//call this in draw function to run every frame
function drawStars() {
  for (let i = 0; i < numStars; i += 1) {

    fill("white");
    circle(starX[i], starY[i], starD[i]);

  }
}


function drawBigbuilding() {
  fill("white")
  beginShape();
  vertex(158, 800);
  vertex(160, 528);
  vertex(263, 368);
  vertex(375, 521);
  vertex(376, 800);
  vertex(154, 800);
  endShape();

  drawWindows(172, 540, 15, 22, 9, 10);
}

function drawSkyscraper() {
  fill("Lightgrey")
  rect(500, 200, 100, 600)
  drawWindows(507, 210, 10, 15, 6, 37)
}
function drawMoon() {
  circle(955,47,60)
}