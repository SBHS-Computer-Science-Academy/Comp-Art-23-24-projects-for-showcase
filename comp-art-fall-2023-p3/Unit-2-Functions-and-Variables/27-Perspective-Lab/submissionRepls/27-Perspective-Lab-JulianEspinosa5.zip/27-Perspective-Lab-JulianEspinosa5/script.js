function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  drawtracks()
  
 
  drawgrass()
  drawSky()
  drawrocks()
  drawpoles()
  drawtracks()
  drawStreet()
  drawhouse()
  drawlane()

  
 
  drawMouseLines("black");
}


function drawgrass() {
   fill("green");
  beginShape();
  vertex(0, 351);
  vertex(1, 800);
  vertex(998, 799);
  vertex(998, 350);
  vertex(0, 350);
  endShape();
}
function drawSky() {
   fill("skyblue");
  beginShape();
  vertex(0, 350);
  vertex(1, -1);
  vertex(999, 1);
  vertex(999, 350);
  vertex(-1, 350);
  endShape();
}


function drawrocks() {
   fill("slategrey");
  beginShape();
  vertex(498, 359);
  vertex(353, 800);
  vertex(632, 798);
  vertex(502, 360);
  vertex(498, 360);
  endShape();
}

function drawtracks() {
   fill("sienna");
  beginShape();
  vertex(354, 799);
  vertex(308, 799);
  vertex(497, 356);
  vertex(353, 800);
  endShape();
  beginShape();
  vertex(633, 798);
  vertex(685, 799);
  vertex(502, 357);
  vertex(633, 797);
  endShape();
  beginShape();
  vertex(314, 750);
  vertex(680, 753);
  vertex(660, 709);
  vertex(334, 708);
  vertex(315, 749);
  endShape();
  beginShape();
  vertex(374, 616);
  vertex(363, 645);
  vertex(630, 645);
  vertex(616, 612);
  vertex(377, 611);
  vertex(364, 644);
  endShape();
  beginShape();
  vertex(414, 531);
  vertex(405, 553);
  vertex(592, 553);
  vertex(580, 527);
  vertex(417, 526);
  vertex(405, 551);
  endShape();
  beginShape();
  vertex(447, 461);
  vertex(440, 475);
  vertex(557, 476);
  vertex(549, 456);
  vertex(446, 456);
  vertex(440, 474);
  endShape();
  beginShape();
  vertex(476, 396);
  vertex(470, 410);
  vertex(528, 410);
  vertex(521, 395);
  vertex(476, 396);
  endShape();
  beginShape();
  vertex(491, 367);
  vertex(488, 373);
  vertex(512, 373);
  vertex(508, 366);
  vertex(491, 366);
  endShape();
  beginShape();
  vertex(496, 359);
  vertex(504, 359);
  vertex(503, 357);
  vertex(496, 357);
  vertex(495, 359);
  endShape();
}

function drawpoles(){
let scaling = 1; // original pole size
for (let i = 0; i < 10; i += 1) {
  let x = map(scaling, 0, 1, 500, 144);
  let y = map(scaling, 0, 1, 350, 588); 
  drawpole(x, y, scaling);
  scaling *= 0.7; // halve the scaling
}
}
function drawpole(x, y, scaling = 1) {

push();
translate(x, y); // move to point (x,y)
scale(scaling); // scale makes it bigger or smaller
translate(-144, -588); // negative of the bottom left (x,y)


   fill("silver");
  beginShape();
  vertex(91, 268);
  vertex(147, 280);
  vertex(144, 588);
  vertex(90, 588);
  vertex(92, 269);
  endShape();
  pop()
}
function drawStreet() {
   fill("yellow");
  beginShape();
  vertex(800, 799);
  vertex(999, 800);
  vertex(999, 682);
  vertex(502, 351);
  vertex(801, 800);
  endShape();
}
function drawhouse() {
   fill("burlywood");
   beginShape();
   beginShape();
  vertex(712, 310);
  vertex(841, 308);
  vertex(842, 493);
  vertex(709, 489);
  vertex(712, 310);
  vertex(589, 332);
  vertex(585, 407);
  vertex(711, 490);
  endShape();
  beginShape();
  vertex(712, 311);
  vertex(780, 234);
  vertex(841, 308);
  vertex(713, 310);
  vertex(588, 334);
  vertex(612, 304);
  vertex(780, 234);
  endShape();
  beginShape();
  vertex(711, 365);
  vertex(711, 490);
  vertex(709, 490);
  vertex(711, 409);
  endShape();
  fill("brown");
  beginShape();
  vertex(745, 490);
  vertex(747, 366);
  vertex(805, 367);
  vertex(805, 491);
  vertex(747, 490);
  endShape();
}
function drawlane() {
   fill("grey");
  beginShape();
  vertex(507, 355);
  vertex(585, 385);
  vertex(585, 406);
  vertex(506, 355);
  endShape();
  beginShape();
  vertex(710, 490);
  vertex(844, 492);
  vertex(998, 556);
  vertex(998, 681);
  vertex(712, 491);
  endShape();
}







