function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();

  drawBackground();
  drawLHDDpe()
  // step one: determine where the horizon is
  //line(0, 250, width, 250); // horizon

  // step two: draw a bunch of lines to make a vanishing point
  //drawVanishingLines(270, 250, 32);

  // step three: draw something at different sizes to make it get smaller
  drawBuilding(543, 522); // first building
  drawBuilding(410, 389, 0.5); // second building
  
  drawBuilding(763, 743, 1.8);
  drawBuilding(348, 321, 0.28);
  drawBuilding(165, 522,0.8); // first building
  drawBuilding(210, 375, 0.4); // second building

  drawBuilding(130, 743, 1.2);
  drawBuilding(230, 300, 0.23);
  drawShape()
  drawVhape()
  drawDe()
  drawWhite()
  drawThape()
  drawLape()
drawDone()
  drawBBSSS()
  drawBIGlinbpe()
  drawHAHAHHAHAHAe()
  drawKKSSSape()
  drawHelp()
  drawScooter()
    drawTbars()
  drawWheel()
  drawPerson()
  drawMouth()
  //text("Use a vanishing point and functions with parameters to create the illusion of depth.", 500, 400)

  drawMouseLines("green");
  

}
function drawBackground() {

  rectGradient(0, 0, width, height, color('red'), color('black'), "horizontal", 400); // for details, see "gradient.js" file
circleGradient(width / 2, 100, 150, "orange", "red"); // moon

}
function drawSNhsff() {
   fill("black");
  beginShape();
  vertex(1, 4);
  vertex(5, 253);
  vertex(999, 239);
  vertex(999, 1);
  vertex(0, 3);
  vertex(5, 253);
  endShape();
}
function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}
function drawLHDDpe() {
  fill("black");
  beginShape();
  vertex(3, 248);
  vertex(721, 243);
  vertex(998, 353);
  vertex(998, 797);
  vertex(2, 799);
  vertex(1, 249);
  endShape();
}


function drawBuilding(x, y, scaling = 1) {

  push();
  translate(x, y); // move to point (x,y)
  scale(scaling); // scale makes it bigger or smaller
  translate(-543, -522); // negative of the bottom left (x,y)

  // put whatever code for the shape you want to draw here
  fill("silver");
  strokeWeight(2);
  beginShape();
  vertex(543, 522);
  vertex(537, 359);
  vertex(627, 399);
  vertex(626, 601);
  vertex(543, 522);
  endShape();

  beginShape();
  vertex(626, 601);
  vertex(719, 552);
  vertex(710, 380);
  vertex(628, 400);
  endShape();

  beginShape();
  vertex(538, 358);
  vertex(615, 335);
  vertex(710, 380);
  vertex(629, 399);
  endShape();
  pop();
  
}


function drawShape() {
  fill("gray");
  beginShape();
  vertex(381, 800);
  vertex(270, 250);
  vertex(787, 800);
  endShape();
}
function drawVhape() {
  fill("gray");
  beginShape();
  vertex(536, 799);
  vertex(272, 256);
  vertex(277, 258);
  vertex(624, 799);
  vertex(536, 800);
  endShape();
}

function drawDe() {
  fill("white");
  beginShape();
  vertex(500, 726);
  vertex(574, 723);
  vertex(586, 741);
  vertex(511, 747);
  vertex(501, 728);
  endShape();
}

function drawWhite() {
  fill("white");
  noStroke()
  beginShape();
  vertex(474, 670);
  vertex(536, 664);
  vertex(548, 682);
  vertex(484, 691);
  vertex(475, 671);
  vertex(450, 620);
  vertex(504, 613);
  vertex(515, 630);
  vertex(456, 636);
  vertex(450, 621);
  vertex(428, 577);
  vertex(477, 570);
  vertex(486, 585);
  vertex(436, 593);
  vertex(429, 576);
  vertex(411, 540);
  vertex(453, 535);
  vertex(464, 551);
  vertex(418, 555);
  vertex(394, 504);
  vertex(433, 501);
  vertex(444, 520);
  vertex(402, 522);
  vertex(376, 467);
  vertex(408, 464);
  vertex(417, 479);
  vertex(382, 483);
  vertex(354, 426);
  vertex(381, 423);
  vertex(392, 438);
  vertex(361, 441);
  vertex(330, 375);
  vertex(348, 372);
  vertex(362, 390);
  vertex(337, 391);
  vertex(308, 331);
  vertex(324, 331);
  vertex(334, 347);
  vertex(317, 349);
  vertex(308, 328);
  vertex(288, 286);
  vertex(295, 286);
  vertex(303, 299);
  vertex(295, 301);
  vertex(287, 288);
  endShape();
}
function drawThape() {
  fill("white");
  beginShape();
  vertex(297, 309);
  vertex(309, 308);
  vertex(315, 322);
  vertex(306, 326);
  vertex(299, 310);
  endShape();
}

function drawLape() {
 fill("black");
  beginShape();
  vertex(2, 248);
  vertex(724, 243);
  endShape();
}
function drawDone() {
   fill("black");
  beginShape();
  curveVertex(280, 207); // control point
  curveVertex(280, 207);
  curveVertex(281, 229);
  curveVertex(269, 243);
  curveVertex(282, 229);
  curveVertex(293, 247);
  curveVertex(282, 231);
  curveVertex(280, 206);
  curveVertex(288, 206);
  curveVertex(286, 185);
  curveVertex(266, 187);
  curveVertex(268, 199);
  curveVertex(281, 205);
  curveVertex(281, 205); // control point
  endShape();
}





function drawBBSSS() {
  fill("black");
  beginShape();
  vertex(725, 244);
  vertex(999, 353);
  endShape();
}
function drawBIGlinbpe() {
  
   fill("gray");
  beginShape();
  vertex(475, 670);
  vertex(271, 254);
  endShape();
}
function drawHAHAHHAHAHAe() {
  fill("gray");
  beginShape();
  vertex(475, 671);
  vertex(275, 263);
  endShape();
}
function drawKKSSSape() {
fill("gray");
  beginShape();
  vertex(475, 671);
  vertex(284, 280);
  vertex(472, 667);
  vertex(303, 319);
  vertex(283, 280);
  vertex(296, 308);
  vertex(313, 343);
  vertex(362, 440);
  vertex(376, 472);
  vertex(464, 649);
  vertex(488, 698);
  vertex(489, 696);
  vertex(464, 648);
  vertex(484, 690);
  vertex(484, 689);
  vertex(475, 673);
  vertex(487, 692);
  vertex(484, 690);
  vertex(463, 644);
  vertex(486, 691);
  vertex(344, 402);
  vertex(363, 444);
  vertex(350, 417);
  vertex(366, 450);
  endShape();
}


function drawHelp() {
   fill("gray");
  beginShape();
  vertex(476, 671);
  vertex(280, 268);
  vertex(277, 269);
  vertex(478, 700);
  vertex(488, 698);
  vertex(466, 647);
  endShape();
}

function drawScooter() {
   fill("black");
  beginShape();
  vertex(341, 396);
  vertex(326, 360);
  vertex(338, 358);
  vertex(351, 392);
  vertex(346, 394);
  vertex(343, 388);
  vertex(341, 389);
  vertex(344, 396);
  vertex(340, 397);
  endShape();
}

function drawTbars() {
   fill("green");
  beginShape();
  vertex(332, 361);
  vertex(320, 305);
  vertex(287, 310);
  vertex(288, 314);
  vertex(347, 305);
  vertex(345, 301);
  vertex(314, 306);
  endShape();
}

function drawWheel() {
   fill("blue");
  beginShape();
  curveVertex(340, 389); // control point
  curveVertex(340, 389);
  curveVertex(343, 387);
  curveVertex(347, 395);
  curveVertex(342, 396);
  curveVertex(340, 391);
  curveVertex(340, 391); // control point
  endShape();
}

function drawPerson() {
  fill("green");
  beginShape();
  vertex(339, 382);
  vertex(345, 347);
  vertex(336, 368);
  vertex(345, 348);
  vertex(346, 311);
  vertex(355, 308);
  vertex(354, 288);
  vertex(331, 291);
  vertex(336, 309);
  vertex(336, 312);
  vertex(347, 310);
  vertex(348, 326);
  vertex(292, 313);
  vertex(346, 325);
  vertex(343, 307);
  endShape();
}

function drawMouth() {
   fill("black");
  beginShape();
  vertex(339, 304);
  vertex(350, 302);
  endShape();
}