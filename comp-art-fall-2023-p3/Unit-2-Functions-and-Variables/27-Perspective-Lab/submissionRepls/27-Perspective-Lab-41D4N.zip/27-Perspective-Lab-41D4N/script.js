function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");

  text("Use a vanishing point and functions with parameters to create the illusion of depth.", 500, 400)
  
  drawMouseLines("black");
}