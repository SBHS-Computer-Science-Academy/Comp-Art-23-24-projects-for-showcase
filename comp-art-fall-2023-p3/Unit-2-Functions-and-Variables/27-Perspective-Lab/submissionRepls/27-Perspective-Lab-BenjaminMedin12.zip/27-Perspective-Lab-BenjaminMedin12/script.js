function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("green");


  line(0, 250, width, 250); // horizon
  drawVanishingLines(504,250, 32)
  

  drawMouseLines("black");
  //drawSky();
}

function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(-180 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}
