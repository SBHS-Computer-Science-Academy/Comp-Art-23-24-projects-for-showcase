function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("skyblue");

  
  line(0,408,width,408)//horizon
  
 
  drawVanishingLines(400,409,32);
  
  
// drawBuilding(543,522);
  drawBuilding(469,478,0.28)
  //drawBuilding(334,325,0.5)
  //drawBuilding(763,743,1.8)
  
  // drawBuilding(770,744)
  
 
 
 
  //drawBuilding(196, 312)
  drawBuilding(349,481,0.28)
  //drawBuilding(191,386,0.5)
  //drawBuilding(165,754,1.08)
  
  drawBuilding()
  
  
  
  
  drawMouseLines("black");
}

function drawBuilding(x,y, scaling = 1){
  
  push();
  translate(x,y);
  scale(scaling);
  translate(-763, -743)
  

  fill("tan");
  beginShape()
  vertex(766, 743);
  vertex(766, 623);
  vertex(816, 603);
  vertex(858, 633);
  vertex(859, 747);
  vertex(767, 744);
  endShape();

  fill("sienna");
  rect(800,711, 20, 35);

  pop()

 

  




  
}

function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}
