function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  drawGround();
  
  line(0, 250, width, 250); 
  drawTrees();
  

  
  drawMouseLines("black");
  rectGradient(0, 0, width, 250, "blue", "darkBlue");

  fill("yellow")
  circle(90, 64,50)
  
  function drawGround() {
     fill("darkGreen");
    beginShape();
    vertex(0, 250);
    vertex(999, 250);
    vertex(999, 799);
    vertex(0, 798);
    vertex(0, 796);
    vertex(0, 250);
    endShape();
  }

}
function drawVanishingLines(x, y, numLines = 8) {
  push(); 
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}

function drawTrees() {
  drawTree(644, 623);
  drawTree(458, 438, 0.5); 
  drawTree(362, 342, 0.25);
  drawTree(316, 297, 0.125);
}
function drawTree(x, y, scaling = 1) {

  push();
  translate(x, y); 
  scale(scaling);
  translate(-644, -623); 


   fill("brown");
  beginShape();
  vertex(732, 707);
  vertex(769, 706);
  vertex(766, 505);
  vertex(731, 505);
  vertex(732, 707);
  endShape();
  fill("green")
  beginShape();
  curveVertex(731, 505); 
  curveVertex(731, 505);
  curveVertex(705, 488);
  curveVertex(711, 463);
  curveVertex(727, 463);
  curveVertex(730, 430);
  curveVertex(752, 441);
  curveVertex(770, 422);
  curveVertex(788, 442);
  curveVertex(820, 439);
  curveVertex(807, 471);
  curveVertex(815, 491);
  curveVertex(796, 510);
  curveVertex(779, 496);
  curveVertex(766, 506);
  curveVertex(766, 506); 
  endShape();
  beginShape()
    vertex(623, 702);
    vertex(630, 691);
    vertex(633, 702);
    vertex(643, 692);
    vertex(647, 702);
    vertex(661, 691);
    vertex(667, 703);
    vertex(671, 691);
    vertex(678, 699);
    vertex(686, 693);
    vertex(689, 705);
    vertex(701, 694);
    vertex(708, 708);
    vertex(720, 694);
    vertex(724, 707);
    vertex(729, 704);
    vertex(734, 713);
    vertex(618, 714);
    vertex(618, 685);
    vertex(623, 702);
    endShape();
  beginShape();
  vertex(775, 712);
  vertex(779, 692);
  vertex(787, 704);
  vertex(794, 693);
  vertex(801, 706);
  vertex(808, 691);
  vertex(814, 703);
  vertex(824, 687);
  vertex(824, 702);
  vertex(837, 686);
  vertex(843, 699);
  vertex(850, 690);
  vertex(854, 713);
  vertex(775, 712);
  endShape();
  
  pop();
}

