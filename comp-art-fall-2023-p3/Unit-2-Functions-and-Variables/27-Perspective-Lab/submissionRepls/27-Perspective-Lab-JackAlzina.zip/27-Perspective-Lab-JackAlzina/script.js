function setup() {
  let myCanvas = createCanvas(1000, 750);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  rectGradient(0, 0, width, height, color('lightGreen'), color('Green'), "horizontal", 375);
  fill("DarkGray");
  triangle(272, 251,2, 796,593, 794)
   rectGradient(0, 0, width, 250, "LightBlue", "SteelBlue"); // sky with sunset

  circleGradient(width / 10,  59, 180, "yellow", "orange"); // sun

  // step one: determine where the horizon is
  
  fill("SaddleBrown");

  line(270, 250,242, 800);
  line(277, 247,352, 800);
  // step two: draw a bunch of lines to make a vanishing point


  // step three: draw something at different sizes to make it get smaller
  drawBuilding(543, 522); // first building
  drawBuilding(410, 389, 0.5); // second building
  drawBuilding(346, 325, 0.28);
  drawBuilding(763, 743, 1.8);
drawrailroad()
 drawpowerlines()
  drawMouseLines("black");
  drawBuildings()

}

function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}

function drawBuilding(x, y, scaling = 1) {

  push();
  translate(x, y); // move to point (x,y)
  scale(scaling); // scale makes it bigger or smaller
  translate(-543, -522); // negative of the bottom left (x,y)

  // put whatever code for the shape you want to draw here
  fill("silver");
  strokeWeight(2);
  beginShape();
  vertex(543, 522);
  vertex(537, 359);
  vertex(627, 399);
  vertex(626, 601);
  vertex(543, 522);
  endShape();

    beginShape();
  vertex(626, 601);
  vertex(719, 552);
  vertex(710, 380);
  vertex(628, 400);
  endShape();

    beginShape();
  vertex(538, 358);
  vertex(615, 335);
  vertex(710, 380);
  vertex(629, 399);
  endShape();
  pop();
}
function  drawrailroad(){
  let x = 270
  push()
  translate(x, 715)

 for (let i = 0; i < 30; i += 1) {
  rect(-50,-10, 150, 20)
   translate(0, -40)
   scale(0.922)
 }
  pop()
}
function  drawpowerlines(){




}
function drawBuildings() {

  push(); // save the current coordinate system
  let numBuildings = 7;
  for (let i = 0; i < numBuildings; i += 1) {
    fill("silver");
    rect(34, 161, 50, 90); // building
    fill("black");
triangle(84, 162,59, 138,34, 163)

   DrawWindows(36, 165, 10, 15, 3, 5)


    translate(150, 0); // move over between each butlding
  }

  pop(); // get the coordinate system back
}

// call this in setup function to run once
function makeStars() {

  numStars = random(30, 200);

  for (let i = 0; i < numStars; i += 1) {

    starX.push(random(width)); // push adds a new number to the end of the list

    starY.push(random(height));

    starD.push(random(3, 10)); //size of each star

  }
}
// call this in draw function to run every frame
function drawStars() {

  for (let i = 0; i < numStars; i += 1) {

    fill("white");
    circle(starX[i], starY[i], starD[i]);
  }
}
function drawBackBuildings(){
  push(); // save the current coordinate system
  let numBuildings = 7;
  for (let i = 0; i < numBuildings; i += 1) {

    fill("grey");
  beginShape();
  vertex(132, 800);
  vertex(131, 616);
  vertex(68, 521);
  vertex(13, 613);
  vertex(14, 800);
  endShape();








    translate(150, 0); // move over between each butlding
  }

  pop(); // get the coordinate system back
}
function DrawWindows(x,y,size,spacing,numCols,numRows){
 push(); // save where each building is

    for (let i = 0; i < numCols; i += 1) {
      push(); // save where each column is

      for (let i = 0; i < numRows; i += 1) {
        fill("yellow")
        square(x, y, size); // window
        translate(0, spacing); // move over between each row
      }
      pop(); // go back to start of column

      translate(spacing, 0); // move over between each column
    }
    pop(); // go back to start of building
}