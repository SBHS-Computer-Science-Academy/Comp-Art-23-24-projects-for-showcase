function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}
function draw() {
  drawBackground();
  drawSun();
  drawGrass();
  drawMouseLines();
  drawRightTrees();
  drawTree(0,800);
  drawTree(81, 753, 0.9);
  drawTree(163, 705, 0.8);
  drawTree(229, 664, 0.7);
  drawTree(291, 628, 0.6);
  drawTree(341, 599, 0.5);
  drawTree(386, 572, 0.4);
  drawPath();
}

function drawBackground() {
  rectGradient(0, 0, width, height, color('purple'), color('orange'), "horizontal", 400);
}
function drawSun() {
   circleGradient(width / 2.3, 540, 200, "orangeRed", "yellow"); // sun
}
function drawGrass() {
  fill(29, 173, 39);
  rect(0,536,1000,2000);
}
  function drawTree(x, y, scaling = 1) {
    push()
    translate(x, y)
    scale(scaling)
    translate(-816, -798)
  fill("saddleBrown");
  beginShape();
  vertex(815, 727);
  vertex(816, 798);
  vertex(844, 798);
  vertex(843, 728);
  vertex(815, 728);
  endShape();
  fill('lightgreen');
     beginShape();
  curveVertex(815, 729); // control point
  curveVertex(815, 729);
  curveVertex(807, 730);
  curveVertex(795, 728);
  curveVertex(791, 723);
  curveVertex(793, 718);
  curveVertex(798, 715);
  curveVertex(802, 715);
  curveVertex(802, 714);
  curveVertex(797, 712);
  curveVertex(795, 710);
  curveVertex(795, 704);
  curveVertex(794, 701);
  curveVertex(798, 698);
  curveVertex(806, 700);
  curveVertex(808, 703);
  curveVertex(809, 707);
  curveVertex(810, 704);
  curveVertex(810, 701);
  curveVertex(810, 695);
  curveVertex(811, 691);
  curveVertex(819, 690);
  curveVertex(821, 692);
  curveVertex(822, 695);
  curveVertex(823, 699);
  curveVertex(823, 701);
  curveVertex(823, 700);
  curveVertex(828, 695);
  curveVertex(832, 692);
  curveVertex(835, 691);
  curveVertex(837, 691);
  curveVertex(839, 693);
  curveVertex(840, 696);
  curveVertex(838, 701);
  curveVertex(838, 703);
  curveVertex(838, 704);
  curveVertex(841, 700);
  curveVertex(845, 698);
  curveVertex(849, 697);
  curveVertex(850, 697);
  curveVertex(854, 701);
  curveVertex(852, 706);
  curveVertex(850, 707);
  curveVertex(848, 709);
  curveVertex(848, 709);
  curveVertex(856, 707);
  curveVertex(856, 707);
  curveVertex(856, 707);
  curveVertex(858, 709);
  curveVertex(862, 712);
  curveVertex(861, 715);
  curveVertex(858, 718);
  curveVertex(855, 719);
  curveVertex(849, 717);
  curveVertex(857, 720);
  curveVertex(857, 722);
  curveVertex(856, 724);
  curveVertex(855, 728);
  curveVertex(852, 729);
  curveVertex(848, 729);
  curveVertex(844, 729);
  curveVertex(842, 728);
  curveVertex(817, 729);
  curveVertex(817, 729); // control point
  endShape();
    pop()
}

function drawRightTrees() {
for (let i = 0; i < 7; i += 1) {
  let x = map(i, 0, 7, 818, 445)
  let y = map(i, 0, 7, 800, 535)
  let scaling = map(i, 0, 7, 1, 0.3)
   drawTree(x, y, scaling);

}
}
function drawPath() {
  fill("yellow");
  beginShape();
  vertex(31, 799);
  vertex(438, 536);
  vertex(819, 799);
  vertex(33, 799);
  endShape();
}