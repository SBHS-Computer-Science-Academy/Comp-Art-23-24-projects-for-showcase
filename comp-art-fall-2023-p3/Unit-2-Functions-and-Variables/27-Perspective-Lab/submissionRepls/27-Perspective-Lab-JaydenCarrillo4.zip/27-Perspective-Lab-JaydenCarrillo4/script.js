function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");

  // step one: determine where the horizon is
  line(0, 250, width, 250); // horizon

  // step two: draw a bunch of lines to make a vanishing point
  drawVanishingLines(270, 250, 4);

  // step three: draw something at different sizes to make it get smaller
  drawBuildings();


  drawMouseLines("black");
}

function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}

function drawBuildings() {
  drawBuilding(644, 623);
  drawBuilding(458, 438, 0.5); 
  drawBuilding(362, 342, 0.25);
  drawBuilding(316, 297, 0.125);


  // ... or use a for loop and the map function to automate:
  // let numBuildings = 7;
  // let scaling = 1; // original building size
  // for (let i = 0; i < numBuildings; i += 1) {
  //   let x = map(scaling, 0, 1, 270, 644);
  //   let y = map(scaling, 0, 1, 250, 623); 
  //   drawBuilding(x, y, scaling);
  //   scaling *= 1/2; // halve the scaling
  // }

}

function drawBuilding(x, y, scaling = 1) {

  push();
  translate(x, y); // move to point (x,y)
  scale(scaling); // scale makes it bigger or smaller
  translate(-644, -623); // negative of the bottom left (x,y)

  // put whatever code for the shape you want to draw here
  fill("silver");
  strokeWeight(2);
  beginShape();
  vertex(644, 623);
  vertex(783, 763);
  vertex(923, 687);
  vertex(923, 381);
  vertex(772, 318);
  vertex(644, 344);
  vertex(644, 623);
  endShape();
  line(783, 763,783, 414);
  line(644, 344, 783, 414);
  line(923, 381, 783, 414);
  pop();
   fill("black")
    beginShape();
    vertex(270, 250);
    vertex(804, 785);
    vertex(270, 249);
    vertex(498, 800);
    vertex(803, 786);
    endShape();
}