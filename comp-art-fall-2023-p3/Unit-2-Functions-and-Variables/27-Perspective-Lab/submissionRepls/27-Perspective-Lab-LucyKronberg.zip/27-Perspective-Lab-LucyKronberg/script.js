function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  rectGradient(0,0,800,300,"lightsteelblue","lightsalmon");
  rectGradient(0,300,800,100,"lightsalmon", "gold");
  rectGradient(0,400,800,400,"black", "gray");
  //background("white");
  drawHorizon();
  //drawVanishingLines(400,400,8)
  drawRoad();
  drawDashes(400,767);
  drawDashes(400,600,0.6);
  drawDashes(400,500, 0.3);
  drawDashes(400,450,0.2);
  drawDashes(400,420,0.1);
  //drawStopSign()
  drawSun()
  drawMountains()
  

  //text("Use a vanishing point and functions with parameters to create the illusion of depth.", 500, 400)
  
  drawMouseLines("black");
}
function drawHorizon() {
line(0,400,800,400);  
}

function drawVanishingLines(x,y,numlines = 8) {
  push();
  translate (x,y);
  for (let i = 0; i < numlines; i += 1) {
    rotate(360/numlines);
    line(0,0,width,0);
  }
  pop();
}

function drawRoad() {
  fill(61,61,61);
   beginShape();
  vertex(0, 800);
  vertex(400, 400);
  vertex(800, 800);
  vertex(0, 800);
  endShape();
}

function drawDashes(x,y, scaling = 1) {
  fill(247, 205, 89);
  push();
  translate(x,y);
  scale(scaling);
  translate(-400,-767);
  
  beginShape();
  vertex(389, 656);
  vertex(412, 656);
  vertex(420, 767);
  vertex(379, 767);
  vertex(389, 656);
  endShape();

  pop();
}

function drawMountains() {
  fill("black");
  beginShape(); //right
  vertex(420, 400);
  vertex(473, 342);
  vertex(503, 345);
  vertex(512, 362);
  vertex(574, 384);
  vertex(591, 400);
  vertex(420, 400);
  endShape();

  beginShape();
  vertex(546, 373);
  vertex(597, 330);
  vertex(644, 286);
  vertex(660, 278);
  vertex(694, 305);
  vertex(730, 328);
  vertex(742, 380);
  vertex(785, 389);
  vertex(799, 400);
  vertex(588, 400);
  vertex(573, 384);
  vertex(545, 374);
  endShape();

  beginShape();
  vertex(736, 351);
  vertex(769, 339);
  vertex(800, 353);
  vertex(800, 400);
  vertex(735, 400);
  vertex(735, 351);
  endShape();

  beginShape();
  vertex(447, 381);
  vertex(425, 400);
  vertex(417, 400);
  vertex(432, 400);
  vertex(434, 400);
  endShape();

   beginShape(); //left 
  vertex(372, 399);
  vertex(348, 365);
  vertex(325, 356);
  vertex(286, 385);
  vertex(256, 384);
  vertex(240, 400);
  vertex(372, 400);
  endShape();

   beginShape();
  vertex(240, 399);
  vertex(224, 358);
  vertex(164, 335);
  vertex(113, 334);
  vertex(61, 279);
  vertex(33, 290);
  vertex(23, 303);
  vertex(0, 342);
  vertex(0, 400);
  vertex(239, 400);
  endShape();

  beginShape();
  vertex(426, 396);
  vertex(412, 401);
  vertex(433, 402);
  vertex(420, 399);
  endShape();
}

function drawStopSign() {
  fill("red");
  beginShape();
  vertex(49, 355);
  vertex(99, 355);
  vertex(125, 387);
  vertex(125, 430);
  vertex(96, 459);
  vertex(49, 459);
  vertex(22, 430);
  vertex(22, 387);
  vertex(49, 355);
  endShape();
fill(166, 148, 98)
  beginShape();
  vertex(63, 460);
  vertex(63, 661);
  vertex(81, 661);
  vertex(81, 460);
  endShape();
}

function drawSun() {
  noStroke();
 fill("yellow");
  beginShape();
  curveVertex(373, 399); // control point
  curveVertex(373, 399);
  curveVertex(380, 390);
  curveVertex(389, 385);
  curveVertex(402, 383);
  curveVertex(416, 387);
  curveVertex(424, 394);
  curveVertex(428, 400);
  curveVertex(373, 399);
  curveVertex(373, 399); // control point
  endShape();

  
}
