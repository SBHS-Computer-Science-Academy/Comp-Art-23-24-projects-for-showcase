function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  rectGradient(0, 0, width, height, color(25), color(0)); //background
  fill(9);
  noStroke();
  push()
  translate(width / 2, height / 3)
  //drawVanishingLines(0, 0, 48)
  //triangle(0, 0, 44, 600 - (height / 3), -44, 600 - (height / 3))
  arc(0, 10, 720, 680, 82.5, 97.5, PIE)
  fill(150)
  drawLights(0, 0, 300, 173, 13)
  drawLights(0, 0, -300, 173, 13)
  drawGrads(0, 0, 235, 235, 6, color(255, 255, 0, 0), color(255, 255, 0, 6))
  drawGrads(0, 0, -235, 235, 6, color(255, 255, 0, 0), color(255, 255, 0, 6))
  drawGrads(0, 0, 162, 280, 8, color(255, 255, 0, 0), color(255, 255, 0, 10))
  drawGrads(0, 0, -162, 280, 8, color(255, 255, 0, 0), color(255, 255, 0, 10))
  drawGrads(0, 0, 84, 311, 12, color(255, 255, 0, 0), color(255, 255, 0, 14))
  drawGrads(0, 0, -84, 311, 12, color(255, 255, 0, 0), color(255, 255, 0, 14))
  pop()
  drawMouseLines("white");
}

function drawLights(x1, y1, x2, y2, numLights = 10) {
  let scaling = 1; // original size
  push()
  translate(x1, y1)
  for (let i = 0; i < numLights; i++) {
    let x = map(scaling, 0, 1, 0, (x2 - x1));
    let y = map(scaling, 0, 1, 0, (y2 - y1));
    circle(x, y, 50 * scaling);
    scaling *= 3 / 4;
  }
  pop()
}

function drawGrads(x1, y1, x2, y2, numLights, color1, color2) {
  let scaling = 1; // original size
  push()
  translate(x1, y1)
  for (let i = 0; i < numLights; i++) {
    let x = map(scaling, 0, 1, 0, (x2 - x1));
    let y = map(scaling, 0, 1, 0, (y2 - y1));
    circleGradient(x, y, 50 * scaling, color1, color2);
    scaling *= 3 / 4;
  }
  pop()
}

function traceLinesR(spacingPercent, x1, y1, x2, y2) {
  mul = spacingPercent / 100
  push()
  translate(x1, y1)
  for (let i = 0; i <= 100 / spacingPercent; i++) {
    circle(i * mul * (x2 - x1), i * mul * (y2 - y1), i * spacingPercent)
    mul *= 1
  }
  pop()
}

function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i++) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}