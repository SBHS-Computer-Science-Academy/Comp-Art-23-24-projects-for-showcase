function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");          

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background('gray');
   circleGradient(270, 250, 1900, "darkblue", "lightblue",); 
  noFill()
  drawline()
  drawline2()
  



  line(0, 250, width, 250); 
 
  drawVanishingLines(270, 250, 32);
 

  
  
  drawMouseLines("black");
}

function drawVanishingLines(x, y, numLines = 8) {
  push(); 
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
    
  }
  pop();
}

function drawBuilding(x, y, scaling = 1) {

  push();
  translate(x, y); 
  scale(scaling); 
  translate(-543, -522); 

  
  fill("silver");
  strokeWeight(2);
  
  
  line(0, 250, width, 250); 

  
  drawVanishingLines(270, 250, 32);

  
  drawBuilding(543, 522); 
  drawBuilding(410, 389, 0.5); 
  drawBuilding(346, 325, 0.28);
  drawBuilding(763, 743, 1.8);
  
 
  drawMouseLines("black");
}

function drawVanishingLines(x, y, numLines = 8) {
  push(); 
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}

function drawBuilding(x, y, scaling = 1) {

  push();
  translate(x, y); 
  scale(scaling); 
  translate(-543, -522); 
  pop();
}
function drawline() {

  beginShape();
  vertex(259, 222);
  vertex(236, 234);
  vertex(228, 256);
  vertex(236, 281);
  vertex(270, 299);
  vertex(298, 294);
  vertex(316, 270);
  vertex(328, 241);
  vertex(310, 205);
  vertex(276, 181);
  vertex(233, 182);
  vertex(202, 203);
  vertex(184, 239);
  vertex(185, 279);
  vertex(209, 319);
  vertex(247, 343);
  vertex(303, 349);
  vertex(343, 331);
  vertex(369, 294);
  vertex(386, 241);
  vertex(375, 194);
  vertex(342, 143);
  vertex(287, 116);
  vertex(225, 118);
  vertex(162, 153);
  vertex(144, 179);
  vertex(128, 222);
  vertex(124, 291);
  vertex(157, 357);
  vertex(211, 396);
  vertex(289, 419);
  vertex(361, 404);
  vertex(410, 371);
  vertex(462, 307);
  vertex(473, 206);
  vertex(449, 120);
  vertex(370, 51);
  vertex(273, 28);
  vertex(162, 33);
  vertex(81, 96);
  vertex(46, 152);
  vertex(35, 265);
  vertex(52, 335);
  vertex(85, 408);
  vertex(154, 458);
  vertex(246, 502);
  vertex(362, 501);
  vertex(445, 461);
  vertex(516, 387);
  vertex(559, 315);
  vertex(578, 214);
  vertex(562, 118);
  vertex(485, 22);
  vertex(448, 0);
  vertex(662, 1);
  vertex(709, 89);
  vertex(710, 160);
  vertex(697, 273);
  vertex(649, 386);
  vertex(554, 494);
  vertex(416, 597);
  vertex(201, 610);
  vertex(47, 541);
  vertex(-3, 447);
  vertex(0, 715);
  vertex(110, 763);
  vertex(217, 769);
  vertex(402, 764);
  vertex(587, 727);
  vertex(707, 614);
  vertex(810, 472);
  vertex(887, 281);
  vertex(907, 125);
  vertex(867, -3);
  vertex(1000, -4);
  vertex(1000, 486);
  vertex(972, 608);
  vertex(926, 739);
  vertex(861, 800);
  endShape();
}
function drawline2() {
  // fill("black");
  beginShape();
  vertex(259, 222);
  vertex(294, 234);
  vertex(295, 252);
  vertex(284, 267);
  vertex(265, 268);
  vertex(251, 256);
  vertex(251, 243);
  vertex(263, 235);
  vertex(284, 244);
  vertex(279, 254);
  vertex(265, 255);
  vertex(261, 250);
  vertex(265, 246);
  vertex(275, 246);
  vertex(278, 251);
  vertex(276, 253);
  endShape();
}


































































































