function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

}

function draw() {
  clear();
  background("white");
  fill('  green')
  noStroke()
  rectGradient(0, 0, 1000, 300, 'black', 'orange')
  rect(0, 300, width, 500)
  drawMouseLines("black");
  //latter(187, 638, 1)
  //latter(230, 550 , .6)
  line(width, 300, 0, 300)
  //drawVanishingLines(500, 300, 20)
  trak()
  f()
  shack()
  //latter(134, 800, 1 )
  //thing(579, 405, 1.2)

}
function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}

function thing(x, y, scaling) {
  push();
  translate(x, y);
  scale(scaling)
  translate(-669, -531)
  beginShape();
  fill('black')
  vertex(669, 531);
  vertex(581, 412);
  vertex(577, 307);
  vertex(582, 408);
  vertex(668, 532);
  vertex(676, 270);
  vertex(580, 308);
  vertex(675, 270);
  vertex(668, 528);
  vertex(788, 508);
  vertex(786, 269);
  vertex(672, 270);
  endShape();
  pop();
}
function latter(x, y, scaling) {
  push();
  translate(x, y)
  scale(scaling)
  translate(-187, -638)
  fill(201, 198, 193)
  beginShape();
  vertex(103, 794);
  vertex(187, 638);
  vertex(219, 637);
  vertex(144, 793);
  vertex(105, 793);
  endShape();
  beginShape();
  vertex(386, 631);
  vertex(456, 794);
  vertex(490, 795);
  vertex(409, 621);
  vertex(380, 623);
  vertex(455, 791);
  endShape();
  pop()

}

function track(x, y, scaling) {
  fill(201, 198, 193)
  beginShape();
  vertex(102, 799);
  vertex(308, 300);
  vertex(321, 301);
  vertex(489, 798);
  vertex(418, 799);
  vertex(314, 302);
  vertex(155, 797);
  vertex(105, 798);
  endShape();
}

function trak(x, y) {
  let scaling = 1
  for (let i = 1; i < 21; i += 1) {
    let x = map(scaling, 0, 1, 313, 296)
    let y = map(scaling, 0, 1, 302, 750)
    push()
    translate(x, y)

    fill(79, 60, 13)
    beginShape();
    scale(scaling)
    translate(-296, -750)
    vertex(102, 755);
    vertex(114, 735);
    vertex(477, 736);
    vertex(487, 752);
    vertex(105, 754);
    endShape();

    pop()
    scaling *= .78
  }
}
function f() {
  fill('silver')
  beginShape();
  vertex(160, 798);
  vertex(315, 299);
  vertex(122, 798);
  vertex(160, 798);
  endShape();
  beginShape()
  vertex(313, 301);
  vertex(446, 793);
  vertex(448, 799);
  vertex(415, 799);
  vertex(312, 302);
  endShape()
}

function shack() {
  fill(145, 99, 7)
  beginShape();
  vertex(539, 591);
  vertex(548, 306);
  vertex(469, 311);
  vertex(463, 465);
  vertex(539, 590);
  endShape();
  beginShape();
  vertex(539, 589);
  vertex(729, 585);
  vertex(738, 307);
  vertex(548, 308);
  vertex(627, 240);
  vertex(738, 306);
  vertex(546, 307);
  vertex(538, 588);
  endShape();
  beginShape();
  vertex(557, 315);
  vertex(554, 307);
  vertex(729, 303);
  vertex(734, 311);
  vertex(714, 458);
  vertex(565, 458);
  vertex(571, 377);
  endShape()
  beginShape();
  vertex(473, 312);
  vertex(515, 277);
  vertex(628, 240);
  vertex(553, 308);
  vertex(476, 312);
  endShape()
  fill(0, 20)
  beginShape();
  vertex(543, 589);
  vertex(548, 307);
  vertex(627, 242);
  vertex(735, 307);
  vertex(728, 584);
  vertex(544, 588);
  endShape();
  beginShape();
  vertex(544, 589);
  vertex(999, 654);
  vertex(999, 554);
  vertex(732, 517);
  vertex(730, 585);
  vertex(548, 588);
  endShape();
  fill('black')
  beginShape();
  vertex(486, 390);
  vertex(483, 425);
  vertex(503, 460);
  vertex(508, 416);
  vertex(488, 397);
  endShape();
}


  // ... or use a for loop and the map function to automate:
  // let numBuildings = 7;
  // let scaling = 1; // original building size
  // for (let i = 0; i < numBuildings; i += 1) {
  //   let x = map(scaling, 0, 1, 270, 644);
  //   let y = map(scaling, 0, 1, 250, 623); 
  //   drawBuilding(x, y, scaling);
  //   scaling *= 1/2; // halve the scaling
  // }

