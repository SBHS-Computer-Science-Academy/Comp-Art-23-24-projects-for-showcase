function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");

 // drawVanishingLines(400, 400, numLines = 14);
  drawRoad() 
  drawTrunk()
  drawRight3Branches()
  drawLeft3Branches()

  
  let numLights = 15;
  let scaling = 1; // original building size
  for (let i = 0; i < numLights; i += 1) {
    let x = map(scaling, 0, 1, 400, 964);
    let y = map(scaling, 0, 1, 400, 126); 
    drawBigLight(x, y, scaling);
    scaling *= 0.8; // halve the scaling
  }
  
  drawMouseLines("black");
}
function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}
function drawBigLight(x, y, scaling = 1) {
  // fill("black");

  push();
  translate(x, y); // move to point (x,y)
  scale(scaling); // scale makes it bigger or smaller
  translate(-964, -126); // negative of the bottom left (x,y)

fill("black")
    
  beginShape();
  vertex(931, 194);
  vertex(910, 164);
  vertex(930, 138);
  vertex(943, 137);
  vertex(944, 127);
  vertex(964, 127);
  vertex(964, 136);
  vertex(979, 136);
  vertex(996, 163);
  vertex(975, 199);
  vertex(974, 625);
  vertex(990, 666);
  vertex(915, 666);
  vertex(932, 626);
  vertex(932, 193);
  endShape();
  pop()
}
function drawRoad() {
   // fill("black");
    beginShape();
    vertex(399, 401);
    vertex(1052, 791);
    vertex(535, 800);
    vertex(401, 398);
    endShape();
  }
function drawTrunk() {
// fill("black");
  beginShape();
  curveVertex(253, 787); // control point
  curveVertex(253, 787);
  curveVertex(101, 567);
  curveVertex(201, 318);
  curveVertex(389, 250);
  curveVertex(389, 250); // control point
  endShape();
}
function drawRight3Branches() {
  // fill("black");
  beginShape();
  vertex(391, 250);
  vertex(456, 266);
  vertex(460, 251);
  vertex(425, 244);
  vertex(502, 214);
  vertex(493, 198);
  vertex(470, 207);
  vertex(482, 182);
  vertex(465, 178);
  vertex(452, 210);
  vertex(421, 221);
  vertex(451, 145);
  vertex(432, 141);
  vertex(400, 227);
  vertex(353, 237);
  vertex(372, 174);
  vertex(404, 152);
  vertex(405, 137);
  vertex(376, 157);
  vertex(401, 70);
  vertex(475, 25);
  vertex(465, 3);
  vertex(408, 39);
  vertex(419, 0);
  vertex(396, 1);
  vertex(371, 86);
  vertex(321, 12);
  vertex(307, 23);
  vertex(363, 108);
  vertex(337, 198);
  vertex(301, 136);
  vertex(313, 81);
  vertex(296, 70);
  vertex(284, 122);
  vertex(243, 54);
  vertex(221, 71);
  vertex(281, 163);
  vertex(238, 163);
  vertex(238, 178);
  vertex(291, 180);
  vertex(328, 236);
  endShape();
}
function drawLeft3Branches() {
  // fill("black");
  beginShape();
  vertex(327, 234);
  vertex(212, 249);
  vertex(220, 188);
  vertex(200, 182);
  vertex(196, 216);
  vertex(173, 154);
  vertex(184, 103);
  vertex(170, 100);
  vertex(158, 145);
  vertex(141, 88);
  vertex(118, 98);
  vertex(152, 186);
  vertex(122, 169);
  vertex(114, 187);
  vertex(164, 216);
  vertex(179, 251);
  vertex(131, 273);
  vertex(70, 246);
  vertex(95, 204);
  vertex(71, 189);
  vertex(53, 225);
  vertex(50, 144);
  vertex(27, 144);
  vertex(27, 177);
  vertex(9, 162);
  vertex(4, 180);
  vertex(23, 192);
  vertex(29, 247);
  vertex(3, 225);
  vertex(-1, 255);
  vertex(103, 288);
  vertex(40, 298);
  vertex(-6, 350);
  endShape();
}

fill("black");
circle(100, 300, 100);
