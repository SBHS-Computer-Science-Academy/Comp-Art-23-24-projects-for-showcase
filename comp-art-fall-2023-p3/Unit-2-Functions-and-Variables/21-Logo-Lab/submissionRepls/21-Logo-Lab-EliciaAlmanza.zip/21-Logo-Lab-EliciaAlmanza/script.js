                function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
    




  
  
  fill('dimgrey')
  circle(263,268,500)
  fill('#4D161A')
  circle(263,268,470)
  fill('MistyRose')
  circle(263,268,330)

  drawP()
  drawDiamond()
  drawB()
  
  drawMouseLines("black");

}




function drawP() {
   fill("#4D161A");
  beginShape();
  vertex(229, 176);
  vertex(160, 179);
  vertex(153, 299);
  vertex(165, 300);
  vertex(172, 226);
  vertex(227, 231);
  vertex(256, 216);
  vertex(258, 203);
  vertex(252, 193);
  vertex(243, 184);
  vertex(224, 177);
  vertex(213, 176);
  vertex(204, 177);
  vertex(188, 176);
  vertex(175, 178);
  endShape();
}

function drawDiamond() {
  fill("dimgrey");
  beginShape();
  vertex(265, 255);
  vertex(228, 291);
  vertex(269, 332);
  vertex(310, 291);
  vertex(267, 255);
  endShape();
}

function drawB() {
  fill("#4D161A");
  beginShape();
  vertex(321, 193);
  vertex(317, 319);
  vertex(363, 323);
  vertex(379, 315);
  vertex(385, 286);
  vertex(369, 270);
  vertex(348, 259);
  vertex(330, 257);
  vertex(322, 260);
  vertex(362, 249);
  vertex(384, 241);
  vertex(379, 223);
  vertex(365, 210);
  vertex(357, 196);
  vertex(329, 195);
  vertex(321, 188);
  endShape();
}