
function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("darkgray");
  
  fill("black");
  text("Create a logo for either a real or imagined brand.", 200, 200);


  drawRhombus();
  
  drawMouseLines("black");


}

function drawRhombus() {

  
  fill('red')
  circle(120,260,190)
  fill('DarkOrange')
  circle(255,260,190)
  fill('OrangeRed')
    beginShape();
   vertex(188, 328);
  vertex(196, 321);
  vertex(202, 313);
  vertex(206, 306);
  vertex(213, 287);
  vertex(215, 273);
  vertex(215, 253);
  vertex(214, 241);
  vertex(213, 231);
  vertex(209, 218);
  vertex(201, 206);
  vertex(194, 199);
  vertex(188, 195);
  vertex(187, 195);
  vertex(177, 205);
  vertex(169, 220);
  vertex(164, 236);
  vertex(161, 248);
  vertex(160, 259);
  vertex(161, 276);
  vertex(165, 289);
  vertex(170, 299);
  vertex(173, 307);
  vertex(180, 319);
  vertex(187, 326);
  vertex(189, 328);
  vertex(188, 329);
  endShape();
fill('white')
beginShape();
  vertex(40, 393);
  vertex(40, 349);
  vertex(52, 370);
  vertex(63, 351);
  vertex(64, 394);
  vertex(69, 394);
  vertex(67, 342);
  vertex(53, 358);
  vertex(38, 339);
  vertex(36, 395);
  vertex(41, 393);
  endShape();

  beginShape();
  vertex(74, 395);
  vertex(82, 351);
  vertex(89, 395);
  vertex(86, 395);
  vertex(82, 367);
  vertex(78, 394);
  vertex(74, 395);
  endShape();

   beginShape();
  vertex(80, 377);
  vertex(84, 377);
  vertex(85, 383);
  vertex(79, 383);
  vertex(80, 379);
  endShape();

  beginShape();
  vertex(114, 372);
  vertex(105, 356);
  vertex(97, 375);
  vertex(113, 387);
  vertex(98, 396);
  vertex(95, 381);
  vertex(100, 389);
  vertex(108, 387);
  vertex(94, 375);
  vertex(104, 351);
  vertex(116, 369);
  vertex(115, 371);
  endShape()

  beginShape();
  vertex(124, 393);
  vertex(126, 371);
  vertex(114, 372);
  vertex(114, 368);
  vertex(135, 368);
  vertex(135, 372);
  vertex(129, 373);
  vertex(129, 391);
  vertex(125, 391);
  endShape();

  beginShape();
  vertex(164, 361);
  vertex(149, 362);
  vertex(151, 391);
  vertex(164, 390);
  vertex(162, 384);
  vertex(155, 385);
  vertex(154, 378);
  vertex(162, 378);
  vertex(162, 372);
  vertex(154, 372);
  vertex(154, 367);
  vertex(163, 366);
  vertex(163, 364);
  vertex(163, 362);
  vertex(163, 361);
  endShape();

   beginShape();
  vertex(172, 358);
  vertex(174, 391);
  vertex(180, 392);
  vertex(178, 378);
  vertex(194, 390);
  vertex(199, 389);
  vertex(183, 374);
  vertex(195, 374);
  vertex(191, 359);
  vertex(172, 358);
  endShape();

  
}
