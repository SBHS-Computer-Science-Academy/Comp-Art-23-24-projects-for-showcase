




let page=0
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  

  
  createConsole("lines");
  drawMouseLines('black')
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  //setTimeout(done, 5000)
  //let color = [255, 0, 200, 140]
  

}

function draw() {
  background("white");
  
  fill("black");
  //text("Create a logo for either a real or imagined brand.", 200, 200);

  //drawRhombus();
  //drawTitle()
  // drawMouseLines("black");
  // clear()
  if(page==0){
     drawTitle()
  }
  
  
}
function keyPressed(){
  
    if (keyCode === LEFT_ARROW && page>0 ) {
      page -=1
    } else if (keyCode === RIGHT_ARROW && page<9 ) {
      page +=1
    }
  }


function drawTitle(){
  
  color1 = color('purple')
  color2 = color('yellow')
  gradientHorizontal(color1, color2, 200)
  textSize(50)
  textFont("Comic Sans MS");
  text("The Pencil", 350, 350, 300, 100)
}



function gradientHorizontal(clrStart, clrEnd, steps ) {
  noStroke()
  let StepSiz = height/steps
  for ( let f = 0; f <=height; f+=StepSiz){
    fill(lerpColor(clrStart, clrEnd, f/width))
    rect(0, f, width, StepSiz)
  }
}



function drawPage2(){
  beginShape();
  vertex(282, 481);
  vertex(283, 362);
  vertex(436, 365);
  vertex(440, 479);
  vertex(409, 479);
  vertex(407, 408);
  vertex(303, 406);
  vertex(302, 480);
  vertex(281, 478);
  vertex(440, 480);
  vertex(434, 268);
  vertex(658, 267);
  vertex(661, 397);
  vertex(651, 110);
  vertex(695, 110);
  vertex(700, 477);
  vertex(440, 479);
  vertex(438, 413);
  vertex(470, 412);
  vertex(478, 475);
  endShape();
}
function page2(){
  for(let i=0; i<100; i++){
    fill(random(0,255), random(0, 255), random(0, 255))
    
  
  
  
  
  }
    
}
