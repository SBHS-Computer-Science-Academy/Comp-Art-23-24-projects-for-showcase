function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  fill("black");
  text("Create a logo for either a real or imagined brand.", 200, 200);


  drawG()
  
  drawMouseLines("black");



}

function drawG() {
   fill("white");
  beginShape();
  vertex(235, 94);
  vertex(163, 93);
  vertex(166, 163);
  vertex(236, 162);
  vertex(235, 132);
  vertex(199, 131);
  vertex(201, 148);
  vertex(219, 148);
  vertex(219, 155);
  vertex(178, 154);
  vertex(176, 106);
  vertex(236, 106);
  vertex(235, 94);
  endShape();
  fill("red")
  // fill("black");
  beginShape();
  vertex(235, 94);
  vertex(163, 93);
  vertex(164, 108);
  vertex(235, 106);
  vertex(235, 95);
  endShape();
  fill("yellow")
// fill("black");
  beginShape();
  vertex(165, 109);
  vertex(166, 140);
  vertex(176, 140);
  vertex(176, 108);
  vertex(165, 109);
  endShape();
  fill("green")
  // fill("black");
  beginShape();
  vertex(166, 141);
  vertex(166, 163);
  vertex(211, 162);
  vertex(211, 156);
  vertex(178, 155);
  vertex(176, 141);
  vertex(167, 141);
  endShape();
  fill("blue")
   // fill("black");
  beginShape();
  vertex(211, 163);
  vertex(236, 162);
  vertex(235, 132);
  vertex(198, 132);
  vertex(201, 146);
  vertex(219, 148);
  vertex(219, 154);
  vertex(211, 156);
  vertex(212, 163);
  endShape();
}



