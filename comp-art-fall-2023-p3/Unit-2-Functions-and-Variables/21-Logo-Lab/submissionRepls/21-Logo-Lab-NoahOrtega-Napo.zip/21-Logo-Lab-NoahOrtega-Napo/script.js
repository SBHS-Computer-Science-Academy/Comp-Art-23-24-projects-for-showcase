function setup() {
  let myCanvas = createCanvas(700,700);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  fill("black");
  text("Create a logo for either a real or imagined brand.", 200, 200);

  fill("red")
circle(360,300,400,100,140,120)
fill("white")
  circle(357,301,297,305,409,304)
  fill("red")
  circle(352,304,100,305,306,303)
  fill("black")
  circle(470,585,60,586,440,585)

drawT()
  drawA()
  drawR()
  drawJ()
  drawE()
  drawlitteT()
 drawMouseLines("black");


}
function drawT() {
   fill("black");
  beginShape();
  vertex(136, 552);
  vertex(229, 551);
  vertex(229, 571);
  vertex(186, 570);
  vertex(190, 642);
  vertex(168, 642);
  vertex(166, 570);
  vertex(129, 570);
  vertex(129, 551);
  vertex(135, 552);
  endShape();
}
function drawA() {
  // fill("black");
  beginShape();
  vertex(279, 554);
  vertex(250, 639);
  vertex(273, 639);
  vertex(282, 606);
  vertex(307, 606);
  vertex(316, 635);
  vertex(345, 634);
  vertex(290, 525);
  vertex(277, 556);
  endShape();
}
function drawR() {
   fill("black");
  beginShape();
  vertex(375, 630);
  vertex(371, 544);
  vertex(387, 544);
  vertex(387, 558);
  vertex(421, 538);
  vertex(421, 557);
  vertex(389, 577);
  vertex(389, 628);
  vertex(370, 630);
  endShape();
}
function drawJ() {
  fill("black");
  beginShape();
  curveVertex(496, 602); // control point
  curveVertex(496, 602);
  curveVertex(500, 675);
  curveVertex(461, 668);
  curveVertex(461, 647);
  curveVertex(486, 656);
  curveVertex(484, 607);
  curveVertex(497, 607);
  curveVertex(497, 607); // control point
  endShape();
}
function drawE() {
   fill("black");
  beginShape();
  curveVertex(537, 588); // control point
  curveVertex(537, 588);
  curveVertex(589, 587);
  curveVertex(569, 549);
  curveVertex(511, 560);
  curveVertex(518, 643);
  curveVertex(588, 651);
  curveVertex(591, 632);
  curveVertex(537, 632);
  curveVertex(536, 587);
  curveVertex(536, 587); // control point
  endShape();
}
function drawlitteT() {
   fill("black");
  beginShape();
  vertex(636, 545);
  vertex(636, 572);
  vertex(607, 571);
  vertex(608, 589);
  vertex(637, 589);
  vertex(638, 648);
  vertex(658, 647);
  vertex(654, 590);
  vertex(679, 590);
  vertex(675, 568);
  vertex(652, 571);
  vertex(650, 542);
  vertex(638, 543);
  endShape();
}