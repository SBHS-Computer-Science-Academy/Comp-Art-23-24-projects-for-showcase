function setup() {
  let myCanvas = createCanvas(800,800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background('lightblue');
  drawJ()
  drawE()
  drawT()
  drawS()
  drawe()
  drawShape()
  drawt()
  drawj()
  drawO()
  drawU()
  drawR()
  drawN()
  drawI()
  drawY()
  draws()
  drawo()
  drawr()
  drawA()
  drawV()
  drawk()
  drawL()
  drawi()
  drawn()
  drawG()
  drawb()
  drawq()
  draw8()
  draw7()
  draw6()
  draw5()
  draw4()
drawMouseLines("black"); 


}
function drawJ() {
  fill("lavender");
  beginShape();
  vertex(152, 185);
  vertex(173, 186);
  vertex(193, 186);
  vertex(205, 186);
  vertex(218, 186);
  vertex(230, 187);
  vertex(231, 201);
  vertex(202, 202);
  vertex(203, 235);
  vertex(202, 255);
  vertex(197, 274);
  vertex(191, 284);
  vertex(181, 289);
  vertex(170, 287);
  vertex(162, 282);
  vertex(155, 277);
  vertex(150, 269);
  vertex(147, 261);
  vertex(147, 252);
  vertex(147, 245);
  vertex(161, 246);
  vertex(161, 254);
  vertex(163, 265);
  vertex(171, 267);
  vertex(179, 265);
  vertex(184, 257);
  vertex(183, 248);
  vertex(185, 239);
  vertex(185, 229);
  vertex(186, 220);
  vertex(185, 211);
  vertex(185, 203);
  vertex(152, 201);
  vertex(151, 187);
  endShape();
}
function drawE() {
  fill("lightpink");
  beginShape();
  vertex(238, 188);
  vertex(238, 282);
  vertex(290, 282);
  vertex(289, 268);
  vertex(251, 268);
  vertex(251, 242);
  vertex(276, 243);
  vertex(276, 230);
  vertex(253, 230);
  vertex(253, 205);
  vertex(287, 205);
  vertex(285, 189);
  vertex(239, 188);
  endShape();
}
function drawT() {
  fill("lightgreen");
  beginShape();
  vertex(312, 190);
  vertex(379, 192);
  vertex(379, 207);
  vertex(352, 207);
  vertex(352, 279);
  vertex(337, 279);
  vertex(337, 208);
  vertex(313, 207);
  vertex(312, 191);
  endShape();
}
function drawS() {
  fill("lightyellow");
  beginShape();
  curveVertex(233, 357); // control point
  curveVertex(233, 357);
  curveVertex(218, 344);
  curveVertex(190, 331);
  curveVertex(162, 334);
  curveVertex(144, 345);
  curveVertex(137, 366);
  curveVertex(154, 389);
  curveVertex(182, 396);
  curveVertex(206, 398);
  curveVertex(236, 410);
  curveVertex(246, 423);
  curveVertex(247, 440);
  curveVertex(234, 451);
  curveVertex(214, 452);
  curveVertex(185, 442);
  curveVertex(165, 432);
  curveVertex(144, 425);
  curveVertex(138, 442);
  curveVertex(156, 455);
  curveVertex(183, 464);
  curveVertex(225, 475);
  curveVertex(251, 475);
  curveVertex(261, 461);
  curveVertex(266, 446);
  curveVertex(266, 427);
  curveVertex(261, 415);
  curveVertex(255, 403);
  curveVertex(242, 389);
  curveVertex(218, 384);
  curveVertex(194, 379);
  curveVertex(177, 369);
  curveVertex(170, 358);
  curveVertex(177, 351);
  curveVertex(191, 354);
  curveVertex(210, 363);
  curveVertex(226, 373);
  curveVertex(234, 360);
  curveVertex(234, 360); // control point
  endShape();
}
function drawe() {
  fill("lightcyan");
  beginShape();
  curveVertex(309, 415); // control point
  curveVertex(309, 415);
  curveVertex(335, 414);
  curveVertex(363, 414);
  curveVertex(392, 414);
  curveVertex(392, 401);
  curveVertex(390, 389);
  curveVertex(378, 379);
  curveVertex(367, 374);
  curveVertex(350, 372);
  curveVertex(332, 375);
  curveVertex(315, 378);
  curveVertex(293, 385);
  curveVertex(282, 399);
  curveVertex(274, 414);
  curveVertex(274, 443);
  curveVertex(281, 461);
  curveVertex(305, 481);
  curveVertex(326, 490);
  curveVertex(360, 490);
  curveVertex(375, 480);
  curveVertex(383, 458);
  curveVertex(387, 441);
  curveVertex(360, 440);
  curveVertex(353, 463);
  curveVertex(333, 465);
  curveVertex(305, 448);
  curveVertex(305, 432);
  curveVertex(310, 415);
  curveVertex(310, 415); // control point
  endShape();
}
function drawShape() {
  fill("lightblue");
  beginShape();
  vertex(322, 400);
  vertex(363, 401);
  vertex(363, 396);
  vertex(358, 391);
  vertex(349, 386);
  vertex(337, 386);
  vertex(328, 387);
  vertex(322, 392);
  vertex(322, 399);
  endShape();
}
function drawt() {
  fill("lightmagenta");
  beginShape();
  vertex(419, 398);
  vertex(418, 376);
  vertex(446, 378);
  vertex(445, 342);
  vertex(468, 343);
  vertex(469, 378);
  vertex(497, 378);
  vertex(497, 393);
  vertex(473, 393);
  vertex(472, 423);
  vertex(473, 446);
  vertex(473, 466);
  vertex(477, 474);
  vertex(488, 480);
  vertex(499, 476);
  vertex(501, 464);
  vertex(502, 454);
  vertex(501, 444);
  vertex(515, 446);
  vertex(525, 446);
  vertex(526, 456);
  vertex(522, 477);
  vertex(518, 490);
  vertex(506, 498);
  vertex(493, 503);
  vertex(478, 499);
  vertex(465, 493);
  vertex(458, 478);
  vertex(455, 463);
  vertex(452, 441);
  vertex(451, 419);
  vertex(451, 396);
  vertex(419, 397);
  endShape();
}
function drawj() {
  fill('lightblue');
  beginShape();
  curveVertex(175, 518); // control point
  curveVertex(175, 518);
  curveVertex(241, 520);
  curveVertex(205, 519);
  curveVertex(206, 554);
  curveVertex(207, 574);
  curveVertex(200, 588);
  curveVertex(182, 593);
  curveVertex(167, 588);
  curveVertex(162, 575);
  curveVertex(162, 558);
  curveVertex(162, 558); // control point
  endShape();
}
function drawO() {
  fill("lightblue");
  beginShape();
  curveVertex(262, 522); // control point
  curveVertex(262, 522);
  curveVertex(244, 536);
  curveVertex(239, 556);
  curveVertex(242, 573);
  curveVertex(253, 586);
  curveVertex(269, 590);
  curveVertex(276, 586);
  curveVertex(281, 576);
  curveVertex(285, 560);
  curveVertex(284, 547);
  curveVertex(283, 536);
  curveVertex(277, 531);
  curveVertex(272, 525);
  curveVertex(264, 523);
  curveVertex(257, 526);
  curveVertex(263, 534);
  curveVertex(272, 536);
  curveVertex(276, 536);
  curveVertex(286, 533);
  curveVertex(293, 526);
  curveVertex(293, 526); // control point
  endShape();
}
function drawU() {
  fill("lightblue");
  beginShape();
  curveVertex(301, 525); // control point
  curveVertex(301, 525);
  curveVertex(303, 569);
  curveVertex(303, 580);
  curveVertex(307, 587);
  curveVertex(313, 591);
  curveVertex(322, 593);
  curveVertex(332, 593);
  curveVertex(342, 589);
  curveVertex(347, 583);
  curveVertex(347, 577);
  curveVertex(345, 564);
  curveVertex(344, 553);
  curveVertex(343, 538);
  curveVertex(343, 530);
  curveVertex(343, 526);
  curveVertex(343, 526); // control point
  endShape();
}
function drawR() {
  fill("lightblue");
  beginShape();
  curveVertex(366, 527); // control point
  curveVertex(366, 527);
  curveVertex(383, 526);
  curveVertex(389, 526);
  curveVertex(392, 526);
  curveVertex(396, 526);
  curveVertex(399, 529);
  curveVertex(410, 537);
  curveVertex(410, 546);
  curveVertex(404, 549);
  curveVertex(397, 550);
  curveVertex(388, 550);
  curveVertex(381, 550);
  curveVertex(371, 551);
  curveVertex(379, 554);
  curveVertex(387, 562);
  curveVertex(393, 569);
  curveVertex(396, 572);
  curveVertex(402, 581);
  curveVertex(405, 584);
  curveVertex(382, 555);
  curveVertex(374, 551);
  curveVertex(370, 551);
  curveVertex(369, 543);
  curveVertex(366, 527);
  curveVertex(370, 551);
  curveVertex(370, 563);
  curveVertex(370, 574);
  curveVertex(371, 587);
  curveVertex(371, 587); // control point
  endShape();
}
function drawN() {
  fill("lightblue");
  beginShape();
  curveVertex(426, 582); // control point
  curveVertex(426, 582);
  curveVertex(421, 521);
  curveVertex(467, 579);
  curveVertex(465, 518);
  curveVertex(465, 518); // control point
  endShape();
}
function drawI() {
  fill("lightblue");
  beginShape();
  curveVertex(486, 517); // control point
  curveVertex(486, 517);
  curveVertex(488, 581);
  curveVertex(530, 581);
  curveVertex(488, 581);
  curveVertex(487, 552);
  curveVertex(513, 552);
  curveVertex(488, 552);
  curveVertex(486, 519);
  curveVertex(528, 519);
  curveVertex(528, 519); // control point
  endShape();
}
function drawY() {
  fill("lightblue");
  beginShape();
  curveVertex(561, 582); // control point
  curveVertex(561, 582);
  curveVertex(559, 541);
  curveVertex(540, 513);
  curveVertex(559, 542);
  curveVertex(573, 511);
  curveVertex(573, 511); // control point
  endShape();
}
function draws() {
  fill("lightblue");
  beginShape();
  curveVertex(618, 519); // control point
  curveVertex(618, 519);
  curveVertex(604, 510);
  curveVertex(589, 512);
  curveVertex(583, 526);
  curveVertex(593, 540);
  curveVertex(614, 547);
  curveVertex(623, 552);
  curveVertex(623, 562);
  curveVertex(616, 575);
  curveVertex(599, 575);
  curveVertex(589, 568);
  curveVertex(587, 562);
  curveVertex(587, 562); // control point
  endShape();
}
function drawo() {
  fill("magenta");
  beginShape();
  curveVertex(171, 662); // control point
  curveVertex(171, 662);
  curveVertex(146, 663);
  curveVertex(144, 643);
  curveVertex(217, 644);
  curveVertex(217, 660);
  curveVertex(191, 661);
  curveVertex(193, 714);
  curveVertex(174, 713);
  curveVertex(171, 663);
  curveVertex(171, 663); // control point
  endShape();
}
function drawr() {
  fill("magenta");
  beginShape();
  curveVertex(230, 646); // control point
  curveVertex(230, 646);
  curveVertex(231, 712);
  curveVertex(244, 712);
  curveVertex(242, 676);
  curveVertex(267, 709);
  curveVertex(278, 710);
  curveVertex(250, 670);
  curveVertex(265, 666);
  curveVertex(271, 662);
  curveVertex(274, 655);
  curveVertex(274, 646);
  curveVertex(268, 638);
  curveVertex(252, 634);
  curveVertex(245, 635);
  curveVertex(236, 635);
  curveVertex(233, 638);
  curveVertex(231, 643);
  curveVertex(231, 643); // control point
  endShape();
}
function drawA() {
  fill("magenta");
  beginShape();
  curveVertex(300, 636); // control point
  curveVertex(300, 636);
  curveVertex(288, 709);
  curveVertex(301, 710);
  curveVertex(306, 675);
  curveVertex(322, 674);
  curveVertex(333, 710);
  curveVertex(346, 710);
  curveVertex(322, 639);
  curveVertex(320, 634);
  curveVertex(301, 635);
  curveVertex(301, 635); // control point
  endShape();
}
function drawV() {
  fill("magenta");
  beginShape();
  vertex(346, 633);
  vertex(370, 712);
  vertex(389, 713);
  vertex(403, 633);
  vertex(389, 633);
  vertex(380, 689);
  vertex(359, 628);
  vertex(344, 630);
  vertex(347, 635);
  endShape();
}
function drawk() {
  fill("magenta");
  beginShape();
  curveVertex(412, 633); // control point
  curveVertex(412, 633);
  curveVertex(413, 710);
  curveVertex(458, 710);
  curveVertex(456, 695);
  curveVertex(429, 695);
  curveVertex(428, 673);
  curveVertex(444, 673);
  curveVertex(443, 660);
  curveVertex(427, 659);
  curveVertex(425, 638);
  curveVertex(452, 638);
  curveVertex(450, 624);
  curveVertex(410, 625);
  curveVertex(412, 636);
  curveVertex(412, 636); // control point
  endShape();
}
function drawL() {
  fill("magenta");
  beginShape();
  curveVertex(468, 624); // control point
  curveVertex(468, 624);
  curveVertex(474, 703);
  curveVertex(522, 698);
  curveVertex(520, 678);
  curveVertex(489, 681);
  curveVertex(486, 620);
  curveVertex(467, 623);
  curveVertex(467, 623); // control point
  endShape();
}
function drawi() {
  fill("magenta");
  beginShape();
  curveVertex(545, 694); // control point
  curveVertex(545, 694);
  curveVertex(598, 694);
  curveVertex(596, 681);
  curveVertex(577, 681);
  curveVertex(573, 626);
  curveVertex(596, 626);
  curveVertex(595, 611);
  curveVertex(529, 612);
  curveVertex(530, 627);
  curveVertex(556, 628);
  curveVertex(559, 677);
  curveVertex(542, 678);
  curveVertex(543, 692);
  curveVertex(543, 692); // control point
  endShape();
}
function drawn() {
  fill("magenta");
  beginShape();
  curveVertex(620, 691); // control point
  curveVertex(620, 691);
  curveVertex(616, 617);
  curveVertex(661, 675);
  curveVertex(655, 611);
  curveVertex(672, 611);
  curveVertex(678, 691);
  curveVertex(658, 691);
  curveVertex(632, 659);
  curveVertex(636, 700);
  curveVertex(619, 697);
  curveVertex(619, 689);
  curveVertex(619, 689); // control point
  endShape();
}
function drawG() {
  fill("magenta");
  beginShape();
  curveVertex(728, 609); // control point
  curveVertex(728, 609);
  curveVertex(713, 600);
  curveVertex(704, 599);
  curveVertex(688, 607);
  curveVertex(684, 617);
  curveVertex(686, 640);
  curveVertex(688, 657);
  curveVertex(692, 676);
  curveVertex(703, 687);
  curveVertex(717, 689);
  curveVertex(732, 685);
  curveVertex(733, 677);
  curveVertex(734, 668);
  curveVertex(734, 659);
  curveVertex(734, 647);
  curveVertex(707, 648);
  curveVertex(707, 657);
  curveVertex(726, 656);
  curveVertex(726, 659);
  curveVertex(726, 661);
  curveVertex(726, 667);
  curveVertex(724, 673);
  curveVertex(717, 674);
  curveVertex(707, 673);
  curveVertex(702, 666);
  curveVertex(702, 663);
  curveVertex(700, 653);
  curveVertex(700, 648);
  curveVertex(699, 637);
  curveVertex(697, 627);
  curveVertex(697, 619);
  curveVertex(701, 613);
  curveVertex(710, 614);
  curveVertex(718, 618);
  curveVertex(719, 623);
  curveVertex(724, 624);
  curveVertex(730, 624);
  curveVertex(732, 616);
  curveVertex(725, 606);
  curveVertex(725, 606); // control point
  endShape();
}
function drawb() {
  fill("lightblue");
  beginShape();
  curveVertex(245, 646); // control point
  curveVertex(245, 646);
  curveVertex(245, 656);
  curveVertex(255, 657);
  curveVertex(260, 656);
  curveVertex(262, 651);
  curveVertex(262, 647);
  curveVertex(258, 645);
  curveVertex(253, 644);
  curveVertex(245, 644);
  curveVertex(245, 646);
  curveVertex(245, 646); // control point
  endShape();
}
function drawq() {
  fill("lightblue");
  beginShape();
  curveVertex(308, 647); // control point
  curveVertex(308, 647);
  curveVertex(304, 662);
  curveVertex(321, 661);
  curveVertex(316, 648);
  curveVertex(308, 647);
  curveVertex(308, 647); // control point
  endShape();
}
function draw8() {
  fill("cyan");
  beginShape();
  vertex(13, 183);
  vertex(51, 182);
  vertex(56, 735);
  vertex(14, 735);
  vertex(4, 181);
  vertex(16, 182);
  endShape();
}
function draw7() {
  fill("yellow");
  beginShape();
  vertex(51, 183);
  vertex(88, 183);
  vertex(94, 734);
  vertex(56, 735);
  vertex(51, 184);
  endShape();
}
function draw6() {
  fill("orange");
  beginShape();
  vertex(87, 184);
  vertex(122, 184);
  vertex(128, 732);
  vertex(95, 733);
  vertex(88, 185);
  endShape();
}
function draw5() {
  fill("purple");
  beginShape();
  vertex(430, 190);
  vertex(478, 189);
  vertex(794, 599);
  vertex(750, 599);
  vertex(433, 190);
  endShape();
}

function draw4() {
  fill("blue");
  beginShape();
  vertex(478, 189);
  vertex(522, 190);
  vertex(794, 528);
  vertex(794, 599);
  vertex(479, 189);
  endShape();
}














  

 
  