function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  



  drawBlueSquare();
  drawRedSquare();
  drawSteam();
  drawMouseLines("black");


}

function drawBlueSquare() {
  fill("SteelBlue");
  beginShape();
  vertex(51, 292);
  vertex(129, 346);
  vertex(186, 275);
  vertex(107, 217);
  vertex(50, 291);
  endShape();

  fill("white")
  circle(115, 260, 30)//upper blue dot 
  circle(120, 305, 30)//lower blue dot 
}

  function drawRedSquare() {
  fill('red')
  beginShape();
  vertex(117, 206);
  vertex(174, 130);
  vertex(253, 187);
  vertex(195, 264);
  vertex(118, 207);
  endShape();

  fill("white")
  circle(185, 200, 30)//red dot 
 
}
function drawSteam() {
  stroke("DarkGray");
  beginShape();
  curveVertex(71, 83); // control point
  curveVertex(71, 83);
  curveVertex(60, 106);
  curveVertex(96, 114);
  curveVertex(86, 143);
  curveVertex(128, 142);
  curveVertex(127, 160);
  curveVertex(127, 160); // control point
  endShape();

  beginShape();
  curveVertex(88, 194); // control point
  curveVertex(88, 194);
  curveVertex(53, 201);
  curveVertex(61, 173);
  curveVertex(34, 176);
  curveVertex(37, 149);
  curveVertex(15, 148);
  curveVertex(6, 124);
  curveVertex(6, 124); // control point
  endShape();
  
  beginShape();
  curveVertex(52, 241); // control point
  curveVertex(52, 241);
  curveVertex(26, 256);
  curveVertex(34, 223);
  curveVertex(7, 229);
  curveVertex(11, 195);
  curveVertex(2, 190);
  curveVertex(2, 190); // control point
  endShape();
}