function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  
}

function draw() {
  background("white");
  rectGradient(0, 0, width, 400, "blue", "black"); // sky with sunset
  fill("black");
  textSize(30)
  text("Archery 2.0", 130, 40);
textSize(25)
  text("BEST VR GAME OUT THERE", 30, 97);

drawRhombus();
 drawbowanarow();
 drawMouseLines("black");
drawtriangle();
drawShape();
  drawstring();
}

function drawRhombus() {
 fill("black");
  beginShape();
  fill("red")
  vertex(164, 127);
  vertex(210, 187);
  vertex(206, 266);
  vertex(167, 311);
  vertex(142, 280);
  vertex(179, 246);
  vertex(175, 189);
  vertex(133, 143);
  vertex(163, 122);
  vertex(172, 137);
  endShape();
}
function drawbowanarow() {
 
}
function drawShape() {
fill("black");
  beginShape();
 fill("green")
  vertex(224, 214);
  vertex(224, 229);
  vertex(98, 230);
  vertex(99, 213);
  vertex(224, 213);
  vertex(224, 219);
  endShape();
}
function drawtriangle() {
fill("black");
  beginShape();
fill("green")
  vertex(256, 221);
  vertex(223, 199);
  vertex(226, 241);
  vertex(253, 220);
  endShape();
}
function drawstring() {
stroke("white")
  fill("white");
  beginShape();
  vertex(134, 146);
  vertex(99, 213);
  vertex(98, 229);
  vertex(143, 282);
  vertex(97, 227);
  vertex(98, 217);
  vertex(135, 145);
  endShape();
}