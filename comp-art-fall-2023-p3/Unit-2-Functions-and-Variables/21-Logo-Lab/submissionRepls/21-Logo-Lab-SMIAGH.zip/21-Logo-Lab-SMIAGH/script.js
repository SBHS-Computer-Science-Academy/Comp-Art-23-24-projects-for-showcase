function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  circleGradient(201,200,400,'red','orange')


  drawA();
  drawShapeA();
  drawRect()
  drawSshape()
  drawMountain()
  
  drawMouseLines("black");


}

function drawA() {
  fill("black");
  beginShape();
  vertex(37, 240);
  vertex(71, 129);
  vertex(90, 129);
  vertex(123, 241);
  vertex(99, 238);
  vertex(85, 180);
  vertex(71, 180);
  vertex(60, 228);
  vertex(37, 238);
  vertex(62, 227);
  vertex(72, 180);
  vertex(77, 156);
  vertex(85, 180);
  endShape();
}


function drawShapeA() {
  // fill("black");
  beginShape();
  vertex(136, 236);
  vertex(172, 120);
  vertex(200, 119);
  vertex(231, 222);
  vertex(208, 217);
  vertex(193, 168);
  vertex(164, 221);
  vertex(136, 232);
  vertex(164, 223);
  vertex(186, 183);
  vertex(194, 166);
  endShape();

}
  

function drawRect() {
 fill("black");
  beginShape();
  vertex(247, 100);
  vertex(237, 123);
  vertex(246, 126);
  vertex(255, 103);
  vertex(248, 99);
  endShape();
}

function drawSshape() {
  fill("black");
  beginShape();
  vertex(375, 111);
  vertex(302, 112);
  vertex(304, 162);
  vertex(373, 160);
  vertex(375, 223);
  vertex(309, 226);
  vertex(310, 238);
  vertex(379, 234);
  vertex(375, 147);
  vertex(311, 149);
  vertex(309, 115);
  vertex(376, 115);
  vertex(376, 111);
  endShape();
}

function drawMountain() {
  fill("SaddleBrown");
  beginShape();
  vertex(30, 261);
  vertex(380, 255);
  vertex(369, 283);
  vertex(356, 305);
  vertex(354, 287);
  vertex(346, 303);
  vertex(340, 275);
  vertex(321, 347);
  vertex(306, 288);
  vertex(292, 323);
  vertex(283, 353);
  vertex(281, 288);
  vertex(259, 338);
  vertex(256, 296);
  vertex(249, 327);
  vertex(242, 293);
  vertex(229, 325);
  vertex(227, 288);
  vertex(209, 355);
  vertex(203, 316);
  vertex(182, 347);
  vertex(172, 298);
  vertex(167, 342);
  vertex(156, 318);
  vertex(139, 326);
  vertex(133, 296);
  vertex(113, 325);
  vertex(104, 287);
  vertex(82, 341);
  vertex(81, 300);
  vertex(63, 324);
  vertex(67, 306);
  vertex(56, 316);
  vertex(52, 281);
  vertex(39, 308);
  vertex(29, 259);
  vertex(379, 254);
  vertex(28, 260);
  vertex(381, 254);
  vertex(28, 260);
  vertex(380, 256);
  vertex(27, 261);
  vertex(379, 256);
  endShape();
}