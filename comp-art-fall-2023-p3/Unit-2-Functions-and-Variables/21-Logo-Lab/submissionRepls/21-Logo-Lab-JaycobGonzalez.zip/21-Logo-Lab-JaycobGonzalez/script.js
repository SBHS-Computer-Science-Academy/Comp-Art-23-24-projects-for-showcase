function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  stroke('black');
  fill("skyblue");
  
  circle(200,200,200);

  drawDiamond();
  
  drawLetterJ();
  
  drawMouseLines("white");
 

}

function drawDiamond() {
  //top part
   stroke('white');
  fill("black");
  beginShape();
  vertex(131, 155);
  vertex(273, 155);
  vertex(286, 181);
  vertex(111, 181);
  vertex(130, 155);
  endShape();

  
  
  
  //bottom part
  beginShape();
  vertex(111, 181);
  vertex(197, 299);
  vertex(286, 181);
  endShape();
  //top triangles
  beginShape();
  vertex(131, 156);
  vertex(146, 180);
  vertex(160, 157);
  vertex(174, 180);
  vertex(184, 155);
  vertex(199, 180);
  vertex(212, 156);
  vertex(226, 180);
  vertex(242, 156);
  vertex(256, 181);
  vertex(271, 156);
  vertex(272, 154);
  endShape();

  //lines
  fill('orange')
  
  beginShape();
  vertex(146, 180);
  vertex(145, 227);
  endShape();

  beginShape();
  vertex(174, 180);
  vertex(175, 269);
  endShape();

   
  beginShape();
  vertex(226, 181);
  vertex(226, 260);
  endShape();

   
  beginShape();
  vertex(256, 181);
  vertex(256, 221);
  endShape();
  
  
  
}

function drawLetterJ() {
  // fill("black");
  beginShape();
  curveVertex(182, 252); // control point
  curveVertex(182, 252);
  curveVertex(183, 269);
  curveVertex(208, 270);
  curveVertex(210, 200);
  curveVertex(198, 193);
  curveVertex(202, 259);
  curveVertex(186, 243);
  curveVertex(182, 253);
  curveVertex(182, 253); // control point
  endShape();
  
}
