function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  
  fill("black");

drawsmall()
 drawhim();
  drawtop()
  drawwop()
  
  drawMouseLines("black");


}

function drawRhombus() {
   fill("pink");
  beginShape();
  vertex(212, 77);
  vertex(162, 140);
  vertex(255, 161);
  vertex(306, 81);
  vertex(212, 77);
  endShape();
}

function drawhim() {
  fill("yellow");
  beginShape();
  vertex(39, 245);
  vertex(38, 287);
  vertex(73, 287);
  vertex(70, 261);
  vertex(110, 262);
  vertex(74, 313);
  vertex(38, 314);
  vertex(33, 341);
  vertex(66, 346);
  vertex(31, 373);
  vertex(130, 354);
  vertex(133, 386);
  vertex(212, 368);
  vertex(203, 298);
  vertex(305, 299);
  vertex(261, 367);
  vertex(336, 367);
  vertex(282, 357);
  vertex(306, 344);
  vertex(292, 334);
  vertex(336, 315);
  vertex(328, 332);
  vertex(357, 328);
  vertex(363, 270);
  vertex(418, 258);
  vertex(353, 229);
  vertex(329, 250);
  vertex(335, 209);
  vertex(296, 208);
  vertex(244, 241);
  vertex(187, 208);
  vertex(93, 209);
  vertex(148, 288);
  vertex(110, 259);
  vertex(39, 246);
  endShape();
}

function drawtop() {
  fill("red");
  beginShape();
  vertex(187, 209);
  vertex(244, 157);
  vertex(298, 208);
  vertex(188, 209);
  vertex(186, 97);
  vertex(86, 95);
  vertex(93, 209);
  vertex(-1, 207);
  vertex(86, 94);
  endShape();
}

function drawwop() {
  fill("red");
  beginShape();
  vertex(88, 94);
  vertex(88, -4);
  vertex(189, -1);
  vertex(186, 97);
  vertex(251, 38);
  vertex(193, 195);
  vertex(245, 148);
  vertex(301, 202);
  vertex(338, 203);
  vertex(341, 205);
  vertex(333, 242);
  vertex(352, 223);
  vertex(396, 240);
  vertex(390, 30);
  vertex(245, 149);
  vertex(264, 38);
  vertex(250, 37);
  vertex(388, 28);
  vertex(189, -1);
  vertex(88, -2);
  vertex(1, 70);
  vertex(1, 208);
  vertex(87, 93);
  endShape();
}

function drawsmall() {
  fill("yellow");
  beginShape();
  vertex(89, 3);
  vertex(191, 2);
  endShape();
}
