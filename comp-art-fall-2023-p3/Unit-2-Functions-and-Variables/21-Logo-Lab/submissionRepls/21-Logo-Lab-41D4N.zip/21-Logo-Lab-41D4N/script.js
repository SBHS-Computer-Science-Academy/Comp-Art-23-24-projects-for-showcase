function setup() {
  let myCanvas = createCanvas(800, 1000);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  drawRhombus();
  
  drawMouseLines("black");


}

function drawRhombus() {
   fill("pink");
  beginShape();
  endShape();
}

