function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  fill("black");
  //text("Create a logo for either a real or imagined brand.", 200, 200);
  
  drawDog()
  drawEye()
  drawFin()
  drawSark()
  drawlLines()
drawCircle()
drawtwist()
  drawT()
  drawL()
  drawI()
  drawMouseLines("black");

  function drawL() {
    fill("blue");
    beginShape();
    vertex(68, 104);
    vertex(67, 268);
    vertex(163, 268);
    vertex(162, 237);
    vertex(97, 236);
    vertex(97, 102);
    vertex(67, 102);
    endShape();

  }
  function drawI() {
    fill("red")
    beginShape();
    vertex(227, 110);
    vertex(227, 268);
    vertex(269, 267);
    vertex(266, 110);
    vertex(226, 110);
    endShape();
  }
  function drawT() {
    fill("orange");
    beginShape();
    vertex(380, 130);
    vertex(375, 254);
    vertex(412, 255);
    vertex(412, 130);
    vertex(470, 132);
    vertex(470, 104);
    vertex(322, 100);
    vertex(321, 127);
    vertex(379, 128);
    endShape();


  }
  function drawtwist() {
   fill("orange");
  beginShape();
  curveVertex(66, 270); // control point
  curveVertex(66, 270);
  curveVertex(38, 302);
  curveVertex(62, 310);
  curveVertex(52, 325);
  curveVertex(73, 323);
  curveVertex(74, 311);
  curveVertex(96, 313);
  curveVertex(77, 300);
  curveVertex(98, 294);
  curveVertex(77, 287);
  curveVertex(92, 283);
  curveVertex(87, 273);
  curveVertex(98, 269);
  curveVertex(98, 269); // control point
  endShape();
}
function drawCircle() {
  fill("orange");
  beginShape();
  curveVertex(251, 62); // control point
  curveVertex(251, 62);
  curveVertex(224, 63);
  curveVertex(230, 77);
  curveVertex(242, 78);
  curveVertex(253, 64);
  curveVertex(245, 50);
  curveVertex(263, 45);
  curveVertex(248, 37);
  curveVertex(238, 49);
  curveVertex(223, 41);
  curveVertex(221, 49);
  curveVertex(198, 51);
  curveVertex(213, 58);
  curveVertex(202, 62);
  curveVertex(224, 67);
  curveVertex(224, 67); // control point
  endShape();
}
  
  function drawlLines() {
  fill("yellow");
  beginShape();
  curveVertex(249, 308); // control point
  curveVertex(249, 308);
  curveVertex(237, 353);
  curveVertex(253, 333);
  curveVertex(253, 363);
  curveVertex(277, 328);
  curveVertex(307, 351);
  curveVertex(263, 264);
  curveVertex(244, 304);
  curveVertex(244, 304); // control point
  endShape();
}
  function drawSark() {
   fill("black");
  beginShape();
  vertex(366, 252);
  vertex(312, 308);
  vertex(348, 342);
  vertex(344, 432);
  vertex(342, 463);
  vertex(475, 456);
  vertex(475, 345);
  vertex(520, 293);
  vertex(432, 239);
  vertex(432, 265);
  vertex(451, 248);
  vertex(449, 272);
  vertex(468, 263);
  vertex(470, 289);
  vertex(493, 275);
  vertex(492, 297);
  vertex(510, 288);
  vertex(510, 302);
  vertex(490, 301);
  vertex(494, 319);
  vertex(472, 308);
  vertex(475, 335);
  vertex(473, 380);
  vertex(474, 471);
  vertex(330, 460);
  vertex(384, 459);
  vertex(343, 461);
  vertex(350, 339);
  vertex(355, 316);
  vertex(334, 329);
  vertex(354, 301);
  vertex(320, 314);
  vertex(333, 298);
  vertex(327, 295);
  vertex(341, 290);
  vertex(341, 277);
  vertex(353, 279);
  vertex(353, 262);
  vertex(378, 272);
  vertex(363, 251);
  endShape();
}
  function drawFin() {
  fill("black");
  beginShape();
  vertex(342, 462);
  vertex(343, 576);
  vertex(473, 577);
  vertex(474, 467);
  vertex(473, 601);
  vertex(504, 660);
  vertex(449, 620);
  vertex(449, 672);
  vertex(333, 669);
  vertex(336, 610);
  vertex(299, 644);
  vertex(343, 570);
  vertex(299, 643);
  vertex(336, 610);
  vertex(334, 720);
  vertex(244, 769);
  vertex(507, 763);
  vertex(457, 725);
  vertex(450, 670);
  endShape();
}
  function drawEye() {
  fill("red");
  beginShape();
  curveVertex(385, 303); // control point
  curveVertex(385, 303);
  curveVertex(362, 332);
  curveVertex(389, 329);
  curveVertex(382, 305);
  curveVertex(382, 305);
  curveVertex(382, 305); // control point
  endShape();
}
  function drawDog() {
fill("black");
  beginShape();
  curveVertex(710, 183); // control point
  curveVertex(710, 183);
  curveVertex(634, 179);
  curveVertex(647, 112);
  curveVertex(665, 105);
  curveVertex(670, 68);
  curveVertex(678, 90);
  curveVertex(685, 68);
  curveVertex(691, 86);
  curveVertex(699, 93);
  curveVertex(713, 102);
  curveVertex(693, 105);
  curveVertex(692, 125);
  curveVertex(692, 141);
  curveVertex(692, 151);
  curveVertex(692, 165);
  curveVertex(692, 184);
  curveVertex(692, 184); // control point
  endShape();
}

  
}
  
  


