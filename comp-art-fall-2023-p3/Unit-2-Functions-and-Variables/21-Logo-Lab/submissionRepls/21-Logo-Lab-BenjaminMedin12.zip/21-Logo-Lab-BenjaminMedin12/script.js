function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("grey");
  
  fill("black");
  


  drawRhombus();
  
  drawMouseLines("white");


}

function drawRhombus() {
  fill("royalblue");
  beginShape();
  vertex(120, 18);
  vertex(34, 139);
  vertex(105, 295);
  vertex(269, 295);
  vertex(340, 139);
  vertex(252, 18);
  vertex(144, 18);
  endShape();
  fill("DarkSlateGray");
  beginShape();
  vertex(113, 52);
  vertex(113, 72);
  vertex(260, 71);
  vertex(260, 53);
  vertex(114, 52);
  endShape();
fill("DarkSlateGray");
  beginShape();
  vertex(113, 52);
  vertex(96, 72);
  vertex(113, 72);
  endShape();
  beginShape();
  vertex(260, 52);
  vertex(274, 71);
  vertex(260, 71);
  endShape();
  fill("DarkSlateGray");
  beginShape();
  vertex(168, 72);
  vertex(168, 258);
  vertex(204, 258);
  vertex(199, 72);
  endShape();
  
  fill("maroon");
  beginShape();
  vertex(99, 118);
  vertex(99, 169);
  vertex(55, 154);
  vertex(97, 177);
  vertex(100, 221);
  vertex(104, 181);
  vertex(148, 169);
  vertex(104, 171);
  vertex(99, 118);
  endShape();
fill("magenta");
  beginShape();
  vertex(252, 172);
  vertex(251, 205);
  vertex(216, 204);
  vertex(250, 212);
  vertex(253, 244);
  vertex(257, 213);
  vertex(289, 213);
  vertex(257, 205);
  vertex(252, 172);
  endShape();
  
  
  
}