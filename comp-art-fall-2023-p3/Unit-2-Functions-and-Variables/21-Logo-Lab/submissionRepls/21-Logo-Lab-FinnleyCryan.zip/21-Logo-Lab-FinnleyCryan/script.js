function setup() {
  let myCanvas = createCanvas(402, 300);
  myCanvas.parent("myCanvas");
  //createConsole("lines");
  textAlign(CENTER, CENTER);
  cx = width/1.5 //x must be divisible by 1.5
  cy = height/2+45 //center values for drawValve(), moves whole logo
}

function draw() {
  background(255);
  fill(65);
  strokeWeight(0);
  drawMDB();
  drawValve();
  drawMouseLines(0);
}

function drawMDB() {
  mx=cx-220
  my=cy-75 //top left values for the MDB, moves the letters left of valve
  rect(mx, my, 22, 90);
  quad(mx+22, my, mx+22, my+30, mx+47, my+55, mx+47, my+25); //topL, botL, botR, topR
  quad(mx+47, my+25, mx+47, my+55, mx+72, my+30, mx+72, my);
  
  rect(mx+72, my, 22, 90);

  arc(mx+94, my+45, 100, 90, 1.5 * PI, PI / 2) //D outer line
  fill(255)
  arc(mx+94, my+45, 60, 55, 1.5 * PI, PI / 2) //D cutout
  fill(65)

  bx=mx+144 //top left x value for B
  rect(bx, my, 22, 90)
  arc(bx+22, my+30, 75, 60, 1.5 * PI, PI / 2)
  arc(bx+22, my+60, 75, 60, 1.5 * PI, PI / 2) //B outer lines
  fill(255)
  arc(bx+22, my+26, 45, 28, 1.5 * PI, PI / 2)
  arc(bx+22, my+64, 45, 28, 1.5 * PI, PI / 2) //B cutouts
}

function drawValve() {
  fill("red")
  arc(cx-1.5, cy-1.5, 27, 27, PI, 1.5 * PI) //topL
  fill("blue")
  arc(cx+1.5, cy+1.5, 27, 27, 0, PI/2) //botR
  fill("#efed00")
  arc(cx+1.5, cy-1.5, 27, 27, 1.5 * PI, 0) //topR
  fill("#00a000")
  arc(cx-1.5, cy+1.5, 27, 27, PI/2, PI) //botL
  fill(255)
  circle(cx-1.5, cy-1.5, 10) //topL
  circle(cx+1.5, cy+1.5, 10) //botR
  circle(cx+1.5, cy-1.5, 10) //topR
  circle(cx-1.5, cy+1.5, 10) //botL
}

