function setup() {
  let myCanvas = createCanvas(600,600);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  fill("black");
 


  drawRhombus();
  
  drawMouseLines("black");


}

function drawRhombus() {
   fill("white");
  beginShape();
  //vertex(295, 327)
  //vertex(35, 220)
  //vertex(32, 445)
  //vertex(234, 106)
  //vertex(98, 384)
  //vertex(293, 326)





fill("black")
circle(400,200,100)
  fill("white")                  
circle(200,200,100)
 
circle(300,300,200)
fill("black")
  arc(300,300,200,200,130,260, CHORD)
  arc(300,300,200,200,72,199, CHORD)

  vertex(280, 203);
  vertex(328, 215);
  vertex(282, 211);
  vertex(312, 240);
  vertex(287, 259);
  vertex(330, 321);
  vertex(286, 300);
  vertex(326, 329);
  vertex(278, 343);
  vertex(332, 395);
 vertex(252, 335);
  vertex(252, 239);

















  
  endShape();

  





  
}
