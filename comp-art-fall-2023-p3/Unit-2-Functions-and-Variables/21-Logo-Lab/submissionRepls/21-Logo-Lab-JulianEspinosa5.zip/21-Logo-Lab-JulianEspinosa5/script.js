function setup() {
  let myCanvas = createCanvas(800,800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  fill("black");
  //text("Create a logo for either a real or imagined brand.", 200, 200);


  drawlemonade();
  drawlip()
  drawtop()
  drawlemon()
  drawnapkin()
   drawstraw()
  drawsign()
  //drawline()
  
  drawLeftEye()
  drawrighteye()
  
  drawMouseLines("black");


}

function drawRhombus() {
   fill("pink");
  beginShape();
  vertex(212, 77);
  vertex(162, 140);
  vertex(255, 161);
  vertex(306, 81);
  vertex(212, 77);
  endShape();
}

  function drawlemonade() {
   fill("yellow");

  
    noStroke()
    
    triangle(471, 300,386, 465,298, 448)
    stroke("black")
     beginShape()
    vertex(298, 448);
  vertex(295, 433);
  vertex(295, 425);
  vertex(302, 412);
  vertex(305, 404);
  vertex(307, 401);
  vertex(305, 393);
  vertex(303, 389);
  vertex(303, 384);
  vertex(303, 380);
  vertex(296, 379);
  vertex(291, 378);
  vertex(294, 374);
  vertex(296, 372);
  vertex(298, 369);
  vertex(298, 364);
  vertex(299, 359);
  vertex(299, 355);
  vertex(298, 348);
  vertex(296, 342);
  vertex(471, 300);
   
  endShape();
  beginShape();
  vertex(471, 300);
  vertex(484, 355);
  vertex(490, 415);
  vertex(488, 468);
  vertex(479, 524);
  vertex(468, 566);
  vertex(375, 545);
  vertex(318, 542);
  vertex(287, 541);
  vertex(300, 491);
  vertex(301, 478);
  vertex(290, 483);
  vertex(281, 453);
  vertex(303, 447);
  vertex(330, 446);
  vertex(357, 451);
  vertex(380, 461);
  vertex(386, 465);
    endShape()

   
   
}
function drawlip() {
   fill("yellow");
  beginShape();
  vertex(302, 478);
  vertex(318, 472);
  vertex(333, 472);
  vertex(343, 471);
  vertex(351, 472);
  endShape();
}


function drawLeftEye() {
   fill("yellow");
  beginShape();
  vertex(303, 380);
  vertex(312, 376);
  vertex(318, 375);
  vertex(322, 377);
  vertex(325, 380);
  vertex(329, 383);
  vertex(334, 385);
  vertex(338, 384);
  vertex(342, 383);
  vertex(345, 381);
  vertex(348, 379);
  vertex(349, 377);
  vertex(351, 375);
  endShape();
  
   fill("white");
  beginShape();
  vertex(341, 384);
  vertex(336, 394);
  vertex(330, 398);
  vertex(321, 398);
  vertex(314, 397);
  vertex(310, 397);
  vertex(305, 396);
  vertex(304, 391);
  vertex(303, 382);
  vertex(309, 378);
  vertex(318, 375);
  vertex(323, 378);
  vertex(329, 383);
  vertex(334, 386);
  vertex(340, 384);
  endShape();
}
    function drawShape() {
   fill("yellow");
  beginShape();
  vertex(342, 384);
  vertex(337, 393);
  vertex(335, 399);
  vertex(333, 402);
  vertex(328, 406);
  vertex(325, 407);
  endShape();
}
function drawrighteye() {
   fill("yellow");
  beginShape();
  vertex(378, 362);
  vertex(375, 373);
  vertex(377, 377);
  vertex(380, 379);
  vertex(384, 381);
  vertex(389, 381);
  vertex(395, 380);
  vertex(402, 379);
  vertex(408, 377);
  vertex(412, 377);
  vertex(417, 376);
  vertex(423, 375);
  vertex(431, 373);
  vertex(438, 370);
  vertex(443, 369);
  vertex(447, 368);
  vertex(453, 368);
  vertex(456, 368);
  endShape();

   fill("white");
  beginShape();
  vertex(377, 378);
  vertex(379, 390);
  vertex(383, 395);
  vertex(390, 398);
  vertex(399, 401);
  vertex(407, 400);
  vertex(415, 398);
  vertex(422, 395);
  vertex(428, 390);
  vertex(430, 385);
  vertex(433, 379);
  vertex(436, 374);
  vertex(438, 371);
  vertex(422, 375);
  vertex(416, 376);
  vertex(407, 378);
  vertex(399, 379);
  vertex(389, 381);
  vertex(383, 381);
  vertex(380, 379);
  vertex(377, 377);
  endShape();
}
function drawtop() {
   fill("yellow");
  beginShape();
  vertex(296, 342);
  vertex(311, 329);
  vertex(341, 319);
  vertex(375, 311);
  vertex(407, 303);
  vertex(431, 298);
  vertex(451, 296);
  vertex(470, 299);
  vertex(471, 301);
  endShape();
}
function drawlemon() {
   fill("yellow");
  beginShape();
  vertex(429, 309);
  vertex(425, 283);
  vertex(434, 266);
  vertex(454, 257);
  vertex(471, 259);
  vertex(486, 265);
  vertex(494, 276);
  vertex(498, 287);
  vertex(499, 292);
  vertex(501, 301);
  vertex(500, 308);
  vertex(499, 311);
  vertex(497, 315);
  vertex(494, 319);
  vertex(491, 322);
  vertex(486, 324);
  vertex(483, 325);
  vertex(481, 325);
  vertex(477, 326);
  vertex(474, 316);
  vertex(469, 298);
  vertex(463, 289);
  vertex(477, 261);
  vertex(463, 289);
  vertex(496, 282);
  vertex(463, 289);
  vertex(495, 317);
  vertex(436, 265);
  vertex(464, 290);
  vertex(428, 302);
  vertex(430, 311);
  vertex(437, 308);
  vertex(431, 281);
  vertex(440, 268);
  vertex(454, 263);
  vertex(476, 267);
  vertex(490, 284);
  vertex(492, 314);
  vertex(476, 323);
  endShape();
}
function drawnapkin() {
   fill("red");
  beginShape();
  vertex(486, 474);
  vertex(497, 473);
  vertex(496, 483);
  vertex(491, 486);
  vertex(484, 484);
  vertex(486, 474);
  vertex(503, 450);
  vertex(496, 474);
  vertex(497, 484);
  vertex(492, 508);
  vertex(484, 484);
  vertex(486, 474);
  vertex(290, 502);
  vertex(269, 603);
  vertex(486, 485);
  endShape();
}
function drawstraw() {
   fill("green");
  beginShape();
  vertex(331, 333);
  vertex(322, 230);
  vertex(327, 231);
  vertex(333, 231);
  vertex(336, 229);
  vertex(332, 226);
  vertex(327, 226);
  vertex(322, 231);
  vertex(331, 335);
  vertex(348, 330);
  vertex(336, 229);
  endShape();
 beginShape();
  vertex(329, 232);
  vertex(327, 286);
  vertex(321, 232);
  vertex(323, 231);
  vertex(329, 232);
  endShape();
}
function drawsign() {
   fill("gainsboro");
  beginShape();
  vertex(319, 522);
  vertex(310, 519);
  vertex(313, 508);
  vertex(306, 508);
  vertex(305, 520);
  vertex(298, 522);
  vertex(297, 529);
  vertex(304, 532);
  vertex(303, 537);
  vertex(298, 539);
  vertex(294, 535);
  vertex(292, 538);
  vertex(294, 543);
  vertex(297, 543);
  vertex(301, 543);
  vertex(302, 550);
  vertex(307, 551);
  vertex(307, 545);
  vertex(314, 543);
  vertex(316, 539);
  vertex(313, 535);
  vertex(307, 532);
  vertex(308, 530);
  vertex(310, 526);
  vertex(316, 528);
  vertex(319, 524);
  vertex(319, 523);
  endShape();
}


