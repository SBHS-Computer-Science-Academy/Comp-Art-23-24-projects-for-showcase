function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  
  fill("black");
  //text("Create a logo for either a real or imagined brand.", 200, 200);


  //drawRhombus();
  drawCircle()
  drawShape()
  drawStar()
  drawSpot1()
  drawSpot2()
  drawSpot3()
  drawSpot4()
  drawSpot5()
  drawSpot6()
  drawSpot7()
  drawSpot8()
  drawMouseLines("black");


}

function drawRhombus() {
   fill("pink");
  beginShape();
  vertex(212, 77);
  vertex(162, 140);
  vertex(255, 161);
  vertex(306, 81);
  vertex(212, 77);
  endShape();
}

function drawCircle() {
  strokeWeight(4);
  stroke('navy');
    beginShape();
  
  endShape();
fill('cornflowerblue');
circle(300,300,300); 
}

function drawShape() {
  strokeWeight(6);
  stroke('Navy'); //NASA
  textSize(70);
  fill('white');
  text("NASA",300,300);
  strokeWeight(6);
  stroke('red');
  noFill();
  // fill("black");

  translate(300, 300)
  rotate(frameCount*0.6);
  translate(-300,-300)
  beginShape();
  curveVertex(154, 346); // control point
  curveVertex(154, 346);
  curveVertex(83, 398);
  curveVertex(535, 223);
  curveVertex(440, 240);
  curveVertex(440, 240); // control point
  endShape();
  

} //text in here



function drawStar() {
  stroke('white');
  strokeWeight(4);
  //fill("white");
  beginShape();
  
  endShape();
}

function drawSpot1() {
  fill("white");
  beginShape();
  curveVertex(206, 400); // control point
  curveVertex(206, 400);
  curveVertex(210, 407);
  curveVertex(220, 405);
  curveVertex(225, 399);
  curveVertex(224, 392);
  curveVertex(215, 386);
  curveVertex(207, 388);
  curveVertex(201, 394);
  curveVertex(206, 401);
  curveVertex(206, 401); // control point
  endShape();
}

function drawSpot2() {
  // fill("black");
  beginShape();
  curveVertex(241, 417); // control point
  curveVertex(241, 417);
  curveVertex(241, 423);
  curveVertex(246, 429);
  curveVertex(257, 430);
  curveVertex(261, 426);
  curveVertex(261, 418);
  curveVertex(253, 413);
  curveVertex(244, 416);
  curveVertex(242, 419);
  curveVertex(242, 419); // control point
  endShape();
}

function drawSpot3() {
  // fill("black");
  beginShape();
  curveVertex(288, 434); // control point
  curveVertex(288, 434);
  curveVertex(293, 439);
  curveVertex(301, 434);
  curveVertex(295, 430);
  curveVertex(289, 431);
  curveVertex(289, 435);
  curveVertex(289, 435); // control point
  endShape();
}

function drawSpot4() {
  // fill("black");
  beginShape();
  curveVertex(412, 222); // control point
  curveVertex(412, 222);
  curveVertex(411, 219);
  curveVertex(401, 219);
  curveVertex(393, 226);
  curveVertex(393, 234);
  curveVertex(401, 241);
  curveVertex(413, 241);
  curveVertex(421, 238);
  curveVertex(423, 228);
  curveVertex(419, 221);
  curveVertex(412, 221);
  curveVertex(412, 221); // control point
  endShape();
}

function drawSpot5() {
  // fill("black");
  beginShape();
  curveVertex(382, 195); // control point
  curveVertex(382, 195);
  curveVertex(380, 191);
  curveVertex(369, 186);
  curveVertex(360, 192);
  curveVertex(362, 204);
  curveVertex(372, 207);
  curveVertex(380, 206);
  curveVertex(385, 199);
  curveVertex(383, 195);
  curveVertex(383, 195); // control point
  endShape();
}

function drawSpot6() {
  // fill("black");
  beginShape();
  curveVertex(336, 169); // control point
  curveVertex(336, 169);
  curveVertex(340, 173);
  curveVertex(341, 177);
  curveVertex(337, 183);
  curveVertex(331, 183);
  curveVertex(328, 181);
  curveVertex(327, 176);
  curveVertex(330, 171);
  curveVertex(337, 170);
  curveVertex(337, 170);
  curveVertex(337, 170); // control point
  endShape();
}

function drawSpot7() {
  // fill("black");
  beginShape();
  curveVertex(324, 438); // control point
  curveVertex(324, 438);
  curveVertex(322, 438);
  curveVertex(324, 434);
  curveVertex(329, 435);
  curveVertex(328, 439);
  curveVertex(323, 439);
  curveVertex(324, 439);
  curveVertex(324, 439); // control point
  endShape();
}

function drawSpot8() {
  // fill("black");
  beginShape();
  curveVertex(307, 163); // control point
  curveVertex(307, 163);
  curveVertex(307, 166);
  curveVertex(304, 171);
  curveVertex(299, 169);
  curveVertex(298, 167);
  curveVertex(298, 162);
  curveVertex(302, 161);
  curveVertex(307, 163);
  curveVertex(307, 164);
  curveVertex(307, 164); // control point
  endShape();
}