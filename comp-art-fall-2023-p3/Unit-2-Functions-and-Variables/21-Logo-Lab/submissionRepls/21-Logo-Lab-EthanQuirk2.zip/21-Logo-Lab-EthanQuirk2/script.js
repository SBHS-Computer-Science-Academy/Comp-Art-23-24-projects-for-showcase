function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  fill("black");
  //text("Create a logo for either a real or imagined brand.", 200, 200);


  //drawRhombus();
  noFill()
  drawA()
  drawB()
  drawC()
  drawD()
  drawE()
  drawF()
  drawG()
  drawH()
  drawI()
  drawJ()
  drawK()
  drawL()
  drawM()
  drawN()
  drawO()
  drawP()
  drawQ()
  drawR()
  drawS()
  drawT()
  drawU()
  drawV()
  drawW()
  drawX()
  drawY()
  drawZ()
  drawAA()
  drawAB()
  drawAC()
  drawAD()
  drawAE()
  drawAF()
  drawAG()
  drawAH()
  drawAI()
  drawAJ()
  drawAK()
  drawAL()
  drawMouseLines("black");


}

function drawRhombus() {
   fill("pink");
  beginShape();
  vertex(212, 77);
  vertex(162, 140);
  vertex(255, 161);
  vertex(306, 81);
  vertex(212, 77);
  endShape();
}
function drawA() {
   //fill("black");
  beginShape();
  vertex(108, 76);
  vertex(84, 42);
  endShape();
}
function drawB() {
  // fill("black");
  beginShape();
  curveVertex(108, 76); // control point
  curveVertex(108, 76);
  curveVertex(183, 64);
  curveVertex(258, 76);
  curveVertex(258, 76); // control point
  endShape();
}
function drawC() {
  // fill("black");
  beginShape();
  vertex(258, 76);
  vertex(275, 42);
  endShape();
}
function drawD() {
  // fill("black");
  beginShape();
  vertex(275, 42);
  vertex(249, 54);
  vertex(244, 12);
  vertex(207, 40);
  vertex(191, 8);
  vertex(169, 40);
  vertex(129, 14);
  vertex(118, 45);
  vertex(84, 42);
  endShape();
}
function drawE() {
  // fill("black");
  beginShape();
  vertex(226, 81);
  vertex(239, 100);
  vertex(244, 87);
  endShape();
}
function drawF() {
  // fill("black");
  beginShape();
  curveVertex(244, 87); // control point
  curveVertex(244, 87);
  curveVertex(278, 94);
  curveVertex(304, 110);
  curveVertex(304, 110); // control point
  endShape();
}
function drawG() {
  // fill("black");
  beginShape();
  vertex(304, 110);
  vertex(309, 130);
  vertex(251, 104);
  vertex(248, 117);
  vertex(222, 102);
  vertex(168, 117);
  vertex(174, 122);
  vertex(156, 130);
  vertex(168, 131);
  endShape();
}
function drawH() {
  // fill("black");
  beginShape();
  curveVertex(168, 131); // control point
  curveVertex(168, 131);
  curveVertex(188, 156);
  curveVertex(256, 158);
  curveVertex(256, 158); // control point
  endShape();
}
function drawI() {
  // fill("black");
  beginShape();
  vertex(257, 158);
  vertex(232, 136);
  endShape();
}
function drawJ() {
  // fill("black");
  beginShape();
  vertex(232, 136);
  vertex(202, 137);
  vertex(187, 126);
  vertex(210, 117);
  vertex(235, 125);
  vertex(240, 118);
  vertex(239, 130);
  vertex(265, 153);
  endShape();
}
function drawK() {
   //fill("black");
  beginShape();
  vertex(265, 153);
  vertex(271, 159);
  vertex(282, 156);
  vertex(302, 156);
  vertex(311, 159);
  vertex(284, 135);
  vertex(281, 127);
  endShape();
}
function drawL() {
  // fill("black");
  beginShape();
  vertex(281, 127);
  vertex(314, 155);
  vertex(316, 147);
  endShape();
}
function drawM() {
  // fill("black");
  beginShape();
  vertex(288, 133);
  vertex(290, 124);
  vertex(303, 133);
  vertex(298, 138);
  vertex(298, 141);
  endShape();
}
function drawN() {
  // fill("black");
  beginShape();
  vertex(270, 171);
  vertex(206, 189);
  vertex(220, 223);
  endShape();
}
function drawO() {
  // fill("black");
  beginShape();
  curveVertex(221, 224); // control point
  curveVertex(221, 224);
  curveVertex(250, 219);
  curveVertex(285, 197);
  curveVertex(285, 197); // control point
  endShape();
}
function drawP() {
  // fill("black");
  beginShape();
  vertex(285, 197);
  vertex(282, 177);
  vertex(270, 171);
  endShape();
}
function drawQ() {
  // fill("black");
  beginShape();
  vertex(315, 169);
  vertex(295, 178);
  vertex(297, 195);
  vertex(317, 209);
  endShape();
}
function drawR() {
  // fill("black");
  beginShape();
  curveVertex(315, 169); // control point
  curveVertex(315, 169);
  curveVertex(322, 180);
  curveVertex(322, 193);
  curveVertex(318, 209);
  curveVertex(318, 209); // control point
  endShape();
}
function drawS() {
   // fill("black");
  beginShape();
  curveVertex(317, 147); // control point
  curveVertex(317, 147);
  curveVertex(348, 206);
  curveVertex(347, 249);
  curveVertex(340, 264);
  curveVertex(340, 264); // control point
  endShape();
}
function drawT() {
  // fill("black");
  beginShape();
  vertex(283, 206);
  vertex(299, 204);
  vertex(317, 219);
  endShape();
}
function drawU() {
  // fill("black");
  beginShape();
  curveVertex(283, 206); // control point
  curveVertex(283, 206);
  curveVertex(257, 226);
  curveVertex(225, 233);
  curveVertex(225, 233); // control point
  endShape();
}
function drawV() {
  // fill("black");
  beginShape();
  vertex(225, 234);
  vertex(231, 252);
  vertex(268, 236);
  vertex(281, 261);
  endShape();
}
function drawW() {
  // fill("black");
  beginShape();
  curveVertex(317, 219); // control point
  curveVertex(317, 219);
  curveVertex(312, 248);
  curveVertex(282, 262);
  curveVertex(282, 262); // control point
  endShape();
}
function drawX() {
  // fill("black");
  beginShape();
  vertex(340, 264);
  vertex(331, 258);
  endShape();
}
function drawY() {
  // fill("black");
  beginShape();
  curveVertex(226, 81); // control point
  curveVertex(226, 81);
  curveVertex(170, 83);
  curveVertex(135, 92);
  curveVertex(135, 92); // control point
  endShape();
}
function drawZ() {
  // fill("black");
  beginShape();
  curveVertex(135, 92); // control point
  curveVertex(135, 92);
  curveVertex(142, 96);
  curveVertex(146, 108);
  curveVertex(146, 108); // control point
  endShape();
}
function drawAA() {
  // fill("black");
  beginShape();
  curveVertex(146, 109); // control point
  curveVertex(146, 109);
  curveVertex(136, 100);
  curveVertex(126, 101);
  curveVertex(122, 105);
  curveVertex(116, 117);
  curveVertex(122, 132);
  curveVertex(122, 132); // control point
  endShape();
}
function drawAB() {
  // fill("black");
  beginShape();
  curveVertex(122, 133); // control point
  curveVertex(122, 133);
  curveVertex(108, 120);
  curveVertex(106, 101);
  curveVertex(106, 101); // control point
  endShape();
}
function drawAC() {
  // fill("black");
  beginShape();
  curveVertex(106, 101); // control point
  curveVertex(106, 101);
  curveVertex(83, 125);
  curveVertex(73, 143);
  curveVertex(73, 143); // control point
  endShape();
}
function drawAD() {
  // fill("black");
  beginShape();
  vertex(73, 144);
  vertex(83, 144);
  endShape();
}
function drawAE() {
  // fill("black");
  beginShape();
  curveVertex(84, 145); // control point
  curveVertex(84, 145);
  curveVertex(62, 191);
  curveVertex(61, 220);
  curveVertex(61, 220); // control point
  endShape();
}
function drawAF() {
  // fill("black");
  beginShape();
  vertex(62, 221);
  vertex(82, 218);
  endShape();
}
function drawAG() {
  // fill("black");
  beginShape();
  curveVertex(83, 218); // control point
  curveVertex(83, 218);
  curveVertex(83, 266);
  curveVertex(89, 284);
  curveVertex(89, 284); // control point
  endShape();
}
function drawAH() {
  // fill("black");
  beginShape();
  vertex(90, 284);
  vertex(128, 244);
  endShape();
}
function drawAI() {
  // fill("black");
  beginShape();
  curveVertex(129, 245); // control point
  curveVertex(129, 245);
  curveVertex(140, 275);
  curveVertex(130, 321);
  curveVertex(130, 321); // control point
  endShape();
}
function drawAJ() {
beginShape();
  curveVertex(130, 321); // control point
  curveVertex(130, 321);
  curveVertex(144, 324);
  curveVertex(198, 325);
  curveVertex(235, 311);
  curveVertex(235, 311); // control point
  endShape();
}
function drawAK() {
  // fill("black");
  beginShape();
  vertex(235, 311);
  vertex(248, 328);
  endShape();
}
function drawAL() {
  // fill("black");
  beginShape();
  curveVertex(331, 258); // control point
  curveVertex(331, 258);
  curveVertex(328, 277);
  curveVertex(314, 301);
  curveVertex(287, 318);
  curveVertex(247, 329);
  curveVertex(247, 329); // control point
  endShape();
}