function setup() {
  let myCanvas = createCanvas(500, 500);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
 



  drawE()
  drawMouseLines("black");
  drawR()
  drawK()
  drawY()
  draw0()
  drawT()
  drawP()
  drawF()
  drawL()

 



}



function drawE() {
  fill("black");
  beginShape();
  vertex(52, 231);
  vertex(53, 475);
  vertex(159, 475);
  vertex(158, 436);
  vertex(84, 436);
  vertex(83, 372);
  vertex(127, 372);
  vertex(125, 339);
  vertex(83, 339);
  vertex(81, 249);
  vertex(186, 249);
  vertex(184, 219);
  vertex(51, 219);
  vertex(51, 239);
  endShape();
}

function drawR() {
  fill("black");
  beginShape();
  vertex(201, 472);
  vertex(194, 287);
  vertex(296, 285);
  vertex(298, 365);
  vertex(248, 365);
  vertex(309, 468);
  vertex(270, 468);
  vertex(246, 420);
  vertex(250, 468);
  vertex(200, 471);
  endShape();
}

function drawK() {
  // fill("black");
  beginShape();
  vertex(348, 464);
  vertex(343, 211);
  vertex(385, 210);
  vertex(387, 330);
  vertex(422, 209);
  vertex(461, 208);
  vertex(413, 365);
  vertex(478, 457);
  vertex(428, 458);
  vertex(391, 392);
  vertex(396, 460);
  vertex(347, 462);
  endShape();
}

function drawY() {
 fill("yellow");
  beginShape();
  vertex(207, 190);
  vertex(15, 192);
  vertex(15, 139);
  vertex(205, 189);
  endShape();

}

function draw0(){ 
  fill("orange");
  beginShape();
  vertex(26, 113);
  vertex(205, 179);
  vertex(82, 58);
  vertex(27, 113);
  endShape();
}

function drawT(){ 
fill("red");
  beginShape();
  vertex(230, 179);
  vertex(119, 35);
  vertex(209, 26);
  vertex(229, 176);
  endShape();
}





function drawL(){
  fill("green");
  beginShape();
  vertex(313, 182);
  vertex(424, 56);
  vertex(471, 56);
  vertex(312, 183);
  endShape();
}
function drawL() {
  fill("green");
  beginShape();
  vertex(323, 187);
  vertex(440, 51);
  vertex(471, 88);
  vertex(323, 188);
  endShape();
}

function drawP() {
  fill("purple");
  beginShape();
  vertex(282, 181);
  vertex(350, 16);
  vertex(247, 15);
  vertex(282, 178);
  endShape();
}

function drawF() {
  fill("DeepSkyBlue");
  beginShape();
  vertex(300, 181);
  vertex(361, 21);
  vertex(424, 45);
  vertex(299, 182);
  endShape();
}



