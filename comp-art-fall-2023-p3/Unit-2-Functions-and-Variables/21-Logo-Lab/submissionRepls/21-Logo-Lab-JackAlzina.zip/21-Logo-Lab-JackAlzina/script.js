function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  fill("White");
  text("Spotify.",200, 200)
  fill("black");
noStroke()
   fill("DarkGreen");
  circle(198, 198, 375)
 fill("Green");
  circle(198, 198, 350)
drawTopArk()
drawArk()
  drawLoop()
  drawMouseLines("black");


}   

function drawRhombus() {
   fill("pink");
  beginShape();
  vertex(212, 77);
  vertex(212, 140);
  vertex(212, 161);
  vertex(312, 81);
  vertex(212, 77);
  endShape();
}
function drawTopArk() {
  
  fill("black");
  beginShape();

  // fill("black");
  beginShape();
 curveVertex(75, 89); // control point
  curveVertex(75, 89);
  curveVertex(131, 68);
  curveVertex(204, 61);
  curveVertex(263, 68);
  curveVertex(324, 90);
  curveVertex(348, 119);
  curveVertex(338, 145);
  curveVertex(296, 116);
  curveVertex(118, 101);
  curveVertex(79, 119);
  curveVertex(75, 90);
  curveVertex(140, 68);
  curveVertex(140, 68); // control point
  endShape();
}


function drawArk() {
   fill("black");
  // fill("black");
  beginShape();
 curveVertex(62, 175); // control point
  curveVertex(62, 175);
  curveVertex(122, 152);
  curveVertex(281, 155);
  curveVertex(330, 184);
  curveVertex(329, 204);
  curveVertex(298, 185);
  curveVertex(183, 180);
  curveVertex(107, 175);
  curveVertex(67, 196);
  curveVertex(62, 174);
  curveVertex(94, 160);
  curveVertex(94, 160); // control point
  endShape();
}
function drawLoop() {
   fill("black");
  // fill("black");
  beginShape();
  curveVertex(87, 261); // control point
  curveVertex(87, 261);
  curveVertex(126, 252);
  curveVertex(270, 259);
  curveVertex(308, 270);
  curveVertex(315, 248);
  curveVertex(282, 226);
  curveVertex(175, 221);
  curveVertex(107, 221);
  curveVertex(81, 226);
  curveVertex(68, 257);
  curveVertex(92, 260);
  curveVertex(97, 256);
  curveVertex(97, 256); // control point
  endShape();
  fill
  text('Spotify',188, 303
      )
}
