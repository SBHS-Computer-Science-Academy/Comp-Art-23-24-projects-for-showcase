function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  fill("black")
  

let s = 'FABI SOSA BARBER SHOP';
fill("black");
textSize(30)
text(s, 100, 50, 90, 150); // Text wraps within text box
  
  drawRed()
  drawBlue()
  drawBlue2()
  drawRed2()
  drawOutline()
  drawMouseLines("black");
  drawDesign()
  drawBottom()

  translate(300,0)
  drawRed()
  drawBlue()
  drawBlue2()
  drawRed2()
  drawOutline()
  drawMouseLines("black");
  
  drawBottom()
}



function drawOutline() {
 noFill()
  stroke("black")
 beginShape();
  vertex(19, 174);
 vertex(20, 89);
  vertex(64, 89);
 vertex(59, 175);
  vertex(18, 174);
 endShape();

  circle(42,70,35)
  fill("black")
  rect(20,80,45,10)
 
  fill("black");
  text(".",  200, 200);
}

function drawRed() {
  fill("red");
  beginShape();
  vertex(19, 111);
  vertex(61, 98);
  vertex(60, 110);
  vertex(20, 122);
  vertex(20, 111);
  endShape();
}


function drawBlue() {
   fill("blue");
  beginShape();
  vertex(21, 98);
  vertex(44, 93);
  vertex(20, 93);
  vertex(21, 98);
  endShape();
}

function drawBlue2() {
  fill("blue");
  beginShape();
  vertex(59, 122);
  vertex(21, 133);
  vertex(21, 146);
  vertex(61, 132);
  vertex(60, 122);
  endShape();
}

function drawRed2() {
  fill("red");
  beginShape();
  vertex(20, 156);
  vertex(59, 146);
  vertex(60, 158);
  vertex(20, 164);
  vertex(20, 157);
  endShape();
}

function drawDesign() {
  // fill("black");
  beginShape();
  vertex(34, 251);
  vertex(72, 247);
  vertex(82, 243);
  vertex(91, 236);
  vertex(104, 216);
  vertex(53, 281);
  vertex(77, 253);
  vertex(97, 249);
  vertex(134, 253);
  vertex(151, 280);
  vertex(119, 218);
  vertex(137, 243);
  vertex(153, 248);
  vertex(179, 249);
  vertex(199, 240);
  vertex(208, 235);
  endShape();
}

function drawBottom() {
   fill("black");
  beginShape();
  vertex(29, 180);
  vertex(15, 179);
  vertex(11, 183);
  vertex(13, 186);
  vertex(22, 186);
  vertex(21, 191);
  vertex(28, 196);
  vertex(36, 196);
  vertex(46, 196);
  vertex(51, 195);
  vertex(55, 187);
  vertex(59, 187);
  vertex(63, 187);
  vertex(64, 186);
  vertex(64, 182);
  vertex(25, 181);
  endShape();
}