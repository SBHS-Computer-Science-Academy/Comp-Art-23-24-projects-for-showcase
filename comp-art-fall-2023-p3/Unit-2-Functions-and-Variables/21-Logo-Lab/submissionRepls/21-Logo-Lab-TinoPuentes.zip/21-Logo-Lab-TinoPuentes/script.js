
function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("sienna");
  
  fill("black");


  drawoutside();
  drawTopBun()
  drawBottomBun()
  letterB();
  drawletterU()
  drawletterR()
  drawletterG()
  drawletterE()
  drawletterR2()
  drawletterK()
  drawletterI()
  drawletterN()
  drawletterG2()
  drawcrown()
  
  
  
  

  drawMouseLines("black");


}

function drawoutside() {
fill('white')
circle(188, 180, 260, 160)
fill('blue')
 beginShape();
  vertex(159, 53);
  vertex(132, 63);
  vertex(111, 76);
  vertex(91, 94);
  vertex(76, 114);
  vertex(64, 140);
  vertex(60, 155);
  vertex(58, 170);
  vertex(58, 192);
  vertex(64, 220);
  vertex(78, 252);
  vertex(108, 283);
  vertex(144, 302);
  vertex(183, 310);
  vertex(198, 309);
  vertex(205, 289);
  vertex(146, 272);
  vertex(107, 244);
  vertex(90, 204);
  vertex(85, 173);
  vertex(97, 134);
  vertex(119, 105);
  vertex(156, 83);
  vertex(172, 74);
  vertex(201, 54);
  vertex(197, 51);
  vertex(175, 50);
  vertex(151, 56);
  endShape();

}

function drawTopBun(){
  fill('gold')
  beginShape();
  vertex(109, 149);
  vertex(124, 127);
  vertex(144, 110);
  vertex(167, 99);
  vertex(189, 90);
  vertex(210, 93);
  vertex(234, 98);
  vertex(252, 110);
  vertex(267, 123);
  vertex(253, 132);
  vertex(231, 139);
  vertex(208, 141);
  vertex(185, 145);
  vertex(165, 150);
  vertex(146, 155);
  vertex(132, 157);
  vertex(119, 159);
  vertex(111, 157);
  vertex(108, 157);
  vertex(109, 150);
  endShape(); 
  
  
  

  
 
}
function drawBottomBun() {
  // fill("black");
  beginShape();
  vertex(136, 230);
  vertex(180, 220);
  vertex(232, 213);
  vertex(279, 213);
  vertex(277, 227);
  vertex(256, 256);
  vertex(229, 264);
  vertex(196, 272);
  vertex(157, 257);
  vertex(134, 243);
  vertex(134, 230);
  vertex(137, 230);
  endShape();
}
function letterB() {
// fill("black");
  beginShape();
  vertex(118, 192);
  vertex(113, 164);
  vertex(132, 162);
  vertex(141, 169);
  vertex(134, 177);
  vertex(116, 180);
  vertex(134, 178);
  vertex(143, 182);
  vertex(147, 190);
  vertex(134, 197);
  vertex(120, 198);
  vertex(118, 191);
  endShape();
  
}
 function drawletterU() {
  // fill("black");
  beginShape();
  vertex(147, 161);
  vertex(154, 189);
  vertex(165, 192);
  vertex(174, 185);
  vertex(170, 157);
  endShape();
}
function drawletterR() {
  // fill("black");
  beginShape();
  vertex(185, 184);
  vertex(179, 153);
  vertex(197, 151);
  vertex(206, 155);
  vertex(206, 161);
  vertex(202, 165);
  vertex(183, 168);
  vertex(203, 169);
  vertex(205, 180);
  endShape();
  
}
function drawletterG() {
  // fill("black");
  beginShape();
  vertex(234, 146);
  vertex(218, 145);
  vertex(215, 155);
  vertex(218, 175);
  vertex(226, 177);
  vertex(237, 172);
  vertex(237, 162);
  vertex(231, 163);
  endShape();
}
function drawletterE() {
  // fill("black");
  beginShape();
  vertex(253, 142);
  vertex(242, 144);
  vertex(247, 171);
  vertex(257, 169);
  vertex(247, 171);
  vertex(244, 154);
  vertex(245, 158);
  vertex(255, 155);
  endShape();
}
function drawletterR2() {
  // fill("black");
  beginShape();
  vertex(269, 168);
  vertex(263, 137);
  vertex(278, 135);
  vertex(284, 143);
  vertex(266, 154);
  vertex(284, 157);
  vertex(291, 166);
  endShape();
}
function drawletterK() {
  // fill("black");
  beginShape();
  vertex(158, 193);
  vertex(161, 220);
  vertex(159, 204);
  vertex(168, 196);
  vertex(159, 205);
  vertex(174, 214);
  endShape();
}
function drawletterI() {
  // fill("black");
  beginShape();
  vertex(189, 187);
  vertex(192, 211);
  endShape();
}
function drawletterN() {
  // fill("black");
  beginShape();
  vertex(213, 204);
  vertex(209, 181);
  vertex(229, 202);
  vertex(227, 181);
  endShape();
}
function drawletterG2() {
  // fill("black");
  beginShape();
  vertex(254, 181);
  vertex(243, 180);
  vertex(241, 186);
  vertex(244, 202);
  vertex(256, 202);
  vertex(257, 194);
  vertex(252, 193);
  endShape();
}
function drawcrown() {
  // fill("black");
  beginShape();
  vertex(136, 45);
  vertex(151, 4);
  vertex(170, 31);
  vertex(186, 5);
  vertex(203, 31);
  vertex(222, 5);
  vertex(239, 60);
  vertex(207, 51);
  vertex(176, 51);
  vertex(144, 59);
  vertex(132, 63);
  vertex(126, 66);
  vertex(136, 45);
  endShape();
}
