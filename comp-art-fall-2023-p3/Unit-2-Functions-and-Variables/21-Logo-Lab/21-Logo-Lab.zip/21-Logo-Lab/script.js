function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  
  fill("black");
  text("Create a logo for either a real or imagined brand.", 200, 200);


  drawRhombus();
  
  drawMouseLines("black");


}

function drawRhombus() {
   fill("pink");
  beginShape();
  vertex(212, 77);
  vertex(162, 140);
  vertex(255, 161);
  vertex(306, 81);
  vertex(212, 77);
  endShape();
}

