//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()
function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear()
  noStroke()

  //Enter code below this line to call your gradient
  //gradientVertical((255, 0, 0), (200, 0, 0), 10)
  // let color1=color('red')
  // let color2=color('blue')

  // for(let i = 0; i<=1000; i+=10){

  //   fill(lerpColor(color1, color2, i/width))
  //   rect(i, 0, 20, 800)
  // }
  color1 = color('purple')
  color2 = color('yellow')
  color3=color(0)
  color4=color(255)
  //gradientVeritcal(color1, color2, 1000)
  gradientHorizontal(color1, color2, 100)
  //gradientVertical(color2, color1, 300)
  //gradientVertical(color1, color2, 100)
  //gradientVertical(color3, color4, 20)
  //gradientEllipse(color1, color2, 100, 1,1, 1)
  // gradientRect(color1, color2, 20)


}


function gradientVertical(clrStart, clrEnd, steps) {
  let stepsSize= width / steps;
  for (let v = 0; v <= width; v += stepsSize) {
    fill(lerpColor(clrStart, clrEnd, v / width))
    rect(v, 0, stepsSize, height)


  }
}
function gradientHorizontal(clrStart, clrEnd, steps ) {
  let StepSiz = height/steps
  for ( let f = 0; f <=height; f+=StepSiz){
    fill(lerpColor(clrStart, clrEnd, f/width))
    rect(0, f, width, StepSiz)
  }
}

function gradientEllipse(clrStart, clrEnd, steps, wr, hr, biggernumval, em ) {
  //let ratio = 
  let stEp = width/steps;

  

  for( let h = 0; h <= width; h+=stEp){
    fill(lerpColor(clrStart, clrEnd, (h/width)))
    ellipse(500, height/2, ((width-h)*wr)/biggernumval, ((height-h)*hr)/biggernumval)
  }


}



function gradientRect(clrStart, clrEnd, steps) {
  let StEp = width/2/steps;

  for(let p=0; p<=width/2; p+=StEp){
    
    fill(lerpColor(clrStart, clrEnd, p/width))
    rect(p, p, width-p*2, height-p*2)
  }
}