//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear()
  noStroke()
  text("Use for loops to create gradients", 400, 400)
  //Enter code below this line to call your gradient


  let color1 = color("darkblue")
  let color2 = color("aqua")

  //gradientVertical(color1, color2)
  gradientHorizontal(color1, color2)
  drawMouseLines("black");
}

function gradientVertical(color1, color2, steps) {

  noStroke()
  for (let i = 0; i <= width; i += 60) {
    fill(lerpColor(color1, color2, i / width))
    rect(i, 0, 60, height)
  }
}

function gradientHorizontal(color1, color2, steps = 1) {
  for (let i = 0; i <= height; i += steps) {
    fill(lerpColor(color1, color2, i / height))
    rect(0, i, width, steps)// enter code here to create your gradient
  }
}

function gradientEllipse(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}

function gradientRect(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}