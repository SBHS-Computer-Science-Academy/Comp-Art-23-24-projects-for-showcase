//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear()
  let color1 = color("pink")
  let color2 = color(195, 250, 209,10)
  noStroke();
  gradientVertical(color1, color2);
  gradientHorizontal(color1,color2);
  drawMouseLines("black");
}

function gradientVertical(color1, color2, steps=100) {
  let stepsize = width/steps
for (let i = 0; i <= width; i += stepsize) {
    fill(lerpColor(color1, color2, i / width))
    rect(i, 0, stepsize,height)
  }
}

function gradientHorizontal(color1, color2, steps = 100) {
  let stepsize = height/steps
for (let i = 0; i <= height; i += stepsize) {
    fill(lerpColor(color1, color2, i / height))
    rect(0, i, width,stepsize)
}
}

function gradientEllipse(clrStart, clrEnd, steps = 10) {

}

function gradientRect(clrStart, clrEnd, steps = 10) {

}