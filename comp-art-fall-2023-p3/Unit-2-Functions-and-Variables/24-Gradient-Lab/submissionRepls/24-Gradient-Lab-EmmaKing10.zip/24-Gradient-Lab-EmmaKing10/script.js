//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear()
  noStroke()
  let color1 = color(252,3,219)
  let color2 = color(252, 252, 3,100)

  gradientVertical(color1, color2)
  gradientHorizontal(color1, color2)

  drawMouseLines("black");
}


function gradientVertical(clrStart, clrEnd, steps = 100) {
  let stepSize = width / steps;
  for (let i = 0; i <= width; i += stepSize) {
    fill(lerpColor(clrStart, clrEnd, i / width))
    rect(i, 0, stepSize, height)
    // enter code here to create your gradient
  }
}

function gradientHorizontal(clrStart, clrEnd, steps = 100){
  let stepSize = height / steps;
  for (let i = 0; i <= height; i += stepSize) {
  fill(lerpColor(clrStart, clrEnd, i / height))
  rect(0, i, width, stepSize) 
  }
}
  // enter code here to create your gradient


//function gradientEllipse(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient


//function gradientRect(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient
