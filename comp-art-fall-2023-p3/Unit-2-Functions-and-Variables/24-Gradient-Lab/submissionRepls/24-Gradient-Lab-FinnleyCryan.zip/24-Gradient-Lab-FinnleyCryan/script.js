function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  //createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear()
  noStroke()
  gradientOld(true, 0, 0, 0, "rgb", 1, 255, 0, width, height, 255)
  // gradient(false, color(255, 0, 0, 255), color(0, 0, 255, 255), 1)
  gradient()
  drawMouseLines("black");
  noLoop()
}

function gradient(vert = "false", color0 = color("white"), color1 = color("black"), res = 5, Min = 0, Max = width, size = height) {
  for (let i = Min; i <= Max; i += res) {
    fill(lerpColor(color0, color1, i/width))
    if (vert == true) {
      rect(0, i, size, res)
    } else {
      rect(i, 0, res, size)
    }
  }
}

// ^ this function uses lerpColor, which I didn't know existed yesterday

// This lower function was my yesterday way of calculating in between colors, which only works for colors RGBCYM, or a weird set a variations from those.

function gradientOld(vert, r, g, b, rgb = "rgb", res = 5, alpha = 255, Min = 0, Max = width, size = height, maxColor = 255) {
  steps = Max / res // 800/5 = 160
  maxR = maxColor-(maxColor-r)/steps
  maxG = maxColor-(maxColor-g)/steps
  maxB = maxColor-(maxColor-b)/steps
  radd = (maxR-r)/steps
  gadd = (maxG-g)/steps
  badd = (maxB-b)/steps
  for (let i = Min; i <= Max; i += res) {
    if (rgb.toLowerCase().includes("r")) {
      r += radd
    }
    if (rgb.toLowerCase().includes("g")) {
      g += gadd
    }
    if (rgb.toLowerCase().includes("b")) {
      b += badd
    }
    fill(r, g, b, alpha)
    if (vert == true) {
      rect(0, i, size, res)
    } else {
      rect(i, 0, res, size)
    }
  }
}
// Syntax:
// gradientOld(vert, r, g, b, rgb, res, alpha, Min, Max, size, maxColor)
//
// Parameters:
// vert boolean: whether or not the gradient runs vertically.
// r Number: starting value for red.
// g Number: starting value for green.
// b Number: starting value for blue.
// rgb String: any combination of the three letters R, G, and B. Specifies which values you want to be included in gradient (Optional) [default=rgb]
// res Number: the step size of the gradient colors. (Optional) [default=10]
// alpha Number: the opacity of the gradient. (Optional) [default=255]
// Min Number: starting coordinate of gradient. (Optional) [default=0]
// Max Number: final coordinate of gradient. (Optional) [default=width]
// size Number: the size of the gradient perpendicular to the axis it runs on. (Optional) [default=height]
// maxColor Constant: the value (0-255) that each chosen color to gradient will reach at xMax (Optional) [default=255]

function gradientEllipse(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}

function gradientRect(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}