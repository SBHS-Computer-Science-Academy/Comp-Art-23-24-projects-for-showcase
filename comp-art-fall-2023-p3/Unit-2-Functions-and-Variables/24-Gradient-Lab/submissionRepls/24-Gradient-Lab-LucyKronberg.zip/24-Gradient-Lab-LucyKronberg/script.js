//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear()
  noStroke()
  
  //text("Use for loops to create gradients", 400, 400)
  //Enter code below this line to call your gradient
  let color1 = color(91, 120, 194,200)
  let color2 = color(151, 91, 194,100)
  
  
  //stroke('black')
  gradientVertical(color1,color2, 5)
  gradientHorizontal(color1,color2, 5)
  
 // rectGradient(0,0,width,height,color('black'), color('white'), "horizontal", 20);
  
  drawMouseLines("black");
}

function gradientVertical(clrStart, clrEnd, steps = 100){
  let stepSize = width / steps;
  for (let i = 0; i <=width; i+=stepSize) {
    fill(lerpColor(clrStart, clrEnd, i/width))
    rect(i,0,stepSize,height)
  }
}

function gradientHorizontal(clrStart, clrEnd, steps=10){
 let stepSize = height / steps;
  for (let i = 0; i <=height; i+=stepSize) {
    fill(lerpColor(clrStart, clrEnd, i/height))
    rect(0,i,width,stepSize)
  }
}

function gradientEllipse(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient
}

function gradientRect(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient
}