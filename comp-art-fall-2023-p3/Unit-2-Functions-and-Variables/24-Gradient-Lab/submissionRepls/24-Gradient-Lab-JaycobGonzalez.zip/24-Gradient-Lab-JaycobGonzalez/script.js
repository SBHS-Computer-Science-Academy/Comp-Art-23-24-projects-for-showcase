//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  noLoop();
  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {

  background(800);
  gradientRect(color(87, 4, 219), color("#db3704"), 25,10,30,125,80);
    
  clear()
  noStroke()
  

  let color1 = color("#db3704")
  let color2 = color("#5704db")

  
  for (let i = 0; i <= width; i+= 20) {
    fill(lerpColor(color1, color2, i/width))
    rect(i, 0, 20, height)
  }

  gradientVertical(color1 , color2, 25)
  
  drawMouseLines("black");
}

function gradientVertical(clrStart, clrEnd, steps = 100){
  let stepSize = width / steps; 
  for (let i = 0; i <= width; i+= stepSize) {
    fill(lerpColor(clrStart, clrEnd, i/width))
    rect(i, 0, stepSize, height)
  }
   
  
}

function gradientHorizontal(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient
}

function gradientEllipse(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient
}

function gradientRect(clrStart, clrEnd, steps=10){
  // enter code here to create your gradient
}