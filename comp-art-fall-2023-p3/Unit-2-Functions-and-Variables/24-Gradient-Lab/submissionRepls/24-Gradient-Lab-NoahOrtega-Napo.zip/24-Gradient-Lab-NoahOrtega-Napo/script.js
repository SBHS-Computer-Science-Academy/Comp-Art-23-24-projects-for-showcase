//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}
function draw() {
  clear()
  noStroke()
  text("Use for loops to create gradients", 400, 400)
  //Enter code below this line to call your gradient

  let color1 = color('red')
  let color2 = color('green')
  gradientVertical(color1, color2, 25)
  drawMouseLines("black");
}

function gradientVertical(clrStart, clrEnd, steps = 100) {
  let stepSize = width / steps;
  for (let i = 0; i <= width; i += stepSize) {
    fill(lerpColor(clrStart, clrEnd, i / width))
    rect(i, 0, stepSize, height)
  }

}

function gradientHorizontal(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}

function gradientEllipse(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}

function gradientRect(clrStart, clrEnd, steps = 10) {
  // enter code here to create your gradient
}