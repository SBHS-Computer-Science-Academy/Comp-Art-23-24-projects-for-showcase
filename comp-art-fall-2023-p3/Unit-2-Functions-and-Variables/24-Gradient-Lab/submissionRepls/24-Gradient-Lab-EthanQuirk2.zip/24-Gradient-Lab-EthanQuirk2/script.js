//What is the gradient of a color?
//Color gradient -In color science, a color gradient (also known as a color ramp or a color progression) specifies a range of position-dependent colors, usually used to fill a region. In assigning colors to a set of values, a gradient is a continuous colormap, a type of color scheme.

// key new functions lerpcolor() and the for(){} loop and color()

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  frameRate(2)
}

function draw() {
  clear()
  noStroke()
  text("Use for loops to create gradients", 400, 400)
  //Enter code below this line to call your gradient

  //for (let diameter = 1000; diameter > 0; diameter -= 100){
  //let colors = ['blue', 'green', 'purple', 'black','white']
  //fill(random(colors))
  //circle(400,400, diameter)
  //}

  let color1 = color("green")
  let color2 = color("purple")


  gradientVertical(color1, color2, 400)
  gradientVertical(color2, color1, 400, 400)

   color1 = color("blue")
   color2 = color("black")

  gradientHorizontal(color1, color2, 400)

  drawMouseLines("black");
}


function gradientVertical(color1, color2, w = width, x = 0, steps = 100) {
  let stepSize = w / steps;
  for (let i = 0; i <= w; i += stepSize) {
    fill(lerpColor(color1, color2, i / w))
    rect(i + x, 0, stepSize, height)
  }

}







function gradientHorizontal(color1, color2, h = height, y = 0, steps = 100) {
  let stepSize = h/ steps;
  for (let i = 0; i <= h; i += stepSize) {
    fill(lerpColor(color1, color2, i / h))
    rect(0, i + y, width, stepSize)
  }
}

