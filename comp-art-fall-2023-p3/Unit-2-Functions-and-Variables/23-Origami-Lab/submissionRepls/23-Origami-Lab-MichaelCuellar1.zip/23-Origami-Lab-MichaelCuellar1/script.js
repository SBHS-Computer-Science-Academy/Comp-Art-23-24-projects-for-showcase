function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
drawBody()
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	fill(255, 0, 0, 80); //transparent red 
	circle(400, 300, 400); // top circle
	fill(0, 255, 0, 80); // transparent green
	circle(267, 533, 400); // bottom left circle
	fill(0, 0, 255, 80); // transparent blue
	circle(533, 533, 400); // bottom right circle
}
function drawBody() {
fill("LightSteelBlue");
  beginShape();
  vertex(619, 140);
  vertex(153, 137);
  vertex(132, 146);
  vertex(120, 159);
  vertex(100, 162);
  vertex(92, 166);
  vertex(89, 170);
  vertex(85, 179);
  vertex(85, 188);
  vertex(88, 199);
  vertex(94, 203);
  vertex(102, 204);
  vertex(114, 204);
  vertex(499, 204);
  vertex(537, 200);
  vertex(568, 193);
  vertex(618, 177);
  vertex(647, 153);
  vertex(650, 147);
  vertex(649, 142);
  vertex(647, 140);
  vertex(643, 139);
  vertex(616, 140);
  vertex(616, 96);
  vertex(615, 92);
  vertex(612, 88);
  vertex(608, 86);
  vertex(600, 87);
  vertex(591, 89);
  vertex(495, 139);
  endShape();

  fill('LightSteelBlue')
    beginShape();
  vertex(177, 167);
  vertex(300, 274);
  vertex(312, 277);
  vertex(333, 279);
  vertex(347, 278);
  vertex(351, 274);
  vertex(274, 172);
  vertex(178, 167);
  endShape();
  fill('LightSteelBlue')
   beginShape();
  vertex(192, 136);
  vertex(259, 56);
  vertex(283, 53);
  vertex(294, 54);
  vertex(288, 139);
  vertex(190, 137);
  endShape();
fill('white')
   beginShape();
  vertex(161, 98);
  vertex(57, 100);
  vertex(49, 89);
  vertex(49, 75);
  vertex(60, 64);
  vertex(77, 65);
  vertex(80, 74);
  vertex(74, 52);
  vertex(81, 40);
  vertex(98, 39);
  vertex(101, 41);
  vertex(105, 50);
  vertex(110, 38);
  vertex(126, 36);
  vertex(137, 39);
  vertex(141, 48);
  vertex(141, 62);
  vertex(149, 59);
  vertex(164, 62);
  vertex(169, 72);
  vertex(171, 86);
  vertex(162, 98);
  endShape();
  
  
  
  
  
  
  fill('skyBlue')
 beginShape();
  vertex(121, 159);
  vertex(156, 158);
  vertex(161, 156);
  vertex(163, 153);
  vertex(163, 149);
  vertex(140, 143);
  vertex(133, 147);
  vertex(121, 159);
  endShape();

  beginShape();
  vertex(228, 369);
  vertex(187, 329);
  vertex(164, 337);
  vertex(118, 386);
  vertex(187, 397);
  vertex(200, 399);
  vertex(213, 364);
  vertex(229, 370);
  endShape();

  beginShape();
  vertex(199, 400);
  vertex(157, 455);
  vertex(81, 470);
  vertex(7, 359);
  vertex(201, 400);
  endShape();

  beginShape();
  vertex(44, 415);
  vertex(3, 410);
  vertex(66, 470);
  vertex(80, 470);
  endShape();

  beginShape();
  vertex(157, 455);
  vertex(103, 406);
  vertex(7, 359);
  endShape();

  fill('black')
    beginShape();
  vertex(186, 350);
  vertex(180, 349);
  vertex(176, 351);
  vertex(175, 355);
  vertex(180, 358);
  vertex(188, 358);
  vertex(191, 356);
  vertex(190, 352);
  vertex(186, 350);
  endShape();


}