function setup() {
  let myCanvas = createCanvas(2000, 2000);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("skyblue");

	stroke("white");
	fill(190, 232, 176);
	beginShape();
vertex(1262, 274);
vertex(1229, 229);
vertex(1003, 286);
vertex(847, 205);
vertex(577, 419);
vertex(930, 479);
vertex(840, 578);
vertex(822, 800);
vertex(733, 862);
vertex(848, 467);
vertex(840, 576);
vertex(830, 714);
vertex(1214, 469);
vertex(1002, 284);
vertex(1214, 469);
vertex(1229, 229);
vertex(1258, 270);
vertex(1263, 275);
vertex(1225, 275);
vertex(1214, 468);
vertex(830, 715);
vertex(869, 690);
vertex(861, 766);
vertex(823, 790);
	endShape();

	stroke(1);
	fill("black");
	beginShape();
vertex(1261, 276);
vertex(1228, 276);
vertex(1225, 318);
vertex(1261, 276);
	endShape();
	
	
	
	
  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawExampleShapes();  
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	fill(255, 0, 0, 80); //transparent red 
	circle(400, 300, 400); // top circle
	fill(0, 255, 0, 80); // transparent green
	circle(267, 533, 400); // bottom left circle
	fill(0, 0, 255, 80); // transparent blue
	circle(533, 533, 400); // bottom right circle
}