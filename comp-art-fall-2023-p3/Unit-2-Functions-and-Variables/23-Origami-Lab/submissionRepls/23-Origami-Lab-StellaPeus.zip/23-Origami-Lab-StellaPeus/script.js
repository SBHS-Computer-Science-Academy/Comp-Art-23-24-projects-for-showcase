function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background('white');
  strokeWeight(1);
  stroke('black');
  drawHead();
  drawEye();
  drawBlush();
  drawEars();
  drawTips();
  drawBody();
  drawBod();
  drawB();
  drawbod();
  drawTail();
  noStroke();
  drawtailshadow();
  drawShadow();
  drawMoreshadow();
  drawTAILSHADOW();
  drawMouseLines("black");
  
  }

  function drawHead() {
  fill("yellow");
  beginShape();
  vertex(307, 240);
  vertex(443, 266);
  vertex(477, 322);
  vertex(460, 390);
  vertex(248, 340);
  vertex(262, 274);
  vertex(308, 240);
  endShape();
}
  function drawEye() {
  fill("black");
  beginShape();
  curveVertex(304, 279); // control point
  curveVertex(304, 279);
  curveVertex(307, 275);
  curveVertex(312, 272);
  curveVertex(319, 271);
  curveVertex(330, 273);
  curveVertex(335, 278);
  curveVertex(337, 282);
  curveVertex(337, 286);
  curveVertex(334, 288);
  curveVertex(332, 285);
  curveVertex(330, 281);
  curveVertex(327, 278);
  curveVertex(320, 277);
  curveVertex(314, 277);
  curveVertex(312, 279);
  curveVertex(310, 281);
  curveVertex(306, 283);
  curveVertex(304, 281);
  curveVertex(304, 279);
  curveVertex(304, 279); // control point
  endShape();
  beginShape();
  curveVertex(396, 298); // control point
  curveVertex(396, 298);
  curveVertex(401, 290);
  curveVertex(405, 288);
  curveVertex(414, 289);
  curveVertex(421, 291);
  curveVertex(427, 294);
  curveVertex(429, 299);
  curveVertex(430, 306);
  curveVertex(426, 306);
  curveVertex(425, 300);
  curveVertex(422, 296);
  curveVertex(415, 295);
  curveVertex(406, 293);
  curveVertex(403, 295);
  curveVertex(400, 300);
  curveVertex(396, 298);
  curveVertex(396, 298); // control point
  endShape();
  beginShape();
  curveVertex(360, 303); // control point
  curveVertex(360, 303);
  curveVertex(356, 304);
  curveVertex(354, 307);
  curveVertex(354, 312);
  curveVertex(356, 314);
  curveVertex(359, 315);
  curveVertex(362, 315);
  curveVertex(365, 315);
  curveVertex(368, 313);
  curveVertex(368, 308);
  curveVertex(367, 306);
  curveVertex(362, 302);
  curveVertex(359, 303);
  curveVertex(359, 303); // control point
  endShape();
  beginShape();
  curveVertex(358, 322); // control point
  curveVertex(358, 322);
  curveVertex(357, 322);
  curveVertex(358, 326);
  curveVertex(357, 330);
  curveVertex(359, 338);
  curveVertex(361, 341);
  curveVertex(366, 342);
  curveVertex(370, 343);
  curveVertex(377, 341);
  curveVertex(378, 343);
  curveVertex(371, 346);
  curveVertex(362, 345);
  curveVertex(359, 343);
  curveVertex(353, 338);
  curveVertex(353, 331);
  curveVertex(354, 324);
  curveVertex(357, 322);
  curveVertex(352, 320);
  curveVertex(350, 321);
  curveVertex(347, 325);
  curveVertex(343, 328);
  curveVertex(338, 330);
  curveVertex(332, 332);
  curveVertex(323, 331);
  curveVertex(320, 328);
  curveVertex(314, 329);
  curveVertex(313, 332);
  curveVertex(316, 334);
  curveVertex(320, 335);
  curveVertex(328, 337);
  curveVertex(334, 336);
  curveVertex(343, 333);
  curveVertex(347, 330);
  curveVertex(350, 328);
  curveVertex(355, 323);
  curveVertex(355, 323); // control point
  endShape();
  
}
  function drawBlush() {
  fill('red');
  circle(421,330,20);
  circle(299,303,20);




  
  
  

}
  function drawEars() {
  fill("yellow");
  beginShape();
  vertex(316, 241);
  vertex(315, 229);
  vertex(308, 210);
  vertex(302, 200);
  vertex(290, 187);
  vertex(277, 177);
  vertex(265, 167);
  vertex(252, 154);
  vertex(243, 145);
  vertex(214, 175);
  vertex(280, 260);
  vertex(308, 241);
  vertex(317, 241);
  endShape();
  beginShape();
  vertex(432, 264);
  vertex(441, 244);
  vertex(446, 238);
  vertex(465, 219);
  vertex(487, 209);
  vertex(511, 186);
  vertex(538, 218);
  vertex(542, 223);
  vertex(463, 299);
  vertex(444, 268);
  vertex(443, 267);
  vertex(432, 264);
  endShape();
}
  function drawTips() {
  fill("black");
  beginShape();
  vertex(511, 186);
  vertex(518, 180);
  vertex(534, 173);
  vertex(548, 172);
  vertex(565, 172);
  vertex(570, 173);
  vertex(575, 173);
  vertex(567, 187);
  vertex(564, 197);
  vertex(557, 206);
  vertex(541, 223);
  vertex(512, 186);
  endShape();
  beginShape();
  vertex(214, 176);
  vertex(243, 145);
  vertex(239, 137);
  vertex(228, 127);
  vertex(216, 122);
  vertex(206, 118);
  vertex(196, 113);
  vertex(198, 123);
  vertex(202, 140);
  vertex(207, 160);
  vertex(214, 175);
  endShape();
}
  function drawBody() {
  fill("yellow");
  beginShape();
  vertex(350, 365);
  vertex(314, 511);
  vertex(248, 339);
  vertex(350, 364);
  endShape();
}
  function drawBod() {
  fill("yellow");
  beginShape();
  vertex(350, 364);
  vertex(459, 390);
  vertex(314, 512);
  vertex(350, 365);
  endShape();
}
  function drawB() {
  fill("yellow");
  beginShape();
  vertex(252, 316);
  vertex(192, 372);
  vertex(313, 510);
  vertex(248, 340);
  vertex(252, 317);
  vertex(253, 318);
  endShape();
}
  function drawbod() {
  fill(200,200,0,100);
  beginShape();
  vertex(464, 371);
  vertex(507, 434);
  vertex(315, 511);
  vertex(459, 390);
  vertex(465, 373);
  endShape();
}
function drawTail() {
  fill("yellow");
  beginShape();
  vertex(370, 252);
  vertex(391, 231);
  vertex(374, 194);
  vertex(406, 171);
  vertex(394, 137);
  vertex(504, 67);
  vertex(508, 65);
  vertex(517, 66);
  vertex(525, 70);
  vertex(525, 75);
  vertex(522, 83);
  vertex(425, 145);
  vertex(435, 176);
  vertex(401, 196);
  vertex(418, 234);
  vertex(395, 257);
  vertex(370, 252);
  endShape();
}
function drawtailshadow() {
  fill(232, 213, 86);
  beginShape();
  vertex(429, 143);
  vertex(484, 79);
  vertex(497, 71);
  vertex(473, 115);
  vertex(434, 139);
  endShape();
  beginShape();
  vertex(417, 233);
  vertex(374, 194);
  vertex(387, 185);
  vertex(406, 207);
  vertex(416, 230);
  endShape();
   beginShape();
  vertex(448, 275);
  vertex(526, 205);
  vertex(455, 287);
  vertex(448, 275);
  endShape();
  beginShape();
  vertex(300, 246);
  vertex(230, 160);
  vertex(291, 253);
  vertex(301, 246);
  endShape();
   beginShape();
  vertex(224, 344);
  vertex(312, 508);
  vertex(208, 356);
  vertex(224, 343);
  endShape();
}

function drawShadow() {
  fill(200,200,200,170);
  beginShape();
  vertex(337, 503);
  vertex(348, 506);
  vertex(360, 515);
  vertex(382, 522);
  vertex(417, 522);
  vertex(454, 522);
  vertex(488, 527);
  vertex(529, 527);
  vertex(570, 527);
  vertex(584, 525);
  vertex(599, 514);
  vertex(607, 502);
  vertex(613, 478);
  vertex(614, 467);
  vertex(610, 448);
  vertex(598, 431);
  vertex(574, 420);
  vertex(556, 410);
  vertex(531, 405);
  vertex(503, 401);
  vertex(485, 402);
  vertex(506, 432);
  vertex(506, 434);
  vertex(336, 503);
  endShape();
}
function drawMoreshadow() {
  fill(200,200,200,100);
  beginShape();
  vertex(314, 511);
  vertex(337, 521);
  vertex(357, 525);
  vertex(393, 531);
  vertex(433, 532);
  vertex(462, 528);
  vertex(483, 526);
  vertex(395, 493);
  vertex(347, 497);
  vertex(315, 511);
  endShape();
}
function drawTAILSHADOW() {
  fill(200,200,200,100);
  beginShape();
  curveVertex(529, 406); // control point
  curveVertex(529, 406);
  curveVertex(552, 390);
  curveVertex(533, 365);
  curveVertex(565, 338);
  curveVertex(540, 306);
  curveVertex(651, 210);
  curveVertex(669, 215);
  curveVertex(671, 224);
  curveVertex(572, 308);
  curveVertex(593, 339);
  curveVertex(558, 365);
  curveVertex(578, 391);
  curveVertex(534, 436);
  curveVertex(513, 420);
  curveVertex(529, 406);
  curveVertex(529, 406); // control point
  endShape();
}




  

