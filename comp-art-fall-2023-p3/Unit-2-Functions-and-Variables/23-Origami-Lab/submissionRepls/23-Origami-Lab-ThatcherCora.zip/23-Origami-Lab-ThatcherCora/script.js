function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
drawShape()
  drawBhape()
  drawTr()
  drawJhape()
  drawLine()
  drawShadow()
  drawMhape()
  drawBigs()
  drawBig()
  drawFin()
  drawB()
  drawPp()
  drawN()
  drawTale()
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawExampleShapes();  
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	//noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	//fill(255, 0, 0, 80); //transparent red 
//circle(400, 300, 400); // top circle
	//fill(0, 255, 0, 80); // transparent green
//	circle(267, 533, 400); // bottom left circle
	//fill(0, 0, 255, 80); // transparent blue
	//rcle(533, 533, 400); // bottom right circle
}
 function drawShape() {
fill(21, 212, 170);
  beginShape();
  vertex(273, 197);
  vertex(271, 329);
  vertex(342, 390);
  vertex(412, 329);
  vertex(411, 195);
  vertex(273, 197);
  endShape();
} 

function drawBhape() {
   fill(0,90);
  beginShape();
  vertex(342, 390);
  vertex(341, 196);
  endShape();
}
function drawTr() {
  noStroke()
   fill(3, 143, 143,60);
  beginShape();
  vertex(341, 389);
  vertex(319, 369);
  vertex(340, 195);
  endShape();
}


function drawJhape() {
   fill(181, 245, 245,70);
  beginShape();
  vertex(345, 197);
  vertex(346, 386);
  endShape();
}
function drawLine() {
   fill(184, 242, 242,70);
  beginShape();
  vertex(345, 199);
  vertex(344, 390);
  vertex(338, 384);
  vertex(341, 197);
  endShape();
}
function drawShadow() {
   fill(3, 156, 138,50);
  beginShape();
  vertex(343, 387);
  vertex(344, 389);
  vertex(365, 371);
  vertex(344, 195);
  endShape();
}
function drawMhape() {
  fill(48, 160, 252);
  beginShape();
  curveVertex(320, 198); // control point
  curveVertex(320, 198);
  curveVertex(319, 168);
  curveVertex(331, 151);
  curveVertex(354, 151);
  curveVertex(367, 162);
  curveVertex(371, 198);
  curveVertex(371, 198); // control point
  endShape();
}
function drawBigs() {
   fill("black");
  beginShape();
  curveVertex(332, 167); // control point
  curveVertex(332, 167);
  curveVertex(325, 172);
  curveVertex(328, 175);
  curveVertex(336, 171);
  curveVertex(338, 168);
  curveVertex(330, 168);
  curveVertex(330, 168); // control point
  endShape();
}
function drawBig() {
 fill("black");
  beginShape();
  curveVertex(349, 169); // control point
  curveVertex(349, 169);
  curveVertex(358, 167);
  curveVertex(359, 172);
  curveVertex(351, 175);
  curveVertex(348, 169);
  curveVertex(346, 174);
  curveVertex(352, 175);
  curveVertex(352, 175); // control point
  endShape();
}
function drawFin() {
   fill(11, 95, 163);
  beginShape();
  vertex(411, 215);
  vertex(412, 243);
  vertex(456, 242);
  vertex(411, 215);
  endShape();
}
function drawB() {
  fill(11,95,163);
  beginShape();
  vertex(403, 336);
  vertex(467, 337);
  vertex(412, 302);
  endShape();
}
function drawPp(){
   fill(11,95,163);
  beginShape();
  vertex(274, 200);
  vertex(272, 229);
  vertex(218, 227);
  vertex(274, 200);
  endShape();
}
function drawN() {
   fill(11,95,163);
  beginShape();
  vertex(270, 328);
  vertex(290, 346);
  vertex(247, 363);
  vertex(270, 327);
  endShape();
}
function drawTale() {
   fill("black");
  beginShape();
  vertex(352, 381);
  vertex(345, 405);
  vertex(333, 381);
  endShape();
}
function drawShadow2() {
 fill(50,110,200,40);
  beginShape();
  vertex(411, 243);
  vertex(425, 243);
  vertex(418, 220);
  vertex(412, 215);
  endShape();
}