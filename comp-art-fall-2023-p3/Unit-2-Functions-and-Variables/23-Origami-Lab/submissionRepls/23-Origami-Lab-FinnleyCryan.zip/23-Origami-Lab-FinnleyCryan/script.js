function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  x = width / 2
  y = height / 2
}

function draw() {
  clear();
  background("white");

  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  strokeWeight(2)
  drawCenter(x, y);
  drawMouseLines("black");
}

function drawCenter(cx, cy) {
  push()
  translate(cx, cy)
  for (let i = 0; i < 8; i++) {
    rotate(-45)
    fill(255, 200, 210, 210)
    triangle(0, 0, 0, -60, 60, -60) //center
    fill(140, 255, 140, 210)
    quad(0, -85, -14, -127, 35, -108, 40, -85) //green
    fill(255, 140, 210, 210)
    quad(0, -85, 0, -60, 60, -60, 80, -100) //orchid
  }
  pop()
}