function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  drawHeadShadow()
  drawHead()
  drawBeak()
  drawNeckShadow()
  drawNeckShadow2()
  drawNeck()
  drawBody()
  drawBottomShadow()
  drawBottom()
  drawMouseLines("black");


}
function drawHeadShadow() {
  fill("Orange");
  beginShape();
  vertex(132, 302);
  vertex(130, 324);
  vertex(145, 412);
  vertex(149, 409);
  endShape();  
}
function drawBeak() {
  fill("gold");
  beginShape();
  vertex(139, 352);
  vertex(101, 425);
  vertex(106, 430);
  vertex(148, 402);
  vertex(139, 353);
  endShape();
}

function drawHead() {
  fill("Gold");
  beginShape();
  vertex(133, 321);
  vertex(131, 273);
  vertex(164, 249);
  vertex(204, 239);
  vertex(246, 249);
  vertex(273, 274);
  vertex(295, 313);
  vertex(151, 420);
  vertex(133, 321);
  endShape();
}

function drawNeckShadow() {
  fill("DarkOrange");
  beginShape();
  vertex(151, 421);
  vertex(149, 429);
  vertex(299, 318);
  vertex(295, 313);
  vertex(150, 421);
  endShape();
}

function drawNeckShadow2() {
  fill("orange");
  beginShape();
  vertex(151, 419);
  vertex(89, 457);
  vertex(88, 469);
  vertex(150, 429);
  vertex(151, 420);
  endShape();
}

function drawNeck() {
  fill("gold");
  beginShape();
  vertex(88, 470);
  vertex(64, 484);
  vertex(241, 463);
  vertex(310, 341);
  vertex(299, 319);
  vertex(88, 470);
  endShape();
}

function drawBody() {
  fill("gold");
  beginShape();
  vertex(63, 485);
  vertex(485, 432);
  vertex(504, 554);
  vertex(62, 486);
  endShape();
}

function drawBottomShadow() {
  fill("orange");
  beginShape();
  vertex(66, 590);
  vertex(61, 606);
  vertex(118, 654);
  vertex(139, 650);
  vertex(66, 590);
  endShape();
}
function drawBottom() {
  fill("gold");
  beginShape();
  vertex(62, 487);
  vertex(67, 603);
  vertex(119, 649);
  vertex(444, 651);
  vertex(505, 600);
  vertex(504, 554);
  vertex(61, 486);
  endShape();
}
