function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("dodgerblue");
  drawplane()
  drawcloud()
  drawsun()
  drawsunrays()
  drawbigcloud()
  drawbiggercloud()
  drawsmallcloud()
  drawslightlylesssmallcloud()
  
  
  

  
  drawMouseLines("black");
}

function drawExampleShapes() {
	noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255

}
function drawplane() {
   fill(189, 189, 189, 150);;
  beginShape();
  vertex(80, 255);
  vertex(137, 225);
  vertex(205, 216);
  vertex(240, 211);
  vertex(183, 118);
  vertex(166, 76);
  vertex(216, 102);
  vertex(296, 200);
  vertex(303, 206);
  vertex(407, 195);
  vertex(472, 190);
  vertex(535, 106);
  vertex(526, 237);
  vertex(485, 251);
  vertex(314, 267);
  vertex(393, 352);
  vertex(402, 397);
  vertex(343, 379);
  vertex(250, 273);
  vertex(140, 287);
  vertex(76, 263);
  vertex(72, 258);
  vertex(80, 255);
  endShape();
}
function drawcloud() {
  fill('white');
  beginShape();
  vertex(679, 403);
  vertex(713, 404);
  vertex(726, 400);
  vertex(750, 382);
  vertex(752, 364);
  vertex(734, 341);
  vertex(708, 340);
  vertex(686, 311);
  vertex(655, 311);
  vertex(631, 320);
  vertex(616, 337);
  vertex(593, 315);
  vertex(581, 320);
  vertex(571, 335);
  vertex(564, 355);
  vertex(575, 386);
  vertex(604, 389);
  vertex(619, 386);
  vertex(633, 394);
  vertex(656, 399);
  vertex(679, 404);
  endShape();
}
function drawShape() {
  // fill("black");
  beginShape();
  vertex(672, 56);
  vertex(650, 59);
  vertex(621, 79);
  vertex(613, 94);
  vertex(605, 115);
  vertex(611, 145);
  vertex(630, 175);
  vertex(658, 187);
  vertex(693, 188);
  vertex(724, 175);
  vertex(746, 148);
  vertex(749, 105);
  vertex(737, 74);
  vertex(717, 61);
  vertex(669, 56);
  vertex(795, 421);
  endShape();
}
function drawsun() {
  fill("gold");
  beginShape();
  vertex(672, 56);
  vertex(650, 59);
  vertex(621, 79);
  vertex(613, 94);
  vertex(605, 115);
  vertex(611, 145);
  vertex(630, 175);
  vertex(658, 187);
  vertex(693, 188);
  vertex(724, 175);
  vertex(746, 148);
  vertex(749, 105);
  vertex(737, 74);
  vertex(717, 61);
  vertex(669, 56);
  endShape();
}
function drawsunrays() {
  // fill("black");
  beginShape();
  vertex(641, 178);
  vertex(646, 230);
  vertex(685, 187);
  vertex(718, 227);
  vertex(723, 174);
  vertex(767, 191);
  vertex(747, 143);
  vertex(789, 138);
  vertex(750, 109);
  vertex(785, 92);
  vertex(738, 75);
  vertex(767, 44);
  vertex(714, 59);
  vertex(705, 16);
  vertex(677, 55);
  vertex(653, 14);
  vertex(639, 63);
  vertex(601, 39);
  vertex(613, 90);
  vertex(565, 94);
  vertex(607, 127);
  vertex(568, 145);
  vertex(617, 156);
  vertex(601, 196);
  vertex(639, 182);
  endShape();
}
function drawbigcloud() {
  fill("white");
  beginShape();
  vertex(72, 496);
  vertex(110, 508);
  vertex(143, 501);
  vertex(162, 506);
  vertex(201, 516);
  vertex(219, 501);
  vertex(250, 514);
  vertex(283, 510);
  vertex(323, 490);
  vertex(339, 463);
  vertex(312, 432);
  vertex(265, 411);
  vertex(230, 423);
  vertex(198, 396);
  vertex(163, 391);
  vertex(151, 404);
  vertex(133, 407);
  vertex(99, 382);
  vertex(77, 391);
  vertex(66, 406);
  vertex(34, 414);
  vertex(18, 429);
  vertex(9, 456);
  vertex(13, 499);
  vertex(34, 508);
  vertex(74, 496);
  endShape();
}
function drawbiggercloud() {
  // fill("black");
  beginShape();
  vertex(287, 655);
  vertex(339, 664);
  vertex(383, 678);
  vertex(431, 668);
  vertex(462, 662);
  vertex(492, 675);
  vertex(536, 676);
  vertex(551, 659);
  vertex(616, 676);
  vertex(684, 662);
  vertex(702, 633);
  vertex(686, 602);
  vertex(656, 573);
  vertex(627, 580);
  vertex(602, 560);
  vertex(564, 544);
  vertex(537, 551);
  vertex(515, 568);
  vertex(487, 539);
  vertex(460, 539);
  vertex(432, 542);
  vertex(412, 557);
  vertex(386, 529);
  vertex(357, 536);
  vertex(331, 545);
  vertex(315, 566);
  vertex(285, 550);
  vertex(265, 551);
  vertex(239, 573);
  vertex(227, 604);
  vertex(233, 645);
  vertex(263, 659);
  vertex(288, 655);
  endShape();
}
 function drawsmallcloud() {
  fill(255, 255, 255, 200);
  beginShape();
  vertex(115, 702);
  vertex(159, 716);
  vertex(194, 712);
  vertex(231, 705);
  vertex(248, 687);
  vertex(254, 663);
  vertex(241, 629);
  vertex(222, 625);
  vertex(205, 631);
  vertex(184, 607);
  vertex(163, 612);
  vertex(141, 630);
  vertex(128, 638);
  vertex(100, 624);
  vertex(87, 633);
  vertex(57, 654);
  vertex(69, 677);
  vertex(114, 701);
  endShape();
}
function drawslightlylesssmallcloud() {
  fill(255, 255, 255, 200);;
  beginShape();
  vertex(285, 111);
  vertex(329, 123);
  vertex(377, 123);
  vertex(420, 118);
  vertex(467, 110);
  vertex(523, 75);
  vertex(522, 23);
  vertex(457, 10);
  vertex(438, 13);
  vertex(413, 31);
  vertex(395, 11);
  vertex(363, 3);
  vertex(348, 9);
  vertex(334, 23);
  vertex(314, 12);
  vertex(294, 16);
  vertex(279, 27);
  vertex(258, 15);
  vertex(236, 28);
  vertex(225, 43);
  vertex(216, 69);
  vertex(233, 92);
  vertex(251, 103);
  vertex(288, 111);
  endShape();
}