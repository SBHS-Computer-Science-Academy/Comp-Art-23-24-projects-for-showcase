function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  //drawExampleShapes();  

  drawA()
  drawB()
  drawC()
  drawD()
  drawE()
  drawF()
  drawG()
  
  drawMouseLines("black");
}

//function drawExampleShapes() {
	//noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	//fill(255, 0, 0, 80); //transparent red 
	//circle(400, 300, 400); // top circle
	//fill(0, 255, 0, 80); // transparent green
	//circle(267, 533, 400); // bottom left circle
	//fill(0, 0, 255, 80); // transparent blue
	//circle(533, 533, 400); // bottom right circle
  
//}
function drawA() {
   fill("darkOrange");
  beginShape();
  vertex(274, 229);
  vertex(218, 267);
  vertex(302, 322);
  vertex(379, 321);
  vertex(444, 268);
  vertex(389, 228);
  vertex(274, 229);
  endShape();
}
function drawB() {
   fill("darkOrange");
  beginShape();
  vertex(218, 268);
  vertex(246, 337);
  vertex(276, 306);
  vertex(218, 268);
  endShape();
}
function drawC() {
  // fill("black");
  beginShape();
  vertex(444, 269);
  vertex(433, 329);
  vertex(405, 300);
  vertex(444, 269);
  endShape();
}
function drawD() {
  // fill("black");
  beginShape();
  vertex(422, 251);
  vertex(434, 227);
  vertex(389, 228);
  vertex(422, 251);
  endShape();
}
function drawE() {
  // fill("black");
  beginShape();
  vertex(247, 247);
  vertex(231, 231);
  vertex(273, 229);
  vertex(247, 247);
  endShape();
}
function drawF() {
  // fill("black");
  beginShape();
  vertex(412, 228);
  vertex(409, 190);
  vertex(434, 227);
  vertex(412, 228);
  endShape();
}
function drawG() {
  // fill("black");
  beginShape();
  vertex(252, 229);
  vertex(259, 190);
  vertex(231, 230);
  vertex(252, 229);
  endShape();
  fill('white')
  circle(297, 228, 30)
  circle(365, 229, 30)
  fill ('black')
  circle(362, 228,25)
  circle(300, 228,25)
  fill("white")
  circle(306, 225, 5)
  circle(359, 225, 5)
}

  
