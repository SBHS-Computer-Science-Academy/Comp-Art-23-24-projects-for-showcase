function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("lavender");
function drawBack() {
  noStroke();
  fill("white");
  beginShape();
  vertex(89, 130);
  vertex(91, 593);
  vertex(695, 593);
  vertex(697, 130);
  endShape();
  
}  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawBack();
  drawHead1();  
  drawBody();
  drawTail();
  drawLeg();
  drawFoot();
  drawShadows();
  drawCrown();
  drawverticalIsoscelesTriangle();
  drawrightTriangle();
  
  drawMouseLines("black");
}

function drawHead1() {
  
	//noStroke(); // turn off outlines
stroke("black");
  strokeWeight(2);
	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	fill(103, 191, 131, 80); //transparent green
  noStroke();
	verticalIsoscelesTriangle(270,180,140,50);
beginShape();
  vertex(200, 230);
  vertex(199, 209);
  vertex(270, 180);
  endShape();
  stroke("black");
  strokeWeight(2);
  noFill();
  beginShape();
  vertex(269, 182);
  vertex(200, 209);
  vertex(200, 230);
  vertex(338, 230);
  endShape();
  line(270,182,339,230);
  fill(103, 191, 131, 80); 
}
  
  function drawBody() {
beginShape(); //body
  vertex(255, 232);
  vertex(253, 246);
  vertex(240, 305);
  vertex(319, 410);
  vertex(362, 407);
  vertex(339, 230);
  endShape();

   beginShape();
  vertex(240, 305); //hand
  vertex(210, 314);
  vertex(198, 345);
  vertex(255, 324);
  endShape();

  beginShape(); //arm
  vertex(211, 315);
  vertex(305, 410);
  vertex(320, 410);
  vertex(242, 305);
 endShape();

    noStroke();
    fill(0,0,0,30);
    beginShape();
  vertex(373,499);
  vertex(301, 518);
  vertex(265, 531);
  vertex(420, 546);
  vertex(457, 540);
  vertex(612, 495);
  vertex(456, 498);
  vertex(446, 539);
  vertex(369, 530);
  vertex(306, 530);
  endShape();
    stroke("black");
  strokeWeight(2);
    line(390,530,447,541);
}

function drawTail() {
  fill(103, 191, 131, 80); //transparent green
  beginShape();
  vertex(345, 281);
  vertex(644, 257);
  vertex(466, 390);
  vertex(434, 400);
  vertex(360, 407);
  endShape();
}

function drawLeg() {
  // fill("black");
  beginShape();
  vertex(363, 279);
  vertex(487, 374);
  vertex(377, 405);
  endShape(); 

  beginShape();
  vertex(486, 374);
  vertex(447, 540);
  vertex(393, 508);
  vertex(377, 405);
  endShape();
}

function drawFoot() {
rightTriangle(394,530,-90,-40);
noStroke();
  beginShape();
  vertex(393, 492);
  vertex(368, 530);
  vertex(446, 539);
  endShape();
}

function drawShadows() {
fill(52, 99, 67,70); //shadow
  noStroke();
  beginShape();
  vertex(254, 230);
  vertex(252, 249);
  vertex(337, 230);
  endShape();

  beginShape();
  vertex(211, 315);
  vertex(213, 339);
  vertex(229, 333);
  endShape();

  beginShape();
  vertex(374, 499);
  vertex(424, 523);
  vertex(391, 492);
  endShape();

  //beginShape();
 // vertex(643, 258);
 // vertex(454, 350);
  //vertex(487, 374);
 // endShape();

   beginShape();
  vertex(471, 362);
  vertex(643, 258);
  vertex(487, 374);
  endShape();

  beginShape();
  vertex(254, 231);
  vertex(253, 240);
  vertex(335, 231);
  endShape();

  beginShape();
  vertex(211, 317);
  vertex(221, 336);
  vertex(228, 333);
  endShape();

  fill(52, 99, 67,30);
  beginShape();
  vertex(485, 374);
  vertex(410, 508);
  vertex(446, 539);
  endShape();

   beginShape();
  vertex(268, 181);
  vertex(275, 191);
  vertex(284, 198);
  vertex(304, 206);
  endShape();

  beginShape();
  vertex(346, 282);
  vertex(363, 280);
  vertex(361, 406);
  endShape();
}


function drawCrown() {
  stroke('gold');
  strokeWeight(3);
  fill(247, 234, 49, 255);
  beginShape();
  vertex(269, 179);
  vertex(304, 204);
  vertex(319, 182);
  vertex(301, 182);
  vertex(310, 150);
  vertex(284, 175);
  vertex(275, 157);
  endShape();

  line(275,156,268,178);
}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function rightTriangle(x,y,w,h) {
let topX = x+w
let bottomY = y+h
  triangle(x, bottomY,topX, y, x,y);
}