function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();

  background("blue");
  drawHead()
  drawEye()


  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawBeak();
  drawBody();
  drawTail();
  drawFeathers();
  drawWing();
  drawWingdetails();
  drawFillhead();
  drawOutlines();
  drawTaildetails();
  drawMoredetails();
  drawMouseLines("black");
}
function drawHead() {
  fill("gold");
  beginShape();
  vertex(549, 300);
  vertex(446, 145);
  vertex(388, 191);
  vertex(276, 301);
  vertex(342, 392);
  vertex(449, 364);
  vertex(517, 379);
  vertex(552, 348);
  vertex(550, 301);
  endShape();
}
function drawFillhead() {
   fill("yellow");
  beginShape();
 vertex(503, 376);
  vertex(449, 364);
  vertex(343, 391);
  vertex(343, 393);
  vertex(502, 377);
  vertex(503, 376);
  endShape();
}
function drawEye() {
  fill("black")
  beginShape();
  vertex(447, 227);
  vertex(427, 249);
  vertex(469, 257);
  vertex(447, 228);
  endShape();

}



function drawBeak() {
  // turn off outlines

  // RGBA = red, green, blue, alpha (transparency)
  // Each value goes 0 to 255


  fill(139, 69, 19); // transparent green
  horizontalIsoscelesTriangle(550, 300, 50, 50)






}
function drawBody() {
  fill("gold");
  beginShape();
  vertex(341, 393);
  vertex(233, 403);
  vertex(161, 364);
  vertex(131, 287);
  vertex(126, 263);
  vertex(84, 248);
  vertex(64, 245);
  vertex(39, 467);
  vertex(56, 505);
  vertex(92, 568);
  vertex(349, 607);
  vertex(460, 576);
  vertex(520, 541);
  vertex(545, 460);
  vertex(523, 393);
  vertex(515, 375);
  vertex(339, 393);
  endShape();
}
function drawTail() {
  beginShape();
  vertex(39, 460);
  vertex(23, 95);
  vertex(63, 242);
  endShape();
}
function drawFeathers() {
  // fill("black");
  beginShape();
  vertex(35, 391);
  vertex(-1, 196);
  vertex(32, 283);
  endShape();
}
function drawWing() {
  fill("yellow");
  beginShape();
  vertex(251, 459);
  vertex(400, 446);
  vertex(273, 648);
  vertex(251, 460);
  endShape();
}
function drawWingdetails() {
   fill("");
  beginShape();
  vertex(284, 604);
  vertex(270, 469);
  vertex(374, 460);
  vertex(284, 606);
  endShape();
}
  function drawOutlines() {
  // fill("black");
  beginShape();
  vertex(63, 245);
  vertex(87, 248);
  vertex(126, 262);
  vertex(161, 355);
  vertex(229, 400);
  vertex(340, 391);
  vertex(340, 397);
  vertex(229, 404);
  vertex(157, 362);
  vertex(122, 268);
  vertex(63, 245);
  endShape();
}
function drawTaildetails() {
   fill("gold");
  beginShape();
  vertex(40, 460);
  vertex(90, 441);
  vertex(63, 241);
  vertex(66, 450);
  endShape();
}
function drawMoredetails() {
   fill("gold");
  beginShape();
  vertex(40, 459);
  vertex(156, 577);
  vertex(91, 438);
  vertex(192, 385);
  vertex(85, 396);
  vertex(123, 267);
  endShape();
}
function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
  triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function horizontalIsoscelesTriangle(x, y, w, h) {
  let bottomY = y + h;
  let rightX = x + w
  let rightY = y + h / 2
  triangle(x, y, x, bottomY, rightX, rightY)
}
function rightTriangle(leftX, topY, w, h) {

  let rightX = leftX + w;
  let bottomY = topY + h;

  triangle(leftX, topY, rightX, topY, leftX, bottomY)

}



