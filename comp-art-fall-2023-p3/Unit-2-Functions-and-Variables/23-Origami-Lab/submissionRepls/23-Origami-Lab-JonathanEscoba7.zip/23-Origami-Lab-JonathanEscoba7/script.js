function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
drawShape()
  drawwing()
  drawbelly()
  drawback()
  drawlegone()
  drawlegtwo()
  drawfeet()
  drawtail()
  drawhand()
  drawShadow()
drawredo()
  drawMouseLines("black");
}
function drawShape() {
   fill(255, 0, 0 , 140);
  beginShape();
  
  endShape();
}
function drawwing() {
  // fill("black");
  beginShape();
  vertex(127, 162);
  vertex(136, 180);
  vertex(227, 168);
  vertex(173, 126);
  vertex(126, 164);
  vertex(129, 165);
  
  endShape();
}
function drawbelly() {
  // fill("black");
  beginShape();
  vertex(163, 177);
  vertex(227, 169);
  vertex(236, 303);
  vertex(216, 304);
  vertex(153, 244);
  vertex(165, 179);
  vertex(167, 177);
  endShape();
}

function drawback() {
  // fill("black");
  beginShape();
  vertex(230, 197);
  vertex(250, 201);
  vertex(256, 294);
  vertex(235, 294);
  vertex(229, 198);
  vertex(236, 199);
  vertex(236, 198);
  endShape();
}
function drawlegone() {
  // fill("black");
  beginShape();
  vertex(249, 202);
  vertex(314, 262);
  vertex(279, 375);
  vertex(262, 357);
  vertex(250, 204);
  vertex(250, 203);
  endShape();
}
function drawlegtwo() {
  // fill("black");
  beginShape();
  vertex(239, 295);
  vertex(256, 295);
  vertex(261, 355);
  vertex(243, 346);
  vertex(239, 294);
  vertex(244, 346);
  
  
  endShape();
}
function drawfeet() {
  // fill("black");
  beginShape();
  vertex(243, 346);
  vertex(224, 369);
  vertex(260, 355);
  vertex(243, 347);
  vertex(261, 355);
  vertex(280, 376);
  vertex(237, 380);
  vertex(263, 358);
  vertex(280, 375);
  endShape();
}
function drawtail() {
  // fill("black");
  beginShape();
  vertex(250, 200);
  vertex(407, 168);
  vertex(312, 262);
  vertex(249, 202);
  vertex(262, 197);
  endShape();
}
function drawhand() {
  // fill("black");
  beginShape();
  vertex(160, 251);
  vertex(143, 261);
  vertex(147, 303);
  vertex(153, 266);
  vertex(168, 258);
  vertex(207, 295);
  vertex(201, 303);
  vertex(153, 266);
  vertex(149, 300);
  vertex(164, 276);
  endShape();
}
function drawredo() { 
beginShape();
  vertex(161, 253);
  vertex(162, 261);
  vertex(167, 259);
  vertex(162, 254);
  vertex(164, 275);
  vertex(154, 269);
  vertex(154, 268);
  vertex(153, 266);
  vertex(168, 259);
  vertex(161, 263);
  vertex(164, 275);
  endShape();
}
function drawShadow() {
  fill(0, 0, 0 , 140);
  beginShape();
  vertex(240, 344);
  vertex(19, 360);
  vertex(246, 380);
  vertex(279, 376);
  vertex(259, 354);
  vertex(237, 343);
  vertex(197, 346);
  endShape();
}
