function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  
 
  drawExampleShapes();  
   face();
  drawEars();
  cheeks();
  eyes();
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
 

   
}
function drawEars(){

fill(818, 120, 0, 220);
triangle(285, 115, 154, 183, 161, 57)
  triangle(639, 129, 756, 86, 732, 215)
   triangle(733, 213, 560, 350, 798, 361)
  triangle(154, 182, 66, 311, 301, 318)
  quad(435, 425, 506, 346, 460, 92, 370, 338)
   fill(44, 44, 55, 220);
  triangle(199, 75, 159, 98, 162, 57) 
    triangle(756, 86, 749, 124, 726, 97) 
      triangle(409, 423, 465, 425, 437, 448) 
}
function cheeks(){
fill(33, 30, 50, 20);// white
 triangle(68, 310, 298, 318, 242, 365)
 triangle(797, 362, 561, 351,624, 406)
  fill(33, 30, 50, 80);// grey
  triangle(297, 319, 435, 447, 239, 364)
  triangle(560, 351, 620, 402, 436, 449)
}
function eyes(){
  fill(44, 44, 55, 220);
   triangle(410, 423, 464, 425, 437, 447) 
     triangle(334, 203, 397, 238, 328, 237)
    triangle(559, 203, 501, 240, 561, 243)
}
function face(){
fill(818, 120, 0, 220);
triangle(285, 115, 154, 183, 161, 57)
  triangle(639, 129, 756, 86, 732, 215)
   triangle(733, 213, 560, 350, 798, 361)
  triangle(154, 182, 66, 311, 301, 318)
  quad(435, 425, 506, 346, 460, 92, 370, 338)


fill(818, 120, 0, 190);
triangle(155, 183, 284, 116, 466, 93)
  triangle(463, 93, 638, 129, 735, 216)
  quad(156, 183, 463, 94, 731, 214, 437, 449)

  fill(818, 120, 0, 230);
  quad(435, 425, 506, 346, 460, 92, 370, 338)
   triangle(562, 350, 321, 342, 437, 447) 
  fill(318, 90, 5, 70);
  triangle(460, 94, 729, 213, 561, 351) 
   triangle(458, 94, 320, 344, 156, 182) 
}