function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw(){

  background("white");
  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawMouseLines("black");
drawHead()
drawNeck()
drawBody()
drawTriangle()
drawS()
drawJ()
  
}

function drawTriangle(){
fill(168,165,165,255)
beginShape();
vertex(206, 405);
  vertex(280, 251);
  vertex(357, 404);
  vertex(358, 408);
  endShape();
}

function drawHead() {
fill(71,69,69,200)
beginShape();
vertex(56, 200);
vertex(167, 128);
vertex(164, 204);
vertex(55, 201);
endShape();
}

function drawNeck(){
fill(168,165,165,255);
 beginShape();
vertex(140, 204);
  vertex(163, 203);
  vertex(72, 403);
  vertex(24, 361);
  vertex(139, 204);
  endShape();

}

function drawBody(){
fill(71,69,69,200);
beginShape();
vertex(72, 403);
  vertex(358, 409);
  vertex(492, 203);
  vertex(125, 286);
  endShape();
}
function drawS(){
fill(10,10,10,200);
beginShape();
vertex(164, 205);
  vertex(134, 284);
  vertex(127, 285);
  vertex(164, 202);
  endShape();
}

function drawJ(){
fill(10,10,10,200);
beginShape();
vertex(362, 403);
  vertex(383, 401);
  vertex(460, 251);
  vertex(365, 399);
  vertex(363, 401);
  endShape();
}
