function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  
  clear();
  background("white");

drawhead()
drawbody()
drawShadow()


  
  drawMouseLines("black");
}



  // RGBA = red, green, blue, alpha (transparency)
  // Each value goes 0 to 255

function drawhead() {
   fill("orange");
  beginShape();
  vertex(306, 286);
  vertex(346, 295);
  vertex(317, 370);
  vertex(306, 285);
  endShape();
   beginShape();
  vertex(305, 285);
  vertex(266, 288);
  vertex(317, 369);
  endShape();
   beginShape();
  vertex(306, 285);
  vertex(305, 280);
  vertex(344, 243);
  vertex(306, 284);
  endShape();
  beginShape();
  vertex(268, 283);
  vertex(267, 289);
  vertex(219, 249);
  vertex(267, 282);
  endShape();
 
  
  fill("darkorange")
  beginShape();
  vertex(266, 289);
  vertex(238, 313);
  vertex(317, 370);
  endShape();
  fill("chocolate")
  beginShape();
  vertex(306, 285);
  vertex(344, 244);
  vertex(346, 296);
  endShape();
  beginShape();
  vertex(266, 288);
  vertex(238, 313);
  vertex(220, 250);
  vertex(266, 288);
  endShape();
  fill("sandybrown")
  beginShape();
  vertex(267, 289);
  vertex(268, 282);
  vertex(304, 280);
  vertex(306, 285);
  vertex(268, 287);
  endShape();
   
}
function drawbody() {
   fill("darkorange");
  beginShape();
  vertex(324, 352);
  vertex(354, 388);
  vertex(348, 396);
  vertex(336, 396);
  vertex(321, 360);
  vertex(324, 353);
  endShape();
  beginShape();
  vertex(405, 305);
  vertex(464, 310);
  vertex(449, 331);
  vertex(420, 322);
  vertex(405, 305);
  endShape();
   beginShape();
  vertex(418, 321);
  vertex(438, 335);
  vertex(435, 377);
  vertex(409, 383);
  vertex(419, 322);
  endShape();
   beginShape();
  vertex(291, 404);
  vertex(307, 499);
  vertex(313, 496);
  vertex(335, 396);
  vertex(292, 403);
  endShape();
  fill("orange")
   beginShape();
  vertex(308, 364);
  vertex(291, 403);
   vertex(335, 396);
  vertex(321, 362);
  vertex(317, 372);
  vertex(308, 364);
  endShape();
  beginShape();
  vertex(348, 397);
  vertex(375, 456);
  vertex(337, 408);
  vertex(347, 397);
  endShape();
  beginShape();
  vertex(375, 459);
  vertex(303, 501);
  vertex(313, 503);
  vertex(376, 459);
  endShape();
  beginShape();
  vertex(394, 461);
  vertex(418, 467);
  vertex(403, 486);
  vertex(394, 461);
  endShape();
  beginShape();
  vertex(417, 468);
  vertex(452, 446);
  vertex(440, 473);
  vertex(420, 468);
  endShape();
  beginShape();
  vertex(375, 372);
  vertex(405, 305);
  vertex(418, 321);
  vertex(409, 384);
  vertex(375, 372);
  endShape();
    fill("sandybrown");
  beginShape();
  vertex(291, 404);
  vertex(293, 371);
  vertex(300, 359);
  vertex(308, 364);
  vertex(291, 403);
  endShape();
  beginShape();
  vertex(375, 372);
  vertex(380, 344);
  vertex(405, 304);
  vertex(376, 371);
  endShape();
    fill("chocolate");
  beginShape();
  vertex(296, 367);
  vertex(305, 371);
  vertex(318, 386);
  vertex(325, 374);
  vertex(333, 364);
  vertex(325, 354);
  vertex(321, 362);
  vertex(317, 371);
  vertex(308, 366);
  vertex(301, 360);
  vertex(296, 366);
  endShape();
  beginShape();
  vertex(449, 332);
  vertex(439, 336);
  vertex(420, 323);
  vertex(448, 331);
  endShape();
  beginShape();
  vertex(347, 397);
  vertex(337, 408);
  vertex(313, 497);
  vertex(335, 397);
  vertex(348, 396);
  endShape();
  beginShape();
  vertex(291, 405);
  vertex(303, 496);
  vertex(307, 496);
  vertex(291, 405);
  endShape();
   beginShape();
  vertex(376, 459);
  vertex(394, 461);
  vertex(404, 491);
  vertex(378, 494);
  vertex(375, 460);
  endShape();
  beginShape();
  vertex(403, 486);
  vertex(404, 491);
  vertex(439, 473);
  vertex(418, 467);
  vertex(403, 486);
  endShape();
  beginShape();
  vertex(409, 383);
  vertex(435, 376);
  vertex(452, 446);
  vertex(418, 467);
  vertex(408, 383);
  endShape();
   fill("darkorange");
  beginShape();
  vertex(376, 458);
  vertex(313, 496);
  vertex(337, 409);
  vertex(376, 457);
  endShape();
   beginShape();
  vertex(354, 387);
  vertex(394, 461);
  vertex(376, 458);
  vertex(348, 397);
  vertex(354, 388);
  endShape();
  beginShape();
  vertex(375, 460);
  vertex(378, 493);
  vertex(313, 503);
  vertex(375, 460);
  endShape();
  beginShape();
  vertex(418, 468);
  vertex(408, 383);
  vertex(375, 372);
  vertex(384, 443);
  vertex(395, 462);
  vertex(417, 467);
  endShape();
}



function drawShadow() {
   fill(0,100);
  beginShape();
  vertex(301, 491);
  vertex(258, 405);
  vertex(219, 352);
  vertex(259, 358);
  vertex(281, 354);
  vertex(285, 348);
  vertex(301, 358);
  vertex(293, 368);
  vertex(291, 402);
  vertex(302, 490);
  endShape();
  beginShape();
  vertex(387, 332);
  vertex(379, 333);
  vertex(372, 347);
  vertex(369, 388);
  vertex(353, 388);
  vertex(384, 442);
  vertex(375, 373);
  vertex(380, 342);
  vertex(386, 333);
  endShape();
}










