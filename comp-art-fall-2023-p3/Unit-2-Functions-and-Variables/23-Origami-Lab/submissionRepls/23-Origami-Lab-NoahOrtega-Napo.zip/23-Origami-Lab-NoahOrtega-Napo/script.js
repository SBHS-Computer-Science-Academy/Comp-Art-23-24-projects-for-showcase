function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");
  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawExampleShapes();  
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	noStroke(); // turn off outlines
function drawShape() {
  // fill("black");
  beginShape();
  vertex(262, 201);
  vertex(337, 201);
  vertex(287, 276);
  vertex(262, 203);
  endShape();
}
	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	fill(255, 0, 0, 80); //transparent red 
	circle(400, 300, 400); // top circle
	fill(0, 255, 0, 80); // transparent green
	circle(267, 533, 400); // bottom left circle
	fill(0, 0, 255, 80); // transparent blue
	circle(533, 533, 400); // bottom right circle
}