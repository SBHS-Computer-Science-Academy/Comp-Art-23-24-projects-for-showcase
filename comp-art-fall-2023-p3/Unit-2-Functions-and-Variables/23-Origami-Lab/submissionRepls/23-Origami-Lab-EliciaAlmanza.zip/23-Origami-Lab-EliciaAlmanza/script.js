function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("skyblue");
    noStroke()
  fill("blue");
  rect(0,602, 800,400); // ground
  fill("black");

  stroke('yellow')
  strokeWeight(9)
  line(383,524,383,602)//arm
  line(431,518,432,601)//arm
  line(471,436,538,382)//rightleg
  line(339,431,288,389)//leftleg 
    
  stroke('black')
 //line(360,352,367,368)

  
  stroke("gold")
  strokeWeight(3)
  fill("yellow")
  rect(335,324,150,200)
   fill("gold")
  circle(347,348,13)//left 
  circle(345,362,5)//left
  circle (470, 334,13)//right



  stroke("black")
  strokeWeight(1)
  fill("white")
  circle(378,386,40)//lefteye
  fill("skyblue")
  circle(378,386,20)//lefteye
  fill("black")
  circle(379,386,8)
  
  
  fill("white")
  circle(442,386,40)//righteye
  fill("skyblue")
  circle(442,386,20)//righteye
  fill("black")
  circle(442,386,8)
  
  
  
  
  function drawShape() {
  fill("black");
  rect(3,608,70,100)


    ellipse()
}
  
  drawExampleShapes();  
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	//noStroke(); // turn off outlines

	// RGBA = red, green, blue, alpha (transparency)
	// Each value goes 0 to 255
  
	//fill(255, 0, 0, 80); //transparent red 
	//circle(400, 300, 400); // top circle
//fill(0, 255, 0, 80); // transparent green
//	circle(267, 533, 400); // bottom left circle
//	fill(0, 0, 255, 80); // transparent blue
//	circle(533, 533, 400); // bottom right circle
}