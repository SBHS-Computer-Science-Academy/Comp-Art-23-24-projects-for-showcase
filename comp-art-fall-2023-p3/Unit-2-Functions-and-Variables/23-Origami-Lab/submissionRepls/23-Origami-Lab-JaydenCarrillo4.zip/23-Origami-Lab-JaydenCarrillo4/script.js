function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("black");
  
  /* you may delete this function call and the definition below.
  It is included as a reference on how to use fill(R,G,B,alpha) */
  drawExampleShapes();  
  
  drawMouseLines("black");
}

function drawExampleShapes() {
	noStroke(); // turn off outlines
}
function draw() {
  background("black");
  

  drawRhombus();
  
  drawMouseLines("black");


}

function drawRhombus() {
  fill("Silver");
  beginShape();
  vertex(385, 145);
  vertex(213, 144);
  vertex(141, 159);
  vertex(24, 236);
  vertex(132, 284);
  vertex(694, 247);
  vertex(779, 176);
  vertex(715, 133);
  vertex(381, 145);
  endShape();
  
   beginShape();
  vertex(330, 210);
  vertex(496, 202);
  vertex(430, 362);
  vertex(329, 211);
  endShape();
  
  beginShape();
  vertex(340, 146);
  vertex(496, 142);
  vertex(421, 61);
  vertex(340, 146);
  endShape();
  

  fill("cyan")
   beginShape();
  vertex(55, 218);
  vertex(147, 217);
  vertex(214, 145);
  vertex(140, 161);
  vertex(54, 217);
  endShape();

  beginShape();
  vertex(623, 188);
  vertex(676, 147);
  vertex(652, 37);
  vertex(754, 179);
  vertex(624, 187);
  endShape();
}
