function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  background("white");

  drawCraneBody(255, 0, 0)
  drawWing()
  drawShadow()
  drawMouseLines("black");
}


function drawWing() {
  beginShape();
  vertex(426, 326);
  vertex(373, 357);
  vertex(325, 374);
  vertex(307, 373);
  vertex(349, 351);
  vertex(354, 347);
  vertex(360, 345);
  vertex(391, 333);
  vertex(425, 327);
  endShape();
  triangle(381, 328, 395, 332, 353, 348)
}

function drawCraneBody(color) {
  fill(255, 0, 0, 160)
  stroke(.01)
  beginShape();
  vertex(401, 341);
  vertex(406, 357);
  vertex(438, 387);
  vertex(430, 333);
  vertex(427, 327);
  vertex(400, 341);
  endShape()
  beginShape();
  vertex(356, 364);
  vertex(365, 379);
  vertex(404, 357);
  vertex(402, 342);
  vertex(402, 342);
  vertex(401, 341);
  vertex(376, 355);
  vertex(356, 363);
  endShape();
  beginShape();
  vertex(366, 338);
  vertex(395, 300);
  vertex(399, 294);
  vertex(399, 318);
  vertex(402, 331);
  vertex(396, 332);
  vertex(369, 337);
  endShape();
  beginShape();
  vertex(403, 328);
  vertex(399, 317);
  vertex(400, 295);
  vertex(427, 327);
  vertex(402, 330);
  vertex(402, 326);
  endShape();
  beginShape();
  vertex(442, 384);
  vertex(447, 282);
  vertex(451, 266);
  vertex(438, 280);
  vertex(424, 323);
  vertex(429, 328);
  vertex(438, 384);
  vertex(442, 382);
  endShape();
  beginShape();
  vertex(448, 282);
  vertex(492, 268);
  vertex(450, 266);
  vertex(450, 274);
  vertex(448, 281);
  endShape();
  beginShape();
  vertex(447, 284);
  vertex(442, 384);
  vertex(447, 387);
  vertex(449, 387);
  vertex(451, 387);
  vertex(458, 279);
  vertex(448, 282);
  vertex(443, 383);
  endShape();
  beginShape();
  vertex(451, 388);
  vertex(461, 326);
  vertex(455, 324);
  vertex(450, 387);
  endShape();
  
  beginShape();
  vertex(401, 296);
  vertex(404, 293);
  vertex(413, 311);
  endShape();
  beginShape();
  vertex(402, 291);
  vertex(429, 309);
  vertex(424, 324);
  vertex(414, 311);
  vertex(403, 294);
  endShape();
  beginShape();
  vertex(456, 322);
  vertex(481, 320);
  vertex(496, 314);
  vertex(500, 304);
  vertex(473, 310);
  vertex(457, 315);
  vertex(455, 322);
  endShape();
   beginShape();
  vertex(367, 337);
  vertex(277, 219);
  vertex(382, 315);
  vertex(367, 337);
  endShape();

  
}


function drawShadow() {
  fill(0, 30)
  noStroke()
  beginShape();
  vertex(422, 331);
  vertex(421, 371);
  vertex(406, 358);
  vertex(401, 341);
  vertex(423, 329);
  endShape();
  fill(0, 40)
  beginShape();
  vertex(356, 364);
  vertex(365, 379);
  vertex(404, 357);
  vertex(402, 342);
  vertex(402, 342);
  vertex(401, 341);
  vertex(376, 355);
  vertex(356, 363);
  endShape();
  beginShape();
  vertex(434, 386);
  vertex(385, 392);
  vertex(364, 379);
  vertex(361, 376);
  vertex(329, 374);
  vertex(323, 374);
  vertex(305, 371);
  vertex(206, 364);
  vertex(354, 385);
  vertex(281, 421);
  vertex(300, 425);
  vertex(309, 424);
  vertex(294, 453);
  vertex(329, 464);
  vertex(307, 446);
  vertex(324, 420);
  vertex(434, 386);
  endShape();;
  endShape();
  beginShape();
  vertex(368, 338);
  vertex(385, 329);
  vertex(399, 295);
  vertex(367, 337);
  endShape();
  beginShape();
  vertex(448, 283);
  vertex(439, 297);
  vertex(437, 373);
  vertex(430, 327);
  vertex(424, 322);
  vertex(438, 280);
  vertex(447, 284);
  endShape()
  beginShape();
  vertex(451, 268);
  vertex(450, 266);
  vertex(455, 267);
  vertex(453, 275);
  vertex(449, 280);
  vertex(450, 276);
  endShape();
  
  stroke(0, 100)
  line(437, 282, 446, 284)
  noStroke()
  fill(0, 40)
  beginShape();
  vertex(448, 283);
  vertex(453, 281);
  vertex(446, 386);
  vertex(443, 386);
  vertex(449, 285);
  endShape();
  fill(0,20)
  beginShape();
  vertex(451, 388);
  vertex(461, 326);
  vertex(455, 324);
  vertex(450, 387);
  endShape();
  fill(0,40)
  fill(255, 200)
  beginShape();
  vertex(401, 296);
  vertex(404, 293);
  vertex(413, 311);
  endShape();  
  fill(255, 10)
  beginShape();
  vertex(438, 282);
  vertex(447, 284);
  vertex(451, 267);
  vertex(438, 282);
  endShape();
  fill(0, 40)
  beginShape();
  vertex(406, 297);
  vertex(427, 313);
  vertex(424, 323);
  vertex(406, 298);
  endShape();
  beginShape();
  vertex(276, 218);
  vertex(378, 320);
  vertex(366, 337);
  vertex(277, 220);
  endShape();
 
  // beginShape();
  // vertex(317, 422);
  // vertex(298, 451);
  // vertex(330, 470);
  // vertex(313, 445);
  // vertex(339, 415);
  // vertex(317, 423);
  // endShape();
  function drawExampleShapes() {
    noStroke(); // turn off outlines
    beginShape();
    vertex(437, 386);
    vertex(395, 394);
    vertex(364, 379);
    vertex(333, 398);
    vertex(314, 437);
    vertex(314, 447);
    vertex(329, 440);
    vertex(381, 413);
    vertex(436, 387);
    endShape();
    beginShape();
    vertex(448, 283);
    vertex(438, 297);
    vertex(437, 291);
    vertex(447, 281);
    endShape();
    // RGBA = red, green, blue, alpha (transparency)
    // Each value goes 0 to 255

    fill(255, 0, 0, 80); //transparent red 
    circle(400, 300, 400); // top circle
    fill(0, 255, 0, 80); // transparent green
    circle(267, 533, 400); // bottom left circle
    fill(0, 0, 255, 80); // transparent blue
    circle(533, 533, 400);
    fill(0, 50)
    circle(533, 533, 400);


    // bottom right circle

    endShape();
  }
}