function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();

  drawThing()
  
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('lightGreen'), color('Green'), "horizontal", 400); // for details, see "gradient.js" file
  rectGradient(0, 0, width, 250, "blue", "lightBlue"); // sky with sunset
                  

 rectGradient(1, 393, width, 150, "LightGray", "grey");
 
}


function drawThing() {
 fill("Silver");
  beginShape();
  curveVertex(160, 105); // control point
  curveVertex(160, 105);
  curveVertex(138, 116);
  curveVertex(129, 150);
  curveVertex(157, 124);
  curveVertex(159, 106);
  curveVertex(159, 106); // control point
  endShape();
 beginShape();
  curveVertex(49, 22); // control point
  curveVertex(49, 22);
  curveVertex(76, 11);
  curveVertex(112, 16);
  curveVertex(57, 34);
  curveVertex(49, 21);
  curveVertex(49, 21); // control point
  endShape();
   // fill("black");
  beginShape();
  curveVertex(451, 189); // control point
  curveVertex(451, 189);
  curveVertex(460, 175);
  curveVertex(468, 189);
  curveVertex(468, 198);
  curveVertex(483, 207);
  curveVertex(468, 209);
  curveVertex(449, 223);
  curveVertex(445, 250);
  curveVertex(440, 220);
  curveVertex(439, 248);
  curveVertex(431, 246);
  curveVertex(433, 220);
  curveVertex(413, 220);
  curveVertex(409, 247);
  curveVertex(405, 245);
  curveVertex(405, 218);
  curveVertex(396, 248);
  curveVertex(392, 246);
  curveVertex(394, 219);
  curveVertex(372, 222);
  curveVertex(342, 244);
  curveVertex(336, 240);
  curveVertex(373, 206);
  curveVertex(407, 194);
  curveVertex(447, 196);
  curveVertex(451, 189);
  curveVertex(451, 189); // control point
  endShape();
 fill("grey");
  beginShape();
  curveVertex(97, 410); // control point
  curveVertex(97, 410);
  curveVertex(97, 445);
  curveVertex(142, 445);
  curveVertex(142, 409);
  curveVertex(97, 412);
  curveVertex(43, 413);
  curveVertex(45, 367);
  curveVertex(120, 356);
  curveVertex(183, 315);
  curveVertex(333, 309);
  curveVertex(388, 365);
  curveVertex(490, 366);
  curveVertex(503, 404);
  curveVertex(389, 408);
  curveVertex(335, 407);
  curveVertex(335, 444);
  curveVertex(383, 445);
  curveVertex(368, 407);
  curveVertex(96, 412);
  curveVertex(96, 412); // control point
  endShape();
   fill("lightBlue");
  beginShape();
  vertex(174, 325);
  vertex(151, 356);
  vertex(340, 352);
  vertex(334, 321);
  vertex(174, 326);
  vertex(255, 323);
  vertex(251, 355);
  endShape();
   fill("LightBlue");
  beginShape();
  vertex(255, 325);
  vertex(175, 327);
  vertex(153, 355);
  vertex(252, 353);
  vertex(255, 325);
  endShape();
    fill("black");
  beginShape();
  curveVertex(458, 194); // control point
  curveVertex(458, 194);
  curveVertex(453, 198);
  curveVertex(462, 202);
  curveVertex(459, 196);
  curveVertex(459, 196); // control point
  endShape();
 fill("yellow");
  beginShape();
  vertex(1, 455);
  vertex(995, 432);
  vertex(995, 445);
  vertex(2, 467);
  endShape();
   fill("white");
  circle(305, 71, 5);
  circle(428, 35, 5);
  circle(325, 153, 5);
  circle(430, 123, 5);
  circle(678, 59, 5);
    circle(546, 72, 5);
    circle(785, 77, 5);
    circle(372, 93, 5);
    circle(260, 30, 5);
    circle(609, 33, 5);
    circle(614, 104, 5);
    circle(862, 29, 5);
    circle(941, 106, 5);
   fill("grey");
  circle(142, 72, 25);
   circle(63, 125, 45);
    fill("black");
  beginShape();
  curveVertex(108, 411); // control point
  curveVertex(108, 411);
  curveVertex(95, 427);
  curveVertex(99, 447);
  curveVertex(113, 447);
  curveVertex(143, 447);
  curveVertex(150, 439);
  curveVertex(148, 417);
  curveVertex(138, 408);
  curveVertex(107, 412);
  curveVertex(107, 412); // control point
  endShape();
  beginShape();
  curveVertex(363, 408); // control point
  curveVertex(363, 408);
  curveVertex(339, 406);
  curveVertex(329, 418);
  curveVertex(328, 433);
  curveVertex(339, 446);
  curveVertex(363, 447);
  curveVertex(383, 439);
  curveVertex(391, 425);
  curveVertex(385, 409);
  curveVertex(373, 408);
  curveVertex(373, 408); // control point
  endShape();
   fill("yellow");
  beginShape();
  curveVertex(489, 367); // control point
  curveVertex(489, 367);
  curveVertex(482, 375);
  curveVertex(484, 387);
  curveVertex(499, 392);
  curveVertex(511, 389);
  curveVertex(511, 389); // control point
  endShape();
    fill("red");
  beginShape();
  curveVertex(45, 368); // control point
  curveVertex(45, 368);
  curveVertex(49, 375);
  curveVertex(49, 388);
  curveVertex(45, 397);
  curveVertex(39, 403);
  curveVertex(38, 404);
  curveVertex(36, 392);
  curveVertex(37, 381);
  curveVertex(41, 371);
  curveVertex(46, 368);
  curveVertex(46, 368); // control point
  endShape();
    fill("lightYellow");
  beginShape();
  curveVertex(529, 390); // control point
  curveVertex(529, 390);
  curveVertex(656, 362);
  curveVertex(751, 349);
  curveVertex(791, 352);
  curveVertex(850, 423);
  curveVertex(809, 437);
  curveVertex(681, 435);
  curveVertex(531, 410);
  curveVertex(530, 389);
  curveVertex(530, 389); // control point
  endShape();
}
 