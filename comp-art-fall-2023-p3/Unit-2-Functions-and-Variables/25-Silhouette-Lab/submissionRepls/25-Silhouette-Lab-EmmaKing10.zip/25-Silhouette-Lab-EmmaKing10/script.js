function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  

  drawMountains()
  drawShadow()


  //text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width/2, 700);
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, 400, color('HotPink'), color('LightGreen'), "horizontal"); // for details, see "gradient.js" file
circleGradient(width / 6, 200, 180, "orangeRed", "yellow"); 
  rectGradient(0,400,width, 400, color ('HotPink'), color('LightGreen'))


  
}
function drawMountains(){
fill("SaddleBrown")
  beginShape()
  vertex(-1, 798);
  vertex(174, 312);
  vertex(339, 632);
  vertex(455, 93);
  vertex(649, 581);
  vertex(721, 258);
  vertex(802, 484);
  vertex(799, 796);
  endShape()


  
}



