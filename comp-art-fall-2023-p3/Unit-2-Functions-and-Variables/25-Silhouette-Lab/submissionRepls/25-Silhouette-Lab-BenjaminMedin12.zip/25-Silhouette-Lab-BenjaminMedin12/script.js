function setup() {
  let myCanvas = createCanvas(1000, 600);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  drawShootingstar();
  drawGround();
  drawMountains();
  drawBird();
  drawRightmountain();
  

  text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width / 2, 700);
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('Darkorange'), color('Crimson'), "horizontal", 400); // for details, see "gradient.js" file  

}
function drawShootingstar() {
  vertexGradient([768, 729, 736, 752, 775, 797, 792, 775], [028, 046, 065, 091, 094, 073, 040, 029], 968, 060, "black", 'red')
}
function drawGround() {
  rectGradient(0, 400, width, 200, "green", "black", "horizontal")
}
function drawMountains() {
  vertexGradient([002, 171, 319], [400, 167, 401], 200, 200, "grey", "black")
}
function drawBird() {
 stroke("black");
  strokeWeight(10)
  noFill()
  beginShape();
  vertex(259, 83);
  vertex(300, 32);
  vertex(323, 67);
  vertex(351, 31);
  vertex(385, 87);
  endShape();

}
function drawRightmountain(){
  vertexGradient([729, 780, 824, 929, 998, 998, 730],[401, 241, 315, 122, 245, 401, 400],824,315,"grey","black")
}