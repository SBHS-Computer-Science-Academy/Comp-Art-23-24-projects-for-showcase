function setup() {
  let myCanvas = createCanvas(400, 400);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();

  text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width/2, 700);
  drawMouseLines("black");
}

function drawBackground() {
  

  rectGradient(0, 0, width, height, color(84, 0, 173), color('yellow'), "horizontal", 400); // for details, see "gradient.js" file

circleGradient(200,200,100,'orange','yellow')





fill('blue')
  rect(0, 215,404, 213)


  fill(0)
  triangle(1, 123,138, 399,1, 399)
triangle(51, 156,2, 221,108, 400)
triangle(56, 220,86, 222,109, 396)
circle(31, 184,50)
circle(67, 223,50)
circle(87, 238,10)

bezier(0, 122,11, 130,30, 141,45, 148)
bezier(45, 150,58, 154,75, 181,92, 216)
bezier(-1, 124,17, 91,38, 117,51, 157)
bezier(91, 217,120, 294,124, 363,132, 397)    
bezier(64, 184,88, 191,117, 224,115, 303)
bezier(3, 128,74, 192,109, 301,126, 379)
bezier(5, 130,41, 148,54, 172,62, 199)
bezier(1, 123,46, 143,90, 206,110, 275)

  circle(4, 131,20)
circle(42, 154,11)
circle(44, 155,11)
circle(47, 157,11)
circle(49, 159,11)
circle(51, 161,11)
circle(52, 162,11)
circle(55, 166,11)
circle(57, 169,11)
circle(58, 172,11)
circle(61, 176,11)
circle(63, 178,11)
circle(65, 181,11)
circle(69, 185,11)
circle(72, 191,11)

  ellipse(86, 294,40,100)
ellipse(105, 388,60,200)
ellipse(96, 295,40,100)



noStroke()

vertexGradient([133, 268, 202], [215, 215, 500 ], 202, 399, "blue","orange", "vertical")


  
}

