function setup() {
  let myCanvas = createCanvas(600, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
drawShark()
  drawMirrorShark()
  drawbody()
  drawMouseLines("black");
}

function drawBackground() {
background("black")


  
  circleGradient(width / 2, 400, 850, "black", "dodgerblue", 300)
   circleGradient(width / 2, 400, 300, "dodgerblue","white")
  circleGradient(width / 2, 400, 10, "white","white")
}

function drawMirrorShark() {
  translate(width / 2, height / 2);
  rotate(180);
  translate(-width / 2, -height /2);
  drawShark();
}

function drawShark() {
   fill("black");
  beginShape();
  vertex(364, 482);
  vertex(376, 441);
  vertex(380, 400);
  vertex(383, 358);
  vertex(391, 337);
  vertex(409, 324);
  vertex(418, 323);
  vertex(425, 323);
  vertex(430, 325);
  vertex(435, 331);
  vertex(438, 339);
  vertex(438, 349);
  vertex(437, 360);
  vertex(437, 364);
  vertex(428, 400);
  vertex(418, 426);
  vertex(408, 447);
  vertex(396, 465);
  vertex(388, 476);
  vertex(377, 486);
  vertex(370, 491);
  vertex(364, 482);
  endShape();
  beginShape();
  vertex(392, 339);
  vertex(431, 327);
  vertex(431, 326);
  vertex(428, 322);
  vertex(426, 320);
  vertex(423, 318);
  vertex(421, 317);
  vertex(416, 316);
  vertex(413, 315);
  vertex(410, 315);
  vertex(408, 316);
  vertex(406, 317);
  vertex(403, 319);
  vertex(400, 322);
  vertex(389, 341);
  endShape();
   beginShape();
  vertex(382, 375);
  vertex(365, 380);
  vertex(359, 382);
  vertex(351, 386);
  vertex(345, 390);
  vertex(343, 393);
  vertex(342, 396);
  vertex(342, 397);
  vertex(342, 397);
  vertex(343, 398);
  vertex(363, 397);
  vertex(381, 395);
  vertex(421, 398);
  vertex(429, 401);
  vertex(441, 407);
  vertex(448, 412);
  vertex(452, 415);
  vertex(455, 416);
  vertex(456, 416);
  vertex(457, 415);
  vertex(457, 414);
  vertex(457, 410);
  vertex(452, 401);
  vertex(432, 380);
  endShape();
   beginShape();
  vertex(453, 403);
  vertex(458, 412);
  vertex(459, 416);
  vertex(457, 417);
  vertex(454, 416);
  vertex(452, 415);
  vertex(420, 398);
  endShape();
   beginShape();
  vertex(405, 447);
  vertex(409, 458);
  vertex(409, 460);
  vertex(396, 458);
  vertex(400, 447);
  vertex(403, 449);
  endShape();
   beginShape();
  vertex(392, 466);
  vertex(386, 481);
  vertex(373, 486);
  endShape();
   beginShape();
  vertex(368, 487);
  vertex(373, 505);
  vertex(372, 515);
  vertex(371, 518);
  vertex(362, 495);
  vertex(363, 484);
  endShape();
  beginShape();
  vertex(364, 483);
  vertex(346, 487);
  vertex(337, 491);
  vertex(332, 494);
  vertex(339, 496);
  vertex(344, 494);
  vertex(363, 494);
  endShape();
   beginShape();
  vertex(364, 483);
  vertex(360, 486);
  vertex(366, 486);
  vertex(373, 480);
  endShape();
}
function drawbody() {
   fill("black");
  beginShape();
  vertex(404, 404);
  vertex(393, 420);
  vertex(405, 427);
  vertex(406, 399);
  vertex(401, 381);
  vertex(401, 396);
  vertex(395, 420);
  vertex(385, 444);
  vertex(395, 437);
  vertex(397, 401);
  vertex(404, 390);
  endShape();
}







