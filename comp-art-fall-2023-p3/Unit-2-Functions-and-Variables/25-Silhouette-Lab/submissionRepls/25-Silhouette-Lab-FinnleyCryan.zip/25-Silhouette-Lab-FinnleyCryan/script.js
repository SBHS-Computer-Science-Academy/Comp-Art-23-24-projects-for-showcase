function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();

  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color(0, 0, 0, 127.5), color(255, 255, 255, 127.5), "center", 2 x width);
  //rectGradient(0, 0, width, height, color(0, 0, 0, 0), color(255, 255, 255, 255), "center", 40);
  

  
}
