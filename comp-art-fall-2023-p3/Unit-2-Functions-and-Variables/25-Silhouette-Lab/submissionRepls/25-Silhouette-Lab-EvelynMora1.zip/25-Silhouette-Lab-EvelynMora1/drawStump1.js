function drawStump1() {
    // fill("black");
    beginShape();
    curveVertex(363, 454); // control point
    curveVertex(363, 454);
    curveVertex(384, 374);
    curveVertex(331, 293);
    curveVertex(354, 263);
    curveVertex(416, 357);
    curveVertex(426, 449);
    curveVertex(367, 458);
    curveVertex(367, 458); // control point
    endShape();
}
