function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();

drawStump()
drawStump2()
drawLeaves1()
drawLeaves2()
drawBird1()
drawBird2()
drawBird3()
  
  text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width/2, 700);
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('orange'), color('white'), "horizontal", 400); // for details, see "gradient.js" file

fill("black")
rect(0, 500, 730, 200)//ground
circle(100, 100, 100)//sun 
circle(500, 530, 200)//right sand pile 
circle(400, 520, 150)//left sand pile 
}
function drawStump() {
  // fill("black");
  beginShape();
  curveVertex(363, 454); // control point
  curveVertex(363, 454);
  curveVertex(384, 374);
  curveVertex(331, 293);
  curveVertex(354, 263);
  curveVertex(416, 357);
  curveVertex(426, 449);
  curveVertex(367, 458);
  curveVertex(367, 458); // control point
  endShape();
} 
function drawStump2() {
  // fill("black");
  beginShape();
  curveVertex(491, 431); // control point
  curveVertex(491, 431);
  curveVertex(510, 342);
  curveVertex(482, 249);
  curveVertex(510, 234);
  curveVertex(541, 333);
  curveVertex(546, 441);
  curveVertex(546, 441); // control point
  endShape();
}
function drawLeaves1() {
  // fill("black");
  beginShape();
  vertex(335, 281);
  vertex(323, 310);
  vertex(305, 302);
  vertex(299, 332);
  vertex(272, 334);
  vertex(264, 321);
  vertex(248, 341);
  vertex(211, 324);
  vertex(169, 352);
  vertex(202, 296);
  vertex(261, 283);
  vertex(258, 265);
  vertex(239, 260);
  vertex(224, 268);
  vertex(191, 268);
  vertex(165, 259);
  vertex(143, 243);
  vertex(139, 211);
  vertex(173, 230);
  vertex(213, 221);
  vertex(288, 229);
  vertex(260, 203);
  vertex(257, 156);
  vertex(295, 127);
  vertex(313, 109);
  vertex(322, 136);
  vertex(300, 160);
  vertex(311, 196);
  vertex(353, 208);
  vertex(375, 172);
  vertex(385, 147);
  vertex(414, 147);
  vertex(416, 172);
  vertex(395, 207);
  vertex(417, 242);
  vertex(422, 263);
  vertex(377, 235);
  vertex(351, 239);
  vertex(377, 260);
  vertex(363, 274);
  vertex(330, 292);
  endShape();
}
function drawLeaves2() {
  // fill("black");
  beginShape();
  vertex(484, 241);
  vertex(469, 288);
  vertex(455, 283);
  vertex(452, 300);
  vertex(413, 289);
  vertex(397, 287);
  vertex(429, 275);
  vertex(453, 239);
  vertex(425, 223);
  vertex(442, 208);
  vertex(464, 198);
  vertex(431, 179);
  vertex(389, 171);
  vertex(367, 167);
  vertex(366, 130);
  vertex(351, 117);
  vertex(387, 121);
  vertex(415, 139);
  vertex(450, 154);
  vertex(476, 152);
  vertex(471, 130);
  vertex(488, 106);
  vertex(513, 86);
  vertex(525, 63);
  vertex(536, 93);
  vertex(527, 112);
  vertex(536, 141);
  vertex(524, 177);
  vertex(560, 176);
  vertex(572, 152);
  vertex(575, 121);
  vertex(616, 102);
  vertex(622, 143);
  vertex(604, 163);
  vertex(599, 205);
  vertex(561, 206);
  vertex(540, 226);
  vertex(584, 235);
  vertex(636, 227);
  vertex(662, 240);
  vertex(675, 259);
  vertex(671, 270);
  vertex(660, 256);
  vertex(642, 256);
  vertex(618, 269);
  vertex(572, 267);
  vertex(536, 247);
  vertex(517, 255);
  vertex(482, 250);
  endShape();
} 
function drawBird1() {
  // fill("black");
  beginShape();
  vertex(32, 273);
  vertex(49, 235);
  vertex(73, 238);
  vertex(83, 213);
  vertex(122, 212);
  vertex(94, 223);
  vertex(81, 245);
  vertex(56, 245);
  vertex(33, 271);
  vertex(46, 277);
  endShape();
}
function drawBird2() {
  // fill("black");
  beginShape();
  vertex(211, 82);
  vertex(227, 49);
  vertex(266, 48);
  vertex(288, 16);
  vertex(317, 19);
  vertex(294, 22);
  vertex(277, 52);
  vertex(235, 57);
  vertex(212, 81);
  endShape();
}
function drawBird3() {
  // fill("black");
  beginShape();
  vertex(170, 157);
  vertex(178, 125);
  vertex(207, 126);
  vertex(224, 98);
  vertex(266, 109);
  vertex(228, 108);
  vertex(213, 134);
  vertex(188, 133);
  vertex(170, 158);
  endShape();
}
