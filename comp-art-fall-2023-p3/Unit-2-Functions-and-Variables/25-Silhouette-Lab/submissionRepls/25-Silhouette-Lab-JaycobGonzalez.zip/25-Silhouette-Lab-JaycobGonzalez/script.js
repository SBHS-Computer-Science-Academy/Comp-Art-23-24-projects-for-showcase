function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();

  
  
  drawShape();
  drawShape2();
  drawShape3();
  drawShape4();
  drawBird();
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('OrangeRed'), color('blue'), "horizontal", 400); // for details, see "gradient.js" file

  
}

function drawShape() {
  fill('orange')
  ellipse(500, 430, 500, 400);
  
  fill('wheat');
  rect(0, 450, 1000, 400);
  noStroke();
  
}

function drawShape2() {
  fill("DeepSkyBlue");
  beginShape();
  curveVertex(645, 451); // control point
  curveVertex(645, 451);
  curveVertex(659, 624);
  curveVertex(579, 800);
  curveVertex(744, 799);
  curveVertex(789, 581);
  curveVertex(693, 451);
  curveVertex(693, 451); // control point
  endShape();

  fill("Wheat");
  beginShape();
  curveVertex(633, 452); // control point
  curveVertex(633, 452);
  curveVertex(636, 606);
  curveVertex(544, 800);
  curveVertex(544, 800); // control point
  endShape();

  beginShape();
  curveVertex(633, 452); // control point
  curveVertex(633, 452);
  curveVertex(645, 452);
  curveVertex(647, 465);
  curveVertex(661, 568);
  curveVertex(661, 609);
  curveVertex(653, 643);
  curveVertex(603, 735);
  curveVertex(581, 772);
  curveVertex(577, 799);
  curveVertex(543, 799);
  curveVertex(638, 613);
  curveVertex(633, 452);
  curveVertex(633, 452); // control point
  endShape();

  beginShape();
  vertex(632, 464);
  vertex(632, 610);
  vertex(566, 741);
  vertex(611, 699);
  vertex(651, 594);
  vertex(636, 461);
  vertex(630, 466);
  endShape();
  
  beginShape();
  curveVertex(696, 453); // control point
  curveVertex(696, 453);
  curveVertex(769, 530);
  curveVertex(791, 641);
  curveVertex(772, 745);
  curveVertex(745, 799);
  curveVertex(817, 796);
  curveVertex(879, 584);
  curveVertex(741, 464);
  curveVertex(696, 450);
  curveVertex(701, 458);
  curveVertex(701, 458); // control point
  endShape();

   
  beginShape();
  vertex(694, 452);
  vertex(773, 534);
  endShape();

   
  beginShape();
  vertex(693, 452);
  vertex(783, 546);
  vertex(790, 652);
  vertex(775, 736);
  endShape();

   beginShape();
    curveVertex(694, 451); // control point
    curveVertex(694, 451);
    curveVertex(777, 742);
    curveVertex(841, 595);
    curveVertex(714, 457);
    curveVertex(696, 465);
    curveVertex(696, 465); // control point
    endShape();
  
  beginShape();
  curveVertex(746, 630); // control point
  curveVertex(746, 630);
  curveVertex(748, 701);
  curveVertex(712, 796);
  curveVertex(757, 799);
  curveVertex(790, 728);
  curveVertex(771, 629);
  curveVertex(746, 631);
  curveVertex(746, 631); // control point
  endShape();
  }

  function drawShape3() {
     fill("black");
    beginShape();
    vertex(112, 681);
    vertex(163, 682);
    vertex(164, 599);
    vertex(190, 599);
    vertex(208, 597);
    vertex(238, 577);
    vertex(252, 563);
    vertex(255, 547);
    vertex(257, 534);
    vertex(239, 507);
    vertex(227, 512);
    vertex(223, 522);
    vertex(222, 536);
    vertex(216, 549);
    vertex(195, 561);
    vertex(174, 561);
    vertex(178, 513);
    vertex(175, 480);
    vertex(174, 441);
    vertex(174, 406);
    vertex(171, 391);
    vertex(165, 387);
    vertex(154, 386);
    vertex(146, 391);
    vertex(143, 395);
    vertex(141, 407);
    vertex(139, 428);
    vertex(135, 549);
    vertex(122, 546);
    vertex(118, 542);
    vertex(115, 537);
    vertex(114, 532);
    vertex(115, 522);
    vertex(118, 515);
    vertex(118, 507);
    vertex(117, 496);
    vertex(115, 488);
    vertex(107, 485);
    vertex(97, 489);
    vertex(90, 498);
    vertex(89, 510);
    vertex(87, 519);
    vertex(85, 534);
    vertex(87, 543);
    vertex(92, 554);
    vertex(101, 564);
    vertex(107, 569);
    vertex(120, 574);
    vertex(134, 575);
    vertex(131, 682);
    endShape();

    
  }

function drawShape4() {
 fill("black");
  beginShape();
  vertex(109, 266);
  vertex(144, 221);
  vertex(167, 258);
  vertex(190, 221);
  vertex(232, 246);
  vertex(193, 210);
  vertex(167, 241);
  vertex(142, 202);
  vertex(108, 267);
  endShape();
}

function drawBird() {
  fill("black");
  beginShape();
  vertex(50, 183);
  vertex(84, 140);
  vertex(95, 189);
  vertex(122, 136);
  vertex(148, 178);
  vertex(126, 118);
  vertex(97, 171);
  vertex(87, 118);
  vertex(49, 182);
  endShape();

  beginShape();
  vertex(185, 334);
  vertex(206, 310);
  vertex(219, 331);
  vertex(231, 311);
  vertex(253, 334);
  vertex(231, 317);
  vertex(221, 337);
  vertex(205, 317);
  vertex(186, 334);
  endShape();

  beginShape();
  vertex(34, 351);
  vertex(55, 320);
  vertex(83, 350);
  vertex(107, 312);
  vertex(134, 341);
  vertex(108, 321);
  vertex(84, 360);
  vertex(56, 330);
  vertex(34, 351);
  endShape();
}
