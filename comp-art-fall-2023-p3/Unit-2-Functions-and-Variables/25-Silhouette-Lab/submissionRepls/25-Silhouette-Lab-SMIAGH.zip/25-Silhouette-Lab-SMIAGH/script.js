 function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  // textAlign(CENTER, CENTER);
  // angleMode(DEGREES);
}

function draw() {
  clear();
 drawMouseLines("black");
  
  drawSky();
  drawSun()
  drawIsland()
  drawSea()
  drawBoat()
  drawMast()
  drawSail()
  drawSail2()
  drawBird()
  drawCloud()
  drawTree()
  drawLeaf()
  
 drawMouseLines("black");
  
}

function drawSky() {

  rectGradient(0, 0, width, height/2, color('yellow'), color('red'), "horizontal", 400); // for details, see "gradient.js" file

  
}

function drawSea() {

  rectGradient(0,400, width, height, color('skyblue'), color('blue'), "horizontal,500")
}

function drawSun() {
  circleGradient(300, 400, 300, color('yellow'), color('white'), 0)
}

function drawBoat() {
  fill("black");
  beginShape();
  vertex(146, 473);
  vertex(163, 485);
  vertex(174, 498);
  vertex(215, 492);
  vertex(250, 493);
  vertex(289, 500);
  vertex(297, 484);
  vertex(146, 473);
  endShape();
}

function drawMast() {
  fill("black");
  beginShape();
  vertex(213, 477);
  vertex(216, 429);
  vertex(221, 431);
  vertex(218, 478);
  vertex(212, 477);
  vertex(219, 478);
  vertex(212, 478);
  endShape();
}

function drawSail() {
  fill("black");
  beginShape();
  vertex(214, 456);
  vertex(192, 457);
  vertex(219, 408);
  vertex(214, 458);
  endShape();
}

function drawSail2() {
  fill("black");
  beginShape();
  vertex(224, 403);
  vertex(218, 471);
  vertex(252, 471);
  vertex(224, 403);
  endShape();
}

function drawBird() {
  // fill("black");
  beginShape();
  vertex(79, 308);
  vertex(85, 285);
  vertex(111, 299);
  vertex(119, 271);
  vertex(140, 279);
  vertex(122, 282);
  vertex(117, 306);
  vertex(90, 295);
  vertex(79, 306);
  endShape();
}

function drawCloud() {
 noStroke()
  fill('white')
  circle(550,280,80)
  circle(590,290,60)
  circle(520,290,40)
  circle(510,310,50)
  circle(550,310,50)


  circle(380,270,80)
  circle(410,270,60)
  circle(350,280,50)
  circle(370,280,50)
  
}


function drawIsland() {
  fill('NavajoWhite')
  ellipse(800,400,150,60)
}

function drawTree() {
  fill("black");
  beginShape();
  curveVertex(763, 378); // control point
  curveVertex(763, 378);
  curveVertex(770, 358);
  curveVertex(756, 315);
  curveVertex(761, 304);
  curveVertex(778, 352);
  curveVertex(781, 376);
  curveVertex(761, 379);
  curveVertex(761, 379); // control point
  endShape();
}

function drawLeaf() {
  // fill("black");
 //leaf1
  beginShape();
  vertex(761, 306);
  vertex(770, 304);
  vertex(784, 305);
  vertex(800, 309);
  vertex(798, 300);
  vertex(786, 292);
  vertex(773, 291);
  vertex(760, 296);
  vertex(756, 303);
  
//leaf2
  vertex(757, 305);
  vertex(739, 304);
  vertex(727, 306);
  vertex(718, 313);
  vertex(721, 301);
  vertex(734, 294);
  vertex(751, 294);
  vertex(759, 300);
  //leaf3
  vertex(751, 295);
  vertex(756, 286);
  vertex(766, 279);
  vertex(779, 276);
  vertex(791, 278);
  vertex(805, 283);
  vertex(814, 290);
  vertex(801, 290);
  vertex(789, 287);
  vertex(775, 287);
  vertex(765, 290);
  vertex(762, 295);
  endShape()

  circle(758,297,15)

  circle(755, 307,10)
  circle(765, 308,10)
}