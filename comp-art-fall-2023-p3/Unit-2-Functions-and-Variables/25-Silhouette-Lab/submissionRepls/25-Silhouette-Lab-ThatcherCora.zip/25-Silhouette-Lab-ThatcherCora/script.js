function setup() {
  let myCanvas = createCanvas(990, 600);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  noStroke()
  drawGreen()
  drawShape()
  drawBody()
  drawtail()//tail
  drawLegs()
  drawWhite()//star
  drawStar()
  drawStar()//stars
  drawShip()
  drawTop()
  drawAlen()
  
  drawGun()
  drawBullets()
  //text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width / 2, 700);
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('black'), color('white'), "horizontal", 400); // for details, see "gradient.js" file
circleGradient(width / 2, 200, 150, "white", "gray"); // moon

}

function drawGreen() {
  fill("green");//grass
  beginShape();
  vertex(1, 409);
  vertex(993, 406);
  vertex(990, 707);
  vertex(2, 718);
  vertex(-1, 406);
  endShape();
}

function drawShape() {
  fill("black");//black
  beginShape();
  curveVertex(626, 302); // control point
  curveVertex(626, 302);
  curveVertex(560, 200);
  curveVertex(536, 197);
  curveVertex(514, 190);
  curveVertex(526, 207);
  curveVertex(501, 201);
  curveVertex(516, 218);
  curveVertex(492, 247);
  curveVertex(533, 232);
  curveVertex(549, 228);
  curveVertex(605, 309);
  curveVertex(626, 303);
  curveVertex(626, 303); // control point
  endShape();
}

function drawBody() {
    fill("black");  // body
  beginShape();
  curveVertex(613, 314); // control point
  curveVertex(613, 314);
  curveVertex(643, 293);
  curveVertex(695, 286);
  curveVertex(762, 287);
  curveVertex(791, 326);
  curveVertex(611, 329);
  curveVertex(627, 303);
  curveVertex(627, 303); // control point
  endShape();
}
function drawtail() {
  fill("black");//tail
  beginShape();
  curveVertex(798, 321); // control point
  curveVertex(798, 321);
  curveVertex(849, 336);
  curveVertex(857, 343);
  curveVertex(862, 340);
  curveVertex(858, 335);
  curveVertex(796, 316);
  curveVertex(796, 316); // control point
  endShape();
}

function drawLegs() {
  fill("black");//legs
  beginShape();
  vertex(603, 327);
  vertex(502, 408);
  vertex(493, 409);
  vertex(493, 413);
  vertex(503, 413);
  vertex(618, 328);
  vertex(663, 407);
  vertex(647, 408);
  vertex(645, 401);
  vertex(652, 401);
  vertex(612, 328);
  vertex(785, 316);
  vertex(854, 408);
  vertex(831, 407);
  vertex(828, 399);
  vertex(838, 398);
  vertex(776, 317);
  vertex(732, 408);
  vertex(709, 407);
  vertex(721, 406);
  vertex(721, 398);
  vertex(730, 397);
  vertex(760, 325);
  endShape();
}

function drawWhite() {
  fill("white");//star
  beginShape();
  vertex(540, 49);
  vertex(567, 78);
  vertex(570, 51);
  vertex(540, 68);
  vertex(584, 66);
  vertex(542, 51);
  endShape();
}

function drawStar() {
   fill("white");//star
  beginShape();
  vertex(796, 45);
  vertex(821, 76);
  vertex(824, 51);
  vertex(796, 66);
  vertex(843, 67);
  vertex(799, 49);
  endShape();
}
function drawStar() {
   fill("white");//star
  beginShape();
  vertex(141, 73);
  vertex(164, 99);
  vertex(173, 74);
  vertex(145, 90);
  vertex(190, 91);
  vertex(139, 69);
  endShape();
}
function drawShip() {
   fill(170,201,250);//ship
  beginShape();
  curveVertex(103, 186); // control point
  curveVertex(103, 186);
  curveVertex(274, 186);
  curveVertex(253, 166);
  curveVertex(107, 165);
  curveVertex(56, 182);
  curveVertex(128, 186);
  curveVertex(128, 186); // control point
  endShape();
}
function drawTop() {
   fill("cyan");//ship
  beginShape();
  curveVertex(130, 166); // control point
  curveVertex(130, 166);
  curveVertex(130, 128);
  curveVertex(178, 123);
  curveVertex(186, 166);
  curveVertex(186, 166); // control point
  endShape();
}
function drawAlen() {
   fill("black");//star
  beginShape();
  vertex(159, 141);
  vertex(168, 140);
  vertex(166, 124);
  vertex(140, 129);
  vertex(141, 142);
  vertex(155, 140);
  vertex(155, 153);
  vertex(162, 162);
  vertex(155, 155);
  vertex(149, 164);
  vertex(155, 154);
  vertex(154, 141);
  vertex(166, 140);
  endShape();
}


function drawGun() {
  fill("black");//gun
  beginShape();
  vertex(190, 189);
  vertex(192, 214);
  vertex(233, 214);
  vertex(230, 204);
  vertex(201, 206);
  vertex(199, 189);
  endShape();
}

function drawBullets() {
  fill("red");//bullets
  beginShape();
  vertex(241, 210);
  vertex(258, 210);
  vertex(258, 214);
  vertex(243, 215);
  vertex(243, 211);
  endShape();
}