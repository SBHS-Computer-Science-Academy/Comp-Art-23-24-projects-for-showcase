
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}
function draw() {
  color1=color(186, 240, 247)
  color2=color(255, 111, 0)
  let colo=color(255, 200, 36)
  let col=color('yellow')
  gradrect(color1, color2, 100)
  circleGradient(350, 490, 200, colo, col)
  fill(30)

  rect(0, 500, 1000, 500)
  fill(0, 255, 0, 20)
  rect(0, 500, 1000, 500)
  cloud()
  guy()
  //faintmtnshadow()
  curveVertexGradient([895, 838, 771, 706, 702, 690, 644, 617, 589, 568, 555, 520, 728], [501, 421, 345, 280, 252, 270, 311, 346, 370, 402, 462, 500, 496], 895, 501, "sienna", "black")
}
function gradrect(clrStart, clrEnd, steps){
  let p=width/steps
  for(let v=0;v<=height;v+=p){
    fill(lerpColor(clrStart, clrEnd, v / height))
    noStroke()
    rect(0, v, 1000, p)
  }
}
function sun(){
  gradientEllipse(col,colo,100,500,300,200,200)
}
function drawThing() {
  // fill("black");
  beginShape();
  vertex(219, 275);
  vertex(165, 355);
  vertex(213, 418);
  vertex(314, 491);
  vertex(231, 558);
  vertex(335, 582);
  vertex(436, 443);
  endShape();
}

function guy(){
  
  strokeWeight(10)
  stroke('black')
  line(182, 752, 223, 621)
  line(223, 621, 299, 751)
  line(223, 621, 222, 492)
  line(225, 511, 256, 576)
  line(222, 511, 187, 575)
  stroke(0, 5)
  line(180, 762, 173, 798)
  line(300, 758, 265, 799)
  fill('black')
  ellipse(223, 450, 100, 100)
}
function cloud(){
  fill(255, 50)
  beginShape();
  curveVertex(561, 140); // control point
  curveVertex(561, 140);
  curveVertex(493, 159);
  curveVertex(451, 170);
  curveVertex(436, 198);
  curveVertex(487, 168);
  curveVertex(538, 184);
  curveVertex(559, 168);
  curveVertex(592, 163);
  curveVertex(618, 189);
  curveVertex(654, 186);
  curveVertex(697, 158);
  curveVertex(696, 143);
  curveVertex(678, 128);
  curveVertex(667, 126);
  curveVertex(648, 127);
  curveVertex(631, 128);
  curveVertex(604, 113);
  curveVertex(593, 103);
  curveVertex(576, 106);
  curveVertex(563, 113);
  curveVertex(563, 113); // control point
  endShape();
  beginShape();
  curveVertex(4, 144); // control point
  curveVertex(4, 144);
  curveVertex(35, 108);
  curveVertex(72, 125);
  curveVertex(129, 146);
  curveVertex(200, 108);
  curveVertex(199, 75);
  curveVertex(164, 71);
  curveVertex(125, 52);
  curveVertex(109, 67);
  curveVertex(82, 79);
  curveVertex(45, 31);
  curveVertex(12, 58);
  curveVertex(12, 58); // control point
  endShape();
}
function faintmtnshadow(){
  fill(0, 5)
  beginShape();
  vertex(525, 500);
  vertex(555, 521);
  vertex(567, 522);
  vertex(574, 524);
  vertex(588, 532);
  vertex(613, 544);
  vertex(648, 559);
  vertex(660, 562);
  vertex(685, 564);
  vertex(709, 572);
  vertex(731, 579);
  vertex(768, 591);
  vertex(810, 596);
  vertex(847, 596);
  vertex(920, 620);
  vertex(943, 621);
  vertex(990, 618);
  vertex(948, 573);
  vertex(958, 539);
  vertex(963, 530);
  vertex(969, 520);
  vertex(962, 510);
  vertex(956, 507);
  vertex(948, 506);
  vertex(936, 508);
  vertex(907, 506);
  vertex(898, 502);
  vertex(894, 503);
  endShape();
}