function drawsomebigsunrays() {
    // fill("black");
    beginShape();
    vertex(537, 502);
    vertex(521, 430);
    vertex(589, 475);
    vertex(596, 476);
    vertex(631, 467);
    vertex(632, 393);
    vertex(690, 461);
    vertex(725, 465);
    vertex(761, 403);
    vertex(793, 480);
    vertex(802, 487);
    vertex(804, 487);
    vertex(825, 495);
    vertex(887, 455);
    vertex(879, 533);
    endShape();
}
