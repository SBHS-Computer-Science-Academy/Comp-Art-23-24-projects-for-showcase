function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  drawground()
  drawcloud()
  drawslightlybiggercloud()
  drawsomemoreground()
  drawsunrise()
  drawslightlysmallercloud()
  drawtreetrunkandbranches()
  drawswingrope1()
  drawwoodenpiece()
  drawswingrope2()
  drawtreebranches()
  drawsingletreebranch()
  drawvshapedbranches()
  drawmoretreebranches()
  drawlasttreebranch()
  drawcircle()
  drawshortline()
  drawarms()
  drawlegs()
  drawleg()
  
  
  
  


  
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, -160, width, height, color('dodgerblue'), color('gold'), "horizontal", 400); // for details, see "gradient.js" file

  
}
function drawground() {
  fill("black");
  beginShape();
  vertex(2, 558);
  vertex(99, 549);
  vertex(266, 530);
  vertex(419, 523);
  vertex(563, 537);
  vertex(741, 565);
  vertex(763, 575);
  vertex(764, 797);
  vertex(4, 800);
  vertex(0, 783);
  vertex(0, 558);
  vertex(5, 558);
  endShape();
}
function drawcloud() {
  fill("lightgray");
  beginShape();
  vertex(60, 234);
  vertex(99, 241);
  vertex(137, 242);
  vertex(184, 239);
  vertex(164, 210);
  vertex(158, 204);
  vertex(145, 207);
  vertex(138, 213);
  vertex(128, 198);
  vertex(110, 198);
  vertex(104, 202);
  vertex(92, 210);
  vertex(77, 201);
  vertex(66, 206);
  vertex(54, 231);
  vertex(62, 235);
  endShape();
}
function drawslightlybiggercloud() {
  fill("lightgray");
  beginShape();
  vertex(421, 186);
  vertex(502, 183);
  vertex(605, 189);
  vertex(646, 176);
  vertex(626, 140);
  vertex(602, 122);
  vertex(582, 123);
  vertex(568, 130);
  vertex(558, 119);
  vertex(540, 114);
  vertex(531, 115);
  vertex(520, 123);
  vertex(509, 130);
  vertex(491, 116);
  vertex(478, 118);
  vertex(467, 122);
  vertex(460, 128);
  vertex(455, 139);
  vertex(439, 132);
  vertex(427, 133);
  vertex(413, 139);
  vertex(404, 148);
  vertex(393, 167);
  vertex(386, 177);
  vertex(427, 187);
  endShape();
}
function drawsomemoreground() {
  fill("black");
  beginShape();
  vertex(744, 564);
  vertex(840, 553);
  vertex(953, 551);
  vertex(999, 553);
  vertex(1000, 799);
  vertex(754, 797);
  vertex(627, 799);
  vertex(541, 799);
  vertex(542, 713);
  vertex(745, 566);
  vertex(746, 564);
  vertex(720, 562);
  vertex(762, 640);
  endShape();
}
function drawsunrise() {
  fill("gold");
  beginShape();
  vertex(506, 528);
  vertex(571, 481);
  vertex(666, 459);
  vertex(763, 469);
  vertex(847, 505);
  vertex(895, 547);
  vertex(897, 553);
  vertex(838, 553);
  vertex(744, 564);
  vertex(697, 557);
  vertex(576, 538);
  vertex(537, 533);
  vertex(504, 531);
  vertex(507, 528);
  endShape();
}
function drawslightlysmallercloud() {
  fill("lightgray");
  beginShape();
  vertex(734, 306);
  vertex(787, 316);
  vertex(879, 311);
  vertex(910, 306);
  vertex(887, 267);
  vertex(864, 253);
  vertex(847, 258);
  vertex(840, 267);
  vertex(822, 250);
  vertex(806, 249);
  vertex(789, 255);
  vertex(779, 272);
  vertex(747, 267);
  vertex(735, 273);
  vertex(716, 295);
  vertex(737, 307);
  endShape();
}
function drawtreetrunkandbranches() {
  fill("black");
  beginShape();
  vertex(140, 543);
  vertex(161, 518);
  vertex(169, 494);
  vertex(175, 456);
  vertex(173, 431);
  vertex(155, 395);
  vertex(80, 357);
  vertex(79, 343);
  vertex(154, 376);
  vertex(139, 275);
  vertex(160, 285);
  vertex(185, 364);
  vertex(220, 280);
  vertex(247, 282);
  vertex(215, 352);
  vertex(214, 373);
  vertex(217, 379);
  vertex(292, 328);
  vertex(297, 337);
  vertex(230, 391);
  vertex(218, 401);
  vertex(224, 419);
  vertex(219, 474);
  vertex(214, 512);
  vertex(233, 531);
  vertex(240, 534);
  vertex(184, 539);
  vertex(140, 546);
  vertex(141, 543);
  endShape();
}
function drawswingrope1() {
  // fill("black");
  beginShape();
  vertex(255, 370);
  vertex(255, 473);
  endShape();
}
function drawwoodenpiece() {
  // fill("black");
  beginShape();
  vertex(251, 472);
  vertex(308, 472);
  vertex(307, 483);
  vertex(250, 484);
  vertex(251, 473);
  endShape();
}
function drawswingrope2() {
  // fill("black");
  beginShape();
  vertex(296, 336);
  vertex(302, 464);
  vertex(303, 473);
  endShape();
}
function drawtreebranches() {
  // fill("black");
  beginShape();
  vertex(221, 280);
  vertex(187, 197);
  vertex(207, 199);
  vertex(233, 265);
  vertex(280, 206);
  vertex(291, 217);
  vertex(245, 281);
  endShape();
}
function drawsingletreebranch() {
  // fill("black");
  beginShape();
  vertex(247, 278);
  vertex(328, 256);
  vertex(333, 269);
  vertex(239, 297);
  endShape();
}
function drawvshapedbranches() {
  // fill("black");
  beginShape();
  vertex(291, 329);
  vertex(312, 279);
  vertex(321, 282);
  vertex(304, 328);
  vertex(363, 339);
  vertex(359, 348);
  vertex(292, 339);
  vertex(292, 329);
  endShape();
}
function drawmoretreebranches() {
 fill("black");
  beginShape();
  vertex(144, 282);
  vertex(65, 230);
  vertex(81, 221);
  vertex(133, 250);
  vertex(133, 168);
  vertex(142, 173);
  vertex(149, 250);
  vertex(200, 207);
  vertex(212, 219);
  vertex(154, 264);
  vertex(161, 289);
  vertex(138, 277);
  endShape();
}
function drawlasttreebranch() {
  fill("black");
  beginShape();
  vertex(80, 356);
  vertex(17, 377);
  vertex(15, 366);
  vertex(64, 348);
  vertex(18, 297);
  vertex(28, 293);
  vertex(78, 342);
  vertex(79, 357);
  endShape();
}
function drawcircle() {
  fill("black");
  beginShape();
  vertex(282, 404);
  vertex(273, 403);
  vertex(262, 409);
  vertex(259, 420);
  vertex(262, 429);
  vertex(271, 437);
  vertex(283, 436);
  vertex(291, 431);
  vertex(294, 425);
  vertex(294, 416);
  vertex(290, 408);
  vertex(282, 404);
  endShape();
}
function drawshortline() {
  // fill("black");
  beginShape();
  vertex(277, 437);
  vertex(278, 472);
  endShape();
}
function drawarms() {
  // fill("black");
  beginShape();
  vertex(260, 451);
  vertex(298, 450);
  endShape();
}
function drawlegs() {
  // fill("black");
  beginShape();
  vertex(277, 484);
  vertex(281, 517);
  vertex(277, 479);
  endShape();
}
function drawleg() {
  // fill("black");
  beginShape();
  vertex(285, 482);
  vertex(304, 514);
  endShape();
}