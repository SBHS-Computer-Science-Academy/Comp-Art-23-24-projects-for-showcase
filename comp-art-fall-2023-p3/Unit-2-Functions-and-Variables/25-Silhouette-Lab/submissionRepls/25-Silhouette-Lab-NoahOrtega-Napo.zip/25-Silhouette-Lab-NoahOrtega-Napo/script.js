

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
drawplane()
  
  text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width/2, 700);
  drawMouseLines("black");
}

function drawBackground() {
background("black")
  circleGradient(width / 2, 350, 700, "black", "DodgerBlue");
  
  
}
function drawplane() {
  fill("black");
   beginShape();
  vertex(333, 521);
  vertex(205, 583);
  vertex(517, 570);
  vertex(386, 519);
  vertex(332, 527);
  endShape();
fill("black")
ellipse(359, 370,75,400)
beginShape();
  vertex(329, 242);
  vertex(91, 368);
  vertex(319, 365);
  vertex(330, 245);
  endShape();
  beginShape();
  vertex(390, 242);
  vertex(596, 353);
  vertex(389, 356);
  vertex(386, 245);
  endShape();
}
  

