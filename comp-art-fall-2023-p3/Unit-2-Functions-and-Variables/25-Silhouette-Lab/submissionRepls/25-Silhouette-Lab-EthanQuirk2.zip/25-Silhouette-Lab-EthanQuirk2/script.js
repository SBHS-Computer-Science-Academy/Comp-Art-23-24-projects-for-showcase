function setup() {
  let myCanvas = createCanvas(1000, 600);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}



function draw() {
 
  
  rectGradient(0, 0, width, 200, "magenta", "crimson"); 
  circleGradient(width / 2, 200, 150, "orangeRed", "yellow"); 
  curveVertexGradient( [055, 055, 112, 170, 229, 225, 178, 147, 106, 033, 005, 027, 055, 055],  [085, 085, 057, 066, 094, 119, 152, 142, 165, 141, 097, 045, 083, 083],107,110 , color(200, 0), color (200, 100), "horizontal"); 
  curveVertexGradient( [629, 629, 704, 753, 783, 837, 918, 855, 825, 717, 634, 536, 514, 562, 614, 629, 629], [119, 119, 077, 097, 086, 112, 160, 166, 139, 165, 161, 153, 082, 096, 077, 121, 121] , 713, 130, color (200,0), color (200,100), "horizontal"); 
  rectGradient(0, 200, width, 400, "blue", "darkblue"); 

  

  
  
  drawDolphin()
  drawBird1()
  drawBird2()
  drawBird3()
  drawBird4()
    drawMouseLines("black");
}
 


function drawDolphin() {
   fill("black");
  beginShape();
  vertex(739, 428);
  vertex(730, 423);
  vertex(730, 435);
  vertex(710, 445);
  vertex(709, 430);
  vertex(718, 404);
  vertex(686, 363);
  vertex(630, 344);
  vertex(575, 336);
  vertex(573, 358);
  vertex(577, 377);
  vertex(566, 374);
  vertex(560, 362);
  vertex(552, 343);
  vertex(496, 344);
  vertex(447, 360);
  vertex(441, 359);
  vertex(439, 353);
  vertex(462, 341);
  vertex(462, 328);
  vertex(464, 320);
  vertex(497, 298);
  vertex(542, 284);
  vertex(590, 280);
  vertex(614, 283);
  vertex(621, 266);
  vertex(637, 258);
  vertex(651, 257);
  vertex(643, 264);
  vertex(634, 276);
  vertex(636, 289);
  vertex(686, 306);
  vertex(704, 324);
  vertex(729, 355);
  vertex(734, 374);
  vertex(734, 397);
  vertex(784, 404);
  vertex(754, 421);
  vertex(739, 428);
  endShape();
}

function drawBird1() {
   fill("black");
  beginShape();
  vertex(357, 163);
  vertex(362, 172);
  vertex(368, 163);
  vertex(369, 165);
  vertex(362, 176);
  vertex(355, 164);
  vertex(357, 163);
  endShape();
}
function drawBird2() {
  // fill("black");
  beginShape();
  vertex(530, 167);
  vertex(535, 184);
  vertex(546, 167);
  vertex(548, 170);
  vertex(534, 190);
  vertex(527, 167);
  vertex(530, 167);
  endShape();
}
function drawBird3() {
  // fill("black");
  beginShape();
  vertex(408, 171);
  vertex(415, 182);
  vertex(424, 170);
  vertex(426, 173);
  vertex(415, 186);
  vertex(406, 172);
  vertex(408, 171);
  endShape();
}
function drawBird4() {
  // fill("black");
  beginShape();
  vertex(462, 176);
  vertex(470, 188);
  vertex(479, 177);
  vertex(481, 179);
  vertex(469, 192);
  vertex(460, 177);
  vertex(462, 176);
  endShape();
}