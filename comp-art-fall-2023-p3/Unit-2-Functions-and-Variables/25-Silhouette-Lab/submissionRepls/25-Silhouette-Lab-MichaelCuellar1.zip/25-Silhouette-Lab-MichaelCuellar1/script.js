function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
drawHorse()
  //text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width/2, 700);
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('deepSkyBlue'), color('green'), "horizontal", 400); // for details, see "gradient.js" file

  
}

function drawHorse() {

  
  fill("gray");
  beginShape();
  vertex(-1, 274);
  vertex(63, 80);
  vertex(152, 263);
  vertex(194, 3);
  vertex(460, 355);
  vertex(-2, 368);
  vertex(-2, 269);
  endShape();

 
  beginShape();
  vertex(106, 364);
  vertex(729, 358);
  vertex(699, 138);
  vertex(645, 225);
  vertex(575, 41);
  vertex(484, 186);
  vertex(426, 153);
  vertex(356, 216);
  vertex(459, 353);
  vertex(105, 364);
  endShape();
  
  fill("black");
  beginShape();
  curveVertex(236, 525); // control point
  curveVertex(236, 525);
  curveVertex(288, 502);
  curveVertex(311, 508);
  curveVertex(332, 551);
  curveVertex(325, 594);
  curveVertex(325, 634);
  curveVertex(333, 649);
  curveVertex(361, 654);
  curveVertex(429, 657);
  curveVertex(512, 651);
  curveVertex(546, 640);
  curveVertex(561, 603);
  curveVertex(557, 571);
  curveVertex(538, 560);
  curveVertex(507, 554);
  curveVertex(405, 550);
  curveVertex(376, 528);
  curveVertex(350, 455);
  curveVertex(314, 422);
  curveVertex(268, 424);
  curveVertex(249, 443);
  curveVertex(207, 488);
  curveVertex(209, 514);
  curveVertex(236, 525);
  curveVertex(236, 525); // control point
  endShape();


  fill("black");
  beginShape();
  curveVertex(324, 612); // control point
  curveVertex(324, 612);
  curveVertex(317, 634);
  curveVertex(306, 651);
  curveVertex(259, 688);
  curveVertex(262, 737);
  curveVertex(275, 738);
  curveVertex(272, 693);
  curveVertex(314, 683);
  curveVertex(365, 650);
  curveVertex(324, 617);
  curveVertex(324, 617); // control point
  endShape();

  fill("black");
  beginShape();
  curveVertex(363, 656); // control point
  curveVertex(363, 656);
  curveVertex(338, 703);
  curveVertex(358, 760);
  curveVertex(372, 761);
  curveVertex(357, 714);
  curveVertex(414, 656);
  curveVertex(362, 654);
  curveVertex(362, 658);
  curveVertex(362, 658); // control point
  endShape();

  fill("black");
  beginShape();
  curveVertex(460, 657); // control point
  curveVertex(460, 657);
  curveVertex(457, 679);
  curveVertex(453, 696);
  curveVertex(425, 741);
  curveVertex(437, 750);
  curveVertex(470, 703);
  curveVertex(500, 684);
  curveVertex(505, 651);
  curveVertex(511, 703);
  curveVertex(473, 751);
  curveVertex(483, 760);
  curveVertex(528, 714);
  curveVertex(557, 621);
  curveVertex(543, 643);
  curveVertex(457, 657);
  curveVertex(457, 657); // control point
  endShape();

  fill("black");
  beginShape();
  curveVertex(531, 706); // control point
  curveVertex(531, 706);
  curveVertex(561, 656);
  curveVertex(554, 618);
  curveVertex(540, 646);
  curveVertex(532, 703);
  curveVertex(532, 703); // control point
  endShape();

fill("black");
  beginShape();
  curveVertex(557, 570); // control point
  curveVertex(557, 570);
  curveVertex(576, 612);
  curveVertex(619, 646);
  curveVertex(641, 654);
  curveVertex(653, 662);
  curveVertex(654, 681);
  curveVertex(607, 658);
  curveVertex(552, 596);
  curveVertex(552, 596); // control point
  endShape();

  fill("black");
  beginShape();
  curveVertex(560, 575); // control point
  curveVertex(560, 575);
  curveVertex(579, 606);
  curveVertex(600, 628);
  curveVertex(655, 656);
  curveVertex(663, 672);
  curveVertex(653, 682);
  curveVertex(574, 618);
  curveVertex(559, 578);
  curveVertex(559, 578); // control point
  endShape();

  fill('DodgerBlue')
  beginShape();
  curveVertex(447, 384); // control point
  curveVertex(447, 384);
  curveVertex(415, 378);
  curveVertex(378, 386);
  curveVertex(360, 410);
  curveVertex(354, 445);
  curveVertex(378, 486);
  curveVertex(446, 515);
  curveVertex(486, 517);
  curveVertex(520, 500);
  curveVertex(569, 512);
  curveVertex(667, 535);
  curveVertex(726, 511);
  curveVertex(734, 482);
  curveVertex(726, 407);
  curveVertex(576, 371);
  curveVertex(513, 387);
  curveVertex(447, 384);
  curveVertex(447, 384); // control point
  endShape();

fill("SaddleBrown");
  beginShape();
  curveVertex(11, 523); // control point
  curveVertex(11, 523);
  curveVertex(70, 501);
  curveVertex(84, 479);
  curveVertex(83, 355);
  curveVertex(65, 351);
  curveVertex(40, 363);
  curveVertex(2, 366);
  curveVertex(-4, 347);
  curveVertex(-6, 238);
  curveVertex(-4, 195);
  curveVertex(57, 180);
  curveVertex(121, 180);
  curveVertex(197, 193);
  curveVertex(257, 218);
  curveVertex(294, 247);
  curveVertex(314, 301);
  curveVertex(279, 342);
  curveVertex(215, 355);
  curveVertex(157, 352);
  curveVertex(131, 343);
  curveVertex(138, 447);
  curveVertex(155, 498);
  curveVertex(196, 514);
  curveVertex(12, 523);
  curveVertex(206, 515);
  curveVertex(206, 515); // control point
  endShape();

 fill("green");
  beginShape();
  curveVertex(105, 338); // control point
  curveVertex(105, 338);
  curveVertex(118, 334);
  curveVertex(133, 335);
  curveVertex(146, 346);
  curveVertex(156, 353);
  curveVertex(184, 356);
  curveVertex(207, 356);
  curveVertex(239, 355);
  curveVertex(256, 351);
  curveVertex(284, 343);
  curveVertex(295, 332);
  curveVertex(308, 320);
  curveVertex(311, 310);
  curveVertex(315, 299);
  curveVertex(312, 282);
  curveVertex(305, 267);
  curveVertex(292, 244);
  curveVertex(273, 226);
  curveVertex(245, 211);
  curveVertex(212, 197);
  curveVertex(189, 190);
  curveVertex(153, 183);
  curveVertex(109, 178);
  curveVertex(73, 177);
  curveVertex(42, 181);
  curveVertex(15, 186);
  curveVertex(1, 190);
  curveVertex(-4, 193);
  curveVertex(-6, 359);
  curveVertex(1, 365);
  curveVertex(17, 366);
  curveVertex(30, 366);
  curveVertex(47, 360);
  curveVertex(61, 352);
  curveVertex(67, 350);
  curveVertex(75, 344);
  curveVertex(82, 347);
  curveVertex(91, 345);
  curveVertex(94, 339);
  curveVertex(97, 337);
  curveVertex(100, 337);
  curveVertex(103, 337);
  curveVertex(106, 337);
  curveVertex(106, 337); // control point
  endShape();
  
}