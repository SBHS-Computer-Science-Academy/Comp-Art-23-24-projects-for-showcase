function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  //Building()


  drawThing()

  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('skyblue'), color('white'), "horizontal", 400);
}

function drawThing() {


}


