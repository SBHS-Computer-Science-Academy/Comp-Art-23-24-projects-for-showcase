function setup() {
  let myCanvas = createCanvas(1000,800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
   
  clear();
  drawBackground();

 rectGradient(0, 0, width, 300, "skyblue", "orange"); // sky with sunset
  circleGradient(width / 2, 300, 300, "orangeRed", "yellow"); // sun
  
 
 
  rectGradient(0, 300, width, 500, "skyblue", "black"); // foreground with shadows
   drawcloud()
  drawflag()
  drawboat()
  drawpole()
drawMouseLines()
  
  
}
function drawBackground() {

  
}
function drawboat() {
 fill("black");
  beginShape();
  curveVertex(206, 543); // control point
  curveVertex(206, 543);
  curveVertex(206, 652);
  curveVertex(501, 640);
  curveVertex(536, 555);
  curveVertex(629, 546);
  curveVertex(228, 546);
  curveVertex(330, 548);
  curveVertex(206, 544);
  curveVertex(206, 544); // control point
  endShape();
}
function drawpole() {
 fill("black");
  beginShape();
  vertex(307, 546);
  vertex(301, 398);
  vertex(323, 398);
  vertex(327, 547);
  vertex(307, 545);
  vertex(302, 401);
  endShape();
}
function drawflag() {
  fill("black");
  beginShape();
  vertex(324, 400);
  vertex(402, 399);
  vertex(365, 435);
  vertex(398, 457);
  vertex(230, 459);
  vertex(265, 442);
  vertex(206, 402);
  vertex(333, 401);
  endShape();
}
function drawcloud() {
  fill(255,230)
  noStroke()
  ellipse(785,148,150,60)
  ellipse(875,148,150,60)
  ellipse(831,120,150,60)
  
  ellipse(100,148,150,60)
    ellipse(200,148,150,60)
    ellipse(150,120,150,60)
  }
