function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  noStroke();
  drawBackground();
  
  drawCity()
 drawLight()
  drawBody()
  drawShape()
  drawLegs()
  
 
  drawStars()
 //text("Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like.", width/2, 700);
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color(46, 48, 74), color(153, 159, 247), "horizontal", 400); // for details, see "gradient.js" file

  
}
function drawLight() {
  fill(255,255,255,100);
vertexGradient([310,151,643,486], [441,800,800,443],396,450,color(255,255,255,5), color(255,255,255,15));

}
function drawBody() {
  fill('black');
  beginShape();
  ellipse(400,400,340,100);
  ellipse(400,320,110,100);
  endShape();
}

function drawShape() {
  // fill("black");
  beginShape();
  vertex(345, 327);
  vertex(289, 363);
  vertex(522, 365);
  vertex(453, 325);
  endShape();
}

function drawLegs() {
  // fill("black");
  beginShape();
  vertex(280, 430); //left
  vertex(262, 450);
  vertex(277, 457);
  vertex(297, 436);

  vertex(395, 449); //middle
  vertex(396, 471);
  vertex(410, 471);
  vertex(409, 445);
  vertex(397, 428);
  vertex(382, 439);
  vertex(394, 448);

  vertex(526, 433); //right
  vertex(545, 448);
  vertex(530, 457);
  vertex(500, 435);
  vertex(465, 413);
  vertex(489, 385);
  vertex(507, 410);
  vertex(530, 417);
  vertex(524, 433);
  endShape();
}
function drawCity() {
  // fill("black");
  beginShape();
  
  
  endShape();
  function drawFix() {
  // fill("black");
  beginShape();
  vertex(50, 726);
  vertex(151, 705);
  vertex(215, 715);
  vertex(219, 800);
  vertex(57, 800);
  vertex(50, 722);
  endShape();
}
}




function drawStars() {
  fill(255,255,255,100);
  beginShape(); //1
  vertex(84, 164);
  vertex(87, 148);
  vertex(92, 163);
  vertex(108, 163);
  vertex(97, 172);
  vertex(101, 186);
  vertex(90, 178);
  vertex(81, 187);
  vertex(81, 172);
  vertex(70, 166);
  vertex(85, 165);
  endShape();

  beginShape(); //2
  vertex(647, 261);
  vertex(650, 253);
  vertex(653, 262);
  vertex(659, 262);
  vertex(654, 268);
  vertex(658, 276);
  vertex(650, 271);
  vertex(642, 275);
  vertex(647, 268);
  vertex(641, 263);
  vertex(648, 262);
  endShape();

  beginShape(); //3
  vertex(125, 394);
  vertex(128, 382);
  vertex(132, 394);
  vertex(143, 394);
  vertex(135, 400);
  vertex(139, 410);
  vertex(129, 404);
  vertex(122, 409);
  vertex(122, 401);
  vertex(113, 395);
  vertex(124, 395);
  endShape();

   beginShape(); //4
  vertex(303, 44);
  vertex(305, 32);
  vertex(310, 45);
  vertex(324, 44);
  vertex(313, 53);
  vertex(320, 64);
  vertex(306, 58);
  vertex(296, 66);
  vertex(300, 54);
  vertex(288, 48);
  vertex(303, 46);
  endShape();
fill(255,255,255,300);
  beginShape();
  vertex(290, 214);
  vertex(291, 203);
  vertex(296, 213);
  vertex(305, 212);
  vertex(300, 219);
  vertex(303, 227);
  vertex(295, 222);
  vertex(290, 228);
  vertex(289, 221);
  vertex(282, 217);
  vertex(290, 215);
  endShape();

   beginShape();
  vertex(582, 104);
  vertex(585, 91);
  vertex(589, 103);
  vertex(601, 105);
  vertex(592, 111);
  vertex(595, 121);
  vertex(587, 115);
  vertex(580, 120);
  vertex(580, 110);
  vertex(570, 107);
  vertex(583, 105);
  
  
  beginShape();
  vertex(649, 502);
  vertex(651, 489);
  vertex(656, 503);
  vertex(667, 503);
  vertex(658, 511);
  vertex(662, 522);
  vertex(652, 513);
  vertex(646, 521);
  vertex(646, 511);
  vertex(635, 507);
  vertex(649, 504);
  endShape();
  
fill(255,255,255,140);
  beginShape();
  vertex(520, 102);
  vertex(524, 89);
  vertex(529, 102);
  vertex(542, 102);
  vertex(532, 111);
  vertex(536, 123);
  vertex(524, 115);
  vertex(515, 123);
  vertex(517, 112);
  vertex(504, 103);
  vertex(522, 102);
  endShape();
fill(255,255,255,200);
  beginShape();
  vertex(549, 126);
  vertex(552, 119);
  vertex(555, 128);
  vertex(564, 129);
  vertex(556, 135);
  vertex(558, 144);
  vertex(551, 136);
  vertex(544, 142);
  vertex(547, 133);
  vertex(539, 129);
  vertex(549, 126);
  endShape();

  beginShape();
  vertex(727, 54);
  vertex(729, 41);
  vertex(736, 54);
  vertex(749, 53);
  vertex(740, 63);
  vertex(745, 72);
  vertex(734, 67);
  vertex(723, 74);
  vertex(727, 65);
  vertex(714, 58);
  vertex(729, 54);
  endShape();
fill(255,255,255,200);
  beginShape();
  vertex(25, 32);
  vertex(28, 21);
  vertex(31, 32);
  vertex(41, 32);
  vertex(33, 40);
  vertex(38, 47);
  vertex(29, 43);
  vertex(21, 47);
  vertex(24, 38);
  vertex(15, 32);
  vertex(26, 33);
  endShape();

  beginShape();
  vertex(93, 375);
  vertex(94, 368);
  vertex(97, 375);
  vertex(103, 374);
  vertex(99, 380);
  vertex(102, 384);
  vertex(96, 383);
  vertex(90, 386);
  vertex(92, 381);
  vertex(84, 377);
  vertex(92, 376);
  endShape();

   beginShape();
  vertex(76, 557);
  vertex(81, 543);
  vertex(86, 558);
  vertex(100, 558);
  vertex(88, 568);
  vertex(95, 580);
  vertex(81, 571);
  vertex(72, 579);
  vertex(73, 566);
  vertex(60, 559);
  vertex(76, 557);
  endShape();

  beginShape();
  vertex(707, 354);
  vertex(713, 340);
  vertex(719, 354);
  vertex(734, 355);
  vertex(722, 367);
  vertex(727, 380);
  vertex(713, 372);
  vertex(703, 380);
  vertex(704, 365);
  vertex(691, 359);
  vertex(707, 355);
  endShape();
  endShape();
}

function drawCity() {
  fill("black");
  beginShape();
  vertex(2, 724);
  vertex(35, 724);
  vertex(35, 800);
  vertex(0, 800);
  vertex(0, 724);
  endShape();

  beginShape();
  vertex(34, 755);
  vertex(66, 755);
  vertex(66, 800);
  vertex(33, 800);
  vertex(34, 756);
  endShape();

   beginShape();
  vertex(66, 756);
  vertex(66, 685);
  vertex(91, 685);
  vertex(91, 800);
  vertex(64, 800);
  vertex(66, 756);
  endShape();

  beginShape();
  vertex(90, 735);
  vertex(150, 735);
  vertex(150, 800);
  vertex(89, 800);
  vertex(90, 736);
  endShape();

  beginShape();
  vertex(150, 760);
  vertex(206, 760);
  vertex(206, 800);
  vertex(148, 800);
  vertex(150, 761);
  endShape();

  beginShape();
  vertex(205, 774);
  vertex(236, 774);
  vertex(236, 800);
  vertex(204, 800);
  vertex(205, 775);
  endShape();

  beginShape();
  vertex(236, 800);
  vertex(236, 707);
  vertex(269, 707);
  vertex(271, 800);
  vertex(236, 800);
  endShape();

  beginShape();
  vertex(269, 732);
  vertex(302, 732);
  vertex(302, 800);
  vertex(269, 800);
  vertex(268, 733);
  endShape();

  beginShape();
  vertex(302, 800);
  vertex(302, 681);
  vertex(341, 681);
  vertex(341, 800);
  vertex(302, 800);
  endShape();

  beginShape();
  vertex(340, 752);
  vertex(404, 752);
  vertex(404, 800);
  vertex(339, 800);
  vertex(340, 752);
  endShape();

  beginShape();
  vertex(404, 754);
  vertex(404, 717);
  vertex(447, 717);
  vertex(448, 800);
  vertex(404, 800);
  vertex(404, 755);
  endShape();

  beginShape();
  vertex(447, 780);
  vertex(472, 780);
  vertex(472, 800);
  vertex(447, 800);
  vertex(447, 782);
  endShape();

  beginShape();
  vertex(472, 782);
  vertex(472, 763);
  vertex(497, 763);
  vertex(497, 800);
  vertex(472, 800);
  vertex(472, 781);
  endShape();

  beginShape();
  vertex(446, 765);
  vertex(461, 765);
  vertex(461, 784);
  vertex(443, 784);
  vertex(446, 767);
  endShape();

  beginShape();
  vertex(67, 742);
  vertex(57, 742);
  vertex(57, 756);
  vertex(75, 760);
  vertex(67, 744);
  endShape();

  beginShape();
  vertex(5, 726);
  vertex(5, 712);
  vertex(26, 712);
  vertex(26, 725);
  endShape();

  beginShape();
  vertex(497, 765);
  vertex(497, 708);
  vertex(549, 708);
  vertex(549, 800);
  vertex(496, 800);
  vertex(497, 765);
  endShape();

  beginShape();
  vertex(508, 709);
  vertex(508, 691);
  vertex(539, 691);
  vertex(539, 709);
  endShape();

  beginShape();
  vertex(517, 692);
  vertex(517, 664);
  vertex(528, 664);
  vertex(528, 691);
  endShape();

   beginShape();
  vertex(549, 739);
  vertex(612, 739);
  vertex(613, 800);
  vertex(548, 800);
  vertex(547, 739);
  endShape();

  beginShape();
  vertex(576, 740);
  vertex(576, 716);
  vertex(612, 716);
  vertex(612, 740);
  endShape();

  beginShape();
  vertex(611, 749);
  vertex(633, 749);
  vertex(633, 800);
  vertex(603, 800);
  vertex(611, 750);
  endShape();

   beginShape();
  vertex(633, 766);
  vertex(674, 766);
  vertex(674, 800);
  vertex(633, 800);
  vertex(633, 768);
  endShape();

  beginShape();
  vertex(673, 788);
  vertex(695, 788);
  vertex(695, 800);
  vertex(673, 800);
  vertex(674, 790);
  endShape();

  beginShape();
  vertex(694, 790);
  vertex(694, 672);
  vertex(715, 672);
  vertex(716, 800);
  vertex(716, 800);
  vertex(695, 800);
  endShape();

   beginShape();
  vertex(714, 734);
  vertex(745, 734);
  vertex(745, 800);
  vertex(715, 800);
  endShape();

  beginShape();
  vertex(713, 717);
  vertex(729, 717);
  vertex(729, 737);
  vertex(712, 737);
  vertex(715, 719);
  endShape();

   beginShape();
  vertex(744, 754);
  vertex(800, 754);
  vertex(800, 800);
  vertex(740, 800);
  endShape();

   beginShape();
  vertex(775, 756);
  vertex(774, 705);
  vertex(800, 705);
  vertex(800, 754);
  endShape();

   beginShape();
  vertex(72, 685);
  vertex(72, 664);
  vertex(84, 664);
  vertex(84, 688);
  endShape();
}
