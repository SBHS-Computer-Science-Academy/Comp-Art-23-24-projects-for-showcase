function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();

  drawThing()
  drawMouseLines("white");
}

function drawBackground() {

  rectGradient(0, 0, width, height, color('black'), color('white'), "horizontal", 400); // for details, see "gradient.js" file

  
}

function drawThing() {
  rectGradient(0, 0, width, 200, "DarkBlue", "LightPink"); // sky with sunset
  circleGradient(width / 2.5, 200, 350, "orangeRed", "yellow"); // sun
  circleGradientLinear(200, 200, 100, "black", "sienna", "vertical"); 
  circleGradientLinear(600, 200, 100, "sienna", "black", "vertical");
  circleGradientLinear(170, 200, 100, "black", "sienna", "vertical"); 
  circleGradientLinear(660, 200, 100, "sienna", "black", "vertical");
  circleGradientLinear(230, 200, 100, "black", "sienna", "vertical"); 
  circleGradientLinear(630, 200, 100, "sienna", "black", "vertical");
  circleGradientLinear(140, 200, 100, "black", "sienna", "vertical"); 
  circleGradientLinear(690, 200, 100, "sienna", "black", "vertical");
  rectGradient(0, 200, width, 400, "ForestGreen", "DarkGreen", "horizontal", 10);

  fill("white");
  beginShape();
  vertex(419, 202);
  vertex(541, 600);
  endShape();
  
  fill("black")
  beginShape();
  vertex(574, 600);
  vertex(426, 201);
  vertex(391, 201);
  vertex(261, 600);
  endShape();
 
 
}