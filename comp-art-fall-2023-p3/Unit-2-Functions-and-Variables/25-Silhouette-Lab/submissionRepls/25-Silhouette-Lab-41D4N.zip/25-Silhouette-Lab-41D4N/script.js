  function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("lines");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  clear();
  drawBackground();
  drawMouseLines("black");
}

function drawBackground() {

  rectGradient(270, 375, 200, 300, color('white'), color('lightgrey'), "horizontal", 400); // for details, see "gradient.js" file

  
}

function drawSilhoutte() {
  
}
//Create a silhouette using at least 3 irregular shapes.  You may use gradients if you like