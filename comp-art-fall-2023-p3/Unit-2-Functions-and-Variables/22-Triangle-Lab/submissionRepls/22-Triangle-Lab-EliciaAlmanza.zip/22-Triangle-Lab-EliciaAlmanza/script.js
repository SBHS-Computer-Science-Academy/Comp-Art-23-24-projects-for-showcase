function setup() {
  let myCanvas = createCanvas(800,600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);


}

function draw() {
  background("white");

  
  drawMouseLines("black");
  rightTriangle(463,291,100,130)
  horizontalIsoscelesTriangle(99,383,20,90)
  rightTriangle(99,475,190,74)
  horizontalIsoscelesTriangle(463,419,20,90)
  
  fill("blue");
	beginShape()
	vertex(181, 77);
	vertex(449, 0);
	vertex(262, 1);
	vertex(181, 81);
	vertex(214, 207);
	vertex(289, 45);
	vertex(426, 103);
	vertex(445, 1);
	vertex(582, 56);
	vertex(608, 2);
	vertex(446, 3);
	vertex(579, 57);
	vertex(210, 207);
	vertex(93, 162);
	vertex(111, 247);
	vertex(142, 183);
	vertex(173, 235);
	vertex(211, 204);
	vertex(194, 318);
	vertex(270, 183);
	vertex(446, 193);
	vertex(468, 102);
	vertex(608, 90);
	vertex(579, 56);
	vertex(655, 1);
	vertex(682, 90);
	vertex(607, 87);
	vertex(190, 320);
	vertex(173, 231);
	vertex(112, 247);
	vertex(193, 320);
	vertex(62, 270);
	vertex(110, 246);
	vertex(38, 218);
	vertex(0, 254);
	vertex(62, 270);

	endShape()


  
}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function horizontalIsoscelesTriangle(x, y,w ,h){
  triangle(x,y,x,y+h,x+w,y+h/2)
}

function rightTriangle(x,y,w,h){
  triangle(x,y,x,y+h,x+w,y)
}
// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {



  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}