function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  draw

  fill("black");
  //verticalIsoscelesTriangle(100, 100, 100, 200);
  
  fill("teal");
  verticalIsoscelesTriangle(100, 100, 200, -50);
  fill("blue");
  horizontalIsoscelesTriangle(100,50,100, 100);
  fill("black")
  ellipse(76,335,10)
  ellipse(14,335,10)
rightTriangle(332, 177,200, 174)
  rightTriangle(332,53,200,144)
  fill("red")
  rightTriangle(560,177,-200,-150)
  fill("pink")
  rightTriangle(530,340,-290,-160)
  horizontalIsoscelesTriangle(190,95,200,144)
  horizontalIsoscelesTriangle(300,77,200,144)
  horizontalIsoscelesTriangle(210,532,200,144)
  horizontalIsoscelesTriangle(210,532,-200,144)
  fill("red")
  horizontalIsoscelesTriangle(10,460,200,144)
  rightTriangle(12,480,-200,-144)
  line(11, 334,82, 331)
  circle(24, 200,87)
  fill("black")
  line(25, 244,23, 292)
  line(23, 292,58, 326)
  line(23, 293,11,329)
  ellipse(7, 190,10)
  ellipse(47, 190,10)
  line(18,200,42,219)
  
  
  drawMouseLines("black");
  


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function horizontalIsoscelesTriangle(topX,topY,w,h) {

let rightX = topX + w ;
  let rightY = topY+h/2
let bottomY = topY + h; 
 triangle(topX, topY, topX, bottomY, rightX, rightY);
}
function rightTriangle(leftX,topY,w,h) {

  let rightX = leftX + w ;
  let bottomY = topY + h;
  
  triangle(leftX, topY,rightX,topY,leftX, bottomY)
}
// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    //insert code for if the triangle opens to downward
  }
}
