function setup() {
  let myCanvas = createCanvas(1000, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

fill('navy')
  rightTriangle(500,200,-200,-200)
  rightTriangle(500,200,200,200)
  fill('yellow')
  rightTriangle(500,200,-200,200)
  

  rightTriangle(500,200,200,-200)
  fill("black");
  horizontalIsoscelesTriangle(100, 100, 100, 200);
  
  fill("teal");
  horizontalIsoscelesTriangle(100, 100, 200, -50);

  drawMouseLines("black");

  fill('sienna')
  horizontalIsoscelesTriangle(500,400,-100,200)
horizontalIsoscelesTriangle(500,400,100,200)

  


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function horizontalIsoscelesTriangle(x, y, w, h) {
  let bottomY=y+h
  let rightX=x+w
  let rightY=y+h/2
  triangle(x,y,x,bottomY,rightX,rightY)
}
function rightTriangle(topX,topY,w,h){
  let bottomY=topY+h
  let rightX=topX+w
  triangle(topX,topY,topX,bottomY,rightX,topY)
}



// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}