function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  fill("magenta");
  verticalIsoscelesTriangle(100, 100, 100, 200);
  
  fill("DeepSkyBlue");
  verticalIsoscelesTriangle(100, 100, 200, -80);

  drawMouseLines("black");

fill("DeepSkyBlue")
horizontalIsocelesTriangle(400,70,100,300)
fill("magenta")
horizontalIsocelesTriangle(300,70,100,300)
fill("DeepSkyBlue")
horizontalIsocelesTriangle(200,70,100,300)
fill("magenta")
rightTriangle(100,400,100,80)
rightTriangle(100,400,-100,-80)
rightTriangle(300,500,100,80)
rightTriangle(300,500,-100,-80)
}



function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function horizontalIsocelesTriangle(topX, topY,w,h){

let bottomY=topY+h
let rightX=topX+w
let rightY=topY+h/2
triangle(topX, topY,topX,bottomY,rightX,rightY)
}

function rightTriangle(topX,topY,w,h){
let bottomY=topY+h
let rightX=topX+w

triangle(topX,topY,rightX,topY,topX, bottomY)
}
 





// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}