function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("purple");

rightTriangle(297,299,-160,-160)
  fill("HotPink");
  verticalIsoscelesTriangle(175,125, 150, 175);
  rightTriangle(408,-70,200,200)
  
  fill("blue");
  verticalIsoscelesTriangle(200, 200, 200, -100);
  fill("magenta")
  rightTriangle(100,300,200,300)

  drawMouseLines("black");
  fill("skyblue");

  horizontalIsoscelesTriangle(100,100,100,200,206,164)
  fill("grey")
  horizontalIsoscelesTriangle(300,200,300,200)
  fill("gold")
  rightTriangle(200,500,300,100,100)
  fill("lime")
 verticalIsoscelesTriangle(344,144,133,160) 
  fill("babyblue")
  horizontalIsoscelesTriangle(300,200,-200,-360)
}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
  
}

function horizontalIsoscelesTriangle(x,y,w,h){
let bottomY = y + h;
  let rightX = x+w
  let rightY = y+h/2
  triangle(x,y,x,bottomY,rightX,rightY)
  
}

function rightTriangle(leftX,topY,w,h) {

  let rightX = leftX + w ;
  let bottomY = topY + h;
  
  triangle(leftX, topY,rightX,topY,leftX, bottomY)
}

// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    
    
  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}