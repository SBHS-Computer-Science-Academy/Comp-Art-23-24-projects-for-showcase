function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");

  fill("SlateBlue");
  verticalIsoscelesTriangle(100, 100, 150, 200);
  verticalIsoscelesTriangle(100, 100, 150, -70);
  verticalIsoscelesTriangle(100, 400, 150, 200);
  verticalIsoscelesTriangle(100, 400, 150, -70);
  verticalIsoscelesTriangle(380, 100, 150, 200);
  verticalIsoscelesTriangle(380, 100, 150, -70);
  verticalIsoscelesTriangle(380, 400, 150, 200);
  verticalIsoscelesTriangle(380, 400, 150, -70);
  verticalIsoscelesTriangle(195, 50, 200, 50);
  verticalIsoscelesTriangle(280, 50, 200, 50);
  verticalIsoscelesTriangle(195, 350, 200, 50);
  verticalIsoscelesTriangle(280, 350, 200, 50);
  horizontalIsoscelesTriangle(300,240,-100,100)
  horizontalIsoscelesTriangle(300,140,-100,100)
 
  
  
  fill("SteelBlue");
  verticalIsoscelesTriangle(100, 100, 200, -50);
  verticalIsoscelesTriangle(100, 100, 100, 100);
  verticalIsoscelesTriangle(100, 400, 200, -50);
  verticalIsoscelesTriangle(100, 400, 100, 100);
  verticalIsoscelesTriangle(380, 100, 200, -50);
  verticalIsoscelesTriangle(380, 100, 100, 100);
  verticalIsoscelesTriangle(380, 400, 200, -50);
  verticalIsoscelesTriangle(380, 400, 100, 100);
  horizontalIsoscelesTriangle(200,290,100,100)
  horizontalIsoscelesTriangle(200,190,100,100)
  horizontalIsoscelesTriangle(200,90,100,100)
  verticalIsoscelesTriangle(380, 100, 200, -50);

  drawMouseLines("black");


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function horizontalIsoscelesTriangle(topX, topY, w, h) {
triangle(topX, topY, topX, topY + h, topX + w, topY + h / 2)
}

// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}