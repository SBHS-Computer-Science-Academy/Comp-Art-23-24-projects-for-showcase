function setup() {
  let myCanvas = createCanvas(600, 320);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  noStroke();
  fill("darkslateblue");
  verticalIsoscelesTriangle(300, 0, 300, 80); //top middle
  
  fill("lavender");
  verticalIsoscelesTriangle(150, 80, 300,-80); //left
  fill("lavender")
  verticalIsoscelesTriangle(300,160,-305,-80); //middle bottom
  


  verticalIsoscelesTriangle(450,80,-300,-80); //right
  fill('darkslateblue');
  verticalIsoscelesTriangle(150,80,-300,80); //left bottom
  verticalIsoscelesTriangle(450,80,-300,80); //right bottom

  fill("lavender");
  rightTriangle(0,80,150,80); //left
  rightTriangle(600,80,-150,80); //right
  

  fill("darkslateblue");
  rightTriangle(600,80,-150,-80); //right
  rightTriangle(0,80,150,-80); //left

  verticalIsoscelesTriangle(300,160,300,80); //bottom middle p
  verticalIsoscelesTriangle(150,240,-300,80); //bottom b left
  verticalIsoscelesTriangle(450,240,-300,80); //bottom b right

  fill("lavender");
  verticalIsoscelesTriangle(150,240,300,-80); //left m
  verticalIsoscelesTriangle(450,240,300,-80); //right m
  
  drawMouseLines("black");
  fill("mediumpurple");
  isoHorizTri(0,160,150,160); //left
  isoHorizTri(600,160,-150,160); //right
  isoHorizTri(300,160,150,160);
  isoHorizTri(300,160,-150,160);
}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function rightTriangle(x,y,w,h) {
let topX = x+w
let bottomY = y+h
  triangle(x, bottomY,topX, y, x,y);
}

function isoHorizTri(x,y,w,h) {
  
  let bottomY = y+h
  let rightX = x+w
  let rightY = y+h / 2
triangle(x,y, x, bottomY, rightX,rightY)
    }
// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}