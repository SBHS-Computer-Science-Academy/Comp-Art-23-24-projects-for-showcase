function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  fill("black");
  //verticalIsoscelesTriangle(100, 100, 100, 200);

  fill("teal");
  //verticalIsoscelesTriangle(100, 100, 200, -50);
  fill('red')
  rightTriangle(273, 240, 100, 40);
  fill('blue')
  rightTriangle(273, 240, -100, 40)
  fill('purple')
  rightTriangle(273, 240, 100, -40);
  fill('yellow')
  rightTriangle(273, 240, -100, -40)
  //rightTriangle(293, 340, 100, -40)
  fill('green')
  horizontalIsoscelesTriangle(173, 200, 100, 80)
  fill('indigo')
  horizontalIsoscelesTriangle(373, 200, -100, 80)
  fill('orange')
  equilateralTriangle(173, 200, 200, "u")

  //equilateralTriangle(458,486,40, "r")
  //equilateralTriangle(458,486,40, "u")
  equilateralTriangle(273, 453, 200, "d")
  //equilateralTriangle(85,292, 42,"r")
  //equilateralTriangle(49,456, 42,"l")







  drawMouseLines("black");



}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
  triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function rightTriangle(x, y, w, h) {

  let pointThree = y + h
  let pointTwo = x + w

  triangle(x, y, x, pointThree, pointTwo, pointThree)
}
function horizontalIsoscelesTriangle(x, y, w, h) {
  let ytwo = h / 2
  let themidy = y + ytwo
  let theendx = x + w
  let endy = y - h
  triangle(x, y, x, y + h, x + w, y + h / 2)
}
//extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "r") {

  if (direction.includes("r")) {

    triangle(x, y, x, y - sideLength, x + (sideLength / 2) * sqrt(3), y - sideLength / 2)

  } else if (direction.includes("l")) {

    triangle(x, y, x, y - sideLength, x - (sideLength / 2) * sqrt(3), y - sideLength / 2)

  } else if (direction.includes("u")) {

    triangle(x, y, x + sideLength / 2, y - (sideLength / 2) * sqrt(3), x + sideLength, y)

  } else if (direction.includes("d")) {

    triangle(x, y, x + sideLength / 2, y - (sideLength / 2) * sqrt(3), x - sideLength / 2, y - (sideLength / 2) * sqrt(3))
  }













}