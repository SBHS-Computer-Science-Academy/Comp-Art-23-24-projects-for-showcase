function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  fill("purple");
  verticalIsoscelesTriangle(100, 100, 100, 200);
  verticalIsoscelesTriangle(474, 375, 100, 200)
  
  fill("green");
  verticalIsoscelesTriangle(100, 100, 200, -50);
  verticalIsoscelesTriangle(486, 278, 200, -50)

  fill("purple")
  horizontalIsoscelesTriangle(200,200, 200, 300)

  
  fill("green")
  rightTriangle(200,500,75,95)
  fill("purple")
  rightTriangle(50,300,150,150)
 fill("green")
  rightTriangle(350,80,150,150)

  
  drawMouseLines("black");
 


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function horizontalIsoscelesTriangle (topX, topY, w, h){
  let bottomY = topY + h;
  let rightX = topX + w
  let rightY = topY + h/2
  triangle(topX, topY, topX, bottomY, rightY, rightX)
}

function rightTriangle (topX, topY, w, h ) {
  let bottomY = topY + h
  let straightX = topX + w
  triangle(topX, topY, topX, bottomY, straightX, topY)
}

// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}