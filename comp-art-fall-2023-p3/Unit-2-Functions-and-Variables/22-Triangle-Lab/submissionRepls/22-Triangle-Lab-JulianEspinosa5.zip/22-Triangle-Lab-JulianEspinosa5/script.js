function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("skyblue");

  fill("black");
  verticalIsoscelesTriangle(400, 100, 100, 200);
  
 
  fill("teal");
  verticalIsoscelesTriangle(400, 100, 200, -50);
horizontalIsoscelesTriangle(431, 229, 100, 50)
  horizontalIsoscelesTriangle(366, 229,-100,50)
  drawMouseLines("black");
verticalIsoscelesTriangle(400, 500, 100, -200);
horizontalIsoscelesTriangle(382, 168,-50,25)
  horizontalIsoscelesTriangle(418, 168, 50, 25)
fill("black")
rightTriangle(417, 338,20,10)
rightTriangle(384, 338,-20,10)
  fill("white")
rightTriangle(417, 338,10,5)
rightTriangle(384, 338,-10,5)
  
}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function horizontalIsoscelesTriangle(x,y,w,h){

  triangle(x,y,x,y+h,x+w,y+h/2)
}
function rightTriangle(x, y, w, h){
triangle(x,y,x+w,y,x,y+h)
  
}



// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}