function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  fill("black");
  verticalIsoscelesTriangle(100, 100, 100, 200);
  
  fill("teal");
  verticalIsoscelesTriangle(100, 100, 200, -50);

  drawMouseLines("black");
fill('blue')
horizontalIsoscelesTriangle(160,160,102,142)

fill('green')
rightTriangle(264,403,144,100)






  

function rightTriangle(leftX,topY,w,h) {

  let rightX = leftX + w ;
  let bottomY = topY + h;
  
  triangle(leftX, topY,rightX,topY,leftX, bottomY)
}








  
}











function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function horizontalIsoscelesTriangle(x,y,w,h) {

  let bottomY=y+h
  let rightX=x+w
  let rightY=y+h/2
  triangle(x,y,x,bottomY,rightX,rightY)

  
  
}








// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}