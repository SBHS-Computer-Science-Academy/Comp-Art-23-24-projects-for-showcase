function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("Pink");

  fill("Yellow");
  verticalIsoscelesTriangle(333, 333, 100, 200);
   fill("Orange");
  verticalIsoscelesTriangle(333, 333, 100, 200);
   verticalIsoscelesTriangle(433, 333, 100, 200);
   verticalIsoscelesTriangle(233, 333, 100, 200);
   verticalIsoscelesTriangle(533, 333, 100, 200);
   verticalIsoscelesTriangle(133, 333, 100, 200);
  fill("Cyan");
  verticalIsoscelesTriangle(124, 307, 305, -90);
   fill("Cyan");
  verticalIsoscelesTriangle(426, 308, 305, -90);
  
   fill("Purple");
  verticalIsoscelesTriangle(275, 218, 300, 90);
  verticalIsoscelesTriangle(-20, 218, 300, 90);
   fill("Purple");
  verticalIsoscelesTriangle(577, 219, 300, 90);
fill("Black");
   verticalIsoscelesTriangle(383, 533, 100, -200);
  verticalIsoscelesTriangle(283, 533, 100, -200);
  verticalIsoscelesTriangle(483, 533, 100, -200);
  verticalIsoscelesTriangle(183, 533, 100, -200);
   verticalIsoscelesTriangle(583, 533, 100, -200);
   verticalIsoscelesTriangle(83, 533, 100, -200);
   verticalIsoscelesTriangle(183, 533, 100, -200);
  fill("yellow");
   rightTriangle(258, 119,60, 50)
  rightTriangle(319, 120,60, 50)
  rightTriangle(258, 171,60, 50)
  rightTriangle(380, 121,60, 50)
  rightTriangle(320, 170,60, 50)
  rightTriangle(381, 170,60, 50)
    fill("green");
  horizontalIsoscelesTriangle(172, 50, 50, 50)
  horizontalIsoscelesTriangle(222, 75, 50, 50)
    horizontalIsoscelesTriangle(142, 88, 50, 50)
    horizontalIsoscelesTriangle(194, 112, 50, 50)
   horizontalIsoscelesTriangle(224, 30, 50, 50)
   horizontalIsoscelesTriangle(194, 164, 50, 50)
   horizontalIsoscelesTriangle(141, 139, 50, 50)
  horizontalIsoscelesTriangle(100, 110, 50, 50)
  drawMouseLines("black");


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function horizontalIsoscelesTriangle(topX, topY, w, h){
let bottomY = topY + h;
  triangle(topX, topY, topX, bottomY, topX+ w, topY+h/2 )
}
function rightTriangle(x,y,w,h){
  triangle(x,y,x,y+h,x+w,y)
}
// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}
