function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");

drawBody()
  
  fill('Silver	')
   verticalIsoscelesTriangle(200, 20, 140,140);
    fill('DodgerBlue')
  horizontalIsoscelesTriangle(130,160,70,170)
  fill('DodgerBlue')
  horizontalIsoscelesTriangle(270,160,-70,170)
  fill('GhostWhite')
  rightTriangle(130,330,70,250)
  fill('GhostWhite')
  rightTriangle(270,330,-70,250)
fill('white')
  rightTriangle(130,210,70,80)
fill('white')
  rightTriangle(270,210,-70,80)

  stroke('white')
  strokeWeight(2)
  fill('red')
horizontalIsoscelesTriangle(487,140,20,20)
fill('lightgrey')
  verticalIsoscelesTriangle(200,330,-140,120)
noStroke()
  fill('darkgrey')
  verticalIsoscelesTriangle(200,120,100,60)
  
drawMoon()

  
  drawMouseLines("black");


  
}

 function verticalIsoscelesTriangle(topX, topY, w, h) {
   let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
 }

function horizontalIsoscelesTriangle(topX,topY,w,h) {

  triangle(topX, topY, topX, topY + h, topX + w, topY + h/2)
  
}

function rightTriangle(topX, topY, w, h) {

  triangle(topX, topY, topX + w, topY, topX, topY + h)
}

function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}

function drawMoon() {
noStroke();
  
  fill('grey')
  circle(486,228,100)
  
  fill('lightgrey')
  circle(460,212,10)
  circle(476,247,30)
  circle(496,215,20)
  circle(512,238,5)
  circle(500,192,10)

  stroke('white')
  strokeWeight(2)
  line(487,180,487,159)


  noStroke()
  fill('Khaki')
  circle(422, 425,20)

  circle(368, 422,30)

  circle(368, 242,30)
fill('Orange')
  circle(504, 398,20)

  circle(408, 326,10)
  circle(504, 110,30)
  circle(308, 334,40)
  fill('gold')
  circle(331, 109,10)
  circle(366, 535,20)
  circle(544, 564,30)
  circle(533, 464,30)
  fill('LemonChiffon')
  circle(77, 99,20)
  circle(23, 482,30)
  circle(51, 334,40)
 fill('gold')
  circle(203, 513,10)
  circle(70, 553,30)
  circle(50, 205,20)
  circle(203, 450,30)
}

function drawBody() {
fill('RoyalBlue')
   quad(131, 164, 270, 163, 268, 328, 130, 329)
}