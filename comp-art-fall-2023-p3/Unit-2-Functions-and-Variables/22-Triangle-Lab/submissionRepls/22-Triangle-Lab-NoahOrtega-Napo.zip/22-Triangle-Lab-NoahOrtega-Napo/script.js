function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");

  fill("black");
  verticalIsoscelesTriangle(100, 100, 100, 200);
  
  fill("teal");
  verticalIsoscelesTriangle(100, 100, 200, -50);
horizontalIsoscelesTriangle(200, 50,100,200 )
 
  
  drawMouseLines("black");


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}

function horizontalIsoscelesTriangle(topX, topY, w, h) {
  let bottomY = topY+ h ;
  let RightX = topX + w ;
  let RightY = topY + h/2;
    triangle(topX, topY, topX, bottomY, RightX, RightY);
}
