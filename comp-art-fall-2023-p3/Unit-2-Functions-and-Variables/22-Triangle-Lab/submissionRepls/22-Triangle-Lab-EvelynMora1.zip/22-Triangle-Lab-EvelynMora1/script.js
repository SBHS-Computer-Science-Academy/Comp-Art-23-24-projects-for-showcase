function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");


  fill("black");
  verticalIsoscelesTriangle(100, 20, 100, 200);
  
  fill("black");
  verticalIsoscelesTriangle(200, 20, 100, 200);

  fill("black");
  verticalIsoscelesTriangle(300, 20, 100, 200);
  
  fill("black");
  verticalIsoscelesTriangle(400, 20, 100, 200);

  fill("grey");
  verticalIsoscelesTriangle(350, 219, 100, -200);
  
  fill("grey");
  verticalIsoscelesTriangle(350, 219, 100, -200);

  fill("grey");
  verticalIsoscelesTriangle(250, 219, 100, -200);
  
  fill("grey");
  verticalIsoscelesTriangle(150, 219, 100, -200);

  fill("grey");
  verticalIsoscelesTriangle(50, 219, 100, -200);

  drawMouseLines("black");
  

  fill("yellow");
  rightTriangle(200, 300, 100, 100)//start of middle 

  fill("yellow");
  rightTriangle(200, 400, 100, 100)

  fill("yellow");
  rightTriangle(200, 500, 100, 100)//end  of middle 

  fill("yellow");
  rightTriangle(100, 300, 100, 100)//start of left side 

  fill("yellow");
  rightTriangle(100, 400, 100, 100)
  
  fill("yellow");
  rightTriangle(100, 500, 100, 100)//end of left side 


  fill("Orange");
 horizontallIsoscelesTriangle(430, 300, 100, 200);
  //function horizontalIsoscelesTriangle(topX, topY, w, h,){
 //triangle(topX, topY,)


  fill("red");
 horizontallIsoscelesTriangle(430, 300, -100, 200);

  }
  

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}


function rightTriangle(x,y,w,h){
let topRightX = x + w 

  triangle(topRightX, y, x,y, x,y+h)
  
}
fill("Orange");
 horizontallIsoscelesTriangle(200, 400, 300, 200);

function horizontallIsoscelesTriangle(x,y, w,h) {
let topRightX = x + w 
  
 triangle(topRightX,y, x+w,y+h/2, x,y+h)
}


// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}