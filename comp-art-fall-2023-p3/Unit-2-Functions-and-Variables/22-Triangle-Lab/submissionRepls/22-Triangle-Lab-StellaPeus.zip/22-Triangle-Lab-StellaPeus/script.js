function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("pink");

  fill("red");
  verticalIsoscelesTriangle(50,0, 100, 200);
  fill("orange")
  verticalIsoscelesTriangle(150,0,100,200);
  fill('yellow');
  verticalIsoscelesTriangle(250,0,100,200);
  fill('green');
  verticalIsoscelesTriangle(350,0,100,200);
  fill('blue');
  verticalIsoscelesTriangle(450,0,100,200);
  fill('purple');
  verticalIsoscelesTriangle(550,0,100,200);
  fill('magenta');
  rightTriangle(0,0,50,200)
  fill('purple');
  verticalIsoscelesTriangle(100,200,100,-200);
  fill('blue');
  verticalIsoscelesTriangle(200,200,100,-200);
  fill('lightgreen');
  verticalIsoscelesTriangle(300,200,100,-200);
  fill('yellow');
  verticalIsoscelesTriangle(400,200,100,-200);
  fill('orange');
  verticalIsoscelesTriangle(500,200,100,-200);
  fill('red');
  rightTriangle(600,0,-50,200)
  fill('lightgreen');
  horizontalIsoscelesTriangle(101,500,200,100);
  fill('lavender');
  horizontalIsoscelesTriangle(305,500,200,100);
  fill('lightyellow');
  horizontalIsoscelesTriangle(500,500,195,100);
  strokeWeight(10);
  stroke('pink');
  line(101,500,0,201)
  fill('green');
  rightTriangle(308,359,100,135)
  fill('red');
  rightTriangle(308,359,100,-135)
  fill('blue');
rightTriangle(308,359,-100,135)
  fill('yellow');
rightTriangle(308,359,-100,-135);

  drawMouseLines("black");

}
function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function rightTriangle(x, y, w, h) {
  
  let topRightX = x + w;
  let bottomY = y + h;
    triangle(x, y, x, bottomY, topRightX,y);
}
function horizontalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}


