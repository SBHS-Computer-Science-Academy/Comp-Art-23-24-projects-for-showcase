function setup() {
  let myCanvas = createCanvas(300, 200);
  myCanvas.parent("myCanvas");
  //createConsole("dots");
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background(255/2);
  cx = width/2
  cy = height/2 //center of shape
  noStroke();

  fill(0);
  isoscelesTriangle(cx, cy, 200, 50, "v");

  fill(255);
  isoscelesTriangle(cx, cy, 200, -50, "v");

  fill("blue");
  isoscelesTriangle(cx, cy, 100, 100, "h")

  fill("red");
  isoscelesTriangle(cx, cy, -100, 100, "h")

  fill("green")
  rightTriangle(cx, cy-50, 100, 50)

  fill("yellow")
  rightTriangle(cx, cy+50, -100, -50)

  a=60
  h=a*(sqrt(3)/2)
  fill("brown")
  equilateralTriangle(cx-h/1.5, cy, a, "r")
  equilateralTriangle(cx+h/1.5, cy, a, "l") //center star, ill make this rotate once we do that

  drawMouseLines("black");

}

function rightTriangle(x, y, w, h) {
  triangle(x, y, x+w, y, x, y+h)
}

function isoscelesTriangle(x, y, w, h, mode) {
  let bottomLeftvX = x - w / 2;
  let bottomRightvX = x + w / 2;
  let bottomvY = y + h; //vertical vars
  
  let righthX = x + w
  let bottomhY = y - (h / 2)
  let tophY = y + (h / 2) //horizontal vars
  
  if (mode.toLowerCase().includes("v")) {
    triangle(x, y, bottomLeftvX, bottomvY, bottomRightvX, bottomvY);
  } else if (mode.toLowerCase().includes("h")) {
    triangle(x, y, righthX, tophY, righthX, bottomhY)
  } else {
    print("invalid syntax: mode")
  }
}

function equilateralTriangle(x, y, s, direction = "right") {
  if (direction.toLowerCase().includes("r")) {
    rpointx = x+s*(sqrt(3)/2)

    triangle(x, y, rpointx, y+s/2, rpointx, y-s/2)
  } else if (direction.toLowerCase().includes("l")) {
    lpointx = x-s*(sqrt(3)/2)

    triangle(x, y, lpointx, y-s/2, lpointx, y+s/2)
  } else if (direction.toLowerCase().includes("u")) {
    upointy = y-s*(sqrt(3)/2)

    triangle(x, y, x-s/2, upointy, x+s/2, upointy)
  } else if (direction.toLowerCase().includes("d")) {
    dpointy = y+s*(sqrt(3)/2)

    triangle(x, y, x+s/2, dpointy, x-s/2, dpointy)
  }
}