function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
rectGradient(0, 0, width, 600, "skyblue", "white"); // sky with sunset
  
  
  fill("black");
  
   
  fill("grey");
  verticalIsoscelesTriangle(300, 600,600, -300);
  rightTri(0, 300, 300, -300)
  rightTri(600, 300, -300, -300)
  fill("black")
  verticalIsoscelesTriangle(283, 400, 100, 80);
  rightTri(144, 385, 100, -50)
  rightTri(440, 385, -100, -50)
  rightTri(50, 290, 200, -200)
  rightTri(550, 290, -200, -200)
  drawMouseLines("black");


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}


function horizontalIsoscelesTriangle(x, y, w, h) {
  let ytwo = h / 2
  let themidy = y + ytwo
  let theendx = x + w
  let endy = y - h
  triangle(x, y, x, y + h, x + w, y + h / 2)
}



function rightTri(x, y, w, h){

  triangle(x,y, x+w, y, x, y+h)
}

// extension: complete the equilateralTriangle function below
function equilateralTriangle(x, y, sideLength, direction = "right") {

  if (direction.includes("r")) {

    // insert code for if the triangle opens to the right

  } else if (direction.includes("l")) {

    // insert code for if the triangle opens to the left

  } else if (direction.includes("u")) {

    // insert code for if the triangle opens to upward

  } else if (direction.includes("d")) {

    // insert code for if the triangle opens to downward

  }

}