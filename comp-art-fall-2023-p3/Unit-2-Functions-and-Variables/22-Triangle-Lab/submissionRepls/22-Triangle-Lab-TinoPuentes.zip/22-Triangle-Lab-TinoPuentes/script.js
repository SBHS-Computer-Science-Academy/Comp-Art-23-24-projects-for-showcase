function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}


function draw() {
  background("DodgerBlue");            
  fill("gray");
  verticalIsoscelesTriangle(150, 60, 350, 400);
  verticalIsoscelesTriangle(500, 160, 400, 300,)
  fill('Yellowgreen')
  rect(1, 460, 598, 600)
  fill('white')
verticalIsoscelesTriangle(150, 59, 118, 134)
verticalIsoscelesTriangle(500, 161, 179, 134)
fill('green')
verticalIsoscelesTriangle(30, 297, 99, 168)
verticalIsoscelesTriangle(152, 265, 148, 200)
verticalIsoscelesTriangle(277, 274, 148, 191)
verticalIsoscelesTriangle(397, 284, 150, 181)
verticalIsoscelesTriangle(530, 265, 149, 200)
fill('sienna')
horizontalIsoscelesTriangle(138, 460, 30, 100)
horizontalIsoscelesTriangle(25, 463, 30, 100)
horizontalIsoscelesTriangle(270, 464, 30, 100)
horizontalIsoscelesTriangle(393, 464, 30, 100)
horizontalIsoscelesTriangle(526, 465, 30, 100)


  
  

  drawMouseLines("black");


}

function verticalIsoscelesTriangle(topX, topY, w, h) {
  let bottomLeftX = topX - w / 2;
  let bottomRightX = topX + w / 2;
  let bottomY = topY + h;
    triangle(topX, topY, bottomLeftX, bottomY, bottomRightX, bottomY);
}
function horizontalIsoscelesTriangle(x, y, w, h) { 
  let bottomY = y + h;
  let rightX=x+w
  let rightY=h/2+y  
triangle(x, y, x, bottomY,rightX, rightY)

  
}




  
