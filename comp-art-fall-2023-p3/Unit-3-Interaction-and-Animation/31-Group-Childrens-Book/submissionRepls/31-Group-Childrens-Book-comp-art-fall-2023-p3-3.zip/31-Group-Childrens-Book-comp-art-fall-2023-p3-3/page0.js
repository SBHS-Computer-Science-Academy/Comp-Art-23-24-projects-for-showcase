function drawPage0() {
  fill("black");
  text("Title Page goes here", 0, height / 2, width);
}