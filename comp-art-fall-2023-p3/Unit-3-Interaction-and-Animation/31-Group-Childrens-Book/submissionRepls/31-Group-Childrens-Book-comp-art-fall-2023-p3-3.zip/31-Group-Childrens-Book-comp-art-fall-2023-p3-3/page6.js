function drawPage6() {
	fill("black");
	text("Page 6 goes here", 0, height / 2, width);
}