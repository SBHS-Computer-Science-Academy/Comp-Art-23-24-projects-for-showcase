function drawPage4() {
	fill("black");
	text("Page 4 goes here", 0, height / 2, width);
}