function drawPage1() {
	fill("black");
	text("Page 1 goes here", 0, height / 2, width);
}


    