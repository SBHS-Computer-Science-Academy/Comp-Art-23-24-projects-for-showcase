function drawPage0() {
  background('black');
    textSize(60)
    stroke(0);
    fill("white");
    text("The Little Astronaut", 0,300, width);

    drawPlanet()
  }

  function drawPlanet() {
    fill(103, 156, 191);
    circle(500, 500, 250);

    noFill();
    stroke('white');
    strokeWeight(5);
    beginShape();
    curveVertex(385, 544); // control point
    curveVertex(385, 544);
    curveVertex(320, 602);
    curveVertex(689, 421);
    curveVertex(607, 438);
    curveVertex(607, 438); // control point
    endShape();
  }
