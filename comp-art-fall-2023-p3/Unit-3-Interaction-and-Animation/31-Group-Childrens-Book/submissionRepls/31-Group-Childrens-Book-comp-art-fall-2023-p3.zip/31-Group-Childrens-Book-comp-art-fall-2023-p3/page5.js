function drawPage5() {
	fill("black");
	text("Page 5 goes here", 0, height / 2, width);
}