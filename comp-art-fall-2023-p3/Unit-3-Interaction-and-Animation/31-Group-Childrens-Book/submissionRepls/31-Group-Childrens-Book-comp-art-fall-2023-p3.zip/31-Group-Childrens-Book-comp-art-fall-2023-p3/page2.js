function drawPage2() {

    fill("white");
    stroke("white");
    noStroke();
    textSize(50);
    text("The Little Astronaut loved space. He wanted to see all the planets in our solar system.", 0, 100, width);
    text("So he blasted off in his...", 0, 650, width);
    text("ROCKETSHIP!", 0, 700, width);


    drawRocket();
  }



  function drawRocket() {
    fill("red");
    beginShape(); //top
    vertex(758, 268);
    vertex(695, 363);
    vertex(641, 262);
    vertex(757, 268);
    endShape();

    beginShape(); //left wing
    vertex(509, 327);
    vertex(335, 312);
    vertex(428, 367);
    vertex(510, 328);
    endShape();

    beginShape(); //right wing
    vertex(562, 427);
    vertex(460, 569);
    vertex(473, 466);
    vertex(562, 425);
    endShape();

    fill('white');
    beginShape();
    vertex(641, 262);
    vertex(427, 366);
    vertex(473, 467);
    vertex(695, 363);
    vertex(642, 263);
    endShape();



    fill('black');
    circle(608,339,70); //window

    fill('orange');
    beginShape();
    vertex(427, 366);
    vertex(367, 364);
    vertex(384, 386);
    vertex(288, 395);
    vertex(334, 408);
    vertex(272, 446);
    vertex(356, 451);
    vertex(311, 501);
    vertex(389, 472);
    vertex(370, 521);
    vertex(432, 470);
    vertex(434, 505);
    vertex(473, 467);
    endShape();

    fill("yellow");
    beginShape();
    vertex(437, 386);
    vertex(412, 391);
    vertex(422, 404);
    vertex(358, 410);
    vertex(389, 427);
    vertex(364, 448);
    vertex(406, 450);
    vertex(412, 465);
    vertex(437, 448);
    vertex(441, 466);
    vertex(462, 443);
    vertex(436, 386);
    endShape();

    fill("white");
    beginShape();
    vertex(444, 405);
    vertex(432, 400);
    vertex(434, 408);
    vertex(403, 419);
    vertex(419, 422);
    vertex(408, 434);
    vertex(439, 436);
    vertex(445, 443);
    vertex(455, 429);
    vertex(444, 405);
    endShape();
  }
