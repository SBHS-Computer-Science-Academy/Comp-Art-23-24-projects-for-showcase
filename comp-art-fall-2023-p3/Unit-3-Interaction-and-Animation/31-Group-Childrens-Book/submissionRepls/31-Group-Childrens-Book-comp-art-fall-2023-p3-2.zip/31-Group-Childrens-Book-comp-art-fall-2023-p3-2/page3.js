function drawPage3() {
  colo1=color("teal")
  colo2=color("purple")
  pencil()
  paper()
  textFont("Comic Sans MS");
  fill('black')
  textSize(100);
  text("This ", 630, 163)
  text("Is", 580, 263)
  text("Pencil", 650, 363)
}

function pencil(){
  fill(219,183,187)
  beginShape();
  vertex(245, 541);
  vertex(273, 554);
  vertex(283, 537);
  vertex(253, 522);
  vertex(245, 541);
  endShape();
  fill(132,135,137)
  beginShape();
  vertex(254, 523);
  vertex(260, 511);
  vertex(285, 524);
  vertex(280, 536);
  vertex(255, 524);
  endShape();
  fill(221, 143, 14)
  beginShape();
  vertex(259, 510);
  vertex(353, 314);
  vertex(384, 328);
  vertex(288, 526);
  vertex(259, 510);
  endShape();
  fill(196, 164, 132)
  beginShape();
  vertex(353, 313);
  vertex(383, 282);
  vertex(384, 328);
  vertex(354, 314);
  endShape();
  fill(132,135,137)
  beginShape();
  vertex(370, 297);
  vertex(383, 303);
  vertex(384, 282);
  vertex(369, 297);
  endShape();
}
function paper(){
  fill(246,238,227)
  beginShape();
  vertex(126, 555);
  vertex(321, 206);
  vertex(89, 91);
  vertex(-6, 252);
  vertex(-6, 561);
  vertex(88, 608);
  vertex(131, 547);
  endShape();
  stroke('black')
  ellipse(100, 132, 40, 40)
  beginShape();
  vertex(102, 139);
  vertex(110, 157);
  endShape();
  beginShape();
  vertex(142, 134);
  vertex(130, 158);
  vertex(132, 169);
  vertex(141, 175);
  vertex(147, 177);
  vertex(153, 177);
  vertex(158, 173);
  vertex(162, 169);
  vertex(166, 164);
  vertex(168, 161);
  vertex(170, 158);
  vertex(174, 154);
  vertex(176, 152);
  endShape();
  beginShape();
  vertex(156, 181);
  vertex(189, 158);
  vertex(187, 193);
  endShape();
  beginShape();
  vertex(174, 168);
  vertex(188, 176);
  endShape();
  beginShape();
  vertex(213, 167);
  vertex(200, 198);
  vertex(210, 210);
  endShape();
  beginShape();
  vertex(238, 179);
  vertex(221, 213);
  endShape()
  beginShape();
  vertex(246, 185);
  vertex(260, 193);
  endShape();
  beginShape();
  vertex(251, 189);
  vertex(235, 221);
  endShape();
  beginShape();
  vertex(271, 199);
  vertex(275, 215);
  vertex(293, 206);
  endShape();
  beginShape();
  vertex(275, 216);
  vertex(260, 236);
  endShape();
  beginShape();
  vertex(66, 170);
  vertex(105, 194);
  vertex(78, 177);
  vertex(60, 213);
  endShape();
  beginShape();
  vertex(115, 194);
  vertex(94, 231);
  vertex(113, 242);
  vertex(94, 231);
  vertex(104, 214);
  vertex(121, 224);
  vertex(104, 212);
  vertex(116, 192);
  vertex(131, 202);
  endShape();
  beginShape();
  vertex(156, 211);
  vertex(150, 208);
  vertex(146, 208);
  vertex(143, 208);
  vertex(140, 210);
  vertex(138, 213);
  vertex(137, 216);
  vertex(136, 219);
  vertex(136, 223);
  vertex(136, 226);
  vertex(137, 227);
  vertex(139, 231);
  vertex(141, 232);
  vertex(145, 233);
  vertex(148, 234);
  vertex(151, 236);
  vertex(152, 239);
  vertex(152, 243);
  vertex(151, 247);
  vertex(150, 249);
  vertex(148, 250);
  vertex(142, 251);
  vertex(139, 251);
  vertex(130, 251);
  vertex(130, 251);
  endShape();
  beginShape();
  vertex(178, 219);
  vertex(212, 226);
  vertex(194, 223);
  vertex(190, 263);
  endShape();
}