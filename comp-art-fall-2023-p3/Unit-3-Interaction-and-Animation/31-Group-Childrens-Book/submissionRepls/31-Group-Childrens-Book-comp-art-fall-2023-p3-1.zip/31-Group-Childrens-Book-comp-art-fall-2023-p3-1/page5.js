function drawPage5() {
	fill("black");
	text("The mans axe broke!", 10, height / 20, width);
  stickmans(475, 202)
  fill("black")
  circle(441, 135,20)
  circle(503, 135,20)
  noFill()
  strokeWeight(3)
  line(500, 113, 480, 128)
  line(443, 111, 461, 125)
  strokeWeight(1)
  drawMouth()
  drawBeard()
  fill("sienna")
  beginShape()
  vertex(566, 358);
  vertex(565, 358);
  vertex(611, 298);
  vertex(623, 308);
  vertex(573, 373);
  vertex(560, 364);
  endShape()
  fill("grey")
  beginShape();
  vertex(611, 292);
  vertex(610, 285);
  endShape();
  beginShape();
  vertex(616, 294);
  vertex(616, 284);
  endShape();
  beginShape();
  vertex(621, 297);
  vertex(627, 287);
  endShape();
  beginShape();
  vertex(619, 296);
  vertex(621, 285);
  endShape();
  beginShape()
  vertex(624, 300);
  vertex(633, 295);
  endShape()
  beginShape();
  vertex(623, 298);
  vertex(630, 291);
  endShape();
  beginShape();
  vertex(626, 304);
  vertex(633, 301);
  endShape();
}