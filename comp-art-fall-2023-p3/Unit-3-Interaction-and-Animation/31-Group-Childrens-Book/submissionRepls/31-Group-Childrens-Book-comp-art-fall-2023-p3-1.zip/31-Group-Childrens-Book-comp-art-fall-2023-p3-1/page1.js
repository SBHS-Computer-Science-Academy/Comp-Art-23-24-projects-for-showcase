class Monkey {
  constructor(x, y) {
    this.x = x;
    this.y = y;
    this.startY = y;
    this.jumpSpeed = 0;
    this.gravity = 1;
    this.isJumping = false;
  }

  show() {
    drawMonkey(this.x, this.y)
    noFill()
  }

  jump() {
    if (this.y >= this.startY) {
      this.y = this.startY;
      this.jumpSpeed = 0;
      this.isJumping = false
    } 
    if (mouseIsPressed && !this.isJumping && mouseIsInRect(this.x-50, this.y-125, 130, 125) ) {
        this.jumpSpeed = -20;
        this.isJumping = true;
      }
    
    if (this.isJumping) {
        this.y += this.jumpSpeed
        this.jumpSpeed += this.gravity
      }
    

  }
}

function drawPage1() {
  fill("black");
  text("The 3 monkeys each found their own tree, one small, one medium and one large.", 10, height / 20, width);


  drawSmallTreeTrunk()
  drawSmallTreeBranches()
  drawMediumTreeTrunk()
  drawMediumTreeBranches()
  drawLargeTreeTrunk()
  drawLargeTreeBranches()
  monkey1.show()
  monkey1.jump()
  drawMonkey(154, 535)
  drawMonkey(655, 290)
}


function drawMonkey(x,y){
  push()
  translate(x,y)
  translate(-154,-535)
  drawSmallMonkeyRightArm()
  drawSmallMonkeyLeftArm()
  drawSmallMonkeyBody()
  drawSmallCrease()
  fill("Sienna")
  circle(176, 442,60)
  drawSmallMonkeyFace()
  drawSmallMonkeySmile()
  fill("black")
  circle(175, 441,5)
  circle(190, 442,5)
pop()
}


  function  drawSmallTreeTrunk() {
     fill("SaddleBrown");
    beginShape();
    vertex(138, 629);
    vertex(158, 629);
    vertex(158, 800);
    vertex(138, 800);
    vertex(138, 629);
    endShape();
  }

function drawSmallTreeBranches() {
   fill("green");
  beginShape();
  curveVertex(138, 630); // control point
  curveVertex(138, 630);
  curveVertex(110, 629);
  curveVertex(104, 607);
  curveVertex(130, 598);
  curveVertex(110, 579);
  curveVertex(115, 551);
  curveVertex(139, 565);
  curveVertex(146, 538);
  curveVertex(181, 535);
  curveVertex(172, 564);
  curveVertex(203, 555);
  curveVertex(227, 580);
  curveVertex(199, 596);
  curveVertex(204, 617);
  curveVertex(158, 630);
  curveVertex(138, 630);
  curveVertex(138, 630); // control point
  endShape();
}
function drawMediumTreeTrunk() {
   fill("SaddleBrown");
  beginShape();
  vertex(360, 800);
  vertex(408, 800);
  vertex(408, 580);
  vertex(360, 580);
  vertex(360, 800);
  endShape();
}
function drawMediumTreeBranches() {
   fill("green");
  beginShape();
  curveVertex(360, 580); // control point
  curveVertex(360, 580);
  curveVertex(306, 566);
  curveVertex(284, 492);
  curveVertex(321, 483);
  curveVertex(318, 417);
  curveVertex(376, 400);
  curveVertex(382, 453);
  curveVertex(454, 386);
  curveVertex(529, 449);
  curveVertex(508, 483);
  curveVertex(450, 517);
  curveVertex(535, 555);
  curveVertex(492, 578);
  curveVertex(409, 581);
  curveVertex(360, 580);
  curveVertex(360, 580); // control point
  endShape();
}
function drawLargeTreeTrunk() {
   fill("SaddleBrown");
  beginShape();
  vertex(710, 800);
  vertex(847, 800);
  vertex(836, 504);
  vertex(700, 504);
  vertex(710, 800);
  endShape();
}
function drawLargeTreeBranches() {
   fill("green");
  beginShape();
  curveVertex(700, 505); // control point
  curveVertex(700, 505);
  curveVertex(625, 457);
  curveVertex(648, 423);
  curveVertex(602, 359);
  curveVertex(651, 291);
  curveVertex(729, 339);
  curveVertex(806, 287);
  curveVertex(922, 349);
  curveVertex(897, 439);
  curveVertex(975, 473);
  curveVertex(837, 510);
  curveVertex(700, 505);
  curveVertex(700, 505); // control point
  endShape();
}
function drawSmallMonkeyBody() {
   fill("SaddleBrown");
  beginShape();
  curveVertex(118, 530); // control point
  curveVertex(118, 530);
  curveVertex(130, 524);
  curveVertex(141, 524);
  curveVertex(150, 531);
  curveVertex(156, 534);
  curveVertex(182, 521);
  curveVertex(186, 528);
  curveVertex(190, 531);
  curveVertex(198, 530);
  curveVertex(199, 524);
  curveVertex(192, 519);
  curveVertex(189, 469);
  curveVertex(168, 465);
  curveVertex(150, 460);
  curveVertex(152, 518);
  curveVertex(136, 512);
  curveVertex(114, 521);
  curveVertex(118, 530);
  curveVertex(118, 530); // control point
  endShape();
}
function drawSmallCrease() {
  stroke("black");
  beginShape();
  curveVertex(157, 508); // control point
  curveVertex(157, 508);
  curveVertex(167, 508);
  curveVertex(170, 519);
  curveVertex(170, 519); // control point
  endShape();
}
function drawSmallMonkeyFace() {
  stroke("black");
  beginShape();
  curveVertex(160, 468); // control point
  curveVertex(160, 468);
  curveVertex(159, 456);
  curveVertex(168, 448);
  curveVertex(166, 436);
  curveVertex(175, 429);
  curveVertex(183, 437);
  curveVertex(190, 432);
  curveVertex(198, 437);
  curveVertex(194, 450);
  curveVertex(201, 458);
  curveVertex(201, 458); // control point
  endShape();
}
function drawSmallMonkeyRightArm() {
   fill("SaddleBrown");
  beginShape();
  curveVertex(192, 488); // control point
  curveVertex(192, 488);
  curveVertex(211, 472);
  curveVertex(219, 473);
  curveVertex(192, 498);
  curveVertex(191, 489);
  curveVertex(191, 489); // control point
  endShape();
}
function drawSmallMonkeyLeftArm() {
  // fill("black");
  beginShape();
  curveVertex(152, 495); // control point
  curveVertex(152, 495);
  curveVertex(122, 484);
  curveVertex(121, 474);
  curveVertex(151, 485);
  curveVertex(152, 495);
  curveVertex(152, 495); // control point
  endShape();
}
function drawSmallMonkeySmile() {
   stroke("black");
  beginShape();
  curveVertex(169, 459); // control point
  curveVertex(169, 459);
  curveVertex(179, 466);
  curveVertex(193, 460);
  curveVertex(193, 460); // control point
  endShape();
}

function mouseIsInRect(x, y, w, h, showLines = false) {
if(showLines) {
stroke('black');
noFill();
rect(x, y,w, h);
}
return mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;
}