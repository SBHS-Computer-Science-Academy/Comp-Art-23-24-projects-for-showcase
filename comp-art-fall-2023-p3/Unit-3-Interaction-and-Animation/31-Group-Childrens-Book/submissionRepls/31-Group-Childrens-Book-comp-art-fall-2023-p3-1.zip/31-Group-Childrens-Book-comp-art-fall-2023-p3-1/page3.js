function drawPage3() {
	fill("black");
	text("The man with the axe cuts the first monkeys tree down.", 10, height / 20, width);

 drawTree(712, 675)
  drawMonkey(712, 275)
  drawStickman(575, 600)
  drawCrack1()
  }

  function drawMonkey(x,y){
  push()
  translate(x,y)
  scale(4)
  translate(-154,-535)
  drawSmallMonkeyRightArm()
  drawSmallMonkeyLeftArm()
  drawSmallMonkeyBody()
  drawSmallCrease()
  fill("Sienna")
  circle(176, 442,60)
  drawSmallMonkeyFace()
  drawSmallMonkeySmile()
  fill("black")
   circle(175, 441,5)
   circle(190, 442,5)
  pop()
  }


function drawTree(x,y){
  push()
  translate(x,y)
  scale(3)
  translate(-147, -675)
  drawSmallTreeBranches()
  drawSmallTreeTrunk()
  pop()
  }

function drawStickman(x,y){
push()
translate(x,y)
  scale(0.5)
translate(-475, -202)
stickmans(475, 202)
circle(441, 135,20)
circle(503, 135,20)
strokeWeight(3)
line(500, 113, 480, 128)
line(443, 111, 461, 125)
strokeWeight(1)
drawMouth()
drawBeard()
drawHandle()
drawSharpe()
drawNonsharp()
pop()
}
function drawCrack1() {
   fill("black");
  beginShape();
  vertex(684, 633);
  vertex(701, 654);
  vertex(685, 672);
  vertex(685, 634);
  endShape();
}