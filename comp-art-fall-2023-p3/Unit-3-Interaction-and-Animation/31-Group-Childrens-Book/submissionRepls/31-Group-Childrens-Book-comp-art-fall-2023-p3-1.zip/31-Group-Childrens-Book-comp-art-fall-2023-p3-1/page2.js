function drawPage2() {
  fill("black");
  text("the man with the axe sees 3 perfect trees to cut down.", 10, height / 20, width);
 
  stickmans(475, 202)
  circle(441, 135,20)
  circle(503, 135,20)
  strokeWeight(3)
  line(500, 113, 480, 128)
  line(443, 111, 461, 125)
  strokeWeight(1)
  drawMouth()
   drawBeard()
  drawGrass()
  drawHandle()
  drawSharpe()
  drawNonsharp()
}
function drawBeard() {
   fill("saddlebrown");
  beginShape();
  vertex(426, 200);
  vertex(431, 229);
  vertex(441, 217);
  vertex(449, 233);
  vertex(454, 220);
  vertex(464, 235);
  vertex(472, 221);
  vertex(485, 240);
  vertex(491, 223);
  vertex(503, 237);
  vertex(506, 216);
  vertex(521, 234);
  vertex(518, 208);
  vertex(427, 208);
  endShape();
}
 function drawMouth() {
  fill("pink");
  beginShape();
  curveVertex(447, 174); // control point
  curveVertex(447, 174);
  curveVertex(467, 191);
  curveVertex(501, 175);
  curveVertex(476, 174);
  curveVertex(447, 173);
  curveVertex(447, 173); // control point
  endShape();
}


function stickmans(x,y){
  push()
translate(x, y)
  scale(2.25)
  translate(-440, -510)
  noFill()
  strokeWeight(5)
  beginShape();
  vertex(401, 706);
  vertex(440, 618);
  vertex(477, 701);
  vertex(440, 618);
  vertex(439, 517);
  vertex(441, 558);
  vertex(479, 581);
  vertex(441, 558);
  vertex(407, 581);
  endShape();
  fill("tan")
  circle(439,488,60)
  strokeWeight(1)
  pop()
}
function drawGrass() {
   fill("green");
  beginShape();
  curveVertex(0, 685); // control point
  curveVertex(0, 685);
  curveVertex(26, 673);
  curveVertex(35, 683);
  curveVertex(88, 665);
  curveVertex(105, 683);
  curveVertex(155, 667);
  curveVertex(159, 685);
  curveVertex(216, 669);
  curveVertex(277, 684);
  curveVertex(316, 653);
  curveVertex(369, 650);
  curveVertex(410, 647);
  curveVertex(513, 649);
  curveVertex(587, 621);
  curveVertex(637, 631);
  curveVertex(653, 668);
  curveVertex(738, 657);
  curveVertex(781, 637);
  curveVertex(838, 684);
  curveVertex(916, 663);
  curveVertex(955, 701);
  curveVertex(998, 683);
  curveVertex(1001, 795);
  curveVertex(0, 799);
  curveVertex(0, 685);
  curveVertex(0, 685); // control point
  endShape();
}
function drawHandle() {
   fill("saddlebrown");
  beginShape();
  vertex(542, 400);
  vertex(588, 305);
  vertex(606, 315);
  vertex(555, 410);
  vertex(543, 400);
  endShape();
}
function drawNonsharp() {
   fill("grey");
  beginShape();
  vertex(581, 300);
  vertex(621, 324);
  vertex(630, 305);
  vertex(589, 281);
  vertex(581, 299);
  endShape();
}
function drawSharpe() {
   fill("grey");
  beginShape();
  curveVertex(620, 324); // control point
  curveVertex(620, 324);
  curveVertex(636, 336);
  curveVertex(639, 346);
  curveVertex(649, 341);
  curveVertex(661, 321);
  curveVertex(659, 309);
  curveVertex(647, 312);
  curveVertex(630, 305);
  curveVertex(620, 321);
  curveVertex(620, 321); // control point
  endShape();
}