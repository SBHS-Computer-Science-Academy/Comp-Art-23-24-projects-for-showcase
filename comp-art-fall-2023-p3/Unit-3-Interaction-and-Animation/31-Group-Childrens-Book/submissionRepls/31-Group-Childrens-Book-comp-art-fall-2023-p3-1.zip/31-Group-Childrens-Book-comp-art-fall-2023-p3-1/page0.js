function drawPage0() {
  rectGradient(0, 0, width, 800, "blue", "skyBlue")
  fill("black");
  text("The Three Little Monkeys", 0, height / 2, width);
  monkeyFace()
}

function monkeyFace()
{

  fill("saddleBrown")
  circle(500,200,300)
  strokeWeight(2)
  fill("tan") 
  beginShape();
  curveVertex(387, 299);
  curveVertex(387, 299);
  curveVertex(446, 156);
  curveVertex(502, 158);
  curveVertex(532, 144);
  curveVertex(561, 157);
  curveVertex(630, 274);
  curveVertex(546, 343);
  curveVertex(442, 339);
  curveVertex(386, 300);
  curveVertex(386, 300);
  endShape();
  fill("black")
  circle(460,200,50)
  circle(540,200,50)
  beginShape();
  curveVertex(452, 267);
  curveVertex(479, 298);
  curveVertex(523, 298);
  curveVertex(555, 267);
  endShape();
  strokeWeight(1)
 }