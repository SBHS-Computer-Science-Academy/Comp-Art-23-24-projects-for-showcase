function drawPage4() {
  fill("black");
    text("The guy chops the second tree down!", 10, height / 20, width);


    drawMediumTreeTrunk()
    drawMediumTreeBranches()
    drawLargeTreeTrunk()
    drawLargeTreeBranches()
    drawMonkey(340,403)
    drawMonkey(655, 290)
    drawMonkey(458, 408)
  drawStickman(250, 600)
  drawCrack2()
  }

  function drawMonkey(x,y){
    push()
    translate(x,y)
    translate(-154,-535)
    drawSmallMonkeyRightArm()
    drawSmallMonkeyLeftArm()
    drawSmallMonkeyBody()
    drawSmallCrease()
    fill("Sienna")
    circle(176, 442,60)
    drawSmallMonkeyFace()
    drawSmallMonkeySmile()
    fill("black")
    circle(175, 441,5)
    circle(190, 442,5)

  pop()
  }

 function drawStickman(x,y){
 push()
 translate(x,y)
   scale(0.5)
 translate(-475, -202)
 stickmans(475, 202)
   fill("black")
 circle(441, 135,20)
 circle(503, 135,20)
   noFill()
 strokeWeight(3)
 line(500, 113, 480, 128)
 line(443, 111, 461, 125)
 strokeWeight(1)
 drawMouth()
 drawBeard()
 drawHandle()
 drawSharpe()
 drawNonsharp()
 pop()
 }
function drawCrack2() {
   fill("black");
  beginShape();
  vertex(360, 644);
  vertex(376, 664);
  vertex(360, 681);
  vertex(360, 645);
  endShape();
}