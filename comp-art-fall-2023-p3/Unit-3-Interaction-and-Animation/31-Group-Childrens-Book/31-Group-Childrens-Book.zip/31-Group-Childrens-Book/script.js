/* 
To change the starting page, change the page variable below.

To add new pages:

1. Change numPages to be total # of pages
2. Add a line per page to function draw() below
3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

let page = 0;
let numPages = 6; 
let myFont;

/*
This is an example of how to load and use fonts.  You can download a font you like from the internet and add it to the files
*/

function preload() {
	myFont = loadFont("PaletteMosaic-Regular.ttf");
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
 
  // printToConsole("Use arrow or number keys to change pages.");
  // printToConsole("");
  
  createConsole("lines");

	textFont(myFont);
	textSize(36);
	textAlign(CENTER, CENTER);  // the x and y for the text command are the center of the text box


}

function draw() {
	background("white");

  if (page == 0) drawPage0();
	if (page == 1) drawPage1();
	if (page == 2) drawPage2();
	if (page == 3) drawPage3();
	if (page == 4) drawPage4();
	if (page == 5) drawPage5();
	if (page == 6) drawPage6();
  
  drawMouseLines("black");
}