// Step 1: draw a shape that you want to animate

function drawBlock() {
  fill("red");
  square(100, 100, 100);
}
// Step 2: turn the shape into a class.  Classes define a group of objects and start with a capital letter:

class Block {
  // this tells us how to make a new object
  constructor(x, y, clr = "red") {
    // the keyword "this" refers to each object
    this.x = x;
    this.y = y;
    this.width = 30;
    this.height = 30;
    this.clr = clr;
    this.speed = 5;
  }

  // we need to show the blocks
  show() {
    push();
    translate(this.x, this.y);
    translate(-100, -100); // our reference point on the block is at (100, 100)
    fill(this.clr);
    rect(100, 100, this.width, this.height);

    pop();
  }

  // let's move the blocks
  move() {
    let jitter = min(frameCount / 120, redBlock.speed);
    if (this.x > redBlock.x) this.x += random(-2 * jitter, jitter);
    else this.x += random(-jitter, 2 * jitter);
    if (this.y > redBlock.y) this.y += random(-jitter * 2, jitter);
    else this.y += random(-jitter, 2 * jitter);

    this.checkForGameOver();
  }

  moveKeys() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.width) this.x += this.speed;
    if (keyIsDown(UP_ARROW) && this.y > 0) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW) && this.y < height - this.height) this.y += this.speed;
  }

  checkForCollisions() {
    let hit = collideRectRect(redBlock.x, redBlock.y, redBlock.width, redBlock.height, this.x, this.y, this.width, this.height);

    return hit;
  }

  checkForGameOver() {
    let hit = this.checkForCollisions();
    if (hit) {
      text("Tagged!", width / 2, height / 2);
      setup(); // reset the sketch
    }
  }
}



let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click

  frameCount = 0; // reset frameCount
  score = 0;

  // Step 3: make one or more new objects

  redBlock = new Block(100, 100);

  let numBlocks = 10;
  blockArray = [];
  for (let i = 0; i < numBlocks; i++) {
    spawnNewBlock();
  }
}

function draw() {
  clear();
  background("white");

  checkForScore();

  // step 4: show and move the blocks

  redBlock.moveKeys();
  redBlock.show();

  for (block of blockArray) {
    block.move();
    block.show();
  }


  animateText();

  drawMouseLines("black");

}


function checkForScore() {
  if (frameCount % 60 == 0) {
    score += 1
    spawnNewBlock();
  }
}

function spawnNewBlock() {
  let newBlock = new Block(random(width), random(height), "blue");

  while (newBlock.checkForCollisions()) {
    newBlock = new Block(random(width), random(height), "blue");
  }
  blockArray.push(newBlock);

}

function animateText() {

  drawText(textX, 400);

  textX -= 2; // decrement
  if (textX < -250) textX = width + 250; // reset when off the screen on the left
}

function drawText(x, y) {

  translate(x, y);

  fill("black");
  text("Uses classes to make a small game or a short story using states.\n Run away!  Your score: " + int(score), 0, 0);

  resetMatrix();
}