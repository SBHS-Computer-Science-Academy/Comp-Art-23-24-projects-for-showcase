let f1, f2, f3, f4, f5, f6;
let projs = [];

function setup() {
  createCanvas(1200, 900);
  frameRate(60);
  background(18, 86, 137);
  f1 = new Plane(width / 7);
  f2 = new Plane(2 * (width / 7));
  f3 = new Plane(3 * (width / 7));
  f4 = new Plane(4 * (width / 7));
  f5 = new Plane(5 * (width / 7));
  f6 = new Plane(6 * (width / 7));
}

function draw() {
  background(130, 180, 255);
  fill(0);
  noStroke();
  f1.drawPlane();
  f2.drawPlane();
  f3.drawPlane();
  f4.drawPlane();
  f5.drawPlane();
  f6.drawPlane();
  xHair();
  for (let i = 0; i < projs.length; i++) {
    projs[i].drawProj();
    if (projs[i].hasCompletePath()) {
      projs.splice(0, 1);
      i -= 1
    }
  }
}

let x = 0;
let y = 0;
function xHair() {
  push();
  stroke(0);
  strokeWeight(1);
  noFill();
  let size = 14
  let xDiff = mouseX - x;
  let yDiff = mouseY - y;
  x += xDiff * 0.15;
  y += yDiff * 0.15;
  sind = size + 1
  if (x > width - sind / 2) x = width - sind / 2
  if (x < sind / 2) x = sind / 2
  if (y > height - sind / 2) y = height - sind / 2
  if (y < sind / 2) y = sind / 2
  circle(x, y, size);
}

function mousePressed() {
  projX = x;
  projY = y;
  projs.push(new Projectile(projX, projY));
}

class Projectile {
  constructor(projX, projY) {
    this.x = projX;
    this.y = 1500
    this.targety = projY;
  }

  drawProj() {
    push();
    fill(80);
    stroke('red');
    ellipse(this.x, this.y, 6, 16);
    pop();
    this.y += (this.targety - this.y) / 15 - 3
  }

  hasCompletePath() {
    return this.y <= this.targety
  }
}

class Plane {
  constructor(xStart) {
    this.x = xStart;
    this.y = 1500;
    this.speed = random(3, 14);
  }

  drawPlane() {
    fill(150);
    triangle(this.x, this.y + 8, this.x - 15, this.y + 31, this.x + 15, this.y + 31); //tail
    ellipse(this.x, this.y - 23, 12, 40); //cockpit
    triangle(this.x - 4, this.y - 37, this.x + 4, this.y - 37, this.x, this.y - 47); //point tip
    quad(this.x - 30, this.y + 8, this.x - 30, this.y + 24, this.x - 6, this.y + 12, this.x - 6, this.y - 15); //wingL
    ellipse(this.x - 29, this.y + 13, 3, 28); //wingtipL
    quad(this.x + 30, this.y + 8, this.x + 30, this.y + 24, this.x + 6, this.y + 12, this.x + 6, this.y - 15); //wingR
    ellipse(this.x + 29, this.y + 13, 3, 28); //wingtipL
    rect(this.x - 9, this.y - 20, 18, 40); //body
    this.y -= this.speed;
    if (this.y < -40) {
      this.y = height + 500;
      this.speed = random(3, 14);
    }
  }
}