// Step 1: draw a shape that you want to animate


// Step 2: turn the shape into a class.  Classes define a group of objects and start with a capital letter:

class People{
  // this tells us how to make a new object
  constructor(x, y, clr = "red") {
    // the keyword "this" refers to each object
    this.x = x
    this.y = y
    this.width = 25
    this.height = 25
    this.clr = clr
    this.jitter =2
    this.speed = 10
  }

  // we need to show the blocks
  show() {
    push();
    translate(this.x, this.y);
    translate(-47, -114); // our reference point on the block is at (100, 100)
    fill(this.clr);
drawPeople()
    function drawPeople() {
      
      beginShape();
      curveVertex(47, 98); // control point
      curveVertex(47, 98);
      curveVertex(44, 97);
      curveVertex(43, 104);
      curveVertex(49, 104);
      curveVertex(46, 97);
      curveVertex(47, 122);
      curveVertex(53, 132);
      curveVertex(47, 124);
      curveVertex(37, 133);
      curveVertex(46, 123);
      curveVertex(46, 113);
      curveVertex(33, 113);
      curveVertex(55, 112);
      curveVertex(55, 112); // control point
      endShape();
    }
    pop();
  }

  // let's move the blocks
  move() {
    let jitter = this.jitter;
    this.x += random(-jitter, jitter);
    this.y += random(-jitter, jitter);
    if (this.x > redCar.x) this.x += random(-2 * jitter, jitter);
      else this.x += random(-jitter, 2 * jitter);
      if (this.y > redCar.y) this.y += random(-jitter * 2, jitter);
      else this.y += random(-jitter, 2 * jitter);
    this.checkForCollisions();
  }
    // let's check for collisions
  moveKeys() {
    let KeyS = 83;
    let KeyD = 68;
    let KeyA = 65;
    let KeyW = 87;
    if (keyIsDown(KeyA)) this.x -= this.speed;
    if (keyIsDown(KeyD)) this.x += this.speed;
    if (keyIsDown(KeyW)) this.y -= this.speed;
    if (keyIsDown(KeyS)) this.y += this.speed;
  }

  checkForCollisions() {
    let hit = collideCircleCircle(redCar.x, redCar.y, redCar.width,  this.x, this.y, this.width, this.height);
  
    
 if (hit) {
      text("Tagged!", width/2, height/2);
      noLoop();
    }
  }
}



let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click


  // Step 3: make one or more new objects

  redCar = new People(100, 100);


  peopleArray = [];
  for (let i = 0; i < 100; i ++) {
    let newPeople = new People(random(300, width), random(height), "blue");
    peopleArray.push(newPeople);
  }

}

function draw() {
  clear();
  background("red");

  // step 4: show and move the blocks

  redCar.moveKeys();
  redCar.show();

  for (person of peopleArray) {
    person.move();
   person.show();
  }

  drawMouseLines("black");

}
