
class Kite{
  constructor(x,y){
    this.x = x;
    this.y = y;
    this.speed = 10;
  
  }
  show(){
    push();
  translate(this.x,this.y);
   translate(-484, -659)
    fill('red');
    noStroke();
    beginShape();
    vertex(445, 656);
    vertex(484, 593);
    vertex(520, 656);
    vertex(484, 713);
    endShape();

    
    stroke('black');
    strokeWeight(3);
    noFill();
    beginShape();
    curveVertex(484, 713); // control point
    curveVertex(484, 713);
    curveVertex(479, 718);
    curveVertex(475, 723);
    curveVertex(475, 731);
    curveVertex(483, 735);
    curveVertex(491, 736);
    curveVertex(498, 739);
    curveVertex(501, 749);
    curveVertex(501, 760);
    curveVertex(492, 765);
    curveVertex(479, 766);
    curveVertex(469, 766);
    curveVertex(461, 769);
    curveVertex(458, 777);
    curveVertex(467, 783);
    curveVertex(489, 783);
    curveVertex(492, 786);
    curveVertex(486, 793);
    curveVertex(486, 793); // control point
    endShape();

    strokeWeight(2);
    beginShape();
    vertex(484, 714);
    vertex(484, 595);
    endShape();

    beginShape();
    vertex(520, 657);
    vertex(446, 657);
    endShape();
    
    pop();
  }

  moveKeys() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;
    if (keyIsDown(UP_ARROW)) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW)) this.y += this.speed;

    if (this.y < -50) this.y = height+50
    

  }
  
}





class Cloud{
  constructor(x,y,speed,clr = "white"){
    this.x = y
    this.y = y
    this.clr = clr
    this.speed = speed
  }
  show() {
    push();
    translate(-100,-100);
    translate(this.x,this.y);
    fill('white');
    noStroke();
    ellipse(120,100,110,50);
    ellipse(130,80,70,70);
    pop();

  
  }

  move() {
    this.x += this.speed;
    if (this.x > width+100) this.x = -100
    //this.checkForCollisions();
  }

 
}



whiteCloud = new Cloud(100,100,5);
white2Cloud = new Cloud(500,500,10);
white3Cloud = new Cloud(300,300,15);
white4Cloud = new Cloud(300,300,5);

kite = new Kite(500,660);

let textX = 500;



function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click

  //cloud1 = new Cloud(120,100);
  //cloud2 = new Cloud(500,200);
}

function draw() {
  clear();
  background("lightblue");
 // cloud1.draw();
  //cloud2.draw();
  whiteCloud.show();
  white2Cloud.show();
  white3Cloud.show();
  white4Cloud.show();
  

  kite.show();

  whiteCloud.move();
  white2Cloud.move();
  white3Cloud.move();
  white4Cloud.move();

  kite.moveKeys();


  
  

  animateText();

  drawMouseLines("black");
}

function animateText() {

  drawText(textX, 400);
  
  textX -= 2; // decrement
  if (textX < -250) textX = width + 250; // reset when off the screen on the left
}

function drawText(x, y) {

  translate(x, y); 
  
  fill("black");
  //text("Uses classes to make a small game or a short story using states", 0, 0);

  resetMatrix();
}

function drawCloud(x,y) {
  rectMode (CENTER)
    translate(x,y);
    fill('white');
    noStroke();
    ellipse(120,100,110,50);
    ellipse(130,80,70,70);
   // ellipse(300,190,100,60);
  
  resetMatrix();
}
