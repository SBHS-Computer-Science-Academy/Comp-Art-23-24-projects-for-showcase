
function drawBlock() {
  fill("red");
 

 // ellipse(100, 100, 60);
  drawCar()
}



class Block {

  constructor(x, y, clr = "red") {
  
    this.x = x;
    this.y = y;
    this.width = 30;
    this.height = 30;
    this.clr = clr;
    this.speed = 5;
  }


  show() {
    push();
    translate(this.x, this.y);
    translate(-100, -100);
    fill(this.clr);
    rect(100, 100, this.width, this.height);
    rect(80,100,this.width,this.height)
    circle(80,130,30)
    circle(120,130,30)
    pop();
  }

  
  move() {
    let jitter = min(frameCount / 120, redBlock.speed);
    if (this.x > redBlock.x) this.x += random(-2 * jitter, jitter);
    else this.x += random(-jitter, 2 * jitter);
    if (this.y > redBlock.y) this.y += random(-jitter * 2, jitter);
    else this.y += random(-jitter, 2 * jitter);

    this.checkForGameOver();
  }

  moveKeys() {
    if (keyIsDown(LEFT_ARROW) && this.x > 0) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW) && this.x < width - this.width) this.x += this.speed;
    if (keyIsDown(UP_ARROW) && this.y > 0) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW) && this.y < height - this.height) this.y += this.speed;
  }

  checkForCollisions() {
    let hit = collideRectRect(redBlock.x, redBlock.y, redBlock.width, redBlock.height, this.x, this.y, this.width, this.height);

    return hit;
  }

  checkForGameOver() {
    let hit = this.checkForCollisions();
    if (hit) {
      text("Tagged!", width / 2, height / 2);
      setup(); // reset the sketch
    }
  }
}



let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);

  frameRate(60); 

  frameCount = 0;
  score = 0;

  

  redBlock = new Block(100, 100);

  let numBlocks = 10;
  blockArray = [];
  for (let i = 0; i < numBlocks; i++) {
    spawnNewBlock();
  }
}

function draw() {
  clear();

   background("white");
  drawSky()
  drawGround()
  drawRoad()
  drawShape()
  drawCactus()
  drawCactus2()
  
  line(0, 250, width, 250); 

  

  drawBuildings(644, 623, false);
  drawBuildings(-60, 623, true);

  

  drawMouseLines("white");

  
  checkForScore();




  redBlock.moveKeys();
  redBlock.show();

  for (block of blockArray) {
    block.move();
    block.show();


    
  }




  drawMouseLines("black");

}


function checkForScore() {
  if (frameCount % 60 == 0) {
    score += 1
    spawnNewBlock();
  }
}

function spawnNewBlock() {
  let newBlock = new Block(random(width), random(height), "blue");

  while (newBlock.checkForCollisions()) {
    newBlock = new Block(random(width), random(height), "blue");
  }
  blockArray.push(newBlock);

}

function animateText() {

  drawText(textX, 400);

  textX -= 2; 
  if (textX < -250) textX = width + 250; 
}


function drawCar() {
 translate(x,y)
  rect(0,0,40,10)
  rect(0,-5,20,10)
  circle(-10,10,10)
  circle(10,10,10)
}


function drawVanishingLines(x, y, numLines = 8) {
  push(); // save the current origin
  translate(x, y);
  for (let i = 0; i < numLines; i += 1) {
    rotate(360 / numLines);
    line(0, 0, width, 0);
  }
  pop();
}

function drawBuildings(x, y, flip) {
  // drawBuilding(644, 623);
  // drawBuilding(458, 438, 0.5); 
  // drawBuilding(362, 342, 0.25);
  // drawBuilding(316, 297, 0.125);


  // ... or use a for loop and the map function to automate:
  let numBuildings = 10;
  let scaling = 0.01; // relative scale of the last building is compared to the first building
  let scaleFactor = scaling ** (1/(numBuildings - 1)); // ** is exponent

  for (let i = 0; i < numBuildings; i += 1) {
    let thisX = map(scaling, 0, 1, 270, x);
    let thisY = map(scaling, 0, 1, 250, y); 
    drawBuilding(thisX, thisY, scaling, flip);
    scaling /= scaleFactor; // apply scaleFactor
  }
}

function drawBuilding(x, y, scaling = 1, flip = false) {

  push();
  translate(x, y); // move to point (x,y)
  scale(scaling); // scale makes it bigger or smaller
  if (flip) scale(-1, 1); // flip over x-axis
  translate(-644, -623); // negative of the bottom left (x,y)

  // put whatever code for the shape you want to draw here
  fill("silver");
  strokeWeight(2);
  beginShape();
  vertex(644, 623);
  vertex(783, 763);
  vertex(923, 687);
  vertex(923, 381);
  vertex(772, 318);
  vertex(644, 344);
  vertex(644, 623);
  endShape();
  line(783, 763,783, 414);
  line(644, 344, 783, 414);
  line(923, 381, 783, 414);
  drawDoor();
  drawWindow()
  drawWindow2()
  drawRect()
  pop();

  function drawDoor() {
    fill("sienna");
    beginShape();
    vertex(715, 695);
    vertex(714, 560);
    vertex(686, 541);
    vertex(684, 663);
    endShape();
  }
}

function drawRoad() {
  fill("black");
  beginShape();
  vertex(268, 251);
  vertex(-1, 562);
  vertex(269, 250);
  vertex(274, 250);
  vertex(569, 669);
  vertex(662, 789);
  vertex(3, 800);
  vertex(1, 558);
  endShape();
}

function drawSky() {
rectGradient(0, 0, width, 250, color('blue'), color('skyblue'), "horizontal", 500); // for details, see "gradient.js" file
}

function drawGround() {
rectGradient(0, 250, width, 550, color(222, 216, 160), color('tan'), "horizontal", 550); // for details, see "gradient.js" file
}

function drawShape() {
  fill("yellow");
 ellipse(140,137,50)
}

function drawWindow() {
   fill("skyblue");
  beginShape();
  vertex(660, 460);
  vertex(696, 479);
  vertex(696, 427);
  vertex(661, 412);
  vertex(660, 461);
  endShape();
}

function drawWindow2() {
  // fill("black");
  beginShape();
  vertex(719, 487);
  vertex(756, 502);
  vertex(754, 448);
  vertex(719, 436);
  vertex(718, 487);
  endShape();
}

function drawRect() {
  fill("yellow");
  beginShape();
  vertex(228, 575);
  vertex(214, 669);
  vertex(257, 671);
  vertex(262, 578);
  vertex(229, 575);
  endShape();
}

function drawCactus() {
  fill("green");
  beginShape();
  vertex(494, 261);
  vertex(496, 261);
  vertex(496, 258);
  vertex(499, 255);
  vertex(500, 253);
  vertex(497, 252);
  vertex(494, 255);
  vertex(493, 251);
  vertex(490, 252);
  vertex(490, 254);
  vertex(487, 256);
  vertex(490, 257);
  vertex(491, 259);
  vertex(493, 261);
  endShape();
}

function drawCactus2() {
  // fill("black");
  beginShape();
  vertex(690, 306);
  vertex(696, 306);
  vertex(697, 299);
  vertex(703, 298);
  vertex(706, 291);
  vertex(703, 287);
  vertex(697, 291);
  vertex(697, 297);
  vertex(691, 297);
  vertex(692, 288);
  vertex(689, 280);
  vertex(684, 282);
  vertex(684, 287);
  vertex(686, 291);
  vertex(687, 294);
  vertex(686, 295);
  vertex(683, 299);
  vertex(684, 301);
  vertex(688, 303);
  vertex(690, 303);
  vertex(691, 305);
  endShape();
}
