class Plane {
// this tells us how to make a new object
constructor(x, y, clr = "red") {
  // the keyword "this" refers to each object
  this.x = x;
  this.y = y;
  this.width = 30;
  this.height = 30;
  
  this.xspeed = 5;
  this.yspeed = 0;

  this.isMoving = false;
}
  show() {
    push();
    translate(this.x, this.y);
    translate(-743, -613); // our reference point on the block is at (100, 100)
    airplane()
    function airplane(){

      fill(227, 227, 227)
      beginShape();//body of plane
      curveVertex(948, 590); // control point
      curveVertex(948, 590);
      curveVertex(938, 513);
      curveVertex(894, 583);
      curveVertex(856, 589);
      curveVertex(675, 589);
      curveVertex(583, 624);
      curveVertex(515, 632);
      curveVertex(507, 646);
      curveVertex(581, 648);
      curveVertex(624, 654);
      curveVertex(895, 656);
      curveVertex(947, 587);
      curveVertex(947, 587); // control point
      endShape();
      beginShape();//wheels
      vertex(640, 655);
      vertex(630, 686);
      endShape();
      beginShape();
      vertex(839, 660);
      vertex(832, 683);
      endShape();
      beginShape();
      fill("black")
      vertex(870, 659);
      vertex(867, 681);
      endShape();
      circle(629, 690,20)
      circle(827, 690,20)
      circle(869, 690,20)
      fill(227, 227, 227)
      beginShape();//wing
      curveVertex(695, 638); // control point
      curveVertex(695, 638);
      curveVertex(798, 687);
      curveVertex(826, 689);
      curveVertex(821, 670);
      curveVertex(792, 630);
      curveVertex(792, 630); // control point
      endShape();
      fill(186, 217, 232)
      circle(689, 612,25)
      circle(742, 612,25)
      circle(800, 612,25)
      beginShape();
      vertex(617, 607);
      vertex(646, 609);
      vertex(645, 618);
      vertex(609, 612);
      vertex(620, 607);
      endShape();
    }
    pop();
  }
  move() {
    if(this.isMoving) {
    this.x -= this.xspeed;
   this.y-=this.yspeed;
    this.yspeed+=0.01;
    }

    if(this.x < -300) {
       airplane= new Plane(743, 613);
    }
  }
}
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);

  airplane= new Plane(743, 613);
  frameRate(60); // prevent a p5.js bug that changes the framerate when you click
}

function draw() {
  clear();
  background("lightBlue");
   ground()
  building()
  airplane.move();
  airplane.show()

  circleGradient(width / 10, 59, 180, "yellow", "orange"); // sun
  drawMouseLines("black");
}
function ground(){
  fill(128, 128, 128)
  rect(0, 700, 1000, 200)
  
}
function mousePressed(){
  airplane.isMoving = true;
}
function building(){
  fill(209, 209, 209)
  rect(519, 304, 100, 395)
   rect(475, 136, 198, 85)  
   fill(173, 172, 172)
  rect(451, 220, 240, 100)
   fill(186, 217, 232)
  rect(460, 226, 50, 80)
  rect(540, 226, 50, 80)
  rect(620, 226, 50, 80)
}
