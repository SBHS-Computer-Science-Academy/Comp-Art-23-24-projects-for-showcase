let textX = 500;
let blockentrancevalue=0
let thing;
let Xcord;
let BLOCKSPEED;
let speeds;
let BLOCK;
let BLOCK2;
let BLOCK3;
let BLOCK4;
let BLOCK5;

let character;

let scoreval=0;
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
  

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click

  
  
  
  BLOCK= new block(900,5, 30)
  BLOCK2= new block(1000,10, 140)
  BLOCK3= new block(1100, 4, 340)
  BLOCK4= new block(800, 12, 570)
  BLOCK5= new block(900, 7, 800)
  character = new Character()
  

  

}

function draw() {
  clear();
  background("white");
  let sec = second();

  drawMouseLines("black");
  BLOCK.move()
  BLOCK.draw()
  BLOCK2.move()

  BLOCK2.draw(1000,10, 140)
  BLOCK3.move()

  BLOCK3.draw(1100, 4, 340)
  BLOCK4.move()

  BLOCK4.draw(800,12,570)
  BLOCK5.move()

  BLOCK5.draw(900, 7, 800)
 character.draw()
  character.move()

  fill('red')
  
  
 
}
class block {
    constructor(thing, speeds, ycord){
      this.thing=thing;
      this.speed=speeds;
      this.cord=ycord;
      
    }
    draw(){

    
    fill('black')
    rect(this.thing, this.cord, 80, 200)

    }
  move() {
      BLOCKSPEED= this.speed;
    this.thing-=BLOCKSPEED
    if(this.thing==0){
      this.thing=1000
    }

    let hit=collideRectRect(this.thing, this.cord, 80, 200, character.x, character.y, 20, 20 )
    if(hit){
      text(500, 400, "dead")
      setup()
    }
    }
  
}

function blockvalues(){
  thing2=random(800)
  thing3=random(300)
}


  

class Character{

  constructor(){
  this.x = 100
    this. y = 400
  }
  
  draw(){
    fill('red')
    rect(this.x,this.y, 20, 20)
  }

  move() {
    if(keyIsDown(RIGHT_ARROW)&& this.x<990){
      this.x+=10
     
    }else if(keyIsDown(LEFT_ARROW )&& this.x>10){
      this.x-=10
   
    }
    else if(keyIsDown(UP_ARROW)&& this.y>10){
      this.y-=10
      if(this.y==0){
        this.y=0
      }
    }
    else if(keyIsDown(DOWN_ARROW) && this.y<790){
      this.y+=10
    }
  }
}
function start(){
  
}

function score(){
  clear()
  textSize(40)
  text("Score: "+second,882, 65)
}