
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click
  boy=new Boy()
}

function draw() {
  clear();
  background("lightblue");
  drawGrass();
  drawTrampoline()
  drawSun();
  boy.show()
  boy.move()
  drawNet()
  drawMouseLines("black");
}
function keyReleased() {
  // clear();
  // text(key, 500, 150);

  if (key == " ") boy.jump()
} 
function drawGrass() {
  fill('green');
  noStroke()
  rect(0, 719, 1000, 80);
}
function drawTrampoline() {
  fill(71, 81, 82)
  rect(284, 631, 37, 89)
  rect(640, 631, 37, 89)
  fill('black');
  ellipse(480, 630, 412, 60)
  fill(149, 171, 173)
  ellipse(480, 610, 300, 30)
  fill('black');
  rect(276, 350, 36, 276)
  rect(640, 346, 36, 276)
}
function drawSun() {
  circleGradient(width / 8, 150, 150, "orangeRed", "yellow"); // sun
}
function drawNet() {
  push()
  for (let i = 0; i <= 50; i += 1) {
    stroke('black')
    line(311, 353, 645, 353)
    translate(0, 5)
  }
  pop()
  push()
  for (let i = 0; i <= 50; i += 1) {
    stroke('black')
    line(316, 353, 316, 616)
    translate(7, 0)
  }
  pop()
}


class Boy {
  constructor() {
    this.x=472
    this.y=444
    this.groundY=444
    this.velocity=0
    this.jumpVelocity = -20
    this.gravity=1
  }
  show() {
    push()
    translate(this.x, this.y)
    translate(-472, -444)
    fill(230, 209, 154)
    circle(472,444,60)
    rect(465,472,15,14)
    fill(111, 143, 94)
    circle(460,436,10)
    circle(481,436,10)
    fill('black');
    circle(460,436,3)
    circle(481,436,3)
    fill('SaddleBrown')
    quad(452,429,454,431,465,424,463,420,453,429)
    quad(476,421,476,425,488,430,488,427,475,421)
    drawBody()    
    pop()

    function drawBody() {
      fill("blue");
      beginShape();
      vertex(466, 486);
      vertex(441, 498);
      vertex(451, 510);
      vertex(460, 504);
      vertex(460, 539);
      vertex(486, 539);
      vertex(483, 503);
      vertex(498, 510);
      vertex(505, 500);
      vertex(480, 486);
      vertex(465, 486);
      endShape();
      fill(230, 209, 154)
      beginShape();
      vertex(444, 502);
      vertex(429, 512);
      vertex(413, 511);
      vertex(412, 515);
      vertex(425, 517);
      vertex(415, 521);
      vertex(416, 525);
      vertex(428, 520);
      vertex(422, 530);
      vertex(427, 532);
      vertex(431, 523);
      vertex(431, 533);
      vertex(434, 533);
      vertex(434, 522);
      vertex(440, 528);
      vertex(443, 526);
      vertex(437, 517);
      vertex(450, 508);
      vertex(445, 503);
      endShape();
      beginShape();
      vertex(499, 507);
      vertex(510, 518);
      vertex(509, 526);
      vertex(512, 527);
      vertex(515, 519);
      vertex(519, 529);
      vertex(522, 528);
      vertex(519, 518);
      vertex(527, 525);
      vertex(530, 522);
      vertex(522, 516);
      vertex(533, 517);
      vertex(533, 513);
      vertex(521, 513);
      vertex(532, 508);
      vertex(525, 505);
      vertex(517, 509);
      vertex(504, 503);
      vertex(503, 504);
      vertex(499, 508);
      endShape();
      fill(79, 100, 125)
      beginShape();
      vertex(461, 539);
      vertex(485, 537);
      vertex(492, 587);
      vertex(478, 587);
      vertex(473, 551);
      vertex(465, 588);
      vertex(450, 588);
      vertex(461, 539);
      endShape();
      fill('black')
      beginShape();
      vertex(450, 587);
      vertex(441, 587);
      vertex(436, 588);
      vertex(431, 589);
      vertex(426, 592);
      vertex(424, 594);
      vertex(427, 597);
      vertex(441, 598);
      vertex(448, 598);
      vertex(456, 597);
      vertex(462, 597);
      vertex(465, 596);
      vertex(466, 592);
      vertex(465, 588);
      vertex(448, 587);
      endShape();
      beginShape();
      vertex(478, 587);
      vertex(491, 587);
      vertex(499, 587);
      vertex(505, 587);
      vertex(510, 588);
      vertex(511, 589);
      vertex(514, 590);
      vertex(514, 591);
      vertex(515, 592);
      vertex(515, 594);
      vertex(511, 596);
      vertex(477, 596);
      vertex(477, 594);
      vertex(480, 588);
      endShape();
      stroke('black')
      noFill()
      beginShape();
      vertex(470, 439);
      vertex(470, 440);
      vertex(469, 443);
      vertex(467, 447);
      vertex(462, 449);
      vertex(462, 452);
      vertex(463, 453);
      vertex(468, 454);
      vertex(475, 453);
      endShape();
      noStroke()
      fill(135, 28, 59)
      beginShape();
      vertex(457, 456);
      vertex(461, 458);
      vertex(466, 459);
      vertex(471, 460);
      vertex(478, 459);
      vertex(483, 458);
      vertex(487, 455);
      vertex(483, 462);
      vertex(476, 466);
      vertex(468, 465);
      vertex(462, 463);
      vertex(456, 455);
      endShape();
      fill('SaddleBrown')
      beginShape();
      vertex(445, 431);
      vertex(449, 424);
      vertex(452, 422);
      vertex(459, 419);
      vertex(470, 416);
      vertex(482, 418);
      vertex(491, 422);
      vertex(496, 429);
      vertex(499, 431);
      vertex(501, 428);
      vertex(502, 425);
      vertex(501, 421);
      vertex(501, 416);
      vertex(499, 412);
      vertex(495, 411);
      vertex(489, 411);
      vertex(486, 409);
      vertex(483, 405);
      vertex(476, 403);
      vertex(472, 403);
      vertex(466, 405);
      vertex(464, 406);
      vertex(461, 405);
      vertex(452, 405);
      vertex(450, 408);
      vertex(448, 412);
      vertex(441, 413);
      vertex(437, 418);
      vertex(438, 425);
      vertex(439, 428);
      vertex(437, 432);
      vertex(442, 441);
      vertex(443, 435);
      vertex(446, 430);
      endShape();
    }
  }

  
  move() {
    this.y += this.velocity
    this.velocity += this.gravity
    if(this.y > this.groundY) {
      this.velocity=0
      this.y=this.groundY
    }
  }

  jump() {
    if (this.y >= this.groundY) {
      this.velocity = this.jumpVelocity
    }
  }
}
