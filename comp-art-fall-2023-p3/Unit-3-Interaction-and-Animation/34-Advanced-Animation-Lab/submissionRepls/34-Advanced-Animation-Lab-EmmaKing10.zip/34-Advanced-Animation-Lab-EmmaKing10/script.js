let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click
}

function draw() {




fill(https://replit.com/@comp-art-fall-2023-p3/33-Basic-Animation-Lab-EmmaKing10#script.j)
  drawMouseLines("black");
  drawButterfly();
}



function drawButterfly(){
  fill(250, 45, 45)
ellipse(197,318,50)
}

