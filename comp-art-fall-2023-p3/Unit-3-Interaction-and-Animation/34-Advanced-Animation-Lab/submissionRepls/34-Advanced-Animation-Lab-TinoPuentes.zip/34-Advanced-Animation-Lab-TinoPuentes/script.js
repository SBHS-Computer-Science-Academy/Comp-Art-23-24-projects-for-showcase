

function drawcircle() {
  fill("orange");
  square(100, 100, 100);
}

class Block {
  
  constructor(x, y, clr = "orange") {
   
    this.x = x
    this.y = y
    this.width = 100
    this.height = 100
    this.clr = clr
    this.jitter = 41
    this.speed = 15
    this.hide = false
  }

  show() {
    if (this.hide) return
    push();
    translate(this.x, this.y);
    translate(-100, -100);  
    fill(this.clr);
    circle(100, 100, this.width);

    pop();
  }

  
  move() {
    let jitter = this.jitter;
    this.x += random(-jitter, jitter);
    this.y += random(-jitter, jitter);

    this.checkForCollisions();
  }

  moveKeys() {
    if (keyIsDown(LEFT_ARROW)) this.x -= this.speed;
    if (keyIsDown(RIGHT_ARROW)) this.x += this.speed;
    if (keyIsDown(UP_ARROW)) this.y -= this.speed;
    if (keyIsDown(DOWN_ARROW)) this.y += this.speed;
  }

  checkForCollisions() {
    let hit = collideCircleCircle(redBlock.x, redBlock.y, redBlock.width, this.x, this.y, this.width);

    if (hit) {
       this.hide = true
      
    }
  }
}



let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);

  frameRate(60); 


  

  redBlock = new Block(100, 100);


  blockArray = [];
  for (let i = 0; i < 100; i ++) {
    let newBlock = new Block(random(300, width), random(height), "blue");
    blockArray.push(newBlock);
  }

}

function draw() {
  clear();
  background(0, 152, 255);
  text("Try to catch as many balls before they go off screen", 150, 693)
  
  


  redBlock.moveKeys();
  redBlock.show();

  for (block of blockArray) {
    block.move();
    block.show();
  }


  drawMouseLines("black");
}

