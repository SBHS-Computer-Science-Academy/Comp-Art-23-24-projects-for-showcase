let thresholdValue = 0;
let thresholdDelta = 0.003;

function preload() {
  batman = loadImage("batman.jpeg")
  batman = loadImage("batman.jpeg")
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
  batman.resize(500, 400)
  image(batman, 0, 0)
  let thresholdImage = getThreshold(batman);
  image(thresholdImage, 0, 0);

  
  let negative = getNegative(batman);
  image(negative, 500, 0)


  image(batman, 0, 400)
  image(batman, 500, 400)

  fill("black");
  //text("Make sure to use the preload function to load any images", 500, 400);

  drawMouseLines("black");
}
function getThreshold(pic) {
  let newPic = createImage(pic.width, pic.height);

  newPic.copy(pic, 0, 0, pic.width, pic.height, 0, 0, pic.width, pic.height);
  newPic.filter(THRESHOLD, thresholdValue);
  thresholdValue += thresholdDelta;
  if (thresholdValue >= 0.5) thresholdDelta *= -1;
  if (thresholdValue <= 0) thresholdDelta *= -1;


  return newPic;
}
function getNegative(pic) {
  //create a new image of the same size as pic.  all pixels will be black.
  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();

  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    newPic.pixels[i] = 255 - pic.pixels[i]; // red
    newPic.pixels[i + 1] = 255 - pic.pixels[i + 1]; // green
    newPic.pixels[i + 2] = 255 - pic.pixels[i + 2]; // blue
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }
  newPic.updatePixels();
  return newPic;
}