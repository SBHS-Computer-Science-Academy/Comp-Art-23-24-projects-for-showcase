function preload() {
  mayback=loadImage('mayback.avif')
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
  image(mayback,0,0)
  fill("black");
  text("Make sure to use the preload function to load any images", 500, 400);

  drawMouseLines("black");
}