function preload() {  
    guy = loadImage('guy.jpg');
   cloudy = loadImage('cloudy.jpg');
   dice = loadImage('dice.jpeg');
  soccer = loadImage('soccer.jpg');
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");

  cloudy.resize(400,400)
 soccer.resize(400,400)
  dice.resize(600,400)
  guy.resize(600,400)

  
  fill("black");
  text("Make sure to use the preload function to load any images", 500, 400);
  image(soccer, 0, 400);
  image(guy, 400,0)
  image(cloudy,0,0);
  image(dice,400,400)
dice.filter(GRAY);
soccer.filter(POSTERIZE, 6)
  cloudy.filter(POSTERIZE, 12)
guy.filter(GRAY)
  
  drawMouseLines("black");
}

