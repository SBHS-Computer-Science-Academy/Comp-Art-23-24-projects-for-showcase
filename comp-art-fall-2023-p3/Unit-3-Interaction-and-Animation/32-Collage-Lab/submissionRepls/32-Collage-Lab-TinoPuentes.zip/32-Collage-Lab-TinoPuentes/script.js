let thresholdValue = 0.003;
let thresholdDelta = 0.001;
function preload() {
logo=loadImage("logo.png")
Unknown=loadImage("Unknown.png")
rblogo=loadImage("rblogo.jpeg")
icon=loadImage("icon.png")
}
function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("darkgray");
  logo.resize(480, 420)

  fill("black");
  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  image(logo, 0, 0)
  tint(greenY, redX, blueUnlessPressed);
  image(Unknown, 370, 0)  
  tint(255, 255, 255); // reset tint
  Unknown.resize(730, 445)

  let thresholdImage = getThreshold(rblogo);
  image(thresholdImage, 475, 410);
  rblogo.resize(488, 420)
  image(icon, -128, 400)
  icon.resize(730, 445)
  if(frameCount%60==0)icon.filter(INVERT)
  

  drawMouseLines("black");
}
function getThreshold(pic) {
  let newPic = createImage(pic.width, pic.height);

  newPic.copy(pic, 0, 0, pic.width, pic.height, 0, 0, pic.width, pic.height);
  newPic.filter(THRESHOLD, thresholdValue);
  thresholdValue += thresholdDelta;
  if (thresholdValue >= 0.05) thresholdDelta *= -1;
  if (thresholdValue <= 0.003) thresholdDelta *= -1;


  return newPic;
}

















