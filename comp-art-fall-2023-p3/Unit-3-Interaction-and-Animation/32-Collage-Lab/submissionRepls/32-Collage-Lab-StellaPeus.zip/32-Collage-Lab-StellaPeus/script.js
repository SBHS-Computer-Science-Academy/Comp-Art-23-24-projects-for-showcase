let thresholdValue = 0.5;
let thresholdDelta = 0.003;
let animateTextFlag = true;
function preload() {
  mallorcasunset=loadImage("images/mallorcasunset.JPG")
  mallorcaocean=loadImage("images/mallorcaocean.JPG")
  mallorcabeach=loadImage("images/mallorcabeach.JPG")
  mallorcatanning=loadImage("images/mallorcatanning.JPG")
  meandkana=loadImage("images/meandkana.JPG")
  nclsleepover=loadImage("images/nclsleepover.JPG")
  orangesky=loadImage("images/orangesky.JPG")
  rafting=loadImage("images/rafting.JPG")
  rainysunset=loadImage("images/rainysunset.JPG")
  silhouette=loadImage("images/silhouette.JPG")
  wedding=loadImage("images/wedding.JPG")
  avajanebiking=loadImage("images/avajanebiking.JPG")
  beachvb=loadImage("images/beachvb.JPG")
  beck=loadImage("images/beck.JPG")
  biggroup=loadImage("images/biggroup.JPG")
  camptanning=loadImage("images/camptanning.JPG")
  carsunset=loadImage("images/carsunset.JPG")
  costumes=loadImage("images/costumes.JPG")
  lake=loadImage("images/lake.JPG")
  starfish=loadImage('images/starfish.jpeg')
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

;
 textAlign(CENTER, CENTER);
}

function draw() {
  drawCollage();
  clear();
  background("white");
  image(mallorcasunset, 0, 0)
  drawMouseLines("black");
  mallorcasunset.resize(0,200)
  drawCollage();
  mallorcaocean.resize(0,200)
  let thresholdImage = getThreshold(mallorcaocean);
  image(thresholdImage, 126,174);
  image(mallorcabeach, 140, 3)
  mallorcabeach.resize(0,200)
  image(mallorcatanning, 381, 5)
  mallorcatanning.resize(0,200)
  let negative = getNegative(meandkana);
  negative.resize(0,200); // maintain aspect ration with the 0
  image(negative, 520,7);
  meandkana.resize(0,200)
  image(nclsleepover, 0, 199)
  nclsleepover.resize(0, 200)
  image(orangesky, 275, 200)
  orangesky.resize(0,200)
  rafting.resize(350,400) // maintain aspect ratio with the 0
  rafting.filter(POSTERIZE, 8); //posterize image
  image(rafting, 422, 201);
  orangesky.resize(0,200)
  image(rainysunset, 0,399)
  rainysunset.resize(0,200)
  image(silhouette,150,372)
  silhouette.resize(0,200)
  wedding.filter(GRAY)
  wedding.resize(0,200); //maintain aspect ratio with the 0
  image(wedding, 259, 373);
  image(avajanebiking,522,480)
  avajanebiking.resize(0,200)
  beachvb.filter(GRAY)
  beachvb.resize(0,200); //maintain aspect ratio with the 0
  image(beachvb, 0, 598);
  image(beck,147,572)
  beck.resize(0,200)
  image(biggroup,295,573)
  biggroup.resize(0,200)
  image(camptanning,407,573)
  camptanning.resize(0,200)
  image(carsunset, 632,480)
  carsunset.resize(0,200)
  image(costumes,672,650)
  costumes.resize(0,200)
  image(lake,741,450)
  lake.resize(0,200)
}

function drawCollage() {
  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  image(mallorcasunset, 0, 0);
  tint(255, 255, 255); // reset tint
}
function getThreshold(pic) {
  let newPic = createImage(pic.width, pic.height);

  newPic.copy(pic, 0, 0, pic.width, pic.height, 0, 0, pic.width, pic.height);
  newPic.filter(THRESHOLD, thresholdValue);
  thresholdValue += thresholdDelta;
  if (thresholdValue >= 0.9) thresholdDelta *= -1;
  if (thresholdValue <= 0.2) thresholdDelta *= -1;


  return newPic;
}

function getNegative(pic) {
  //create a new image of the same size as pic.  all pixels will be black.
  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();

  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    newPic.pixels[i] = 255 - pic.pixels[i]; // red
    newPic.pixels[i + 1] = 255 - pic.pixels[i + 1]; // green
    newPic.pixels[i + 2] = 255 - pic.pixels[i + 2]; // blue
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }
  newPic.updatePixels();
  return newPic;
}
