let page = 0
let photo;
let photo1;
let photo2;
let city;
let va = 0
let p = 0
let quadval = 0
function preload() {
  photo = loadImage('images/cooli.jpg')
  photo1 = loadImage('images/cooli.jpg')
  photo2 = loadImage('images/cooli.jpg')
  city = loadImage('images/city.jpg')
      plane=loadImage('images/plane.jpeg')
left=loadImage('images/cooli.jpg')
}

function setup() {
  let myCanvas = createCanvas(1300, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  textAlign(CENTER, CENTER);
  photo1.resize(650, 360)
  photo2.resize(650, 400)
  city.resize(650, 400)
  photo2.blend(city, 0, 0, 650, 400, 0, 0, 650, 400, MULTIPLY)
  photo1.filter(BLUR, 3)
  
}
 
function draw() {
  
  clear();
  background("white");

  fill("black");

  drawMouseLines("black");
 
  image(photo2, 638, 0)
  tintthing()
  image(photo1, 640, 359)
  push()
  left.filter(POSTERIZE, 3)
  image(left, 0, 357)

  pop()


  fill(255)
  textSize(15)
  text("Press left and right arrows and move mouse", 300, 340)
}

function tintthing() {
  let redthing = map(mouseX, 0, width, 0, 255);
  let greenthing = map(mouseY, 0, height, 0, 255);
  let bluething = 255
  if (page == 1) {
    bluething = 0
  }
  tint(redthing, greenthing, bluething)

  image(photo, 0, 0)
  tint('white')
}

function keyPressed() {
  if (keyCode === LEFT_ARROW && page == 0) {
    page = 1

  }
  else if (keyCode === RIGHT_ARROW && page == 1) {
    page = 0
  }
  else if (keyCode === UP_ARROW && va == 0) {
    va = 1
  }
  else if (keyCode === DOWN_ARROW && va == 1) {
    va = 0
  }

  function sat() {
    colorMode(HSB, 255);

    const c = color(105, 219, 24)
    const satval = saturation(c)
    if (va == 1) {
      p = 1
    }
    else {
      p = 0
    }
  }



}