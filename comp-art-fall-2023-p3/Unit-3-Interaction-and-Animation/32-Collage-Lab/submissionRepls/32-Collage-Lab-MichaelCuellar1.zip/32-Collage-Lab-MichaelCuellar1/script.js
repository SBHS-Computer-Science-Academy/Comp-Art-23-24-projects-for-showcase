  function preload() {
  team=loadImage('team.jpg')
    solo=loadImage('solo.jpg')
    juke=createVideo('juke.mov')
    Bored=loadImage('Bored.jpg')
    onehand=loadImage('onehand.jpg')
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  juke.loop()
  juke.hideControls()
  juke.hide()
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
 background("white");
  solo.resize(325, 0)
  solo.filter(GRAY)
  image(solo,0,0)

  team.resize(325, 0)
  tint("gold")
image(team,325,0)

image(juke,0,400, 300, 200);
  drawMouseLines("black");

  Bored.resize(325, 0)
  
  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  image(Bored, 650, 0);
  tint(255, 255, 255); // reset tint
  
  onehand.resize(325, 0)
  onehand.filter(POSTERIZE, 6); //posterize image
  image(onehand,300, 435);
}