function preload() {
  snow=loadImage("snow.jpeg");
  spooky=loadImage("snow.jpeg")
  mountianLion=loadImage("snow.jpeg")
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
 // createConsole();
  snow.resize(500,400)
  mountianLion.resize(500,400)
 negative = getNegative(snow);
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
  if(mouseIsPressed) image(snow, 0, 0)
  else image(negative, 0, 0);
  fill("black");
  drawCollage()
  tintImage()
}

function drawCollage(){
  spooky.filter(POSTERIZE, 3) //posterize image
  image(spooky, 500, 400);

    mountianLion.filter(GRAY)
  image(mountianLion, 0, 400);
}

function getNegative(pic) {
  //create a new image of the same size as pic.  all pixels will be black.
  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();

  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    newPic.pixels[i] = 255 - pic.pixels[i]; // red
    newPic.pixels[i + 1] = 255 - pic.pixels[i + 1]; // green
    newPic.pixels[i + 2] = 255 - pic.pixels[i + 2]; // blue
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }
  newPic.updatePixels();
  return newPic;
}
function tintImage(){
let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
let blueUnlessPressed = 255;
if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
image(snow, 500, 0);
tint(255, 255, 255); // reset tint

}