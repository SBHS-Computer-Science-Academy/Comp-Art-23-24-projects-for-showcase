let thresholdValue = 0;
let thresholdDelta = 0.003;
function preload() {
  unknown2=loadImage("Unknown2.webp")
unknowncool=loadImage("Unknowncool.avif")
nighttime=loadImage("night time.jpeg")
cools=loadImage("cools.jpeg")
  

}

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
  unknowncool.resize(00,0)
  fill("black");
  //text("Make sure to use the preload function to load any images", 500, 400);
drawPIC()
  unknown2.resize(550,0)
  drawMouseLines("black");
  cools.resize(0,530)
   image(cools,200,0)
  let thresholdImage = getThreshold(cools);
    image(thresholdImage, 200 ,0);
  
  
  
 
  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  image(unknowncool, -326, 0);
  tint(0, greenY, blueUnlessPressed); // change tint based on mouse input
  image(unknown2, 0, 533);
  tint(redX, 0, blueUnlessPressed); // change tint based on mouse input
  image(nighttime, 508, 533);
  tint(255, 255, 255); // reset tint
   nighttime.resize(0,267)
  
  

}

function drawPIC() {
   noFill("black");
  beginShape();
  vertex(364, -4);
  vertex(378, 796);
  vertex(823, 797);
  vertex(828, 350);
  vertex(-7, 363);
  vertex(-4, 799);
  vertex(385, 795);
  endShape();
}
function getThreshold(pic) {
  let newPic = createImage(pic.width, pic.height);

  newPic.copy(pic, 0, 0, pic.width, pic.height, 0, 0, pic.width, pic.height);
  newPic.filter(THRESHOLD, thresholdValue);
  thresholdValue += thresholdDelta;
  if (thresholdValue >= 0.9) thresholdDelta *= -1;
  if (thresholdValue <= 0) thresholdDelta *= -1;

  return newPic;
}