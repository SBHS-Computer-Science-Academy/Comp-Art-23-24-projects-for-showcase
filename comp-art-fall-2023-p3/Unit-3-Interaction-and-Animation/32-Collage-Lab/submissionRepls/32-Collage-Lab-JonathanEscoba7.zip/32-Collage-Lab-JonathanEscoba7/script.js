function preload() {  
   food = loadImage('bg.avif');
  wave = loadImage('wave.jpg');
  dog1 = loadImage('whitedog.jpg');
  dog2 = loadImage('canelo.PNG');
 

}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("black");
  
  fill("black");
  text("Make sure to use the preload function to load any images", 500, 400);
  wave.filter(POSTERIZE, 8); 
  dog2.filter(GRAY);
  wave.filter(GRAY);
   food.resize(1000, 0) 
  wave.resize(900, 0) 
  dog2.resize(300, 0) 
  dog1.resize(300, 0)
  image(food, 0,0);
  image(wave, 0,400);
   image(dog1,0 ,0);
   image(dog2, 700,300);
  drawMouseLines("black");
}






