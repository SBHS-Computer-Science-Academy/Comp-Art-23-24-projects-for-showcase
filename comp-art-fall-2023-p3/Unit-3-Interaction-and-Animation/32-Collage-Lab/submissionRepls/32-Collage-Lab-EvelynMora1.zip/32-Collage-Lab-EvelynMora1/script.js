 function preload() {
  Yellow = loadImage("Yellow.jpg");
  Rainbow = loadImage("Rainbow.jpg")
  Orange = loadImage("Orange.jpg")
  Eastside = loadImage("Eastside.jpg")
}

function setup() {
  let myCanvas = createCanvas( 850, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
 Yellow.resize (500, 0)
  Yellow.filter(GRAY)
  image(Yellow, 500,0)
  

  Orange.resize (500, 0)
  image(Orange, 0, 0 )
  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
image(Orange, 0, 0);
  tint(255, 255, 255); // reset tint
  
  Rainbow.resize (500, 0)
  image(Rainbow, 0, 460 )
  let negative = getNegative(Rainbow);
  image(negative, 0, 460);


  Eastside.resize (400, 0)
  image(Eastside, 470, 390)
  Eastside.resize(360, 0) // maintain aspect ratio with the 0
  Eastside.filter(POSTERIZE, 8); //posterize image
  image(Eastside, 470, 390);

  
// fill("black");
  //text("Make sure to use the preload function to load any images", 500, 400);

  drawMouseLines("black");
 
}
function getNegative(pic) {
  //create a new image of the same size as pic.  all pixels will be black.
  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();

  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    newPic.pixels[i] = 255 - pic.pixels[i]; // red
    newPic.pixels[i + 1] = 255 - pic.pixels[i + 1]; // green
    newPic.pixels[i + 2] = 255 - pic.pixels[i + 2]; // blue
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }
  newPic.updatePixels();
  return newPic;
}