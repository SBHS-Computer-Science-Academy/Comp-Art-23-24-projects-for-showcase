function preload() {
  spincups = loadImage("spincups.jpeg");
  castle = loadImage("castle.jpeg");
  mainstreet = loadImage("mainstreet.jpeg");
  junglecruise = loadImage("junglecruise.webp");
  splashmountain = loadImage("splashmountain.jpeg");
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  castle.resize(0,400);

  spincups.resize(0,400);
  
  mainstreet.resize(500,400);
  junglecruise.resize(500,400);
  splashmountain.resize(500,400);
  textAlign(CENTER, CENTER);

  mainstreet.filter(POSTERIZE, 4);
}

function draw() {
  clear();
  background("white");

  
  tint('lightskyblue');
  image (spincups,0,0);
  tint('palegreen');
  image (junglecruise, 0,400);
  tint('white');
  image (mainstreet, 500,0);
   tint('pink');
  image (splashmountain, 500,400);
  drawCastle();

  function drawCastle() {
    let redX = map(mouseX,0,width,0,255);
    let greenY = map(mouseY,0,height,0,255);
    let blueUnlessPressed = 255;
    if (mouseIsPressed) blueUnlessPressed = 0;
    
    tint(redX,greenY,blueUnlessPressed);
    image (castle, 500-castle.width/2, 400-castle.height/2);
    tint(255,255,255);
  }
  
  
  fill("black");
  //text("Make sure to use the preload function to load any images", 500, 400);

  drawMouseLines("black");
}