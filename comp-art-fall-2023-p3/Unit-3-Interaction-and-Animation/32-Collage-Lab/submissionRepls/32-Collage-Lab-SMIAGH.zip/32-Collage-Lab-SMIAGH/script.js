let thresholdValue = 0;
let thresholdDelta = 0.003;


let animateTextFlag = true;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
  soccerball.resize(300,0)
  image(soccerball, 0, 0);


  
  drawMouseLines("black"); 
  drawProject()
}

function preload(){
  soccerball = loadImage("SoccerBall.webp");
  ronaldo = loadImage("Ronaldo.jpeg");
  team = loadImage("team.jpeg");
  Trophie = loadImage("Trophie.jpeg");
}


function drawProject(){
let redX = map(mouseX, 0, width, 0, 255); 
let greenY = map(mouseY, 0, height, 0, 255); 
let blueUnlessPressed = 255;
if (mouseIsPressed) blueUnlessPressed = 0; 
tint(redX, greenY, blueUnlessPressed); 
image(soccerball, 0, 0);
tint(255, 255, 255); 

  ronaldo.filter(GRAY)
  ronaldo.resize(380, 0); 
  image(ronaldo,304,293)

  team.resize(400,0)
  image(team,290,80)

  Trophie.resize(360, 0) 
  Trophie.filter(POSTERIZE, 8); 
  image(Trophie, 3, 290);

}  
