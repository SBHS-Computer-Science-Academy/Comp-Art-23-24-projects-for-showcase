let thresholdValue = 0;
let thresholdDelta = 0.003;

function preload() {
  plane = loadImage("images/plane.jpeg")
  italy = loadImage("images/italy.jpeg")
  football = loadImage("images/football.jpeg")
  baby = loadImage("images/baby.jpeg")

}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("Sienna");
  plane.resize(300, 0)
  italy.resize(350, 0)
  football.resize(400, 0)
  image(getSepia(football), 100, 429)
  baby.resize(0, 300)

  drawCollage()


  football.filter(GRAY)

  let thresholdImage = getThreshold(italy);
  image(thresholdImage, 589, 380);


  drawMouseLines("black");
}

function getThreshold(pic) {
  let newPic = createImage(pic.width, pic.height);

  newPic.copy(pic, 0, 0, pic.width, pic.height, 0, 0, pic.width, pic.height);
  newPic.filter(THRESHOLD, thresholdValue);
  thresholdValue += thresholdDelta;
  if (thresholdValue >= 0.9) thresholdDelta *= -1;
  if (thresholdValue <= 0) thresholdDelta *= -1;


  return newPic;
}
function drawCollage() {

  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  image(plane, 100, 0);
  tint(255, 255, 255); // reset tint

  let negative = getNegative(baby);

  image(negative, 550, 50)
}
function getNegative(pic) {

  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();

  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    newPic.pixels[i] = pic.pixels[i]; // red
    newPic.pixels[i + 1] = pic.pixels[i + 1]; // green
    newPic.pixels[i + 2] = 255 - pic.pixels[i + 2]; // blue
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }
  newPic.updatePixels();
  return newPic;
}
function mousePressed() {
  print(int(mouseX) + ", " + int(mouseY));
}

function getSepia(pic) {
  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();
  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    var r = pic.pixels[i + 0];
    var g = pic.pixels[i + 1];
    var b = pic.pixels[i + 2];

    //sepia
    var tr = r * .393 + g * .769 + b * .189;
    var tg = r * .349 + g * .686 + b * .168;
    var tb = r * .272 + g * .534 + b * .131;

    newPic.pixels[i + 0] = tr;
    newPic.pixels[i + 1] = tg;
    newPic.pixels[i + 2] = tb;
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }

  newPic.updatePixels();

  return newPic;
}