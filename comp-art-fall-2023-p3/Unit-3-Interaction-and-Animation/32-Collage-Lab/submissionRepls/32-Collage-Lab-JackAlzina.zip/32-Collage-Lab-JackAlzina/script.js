function preload() {
  jack = loadImage("jack.jpeg");
  family = loadImage("family.jpeg");
  mommy = loadImage("mommy.jpeg");
 kid = loadImage("kid.jpeg");
  sis = loadImage("sis.jpeg");
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();

  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("lightBlue");
  jack.resize(500, 0);
  image(jack, 0, 0)                                   
  family.resize(0, 500);
  image(family, 657, 160)
  mommy.resize(0, 400);
   image(mommy, 321, 126)
  kid.resize(0, 400);
   image(kid, 113, 485)
    drawCollage();
  sis.resize(0, 400);
   image(sis, 550, 485)
    
   sis.resize(0, 300);
   image(sis, 385, 524)
  fill("black");
 

  drawMouseLines("black");
}
function drawCollage() {

  let redX = map(mouseX, 0, width, 0, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  image(kid, 0, 0);
  tint(255, 255, 255); // reset tint
}