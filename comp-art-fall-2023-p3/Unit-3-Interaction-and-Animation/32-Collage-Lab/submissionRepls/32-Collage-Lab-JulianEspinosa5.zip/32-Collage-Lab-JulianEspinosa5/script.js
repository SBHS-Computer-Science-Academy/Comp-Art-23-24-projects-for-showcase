function preload() {
vina = loadFont('VinaSans-Regular.ttf');
  joker = loadImage('joker.jpeg');
}

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("white");
  
  joker.resize(400,400)

  image(joker, 0, 0)
  image(joker, 0, 400)
  image(joker,400,0)
  image(joker,400,400)
  drawCollage()
  fill("white");
  textSize(100)
  textFont(vina)
  text("JOKER", 400, 400);

  drawMouseLines("black");
}

function drawCollage() {

  let redX = map(mouseX, 0, width, 0, 255); // change red (0->400) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->400) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 400 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input
  if (mouseX < 400 && mouseY < 400) image(joker, 0, 0);
  else if (mouseX < 800 && mouseY < 400 ) image(joker, 400, 0);
  else if (mouseX < 400 && mouseY < 800 ) image(joker, 0, 400);
  else if (mouseX < 800 && mouseY < 800 ) image(joker, 400, 400);
  tint(255, 255, 255); // reset tint
  
}
