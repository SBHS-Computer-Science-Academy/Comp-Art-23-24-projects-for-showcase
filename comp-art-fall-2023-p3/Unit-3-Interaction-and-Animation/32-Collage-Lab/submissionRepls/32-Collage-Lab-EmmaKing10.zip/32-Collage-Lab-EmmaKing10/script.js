
function preload() {
  fam=loadImage("fam.jpg")
  bro=loadImage("bro.jpg")
  mom=loadImage("mom.jpg")
  stel=loadImage("stel.jpg")
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background(160,250,247);
  fam.resize(300,0)
  bro.resize(300,0)
  mom.resize(300,0)
  stel.resize(300,0)



  let redX = map(mouseX, 0, width, 127, 255); // change red (0->255) based on mouseX
  let greenY = map(mouseY, 0, height, 0, 255); // change green (0->255) based on mouseY
  let blueUnlessPressed = 255;
  if (mouseIsPressed) blueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, blueUnlessPressed); // change tint based on mouse input

  image(fam,0,0)
image(bro,300,0)
image(mom,0,235)
image(stel,301,327)
  tint(255, 255, 255)
 
}