let gorge, dustbowl, granary, viaduct;
let negativegorge, negativedustbowl, negativegranary, negativeviaduct;
let flipped = 0;

function preload() {
  gorge = loadImage("img/gorge.jpg");
  dustbowl = loadImage("img/dustbowl.jpg");
  // granary = loadImage("img/granary.jpg");
  // viaduct = loadImage("img/viaduct.jpg");
}

function setup() {
  createCanvas(1920, 1080);
  
  negativegorge = getNegative(gorge);
  negativedustbowl = getNegative(dustbowl);
  // negativegranary = getNegative(granary);
  // negativeviaduct = getNegative(viaduct);
}

function draw() {
  clear();
  background("black");

  tint(255, alphaMap(0));
  if (flipped == 0) {
    image(gorge, 0, 0);
    tint(255, alphaMap(1));
    image(negativegorge, 0, 0);
  }
  else {
    image(granary, 0, 0);
    tint(255, alphaMap(1));
    image(negativegranary, 0, 0);
  }
  tint(255, alphaMap(2));
  if (flipped == 0) {
    image(dustbowl, 0, 0);
    tint(255, alphaMap(3));
    image(negativedustbowl, 0, 0);
  }
  else {
    image(viaduct, 0, 0);
    tint(255, alphaMap(3));
    image(negativeviaduct, 0, 0);
  }
}

function alphaMap(focus = 0) {
  let alphaX = map(mouseX, 0, width, 255, 0); //change alpha based on mouseX
  let alphaY = map(mouseY, 0, height, 255, 0); //change alpha based on mouseY
  let alphaV
  
  if (focus == 0) alphaV = map(alphaX*alphaY, 0, 65025, 0, 255); //change alpha based on combination of alphas of x and y
  if (focus == 1) alphaV = map(alphaX*(255-alphaY), 0, 65025, 0, 255); //done from the bottom left as fully opaque, instead of top left
  if (focus == 2) alphaV = map((255-alphaX)*alphaY, 0, 65025, 0, 255); //top right
  if (focus == 3) alphaV = map((255-alphaX)*(255-alphaY), 0, 65025, 0, 255); //bottom right
  if (focus < 0 || focus > 3) print("start must be value 0-3");
  return(alphaV);
}

function mousePressed() {
  flipped ^= 1;
}

function getNegative(pic) {
  //create a new image of the same size as pic.  all pixels will be black.
  let newPic = createImage(pic.width, pic.height);

  pic.loadPixels();
  newPic.loadPixels();

  for (let i = 0; i < newPic.width * newPic.height * 4; i += 4) {
    newPic.pixels[i] = 255 - pic.pixels[i]; // red
    newPic.pixels[i + 1] = 255 - pic.pixels[i + 1]; // green
    newPic.pixels[i + 2] = 255 - pic.pixels[i + 2]; // blue
    newPic.pixels[i + 3] = pic.pixels[i + 3]; // alpha
  }
  newPic.updatePixels();
  return newPic;
}