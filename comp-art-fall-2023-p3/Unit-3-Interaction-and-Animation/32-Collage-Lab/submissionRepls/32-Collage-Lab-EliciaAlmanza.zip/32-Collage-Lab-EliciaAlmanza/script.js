function preload() {
  Special=loadImage("Special.jpeg");
  Park=loadImage("Park.jpeg");
  Smile=loadImage("Smile.jpeg");
  Pup=loadImage("Pup.jpg");
  heart=loadImage("heart.png");
}

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  Pup.filter(POSTERIZE,5)
  textAlign(CENTER, CENTER);
}

function draw() {
  clear();
  background("skyblue");
 



  // pink=: 255, 192, 203
  //magenta = 255, 0, 255
  // skyblue = 135, 206, 235
  
  let redX = map(mouseX, 0, width, 255, 135); 
  let greenY = map(mouseY, 0, height, 200, 0); // change Pink (0->255) based on mouseY
  let SkyblueUnlessPressed = 255;
  if (mouseIsPressed) SkyblueUnlessPressed = 0; // make blue be 255 if mouse isn't pressed, 0 if it is
  tint(redX, greenY, SkyblueUnlessPressed); // change tint based on mouse input

  Smile.resize(250,445)
  image(Smile,750,0)
  
  Special.resize(250,0)
  image(Special,0,0)
  
  
  tint('white')

 
  
  Park.resize(250,445)
  heart.resize(Park.width, Park.height);
  Park.blend(heart, 0, 0, heart.width, heart.height, 0, 0, Park.width, Park.height, ADD);
  
  image(Park,500,0)

  


  Pup.resize(250,445)
  image(Pup,250,0)
  
  fill("black");

  let str = ["GHOSTY"];
  writeText(str);

  drawMouseLines("black");
  updateLetters(str);




}




let animateTextFlag = true;
let fadeVal = 0;
let idx = 0;
let row = 0;
let textX = 300;


function coverText() {
  fill("black")
  rect(545, 0, 45, 380);
}

function writeText(str) {
  textSize(42);
  fill("white")
  for (let i = 0; i < idx; i++) {
    text(str[row][i], textX+80*i, 650)
  }

  fill(255, fadeVal)
  text(str[row][idx], textX+80*idx, 650)

}

function updateLetters(str) {

  if (animateTextFlag == true) fadeVal += 4;

  if (fadeVal > 255) {
    fadeVal = 0;
    idx++;
    if (idx >= str[row].length) {
      idx = 0;
      row++;
      if (row >= str.length) row = 0;
      setTimeout(restart, 1000); // wait 1000 milliseconds, then restart
      animateTextFlag = false;
    }
  }
}

function restart() {
  animateTextFlag = true;
}