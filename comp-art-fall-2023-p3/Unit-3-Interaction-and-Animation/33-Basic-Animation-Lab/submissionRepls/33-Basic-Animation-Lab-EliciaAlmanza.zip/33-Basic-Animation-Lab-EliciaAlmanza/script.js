let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click
}

function draw() {
  clear();
  background("white");

  animateText();

  drawMouseLines("black");
}

function animateText() {

  drawText(textX, 400);
  
  textX -= 2; // decrement
  if (textX < -250) textX = width + 250; // reset when off the screen on the left
}

function drawText(x, y) {

  translate(x, y); 
  
  fill("black");
  text("The trick to animation is using translates and global variables that you increment", 0, 0);

  resetMatrix();
}