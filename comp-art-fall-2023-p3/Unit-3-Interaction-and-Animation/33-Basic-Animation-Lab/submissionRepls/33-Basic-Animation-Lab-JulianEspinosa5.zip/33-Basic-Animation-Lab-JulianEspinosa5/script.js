let textX = 500;

function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole();
  
  textAlign(CENTER, CENTER);

  frameRate(60); // prevent a p5.js bug that changes the framerate when you click
}

function draw() {
  clear();
  background("lightblue");

  animateText();

  


  drawOcenfloor()

   drawMouseLines("black");
}

function animateText() {

  drawText(textX, 400);
  
  textX -= 2; // decrement
  if (textX < -250) textX = width + 250; // reset when off the screen on the left
}

function drawText(x, y) {

  translate(x, y); 
  
  fill("black");
  text("The trick to animation is using translates and global variables that you increment", 0, 0);

  resetMatrix();
}




function drawOcenfloor() {
   fill("tan");
  beginShape();
  curveVertex(0, 709); // control point
  curveVertex(0, 709);
  curveVertex(113, 667);
  curveVertex(371, 696);
  curveVertex(572, 631);
  curveVertex(797, 701);
  curveVertex(969, 669);
  curveVertex(968, 800);
  curveVertex(0, 800);
  curveVertex(0, 708);
  curveVertex(0, 708); // control point
  endShape();
  fill("green");
  beginShape();
  vertex(71, 730);
  vertex(94, 551);
  vertex(99, 712);
  vertex(122, 622);
  vertex(116, 693);
  vertex(189, 627);
  vertex(113, 738);
  vertex(215, 720);
  vertex(93, 758);
  vertex(48, 761);
  vertex(21, 620);
  vertex(41, 671);
  vertex(51, 588);
  vertex(63, 651);
  vertex(71, 621);
  vertex(71, 731);
  endShape();
  beginShape();
  vertex(438, 737);
  vertex(362, 674);
  vertex(412, 696);
  vertex(400, 639);
  vertex(432, 694);
  vertex(452, 560);
  vertex(455, 702);
  vertex(575, 657);
  vertex(499, 708);
  vertex(591, 719);
  vertex(470, 739);
  vertex(437, 737);
  endShape();
  fill("orange");
  beginShape();
  vertex(186, 696);
  vertex(190, 693);
  vertex(190, 703);
  vertex(186, 701);
  vertex(175, 705);
  vertex(166, 702);
  vertex(168, 697);
  vertex(175, 693);
  vertex(185, 697);
  endShape();
  fill("black");
  beginShape();
  vertex(667, 603);
  vertex(672, 594);
  vertex(690, 593);
  vertex(702, 604);
  vertex(693, 624);
  vertex(662, 622);
  vertex(667, 603);
  endShape();
  fill("white");
  beginShape();
  vertex(670, 603);
  vertex(688, 602);
  vertex(689, 610);
  vertex(671, 611);
  vertex(673, 602);
  endShape();
  fill("yellow");
  beginShape();
  vertex(703, 604);
  vertex(711, 590);
  vertex(788, 589);
  vertex(795, 603);
  vertex(703, 604);
  endShape();
  beginShape();
  vertex(869, 596);
  vertex(877, 609);
  vertex(877, 626);
  vertex(883, 618);
  vertex(887, 617);
  vertex(893, 627);
  vertex(885, 592);
  vertex(868, 595);
  endShape();
  beginShape();
  vertex(887, 641);
  vertex(883, 661);
  vertex(891, 656);
  vertex(895, 656);
  vertex(900, 663);
  vertex(898, 632);
  vertex(883, 633);
  vertex(887, 641);
  endShape();
  fill("black");
  beginShape();
  vertex(693, 625);
  vertex(709, 651);
  vertex(668, 658);
  vertex(659, 653);
  vertex(663, 660);
  vertex(651, 659);
  vertex(661, 663);
  vertex(652, 664);
  vertex(662, 666);
  vertex(652, 668);
  vertex(663, 669);
  vertex(656, 672);
  vertex(672, 666);
  vertex(720, 659);
  vertex(707, 624);
  vertex(766, 625);
  vertex(816, 639);
  vertex(831, 656);
  vertex(887, 640);
  vertex(884, 633);
  vertex(839, 638);
  vertex(809, 615);
  vertex(839, 617);
  vertex(877, 608);
  vertex(869, 595);
  vertex(793, 603);
  vertex(703, 604);
  vertex(693, 624);
  endShape();
  beginShape();
  vertex(687, 625);
  vertex(597, 635);
  vertex(590, 637);
  vertex(600, 638);
  vertex(590, 641);
  vertex(601, 640);
  vertex(597, 646);
  vertex(604, 641);
  vertex(602, 649);
  vertex(608, 639);
  vertex(662, 637);
  vertex(697, 629);
  vertex(692, 625);
  vertex(685, 625);
  endShape();
}


