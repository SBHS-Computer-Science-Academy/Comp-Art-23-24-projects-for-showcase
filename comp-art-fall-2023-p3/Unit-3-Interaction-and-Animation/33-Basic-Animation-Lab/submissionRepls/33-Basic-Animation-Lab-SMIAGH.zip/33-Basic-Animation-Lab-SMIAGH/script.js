let carX1 = 50;
let carX2 = 250;
let carSpeed1 = 2;
let carSpeed2 = -3;

function setup() {
  createCanvas(400, 200);
}

function draw() {
  background(220);
drawRoad()
  drawRect()

  drawBuilding()
  // First car
  fill('blue');
  rect(carX1, 100, 50, 20);

  // Second car
  fill('red');
  rect(carX2, 150, 50, 20);

  // Move first car back and forth
  carX1 += carSpeed1;
  if (carX1 > width || carX1 < 0) {
    carSpeed1 *= -1;
  }

  // Move second car back and forth
  carX2 += carSpeed2;
  if (carX2 > width || carX2 < 0) {
    carSpeed2 *= -1;
  }
}

function drawRoad(){
  fill('black')
  rect(0,80,400,200);
}

function drawRect(){
  fill('yellow')
  rect(30,130,50,10);
  rect(130,130,50,10);
  rect(230,130,50,10);
}

function drawBuilding(){
  fill('grey')
  rect(30,20,55,55);
fill('#adb7c7')
rect(110,20,100,55);
fill('#35373b')
  rect(250,10,55,70);
}
