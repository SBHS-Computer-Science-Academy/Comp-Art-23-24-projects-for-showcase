function drawPage2() {
	fill("black");
  textSize(14)
	text("Once upon a time, there was once an orange ball lying down on the asphalt peacefuly, moments later someone approached the orange ball", 0, 5, 550);
  text("The person who came kicked the ball with a lot of force", 784, 190)
  text("The orange ball flew into the sky", 175, 345)
  text("The orange ball was going very fast, it was going so fast that it went to space", 749, 463)
  text("The orange ball started to orbit the earth until...", 658, 558  )
  drawline1()
  drawline2()
  drawline3()
  drawasphalt()
  drawline4()
  drawasphalt2()
  drawline5()
  drawasphalt3()
  drawline6()
  drawline7()
  fill('orange')
  ellipse(243, 194, 79, 76) 
  drawshadow2()
  drawsomerandompersonsleg()
  drawsomerandompersonsshoe()
  text("The person who came kicked the ball", 538, 868, 250)
  fill('orange')
  ellipse(822, 69, 79, 76) 
  drawshadow3()
  fill('orange')
  ellipse(281, 316, 79, 76)
  drawshadow4()
  fill('orange')
  ellipse(828, 338, 79, 76)
  drawfire()
  drawearth()
  drawspace()
  drawsouthamerica()
  fill('orange')
  ellipse(361, 611, 79, 76)
  drawspaceagain()
  fill('Blue')
  ellipse(709, 671, 79, 76)
  fill('Orange')
  ellipse(755, 663, 25, 21)
  drawtheamericas()
  
  
  
  
  
 
  
}  

function drawline1() {
  // fill("black");
  beginShape();
  vertex(0, -1);
  vertex(0, 275);
  endShape();
}
function drawline2() {
  // fill("black");
  beginShape();
  vertex(0, 276);
  vertex(549, 276);
  endShape();
}
function drawline3() {
  // fill("black");
  beginShape();
  vertex(549, 277);
  vertex(547, -2);
  endShape();
}
function drawasphalt() {
  fill("gray");
  beginShape();
  vertex(1, 221);
  vertex(549, 221);
  vertex(549, 276);
  vertex(-1, 276);
  vertex(0, 220);
  endShape();
}
function drawline4() {
  // fill("black");
  beginShape();
  vertex(549, 274);
  vertex(997, 313);
  vertex(1001, 313);
  endShape();
}
function drawasphalt2() {
  // fill("black");
  beginShape();
  vertex(549, 215);
  vertex(1012, 216);
  vertex(1001, 310);
  vertex(999, 314);
  vertex(997, 313);
  vertex(548, 274);
  vertex(549, 265);
  vertex(549, 215);
  endShape();
}
function drawline5() {
  fill("dodgerblue");
  beginShape();
  vertex(494, 276);
  vertex(492, 557);
  vertex(-2, 562);
  endShape();
}
function drawasphalt3() {
  fill("gray");
  beginShape();
  vertex(-1, 496);
  vertex(493, 487);
  vertex(492, 558);
  vertex(-1, 562);
  vertex(0, 495);
  endShape();
}
function drawline6() {
  // fill("black");
  beginShape();
  vertex(493, 556);
  vertex(1002, 559);
  endShape();
}
function drawline7() {
  // fill("black");
  beginShape();
  vertex(492, 558);
  vertex(485, 800);
  endShape();
}
function drawshadow2() {
  fill(71, 71, 71);
  beginShape();
  vertex(244, 231);
  vertex(246, 238);
  vertex(250, 249);
  vertex(256, 254);
  vertex(281, 270);
  vertex(294, 269);
  vertex(310, 266);
  vertex(315, 256);
  vertex(312, 242);
  vertex(306, 231);
  vertex(287, 223);
  vertex(270, 221);
  vertex(266, 226);
  vertex(254, 230);
  vertex(244, 232);
  endShape();
}
function drawsomerandompersonsleg() {
  fill("Darkblue");
  beginShape();
  vertex(581, -2);
  vertex(702, 122);
  vertex(655, 149);
  vertex(546, 41);
  vertex(547, -1);
  vertex(585, 1);
  endShape();
}
function drawsomerandompersonsshoe() {
  fill("black");
  beginShape();
  vertex(702, 120);
  vertex(727, 112);
  vertex(745, 116);
  vertex(752, 124);
  vertex(749, 138);
  vertex(686, 177);
  vertex(655, 149);
  vertex(702, 123);
  vertex(701, 120);
  endShape();
}
function drawshadow3() {
  fill(71, 71, 71);
  beginShape();
  vertex(856, 225);
  vertex(837, 219);
  vertex(811, 220);
  vertex(792, 225);
  vertex(785, 230);
  vertex(783, 236);
  vertex(783, 243);
  vertex(788, 247);
  vertex(803, 249);
  vertex(820, 249);
  vertex(837, 249);
  vertex(853, 245);
  vertex(862, 241);
  vertex(865, 229);
  vertex(855, 225);
  endShape();
}
function drawshadow4() {
  fill(71, 71, 71);
  beginShape();
  vertex(311, 509);
  vertex(282, 502);
  vertex(264, 503);
  vertex(252, 505);
  vertex(242, 510);
  vertex(233, 515);
  vertex(230, 519);
  vertex(232, 524);
  vertex(238, 530);
  vertex(248, 536);
  vertex(260, 537);
  vertex(275, 537);
  vertex(288, 536);
  vertex(298, 536);
  vertex(307, 531);
  vertex(315, 522);
  vertex(314, 513);
  vertex(312, 510);
  vertex(310, 510);
  endShape();
}
function drawfire() {
  fill("gold");
  beginShape();
  vertex(790, 346);
  vertex(761, 371);
  vertex(775, 374);
  vertex(742, 404);
  vertex(770, 402);
  vertex(721, 443);
  vertex(781, 417);
  vertex(777, 433);
  vertex(800, 408);
  vertex(805, 417);
  vertex(831, 376);
  vertex(817, 375);
  vertex(803, 369);
  vertex(790, 348);
  endShape();
}

function drawearth() {
  fill("blue");
  beginShape();
  vertex(-1, 618);
  vertex(21, 612);
  vertex(67, 609);
  vertex(110, 613);
  vertex(161, 633);
  vertex(196, 655);
  vertex(218, 686);
  vertex(238, 721);
  vertex(244, 755);
  vertex(234, 791);
  vertex(226, 799);
  vertex(0, 798);
  vertex(0, 616);
  endShape();
}

function drawspace() {
 fill("black");
  beginShape();
  vertex(1, 562);
  vertex(495, 558);
  vertex(492, 559);
  vertex(485, 799);
  vertex(225, 799);
  vertex(235, 792);
  vertex(245, 753);
  vertex(238, 720);
  vertex(213, 679);
  vertex(197, 655);
  vertex(158, 629);
  vertex(106, 610);
  vertex(62, 607);
  vertex(17, 611);
  vertex(-1, 618);
  vertex(0, 560);
  endShape();
}
function drawsouthamerica() {
  fill("green");
  beginShape();
  vertex(14, 695);
  vertex(42, 689);
  vertex(68, 684);
  vertex(88, 697);
  vertex(110, 707);
  vertex(131, 710);
  vertex(182, 747);
  vertex(204, 784);
  vertex(222, 791);
  vertex(193, 789);
  vertex(165, 779);
  vertex(138, 774);
  vertex(109, 774);
  vertex(79, 774);
  vertex(66, 768);
  vertex(40, 745);
  vertex(25, 731);
  vertex(9, 712);
  vertex(1, 709);
  vertex(3, 690);
  vertex(16, 696);
  endShape();
}

function drawspaceagain() {
 fill("black");
  beginShape();
  vertex(493, 588);
  vertex(1004, 591);
  vertex(999, 800);
  vertex(483, 799);
  vertex(490, 587);
  vertex(493, 588);
  endShape();
}
function drawtheamericas() {
fill("green");
  beginShape();
  vertex(673, 657);
  vertex(681, 652);
  vertex(683, 651);
  vertex(684, 656);
  vertex(694, 655);
  vertex(697, 658);
  vertex(699, 662);
  vertex(693, 668);
  vertex(688, 666);
  vertex(691, 671);
  vertex(694, 673);
  vertex(687, 676);
  vertex(689, 679);
  vertex(697, 683);
  vertex(709, 682);
  vertex(712, 679);
  vertex(720, 677);
  vertex(725, 680);
  vertex(728, 684);
  vertex(733, 690);
  vertex(736, 693);
  vertex(740, 697);
  vertex(730, 697);
  vertex(719, 697);
  vertex(710, 696);
  vertex(699, 694);
  vertex(693, 687);
  vertex(690, 685);
  vertex(681, 680);
  vertex(674, 680);
  vertex(671, 677);
  vertex(669, 669);
  vertex(673, 658);
  vertex(675, 657);
  endShape();
}












































































