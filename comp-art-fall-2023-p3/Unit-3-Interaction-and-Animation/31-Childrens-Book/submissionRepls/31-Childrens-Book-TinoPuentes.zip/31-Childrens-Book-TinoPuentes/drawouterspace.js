function drawouterspace() {
    // fill("black");
    beginShape();
    vertex(1, 29);
    vertex(333, 25);
    vertex(328, 247);
    vertex(-3, 249);
    vertex(1, 29);
    endShape();
}
