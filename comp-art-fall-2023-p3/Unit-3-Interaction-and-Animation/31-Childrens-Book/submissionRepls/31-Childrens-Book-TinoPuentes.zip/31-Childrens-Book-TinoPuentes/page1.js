function drawPage1() {
  drawrect()
  textSize(50)
	fill("white");
	text("The Orange Ball", 0, height / 19, width);
 drawground()
 drawshadow()
  
  

}


function drawground() {
  fill(114, 171, 70);
  beginShape();
  vertex(-3, 557);
  vertex(1000, 566);
  vertex(1000, 799);
  vertex(-1, 799);
  vertex(0, 555);
  endShape();
  fill(255, 146, 0)
  ellipse(480, 539, 200, 200)
}
function drawshadow() {
  fill(73, 82, 49);
  beginShape();
  vertex(571, 580);
  vertex(612, 574);
  vertex(686, 575);
  vertex(724, 580);
  vertex(740, 594);
  vertex(749, 603);
  vertex(750, 613);
  vertex(747, 623);
  vertex(737, 632);
  vertex(721, 640);
  vertex(668, 645);
  vertex(594, 637);
  vertex(542, 617);
  vertex(565, 594);
  vertex(572, 580);
  endShape();
}
function drawrect() {
  fill(255, 161, 0);
  beginShape();
  vertex(155, 115);
  vertex(155, 30);
  vertex(851, 27);
  vertex(851, 125);
  vertex(155, 128);
  vertex(155, 116);
  endShape();
}













































