/* 
To change the starting page, change the page variable below.

To add new pages:

1. Change numPages to be total # of pages
2. Add a line per page to function draw() below
3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

let page = 1;
let numPages = 5; 


function preload() {
myfont=loadFont("Oxygen-Bold.ttf")
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
 textFont(myfont)
  // printToConsole("Use arrow or number keys to change pages.");
  // printToConsole("");
  
  createConsole("lines");

	
	textAlign(CENTER, TOP); 
  

}

function draw() {
	background("dodgerblue");


	if (page == 1) drawPage1();
	if (page == 2) drawPage2();
	if (page == 3) drawPage3();

  drawMouseLines("black");
}
function drawground() {
  fill("darkolivegreen");
  beginShape();
  vertex(-3, 557);
  vertex(1000, 566);
  vertex(1000, 799);
  vertex(-1, 799);
  vertex(0, 555);
  endShape();
  fill(255, 146, 0)
  ellipse(480, 539, 200, 200)
}
function drawshadow() {
  fill("black");
  beginShape();
  vertex(571, 580);
  vertex(612, 574);
  vertex(686, 575);
  vertex(724, 580);
  vertex(740, 594);
  vertex(749, 603);
  vertex(750, 613);
  vertex(747, 623);
  vertex(737, 632);
  vertex(721, 640);
  vertex(668, 645);
  vertex(594, 637);
  vertex(542, 617);
  vertex(565, 594);
  vertex(572, 580);
  endShape();
}
function keyPressed() {

if (key == "ArrowRight" && page<numPages) page += 1
if (key == "ArrowLeft" && page>1) page -= 1
  }
function keyReleased() {
  text("testing", 500, 200);
}