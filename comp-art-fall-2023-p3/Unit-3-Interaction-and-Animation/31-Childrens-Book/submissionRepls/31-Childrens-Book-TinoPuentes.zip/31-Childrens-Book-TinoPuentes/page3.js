function drawPage3() {
	fill("black");
  text("The orange ball got a little too close to earth and the gravity started to make the ball come down", 345, 263)
  text("the ball was falling very fast", 502, 2)
  text("The ball eventually hit the ground with a lot of force", 226, 522)
  text("the orange ball landed and joined the blue ball", 808, 600,)
drawouterspace()
  fill('orange')
ellipse(184, 23, 79, 76)
  drawplanetearth()
  drawamerica()
  drawouterspaceoncemore()
  fill('orange')
  ellipse(592, 144, 79, 76)
  drawfireagain()
  drawblackbox()
  drawbluebox()
  fill('orange')
  ellipse(252, 390, 79, 76)
  drawfireoncemore()
  drawlighterbluebox()
  fill('orange')
  ellipse(783, 400, 79, 76)
  drawsomemorefire()
  drawimagedivider()
  drawsecondimagedivider()
  drawgrounddd()
  drawmushroomcloud()
  fill('orange')
  ellipse(465, 563, 79, 76)
  drawasphalt4()
  fill("orange")
  ellipse(785, 723, 76, 76)
  fill("blue")
  ellipse(868, 723, 77, 76)
  
}
function drawouterspace() {
  // fill("black");
  beginShape();
  vertex(0, 2);
  vertex(0, 248);
  vertex(407, 260);
  vertex(401, -3);
  vertex(-3, -1);
  endShape();
}
function drawplanetearth() {
  fill("blue");
  beginShape();
  vertex(0, 245);
  vertex(33, 212);
  vertex(88, 181);
  vertex(157, 165);
  vertex(233, 163);
  vertex(311, 167);
  vertex(383, 192);
  vertex(407, 206);
  vertex(406, 259);
  vertex(0, 245);
  vertex(1, 209);
  endShape();
}
function drawamerica() {
  fill("green");
  beginShape();
  vertex(43, 209);
  vertex(69, 223);
  vertex(79, 233);
  vertex(91, 235);
  vertex(116, 239);
  vertex(100, 230);
  vertex(82, 219);
  vertex(69, 201);
  vertex(78, 202);
  vertex(104, 212);
  vertex(119, 224);
  vertex(140, 237);
  vertex(160, 246);
  vertex(175, 251);
  vertex(285, 255);
  vertex(237, 224);
  vertex(239, 218);
  vertex(243, 207);
  vertex(252, 201);
  vertex(265, 205);
  vertex(276, 193);
  vertex(289, 183);
  vertex(302, 189);
  vertex(310, 198);
  vertex(321, 205);
  vertex(328, 193);
  vertex(321, 178);
  vertex(323, 174);
  vertex(326, 172);
  vertex(287, 167);
  vertex(237, 164);
  vertex(189, 165);
  vertex(157, 167);
  vertex(104, 177);
  vertex(67, 193);
  vertex(45, 208);
  endShape();
}
function drawouterspaceoncemore() {
  fill("black");
  beginShape();
  vertex(401, 26);
  vertex(827, 28);
  vertex(826, 260);
  vertex(406, 261);
  vertex(403, 25);
  endShape();
}

function drawfireagain() {
  fill("gold");
  beginShape();
  vertex(560, 123);
  vertex(538, 90);
  vertex(551, 96);
  vertex(544, 76);
  vertex(560, 87);
  vertex(567, 56);
  vertex(580, 77);
  vertex(589, 63);
  vertex(593, 86);
  vertex(608, 75);
  vertex(606, 110);
  vertex(593, 106);
  vertex(579, 108);
  vertex(569, 113);
  vertex(558, 124);
  endShape();
}
function drawblackbox() {
  fill("black");
  beginShape();
  vertex(828, 28);
  vertex(1006, 29);
  vertex(1000, 263);
  vertex(821, 259);
  vertex(827, 29);
  vertex(1011, 29);
  vertex(999, 263);
  endShape();
}
function drawbluebox() {
  fill(20, 93, 196);
  beginShape();
  vertex(-1, 288);
  vertex(629, 283);
  vertex(634, 419);
  vertex(633, 518);
  vertex(-2, 514);
  vertex(0, 288);
  vertex(-1, 512);
  endShape();
}
function drawfireoncemore() {
  fill("Gold");
  beginShape();
  vertex(263, 348);
  vertex(332, 311);
  vertex(314, 329);
  vertex(403, 298);
  vertex(391, 312);
  vertex(484, 287);
  vertex(447, 310);
  vertex(506, 315);
  vertex(428, 343);
  vertex(504, 352);
  vertex(417, 362);
  vertex(473, 375);
  vertex(387, 377);
  vertex(430, 405);
  vertex(334, 397);
  vertex(370, 416);
  vertex(281, 412);
  vertex(292, 399);
  vertex(291, 381);
  vertex(277, 359);
  vertex(256, 351);
  vertex(267, 348);
  endShape();
}
function drawlighterbluebox() {
  fill(46, 118, 219);
  beginShape();
  vertex(629, 281);
  vertex(629, 259);
  vertex(1002, 263);
  vertex(1001, 526);
  vertex(632, 519);
  vertex(635, 419);
  vertex(628, 259);
  vertex(697, 260);
  vertex(887, 262);
  vertex(1001, 261);
  vertex(1000, 525);
  endShape();
}
function drawsomemorefire() {
  fill('gold');
  beginShape();
  vertex(764, 361);
  vertex(770, 327);
  vertex(778, 338);
  vertex(797, 300);
  vertex(801, 322);
  vertex(821, 288);
  vertex(827, 321);
  vertex(857, 308);
  vertex(842, 338);
  vertex(869, 332);
  vertex(837, 361);
  vertex(864, 359);
  vertex(823, 400);
  vertex(820, 386);
  vertex(812, 372);
  vertex(789, 360);
  vertex(770, 364);
  vertex(761, 369);
  vertex(764, 359);
  endShape();
}
function drawimagedivider() {
  // fill("black");
  beginShape();
  vertex(359, 515);
  vertex(362, 800);
  endShape();
}

function drawsecondimagedivider() {
  // fill("black");
  beginShape();
  vertex(679, 519);
  vertex(682, 800);
  endShape();
}
function drawgrounddd() {
  fill("darkgray");
  beginShape();
  vertex(1, 744);
  vertex(362, 751);
  vertex(362, 798);
  vertex(-2, 799);
  vertex(-1, 743);
  endShape();
}
function drawmushroomcloud() {
  fill("lightgray");
  beginShape();
  vertex(110, 667);
  vertex(94, 666);
  vertex(62, 677);
  vertex(57, 686);
  vertex(75, 700);
  vertex(103, 702);
  vertex(127, 698);
  vertex(127, 708);
  vertex(123, 715);
  vertex(98, 734);
  vertex(80, 742);
  vertex(61, 757);
  vertex(109, 774);
  vertex(169, 778);
  vertex(211, 778);
  vertex(247, 770);
  vertex(276, 763);
  vertex(266, 756);
  vertex(249, 751);
  vertex(226, 741);
  vertex(222, 717);
  vertex(219, 704);
  vertex(222, 702);
  vertex(251, 701);
  vertex(288, 693);
  vertex(290, 683);
  vertex(279, 675);
  vertex(255, 667);
  vertex(231, 661);
  vertex(215, 661);
  vertex(229, 657);
  vertex(252, 660);
  vertex(272, 655);
  vertex(300, 634);
  vertex(282, 571);
  vertex(207, 540);
  vertex(156, 536);
  vertex(131, 543);
  vertex(104, 557);
  vertex(86, 570);
  vertex(62, 595);
  vertex(58, 618);
  vertex(66, 634);
  vertex(78, 645);
  vertex(91, 653);
  vertex(98, 661);
  vertex(124, 669);
  vertex(140, 670);
  vertex(86, 677);
  vertex(145, 685);
  vertex(233, 683);
  vertex(242, 678);
  vertex(207, 671);
  vertex(196, 668);
  vertex(218, 663);
  endShape();
}
function drawasphalt4() {
fill("darkgray");
  beginShape();
  vertex(681, 751);
  vertex(1001, 748);
  vertex(1000, 798);
  vertex(683, 800);
  vertex(682, 752);
  endShape();
}

























    
  





















































