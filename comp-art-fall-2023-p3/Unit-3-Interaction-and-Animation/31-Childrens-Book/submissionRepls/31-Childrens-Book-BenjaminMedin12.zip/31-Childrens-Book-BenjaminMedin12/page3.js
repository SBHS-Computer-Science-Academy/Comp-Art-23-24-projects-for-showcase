function drawPage3() {
  background("skyblue")
  fill("black");
  text("one day the tree was caught in a wild fire", 0, 300, 300);
  drawGround();
  drawFence();
  drawTree();
  drawLeaves();
  drawFire();

}
function drawGround() {
  fill("green")
  rect(0, 600, 1000, 200);
}
function drawFence() {
  fill("#CD853F");
  beginShape();
  vertex(0, 489);
  vertex(999, 496);
  vertex(999, 513);
  vertex(0, 507);
  vertex(1, 489);
  vertex(0, 542);
  vertex(997, 543);
  vertex(998, 562);
  vertex(1, 560);
  vertex(-1, 541);
  vertex(0, 582);
  vertex(999, 582);
  vertex(1000, 596);
  vertex(998, 600);
  vertex(0, 601);
  vertex(0, 583);
  endShape();
}





function drawTree() {
  fill("SaddleBrown");
  beginShape();
  vertex(573, 601);
  vertex(656, 554);
  vertex(753, 486);
  vertex(792, 423);
  vertex(791, 349);
  vertex(783, 271);
  vertex(795, 265);
  vertex(813, 267);
  vertex(846, 260);
  vertex(872, 278);
  vertex(872, 428);
  vertex(890, 477);
  vertex(930, 517);
  vertex(963, 554);
  vertex(988, 600);
  vertex(574, 601);
  endShape();
}


function drawLeaves() {
  fill("Darkgreen");
  beginShape()
  vertex(782, 274);
  vertex(711, 361);
  vertex(651, 357);
  vertex(616, 325);
  vertex(641, 245);
  vertex(624, 215);
  vertex(656, 179);
  vertex(691, 148);
  vertex(686, 125);
  vertex(680, 103);
  vertex(696, 89);
  vertex(728, 63);
  vertex(767, 53);
  vertex(856, 37);
  vertex(872, 34);
  vertex(880, 56);
  vertex(891, 93);
  vertex(904, 106);
  vertex(930, 110);
  vertex(950, 115);
  vertex(965, 86);
  vertex(988, 112);
  vertex(968, 206);
  vertex(955, 221);
  vertex(981, 251);
  vertex(997, 288);
  vertex(999, 330);
  vertex(970, 368);
  vertex(931, 386);
  vertex(903, 368);
  vertex(907, 334);
  vertex(889, 299);
  vertex(871, 278);
  vertex(846, 260);
  vertex(814, 267);
  vertex(797, 266);
  vertex(781, 272);
  vertex(710, 360);
  endShape()
}
function drawOranges() {
  fill("orange")
  circle(668, 276, 50)
  circle(806, 154, 50)
  circle(957, 332, 40)
}
function drawFire() {
  fill("red")
  beginShape();
  vertex(709, 358);
  vertex(594, 276);
  vertex(692, 297);
  vertex(639, 180);
  vertex(611, 169);
  vertex(605, 139);
  vertex(663, 185);
  vertex(706, 218);
  vertex(681, 110);
  vertex(722, 159);
  vertex(728, 59);
  vertex(712, 28);
  vertex(725, 14);
  vertex(770, 80);
  vertex(814, 9);
  vertex(832, 62);
  vertex(892, 40);
  vertex(843, 99);
  vertex(852, 145);
  vertex(900, 148);
  vertex(931, 81);
  vertex(929, 156);
  vertex(962, 215);
  vertex(890, 225);
  vertex(935, 290);
  vertex(979, 380);
  vertex(933, 351);
  vertex(902, 305);
  vertex(869, 341);
  vertex(839, 266);
  vertex(781, 303);
  vertex(777, 344);
  vertex(730, 335);
  vertex(727, 370);
  vertex(709, 358);
  endShape();
}