function drawPage2() {
  background('skyblue')
  fill("black");
  text("This boy loved this tree and would always pick from the tree", 0, 300, 300);
  drawGround();
  drawFence();
  drawTree();
  drawLeaves();
  drawPerson();
  drawShirt();
  drawOranges();
}

function drawGround() {
  fill("green")
  rect(0, 600, 1000, 200);
}
function drawFence() {
  fill("#CD853F");
  beginShape();
  vertex(0, 489);
  vertex(999, 496);
  vertex(999, 513);
  vertex(0, 507);
  vertex(1, 489);
  vertex(0, 542);
  vertex(997, 543);
  vertex(998, 562);
  vertex(1, 560);
  vertex(-1, 541);
  vertex(0, 582);
  vertex(999, 582);
  vertex(1000, 596);
  vertex(998, 600);
  vertex(0, 601);
  vertex(0, 583);
  endShape();
}





function drawTree() {
  fill("SaddleBrown");
  beginShape();
  vertex(573, 601);
  vertex(656, 554);
  vertex(753, 486);
  vertex(792, 423);
  vertex(791, 349);
  vertex(783, 271);
  vertex(795, 265);
  vertex(813, 267);
  vertex(846, 260);
  vertex(872, 278);
  vertex(872, 428);
  vertex(890, 477);
  vertex(930, 517);
  vertex(963, 554);
  vertex(988, 600);
  vertex(574, 601);
  endShape();
}


function drawLeaves() {
  fill("Darkgreen");
  beginShape()
  vertex(782, 274);
  vertex(711, 361);
  vertex(651, 357);
  vertex(616, 325);
  vertex(641, 245);
  vertex(624, 215);
  vertex(656, 179);
  vertex(691, 148);
  vertex(686, 125);
  vertex(680, 103);
  vertex(696, 89);
  vertex(728, 63);
  vertex(767, 53);
  vertex(856, 37);
  vertex(872, 34);
  vertex(880, 56);
  vertex(891, 93);
  vertex(904, 106);
  vertex(930, 110);
  vertex(950, 115);
  vertex(965, 86);
  vertex(988, 112);
  vertex(968, 206);
  vertex(955, 221);
  vertex(981, 251);
  vertex(997, 288);
  vertex(999, 330);
  vertex(970, 368);
  vertex(931, 386);
  vertex(903, 368);
  vertex(907, 334);
  vertex(889, 299);
  vertex(871, 278);
  vertex(846, 260);
  vertex(814, 267);
  vertex(797, 266);
  vertex(781, 272);
  vertex(710, 360);
  endShape()
}
function drawOranges() {
  fill("orange")
  circle(668, 276, 50)
  circle(806, 154, 50)
  circle(957, 332, 40)
}
