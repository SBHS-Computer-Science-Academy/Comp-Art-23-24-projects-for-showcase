
function drawPage0() {
  //if (mouseX >200 && mouseX < 750)
  background("skyblue")
  fill("white");
  // else fill("green")
  text("The Orange Tree", 0, 100, 300);

  drawGround();
  drawTree();
  drawLeaves();
  drawOranges();
}
function drawGround() {
  fill("green")
  rect(0, 600, 1000, 200);
}
function drawTree() {
  fill("SaddleBrown");
  beginShape();
  vertex(573, 601);
  vertex(656, 554);
  vertex(753, 486);
  vertex(792, 423);
  vertex(791, 349);
  vertex(783, 271);
  vertex(795, 265);
  vertex(813, 267);
  vertex(846, 260);
  vertex(872, 278);
  vertex(872, 428);
  vertex(890, 477);
  vertex(930, 517);
  vertex(963, 554);
  vertex(988, 600);
  vertex(574, 601);
  endShape();
}
function drawLeaves() {
  fill("DarkGreen");
  beginShape();
  vertex(782, 274);
  vertex(711, 361);
  vertex(651, 357);
  vertex(616, 325);
  vertex(641, 245);
  vertex(624, 215);
  vertex(656, 179);
  vertex(691, 148);
  vertex(686, 125);
  vertex(680, 103);
  vertex(696, 89);
  vertex(728, 63);
  vertex(767, 53);
  vertex(856, 37);
  vertex(872, 34);
  vertex(880, 56);
  vertex(891, 93);
  vertex(904, 106);
  vertex(930, 110);
  vertex(950, 115);
  vertex(965, 86);
  vertex(988, 112);
  vertex(968, 206);
  vertex(955, 221);
  vertex(981, 251);
  vertex(997, 288);
  vertex(999, 330);
  vertex(970, 368);
  vertex(931, 386);
  vertex(903, 368);
  vertex(907, 334);
  vertex(889, 299);
  vertex(871, 278);
  vertex(846, 260);
  vertex(814, 267);
  vertex(797, 266);
  vertex(781, 272);
  vertex(710, 360);
  endShape();
}
function drawOranges() {
  fill("orange")
  circle(668, 276, 50)
  circle(806, 154, 50)
  circle(957, 332, 40)
}


