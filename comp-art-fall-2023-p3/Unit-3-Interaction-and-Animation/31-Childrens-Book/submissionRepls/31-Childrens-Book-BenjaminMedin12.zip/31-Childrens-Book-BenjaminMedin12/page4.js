function drawPage4() {
  background("skyblue")
  fill("black");
  text("But that boy kept an orange with him and he was sad at first but realized ", 0, 300, 300);
  drawGround();
  drawFence();
  drawPerson();
  drawShirt();
  drawTree();
  drawOrange();


}
function drawGround() {
  fill("green")
  rect(0, 600, 1000, 200);
}
function drawFence() {
  fill("#CD853F");
  beginShape();
  vertex(0, 489);
  vertex(999, 496);
  vertex(999, 513);
  vertex(0, 507);
  vertex(1, 489);
  vertex(0, 542);
  vertex(997, 543);
  vertex(998, 562);
  vertex(1, 560);
  vertex(-1, 541);
  vertex(0, 582);
  vertex(999, 582);
  vertex(1000, 596);
  vertex(998, 600);
  vertex(0, 601);
  vertex(0, 583);
  endShape();
}
function drawPerson() {

  fill("Burlywood")
  circle(541, 483, 40)
  beginShape();
  vertex(541, 505);
  vertex(541, 517);
  vertex(507, 542);
  vertex(508, 549);
  vertex(531, 532);
  vertex(541, 528);
  vertex(534, 542);
  vertex(535, 557);
  vertex(543, 567);
  vertex(558, 567);
  vertex(569, 557);
  vertex(568, 540);
  vertex(559, 528);
  vertex(584, 544);
  vertex(586, 536);
  vertex(568, 527);
  vertex(551, 514);
  vertex(548, 503);
  vertex(544, 500);
  vertex(541, 505);
  vertex(543, 567);
  vertex(534, 576);
  vertex(529, 595);
  vertex(538, 602);
  vertex(546, 589);
  vertex(551, 567);
  vertex(560, 567);
  vertex(568, 595);
  vertex(575, 598);
  vertex(582, 593);
  vertex(574, 574);
  vertex(564, 559);
  vertex(561, 566);
  endShape();

}
function drawShirt() {
  fill("red")
  beginShape();
  vertex(542, 514);
  vertex(550, 513);
  vertex(563, 523);
  vertex(559, 528);
  vertex(566, 540);
  vertex(569, 549);
  vertex(569, 559);
  vertex(560, 567);
  vertex(545, 566);
  vertex(537, 559);
  vertex(534, 543);
  vertex(543, 530);
  vertex(533, 527);
  vertex(531, 524);
  vertex(541, 518);
  vertex(543, 514);
  endShape();
}




function drawTree() {
  fill("SaddleBrown");
  beginShape();
  vertex(573, 601);
  vertex(656, 554);
  vertex(753, 486);
  vertex(792, 423);
  vertex(791, 349);
  vertex(783, 271);
  vertex(795, 265);
  vertex(813, 267);
  vertex(846, 260);
  vertex(872, 278);
  vertex(872, 428);
  vertex(890, 477);
  vertex(930, 517);
  vertex(963, 554);
  vertex(988, 600);
  vertex(574, 601);
  endShape();
}
function drawOrange() {
  fill("orange")
  circle(29, 580, 0)
}


