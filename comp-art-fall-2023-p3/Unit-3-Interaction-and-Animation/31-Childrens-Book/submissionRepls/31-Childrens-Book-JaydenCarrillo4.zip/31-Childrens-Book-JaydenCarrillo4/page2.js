function drawPage2() {
  islands()
	fill("black");
	text("The Boat saw", -300, height / 8, width);
  text("and the boat saw", 300, height / 8, width);
  fill ("green");
  textSize(60)
  text("BIG ISLANDS",-250, height / 3, width);
  text("small islands",250, height / 3, width )
}

function islands(){
  fill("green")
  circle(166, 596, 300)
  circle(843, 600,150)
}