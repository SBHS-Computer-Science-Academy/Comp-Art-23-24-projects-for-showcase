let page = 0;
let numPages = 3; 
let myFont;


function preload() {
	myFont = loadFont('PaletteMosaic-Regular.ttf');
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");

	textFont(myFont);
	textSize(36);
	textAlign(CENTER, CENTER);

  makeStars();
}

function draw() {
	background("skyblue");
  sun();
  if (page == 0) drawPage0();
	if (page == 1) drawPage1();
	if (page == 2) drawPage2();
	if (page == 3) drawPage3();
  boat();
  sea();
  
  drawMouseLines("black");
}

function boat() {
  fill("Peru");
arc(500, 503,200, 200, 0, 399 );
  beginShape();
  vertex(484, 503);
  vertex(479, 336);
  vertex(505, 336);
  vertex(509, 503);
  vertex(484, 503);
  endShape();

  fill("WhiteSmoke");
  beginShape();
  vertex(479, 336);
  vertex(396, 411);
  vertex(481, 411);
  vertex(479, 336);
  endShape();

  }

function sea(){
fill("DeepSkyBlue")
rect(0, 600, 1000, 200);

}
function keyPressed(){
  clear();
  text("pressed",500,150);
  if (key == "ArrowRight" && page < numPages) page += 1
  if (key == "ArrowLeft" && page > 0) page -= 1
}

function keyReleased(){
  text("released",500,150)
}



