function drawPage1() {
	fill("black");
	text("There was a Boat drifting across the",-20, height / 8, width);
  text("BIG", -150, height / 4, width)
  fill("blue")
  text("BLUE SEA",55, height / 4, width)
}

function sun(){
  fill("Gold")
  circle(width/2,height/8,150)
}