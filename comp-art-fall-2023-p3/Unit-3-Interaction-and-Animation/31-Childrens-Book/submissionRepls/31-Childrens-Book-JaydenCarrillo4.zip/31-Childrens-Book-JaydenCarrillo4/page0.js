function drawPage0() {
  fill("black");
  textFont("Roboto Mono")
  text("A Boat on the", -300, height / 8, width);
  textSize(60);
  text("BIG",-150, height / 4, width)
  fill("blue")
  text("BLUE SEA",55, height / 4, width)
}
function sun(){
  fill("Gold")
  circle(width/2,height/8,150)
}
