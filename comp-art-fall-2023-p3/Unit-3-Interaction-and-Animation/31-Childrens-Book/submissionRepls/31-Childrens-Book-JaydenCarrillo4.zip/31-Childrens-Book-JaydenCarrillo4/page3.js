function drawPage3() {
  background("Black");
  moon()
   drawStars();
	fill("white");
	text("at night the boat saw", -255, height / 8, width);
  text("all the small stars",-255, height / 5, width);
  text("and the",200, height / 6, width);
  text( "BIG MOON",200, height / 3.5, width)
}

let numStars;

let starX = [];
let starY = [];
let starD = [];

  function makeStars() {
  numStars = random(30,200);
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(height));
    starD.push(random(3, 10));
  }
}


  function drawStars() {
  for (let i = 0; i < numStars; i += 1) {

  fill ("white")
  circle(starX[i], starY[i], starD[i]);

  }
}
function moon(){
  fill("DarkGray")
  circle(960, 22,400)
  fill("lightgray")
  circle(841, 34,50)
  circle(959, 33,50)
  circle(930, 142,50)
}