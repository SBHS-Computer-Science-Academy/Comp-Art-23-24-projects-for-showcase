  function drawPage0() {
    fill("black");
fill("red")

  drawRainbow();
  
  noStroke();
  text("Title Page goes here", 0, height / 2, width);

  
}  

function drawRainbow() {
  image(rainbow, 0, 0);
}