function drawPage1() {
	fill("black");
	text("Our favorite colors",10, height / 74, width);

  fill("black")
  ellipse(500,400,600,600)
  
  
  fill("red")

  for (let x = 0; x < 12; x++) {
    let thisHue = x * 360 / 12;
    fill(thisHue, 100, 100);
    circle(500-250*sin(thisHue), 400-250*cos(thisHue),100);
  }


}