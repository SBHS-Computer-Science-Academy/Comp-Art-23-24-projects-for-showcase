/* 
To change the starting page, change the page variable below.

To /add new pages:

1. Change numPages to be tota`o'`# o
f pages
2. Add a line per page to function draw() below
3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

let page = 1;
let numPages = 3;

let myFont;


let rainbow;


function preload() {
  myFont = loadFont('RobotoSlab.ttf');
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");


  createConsole("lines");

  textFont(myFont);
  textSize(36);
  textAlign(CENTER, CENTER);
  angleMode(DEGREES)

  rainbow = createGraphics(width, height);

  colorMode(HSB);

  rainbow.colorMode(HSB);
  for (let x = 0; x < width; x++) {
    let thisHue = x * 360 / width;
    rainbow.stroke(thisHue, 100, 100);
    rainbow.line(x, 0, x, height);
  }

}

function draw() {
  background("grey");
  drawRainbow();

  if (page == 0) drawPage0();
  if (page == 1) drawPage1();
  if (page == 2) drawPage2();
  if (page == 3) drawPage3();

  drawMouseLines("white");
}

function keyReleased() {

  if (key == "ArrowRight" && page < numPages) page += 1
  if (key == "ArrowLeft" && page > 0) page -= 1
}


