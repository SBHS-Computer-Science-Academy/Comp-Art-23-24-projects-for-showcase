function drawPage3() {


  fill("white");
  textAlign(LEFT, TOP)
  textSize(50);
  noStroke();
  text("First, he saw the Sun", 50, 70, width);
  text("He saw Mercury", 50, 325, width);
  text("And then, he saw Venus!", 50, 560, width);

  textAlign(CENTER, CENTER);
  drawSun();
  drawMercury();
  drawVenus();


  funFacts(712, 155, 200, "The Sun isn't \nactually a planet,\nit's a star!", "black", 24);
  funFacts(575,385,20, "Mercury is the smallest planet in our Solar System!", "white", 14);
  funFacts(841,650,90, "Venus is the second brightest \nplanet in the night sky \nafter the Moon!","white", 20);
}
  
function drawSun() {
  fill("yellow");
  circle(712, 155, 200);

  beginShape();
  vertex(620, 80);
  vertex(648, 55);
  vertex(610, 45);
  vertex(620, 79);
  endShape();

  beginShape();
  vertex(703, 41);
  vertex(733, 41);
  vertex(718, 10);
  vertex(703, 41);
  endShape();

  beginShape();
  vertex(787, 64);
  vertex(822, 58);
  vertex(809, 88);
  vertex(788, 66);
  endShape();

  beginShape();
  vertex(827, 154);
  vertex(826, 180);
  vertex(858, 171);
  vertex(827, 154);
  endShape();

  beginShape();
  vertex(799, 231);
  vertex(779, 251);
  vertex(810, 261);
  vertex(800, 233);
  endShape();

  beginShape();
  vertex(692, 271);
  vertex(726, 272);
  vertex(709, 301);
  vertex(692, 273);
  endShape();

  beginShape();
  vertex(609, 211);
  vertex(625, 234);
  vertex(592, 241);
  vertex(608, 211);
  endShape();

  beginShape();
  vertex(594, 131);
  vertex(594, 158);
  vertex(564, 147);
  vertex(594, 132);
  endShape();
}
function drawMercury() {
  fill("lightgray");
  circle(575, 365, 20);
  fill("gray");
  circle(574, 360, 5);
  circle(576, 367, 9);
  circle(568, 362, 4);
}
function drawVenus() {
  fill(227, 206, 154);
  circle(841, 594, 90);
  fill(204, 183, 131,120);
  circle(835, 590, 60);
  fill(235, 221, 188,180);
  circle(864, 575,30);
  circle(844,580,10);
  fill(186, 162, 102,130);
  circle(863,620,15);
}

