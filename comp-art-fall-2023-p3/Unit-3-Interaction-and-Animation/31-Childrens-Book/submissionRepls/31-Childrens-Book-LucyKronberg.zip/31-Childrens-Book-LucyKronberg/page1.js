

function drawPage1() {

  textSize(65)
  stroke(0);
  
	fill("white");
	text("The Little Astronaut", 0,250, width);

  
  drawPlanet()
}



  function drawPlanet() {
    noStroke();
    fill(103, 156, 191);
    circle(500, 500, 250);

    fill(148, 195, 227,150);
    circle(500,500,180);

    noFill();
    stroke('white');
    strokeWeight(5);
    beginShape();
    curveVertex(385, 544); // control point
    curveVertex(385, 544);
    curveVertex(320, 602);
    curveVertex(689, 421);
    curveVertex(607, 438);
    curveVertex(607, 438); // control point
    endShape();

    fill(240, 238, 117);
    noStroke();
    beginShape();
    vertex(674, 526);
    vertex(682, 507);
    vertex(689, 526);
    vertex(708, 530);
    vertex(695, 542);
    vertex(700, 560);
    vertex(678, 548);
    vertex(661, 560);
    vertex(666, 537);
    vertex(652, 527);
    vertex(673, 525);
    endShape();

    beginShape();
    vertex(672, 582);
    vertex(674, 579);
    vertex(677, 585);
    vertex(685, 587);
    vertex(680, 591);
    vertex(684, 596);
    vertex(677, 591);
    vertex(671, 596);
    vertex(670, 589);
    vertex(664, 587);
    vertex(670, 586);
    endShape();

    beginShape();
    vertex(327, 427);
    vertex(332, 415);
    vertex(338, 426);
    vertex(353, 427);
    vertex(346, 437);
    vertex(348, 448);
    vertex(337, 443);
    vertex(327, 450);
    vertex(326, 439);
    vertex(313, 430);
    endShape();

  }