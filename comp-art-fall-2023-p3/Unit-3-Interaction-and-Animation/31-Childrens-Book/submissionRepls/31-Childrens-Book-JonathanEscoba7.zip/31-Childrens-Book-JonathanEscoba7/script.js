/* 
To change the starting page, change the page variable below.

To add new pages:

1. Change numPages to be total # of pages
2. Add a line per page to function draw() below
3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

let page = 2
let numPages = 3; 
let myFont;

/*
This is an example of how to load and use fonts.  You can download a font you like from the internet and add it to the files
*/

function preload() {
	myFont = loadFont('PaletteMosaic-Regular.ttf');
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
 
  // printToConsole("Use arrow or number keys to change pages.");
  // printToConsole("");
 
  createConsole("lines");

	textFont(myFont);
	textSize(36);
	textAlign(CENTER, CENTER);  // the x and y for the text command are the center of the text box


}

function draw() {
	background(255,218,134);

  if (page == 0) drawPage0();
	if (page == 1) drawPage1();
	if (page == 2) drawPage2();
	if (page == 3) drawTitle();
   
  drawMouseLines("black");
}
function drawdoor() {
  fill(218 ,188,120);
  beginShape();
  vertex(207, 799);
  vertex(717, 799);
  vertex(718, -2);
  vertex(265, -7);
  vertex(258, 798);
  vertex(291, 798);
  vertex(335, 799);
  vertex(716, 800);
  endShape();
  fill("yellow");
  circle(659,412,50)
  fill(83 ,53,00)
  beginShape();
  vertex(318, 798);
  vertex(317, 664);
  vertex(439, 665);
  vertex(440, 798);
  vertex(319, 798);
  vertex(318, 728);
  endShape();
  fill ("white")
  beginShape();
  vertex(349, 666);
  vertex(347, 710);
  vertex(403, 709);
  vertex(406, 666);
  vertex(348, 665);
  vertex(350, 677);
  endShape();
}
function drawwindows() {
fill("skyblue");
  beginShape();
  vertex(844, -2);
  vertex(844, 304);
  vertex(1004, 305);
  vertex(1004, -2);
  vertex(843, -2);
  endShape();
}
