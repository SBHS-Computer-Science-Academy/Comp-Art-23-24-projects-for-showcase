function drawPage0() {
  fill("black");
  
  textFont("Comic Sans MS");
  textSize(36);
  textAlign(CENTER, CENTER);
  drawdoor()
  drawwindows()
  fill('black')
  text("And the penicls arrived ", 300,150);

}