/* 
To change the starting page, change the page variable below.

To add new pages:

1. Change numPages to be total # of pages
2. Add a line per page to function draw() below
3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

let page = 0;
let numPages = 3;
let myFont;

/*
This is an example of how to load and use fonts.  You can download a font you like from the internet and add it to the files
*/

function preload() {
  myFont = loadFont('PaletteMosaic-Regular.ttf');
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  printToConsole("Use arrow or number keys to change pages.");

  //createConsole("lines");

  textFont(myFont);
  textSize(36);
  textAlign(CENTER, CENTER);  // the x and y for the text(x, y) function are the center of the text box


}

function keyPressed() {
  if (keyCode === LEFT_ARROW & page > 0) {
    page -= 1
  } else if (keyCode === RIGHT_ARROW & page < numPages) {
    page += 1
  }
  if (key === "1") {
    page = 1
  } else if (key === "2") {
    page = 2
  } else if (key === "3") {
    page = 3
  }
}

function mouseInRect(x, y, w, h) {
  return mouseX >= x && mouseX <= x + w && mouseY >= y && mouseY <= y + h;
}

function mousePressed() {
  let top = height - 30;
  if (mouseInRect(width - 50, top, 25, 20) && page < numPages - 1) page = numPages;
  if (mouseInRect(width / 2 + 35, top, 16, 20) && page < numPages) page += 1;
  if (mouseInRect(width / 2 - 51, top, 16, 20) && page > 0) page -= 1;
  if (mouseInRect(25, top, 25, 20) && page > 1) page = 0;
}

function draw() {
  background("white");
  if (page == 0) drawPage0();
  if (page == 1) drawPage1();
  if (page == 2) drawPage2();
  if (page == 3) drawPage3();

}