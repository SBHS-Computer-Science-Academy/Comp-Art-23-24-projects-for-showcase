function drawPage0() {
  fill("black");
  rectGradient(0,-700, width, height+500, color("green"), color("saddlebrown"))
  noStroke();
  fill("saddlebrown")
  rect(0, 600, width, 160)
  fill("greenyellow");
  text("Title Page goes here", 0, height / 2, width);
  fill(0)
  text("0/3", width/2, height-25)
  triangle(width/2 + 36, height - 10, width/2 + 36, height - 30, width/2 + 50, height - 20) //triangleforward
  triangle(width - 50, height - 10, width - 50, height - 30, width - 36, height - 20)
  triangle(width - 42, height - 10, width - 42, height - 30, width - 28, height - 20) //triangles forward 
}