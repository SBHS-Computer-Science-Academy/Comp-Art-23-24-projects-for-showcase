function drawPage1() {
	fill("black");
	text("Page 1 goes here", 0, height / 2, width);
  text("1/3", width/2, height-25)
  triangle(width/2 + 36, height - 10, width/2 + 36, height - 30, width/2 + 50, height - 20) //triangleforward
  triangle(width/2 - 36, height - 10, width/2 - 36, height - 30, width/2 - 50, height - 20) //trianglebackward
  triangle(width - 50, height - 10, width - 50, height - 30, width - 36, height - 20)
  triangle(width - 42, height - 10, width - 42, height - 30, width - 28, height - 20) //triangles forward 
}