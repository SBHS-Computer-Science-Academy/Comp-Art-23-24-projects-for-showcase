function drawPage3() {
	fill("black");
	text("Page 3 goes here", 0, height / 2, width);
  text("3/3", width/2, height-25)
  triangle(width/2 - 36, height - 10, width/2 - 36, height - 30, width/2 - 50, height - 20) //trianglebackward
  triangle(50, height - 10, 50, height - 30, 36, height - 20)
  triangle(42, height - 10, 42, height - 30, 28, height - 20) //triangles backward 
}