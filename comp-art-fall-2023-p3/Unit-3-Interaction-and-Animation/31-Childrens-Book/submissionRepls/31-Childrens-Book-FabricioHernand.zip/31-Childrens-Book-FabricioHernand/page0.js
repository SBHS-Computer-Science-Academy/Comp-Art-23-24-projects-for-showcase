function drawPage0() {
    fill("black");
fill("black");

  drawRainbow();
  
  noStroke();
    textSize(100)
  
  text("Colors of the world", 0, height / 2, width);
  textSize(50)
  text("by elicia and fabricio", 0, + 520, width);

  
}  

function drawRainbow() {
  image(rainbow, 0, 0);
}