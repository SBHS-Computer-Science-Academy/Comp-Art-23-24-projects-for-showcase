function drawPage3() {

  rectGradient(0, 0, width, height, picker1.color(), picker2.color(), "vertical");

  fill("black");
  text("Page 3 goes here", 0, height / 2, width);


  picker1.position(950, 400);
  picker2.position(0, 300);



}