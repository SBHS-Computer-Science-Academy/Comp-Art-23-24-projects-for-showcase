
function drawPage2() {
  fill("white");
  

  fill("red")
  ellipse(50,100,90)//first 
  fill("yellow")
  ellipse(220,100,90)
  fill("orange")
  ellipse(420,100,90)


  fill("green")
  ellipse(50,300,90)
  fill("yellow")
  ellipse(220,300,90)
  fill("limegreen")
  ellipse(420,300,90)


  fill("blue")
  ellipse(50,500,90)
  fill("yellow")
  ellipse(220,500,90)
  fill("green")
  ellipse(420,500,90)

  fill("blue")
  ellipse(50,700,90)
  fill("red")
  ellipse(220,700,90)
  fill("purple")
  ellipse(420,700,90)

  //whites 

  fill("white")
  ellipse(570,100,90)
  fill("red")
  ellipse(760,100,90)
  fill("pink")
  ellipse(950,100,90)

  fill("white")
  ellipse(570,300,90)
  fill("purple")
  ellipse(770,300,90)
  fill("lightpurple")
  ellipse(950,300,90)


  fill("white")
  ellipse(570,500,90)
  fill("blue")
  ellipse(770,500,90)
  fill("skyblue")
  ellipse(950,500,90)


  fill("white")
  ellipse(570,700,90)
  fill("black")
  ellipse(770,700,90)
  fill("grey")
  ellipse(950,700,90)
fill("black")
  rect(495,0,10,800)

  textSize(60);
  for(let i = 0; i < 4; i = i + 1){
  // fill("black")
  // rect(100,98,70,10)

  fill("black")
  // rect(130,70,10,70)

    text("+", 135, 90)
    text("+", 665,90)
    text("=", 316,90)
    text("=", 856,90)
    translate(0,200)

  }
}
