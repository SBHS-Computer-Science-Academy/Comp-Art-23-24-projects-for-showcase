let colors = ["red", "orange","yellow","green", "blue", 'purple' ]

function drawPage1() {
	fill("black");
	text("Our favorite colors",10, height / 74, width);

  fill("black")
  circleGradient(500,400,600,'black', 'white')
  textSize(20);
  
  fill("red")

  for (let x = 0; x < colors.length; x++) {
    let thisHue = x * 360 / colors.length;
    fill(colors[x]);
    noStroke()
    circle(500-250*sin(thisHue), 400-250*cos(thisHue),100);
    fill('white')
    stroke('black')
    text(colors[x], 500-250*sin(thisHue), 400-250*cos(thisHue))
  }
  
  

}