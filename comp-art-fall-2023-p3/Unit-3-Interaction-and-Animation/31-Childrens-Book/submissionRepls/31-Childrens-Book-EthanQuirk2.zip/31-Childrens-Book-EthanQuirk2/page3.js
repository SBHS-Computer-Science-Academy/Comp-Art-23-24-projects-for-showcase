function drawPage3() {
  fill("black");
  text("the man with the axe sees 3 perfect trees to cut down.", 10, height / 20, width);


  drawMediumTreeTrunk()
  drawMediumTreeBranches()
  drawLargeTreeTrunk()
  drawLargeTreeBranches()
  drawMonkey(340,403)
  drawMonkey(655, 290)
  drawMonkey(458, 408)
}

function drawMonkey(x,y){
  push()
  translate(x,y)
  translate(-154,-535)
  drawSmallMonkeyRightArm()
  drawSmallMonkeyLeftArm()
  drawSmallMonkeyBody()
  drawSmallCrease()
  fill("Sienna")
  circle(176, 442,60)
  drawSmallMonkeyFace()
  drawSmallMonkeySmile()
  fill("black")
  circle(175, 441,5)
  circle(190, 442,5)

pop()
}

function drawstickman(){
line(313,800,291,750)


}