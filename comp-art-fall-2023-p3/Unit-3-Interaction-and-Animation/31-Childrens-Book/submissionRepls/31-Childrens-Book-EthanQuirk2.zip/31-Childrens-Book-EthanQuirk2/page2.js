function drawPage2() {
	fill("black");
	text("the man with the axe sees 3 perfect trees to cut down.", 10, height / 20, width);


  