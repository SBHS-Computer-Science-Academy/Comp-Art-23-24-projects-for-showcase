function drawPage3() {
	fill("black");
	text("The monkeys have survived!", 0, 100, width);
}

