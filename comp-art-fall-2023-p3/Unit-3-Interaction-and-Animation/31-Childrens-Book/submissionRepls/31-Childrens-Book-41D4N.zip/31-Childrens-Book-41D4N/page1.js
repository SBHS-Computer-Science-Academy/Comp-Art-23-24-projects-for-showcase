function drawPage1() {
	fill("black");
	text("The man chops the second tree down.", 0, 100, width);
}