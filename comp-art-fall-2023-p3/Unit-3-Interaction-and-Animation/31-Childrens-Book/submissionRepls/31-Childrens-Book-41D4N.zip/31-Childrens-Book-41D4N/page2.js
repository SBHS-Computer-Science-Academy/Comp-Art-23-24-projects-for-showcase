function drawPage2() {
	fill("black");
	text("The man's axe broke!", 0, 100, width);
  stickman()
}

function stickman() {
  noFill()
  beginShape();
  vertex(401, 706);
  vertex(440, 618);
  vertex(477, 701);
  vertex(440, 618);
  vertex(439, 517);
  vertex(441, 558);
  vertex(479, 581);
  vertex(441, 558);
  vertex(407, 581);
  endShape();
  circle(439,499,60)
}