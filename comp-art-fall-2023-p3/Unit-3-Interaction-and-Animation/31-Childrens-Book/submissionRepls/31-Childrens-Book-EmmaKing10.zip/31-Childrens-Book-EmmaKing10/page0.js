function drawPage0() {
  stroke("black")
  drawRock()
  drawPaper()
  
  fill("black")
  textSize(100)
  text("Designed By: Emma King ",500,100)
  text("Rock and Paper",500,400 ); 


  
 
}

function drawRock(){
  
fill(145, 143, 142)
  beginShape();//right arm 
  vertex(227, 605);
  vertex(280, 559);
  vertex(286, 565);
  vertex(226, 613);
  vertex(223, 607);
  vertex(234, 599);
  endShape();

  beginShape();//left arm
  vertex(112, 608);
  vertex(45, 560);
  vertex(40, 567);
  vertex(101, 613);
  vertex(111, 609);
  vertex(103, 602);
  endShape();

  beginShape();//left leg 
  vertex(139, 664);
  vertex(121, 718);
  vertex(127, 719);
  vertex(146, 668);
  vertex(138, 666);
  vertex(136, 674);
  endShape();

  beginShape();//right leg
  vertex(191, 664);
  vertex(202, 716);
  vertex(214, 713);
  vertex(203, 666);
  vertex(190, 667);
  vertex(192, 672);
  endShape();

  ellipse(48,568,30,30)//left hand
  ellipse(278,564,30,30)//right hand 
  ellipse(126,714,30,30)//left foot
  ellipse(207,709,30,30)//right foot


  fill( 145, 143, 142);
  beginShape();
  vertex(133, 557);
  vertex(162, 541);
  vertex(176, 566);
  vertex(205, 566);
  vertex(211, 595);
  vertex(238, 601);
  vertex(230, 628);
  vertex(248, 650);
  vertex(220, 653);
  vertex(218, 675);
  vertex(186, 669);
  vertex(178, 692);
  vertex(153, 672);
  vertex(128, 676);
  vertex(128, 647);
  vertex(103, 644);
  vertex(109, 624);
  vertex(92, 615);
  vertex(109, 596);
  vertex(89, 570);
  vertex(110, 567);
  vertex(105, 540);
  vertex(133, 556);
  endShape();


  fill("black");
  ellipse(130,598,15,15)
  ellipse(184,600,15,15)

  fill(230, 156, 205)
  beginShape();//mouth
  vertex(146, 630);
  vertex(166, 632);
  vertex(165, 640);
  vertex(143, 638);
  vertex(145, 631);
  endShape();

}

function drawPaper(){
  push()
    translate(200,0)

fill(145, 143, 142)

  beginShape();
  vertex(527, 617);
  vertex(559, 536);
  vertex(568, 540);
  vertex(531, 620);
  vertex(519, 604);
  vertex(537, 590);
  endShape();

  beginShape();
  vertex(381, 627);
  vertex(333, 566);
  vertex(339, 562);
  vertex(378, 612);
  vertex(377, 625);
  endShape();

  beginShape();
  vertex(422, 703);
  vertex(410, 766);
  vertex(421, 766);
  vertex(430, 716);
  vertex(420, 716);
  vertex(419, 723);
  endShape();

  beginShape();
  vertex(495, 714);
  vertex(500, 755);
  vertex(510, 754);
  vertex(504, 716);
  vertex(493, 716);
  vertex(497, 724);
  endShape();

  fill(145, 143, 142)

  ellipse(561,543,30,30)
  ellipse(331,553,30,30)
  ellipse(416,764,30,30)
  ellipse(505,759,30,30)


  fill(250, 247, 249)
  beginShape();
  vertex(379, 724);
  vertex(374, 533);
  vertex(535, 526);
  vertex(540, 722);
  vertex(379, 725);
  endShape();

  fill("black")
  beginShape();
  vertex(375, 562);
  vertex(536, 552);
  vertex(535, 559);
  vertex(375, 568);
  vertex(374, 557);
  endShape();

  fill("black");
  beginShape();
  vertex(377, 650);
  vertex(538, 641);
  vertex(538, 646);
  vertex(376, 656);
  vertex(377, 637);
  endShape();

  beginShape();
  vertex(378, 708);
  vertex(540, 702);
  vertex(539, 708);
  vertex(379, 712);
  vertex(377, 695);
  endShape();

  beginShape();
  vertex(393, 533);
  vertex(396, 724);
  vertex(405, 723);
  vertex(399, 531);
  vertex(382, 532);
  endShape();

  ellipse(383,547,10,10)
  ellipse(383, 610,10,10)
  ellipse(388,683,10,10)
  ellipse(429,598,15,15)
  ellipse(485, 593,15,15)

  fill(230, 156, 205)
  beginShape();
  vertex(442, 625);
  vertex(467, 626);
  vertex(467, 633);
  vertex(440, 634);
  vertex(440, 626);
  endShape();


pop()
}

function drawCloud(){
  fill('white');
  noStroke()
  ellipse(580, 150, 200, 100)
  ellipse(740, 150, 200, 100)
  ellipse(660, 90, 200, 100)

  ellipse(125,158,200,100)
  ellipse(253,152,200,100)
  ellipse(173,96,200,100)






}

