function drawPage0() {
  fill("black");
  text("8up", 0, height / 2, width);

circle(w 






  
}