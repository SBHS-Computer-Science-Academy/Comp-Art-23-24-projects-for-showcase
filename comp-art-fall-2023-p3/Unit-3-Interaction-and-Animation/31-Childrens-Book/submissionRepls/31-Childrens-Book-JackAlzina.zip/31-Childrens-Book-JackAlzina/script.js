/* 
To change the starting page, change the page variable below.

To add new pages:

1. Change numPages to be total # of pages
2. Add a line per page to function draw() below
3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

let page = 0;
let numPages = 3;
let myFont;

/*
This is an example of how to load and use fonts.  You can download a font you like from the internet and add it to the files
*/

function preload() {
  myFont = loadFont('Roboto-Regular.ttf');
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  // printToConsole("Use arrow or number keys to change pages.");
  // printToConsole("");

  createConsole("lines");

  textFont(myFont);
  textSize(56);
  textAlign(CENTER, CENTER);  // the x and y for the text command are the center of the text box


}

function draw() {
  background("skyBlue");

  if (page == 0) drawPage0();
  if (page == 1) drawPage1();
  if (page == 2) drawPage2();
  if (page == 3) drawPage3();
  circleGradient(width / 10, 59, 180, "yellow", "orange"); // sun
  // drawMouseLines("black");
}
function branch() {

  fill("SaddleBrown");
  beginShape();
  vertex(1, 398);
  vertex(933, -2);
  vertex(998, 0);
  vertex(999, 75);
  vertex(0, 520);
  endShape();
  beginShape();
  vertex(497, 290);
  vertex(666, 381);
  vertex(694, 542);
  vertex(711, 545);
  vertex(682, 383);
  vertex(884, 535);
  vertex(899, 532);
  vertex(689, 371);
  vertex(606, 326);
  vertex(771, 306);
  vertex(763, 290);
  vertex(597, 313);
  vertex(542, 278);
  endShape();

}

function catipillar() {
  fill("green");
  circle(381, 285, 50);//body
  circle(427, 264, 50);//body
  circle(334, 302, 50);//body
  fill("red");
  circle(447, 230, 50);//head
  fill("yellow");
  ellipse(439, 222, 10, 13);//eyes lids
  ellipse(459, 221, 10, 13);//eyes lids
  fill("green");
  ellipse(439, 222, 7, 10);//eyes
  ellipse(459, 221, 7, 10);//eyes
  circle(447, 241, 7);//mouth
  fill("black");
  line(428, 188, 433, 210);//intenas
  line(459, 209, 459, 186);//intenas
  line(327, 325, 325, 345);
  line(346, 343, 344, 324);
  line(420, 287, 421, 303);
  line(430, 302, 428, 288);
  line(436, 288, 440, 299);
  line(445, 283, 452, 296);
}
function keyPressed() {
  //clear();
  //text(key, 500, 150);
  if (key === "ArrowRight" && page < numPages) page += 1
  if (key === "ArrowLeft" && page > 0) page -= 1
}

function keyReleased() {
  text("Released", 500, 200);
}
function drawpage() {
  if (mouseX > 275 && mouseX < 740) { fill("black"); 
                                    }
  else fill("red")
  text(" title page goes here", 0, height / 2, width);
}