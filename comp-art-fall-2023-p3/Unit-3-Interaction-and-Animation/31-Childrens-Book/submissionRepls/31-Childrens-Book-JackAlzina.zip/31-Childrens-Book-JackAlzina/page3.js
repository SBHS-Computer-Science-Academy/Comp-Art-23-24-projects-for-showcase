function drawPage3() {
  fill("black");
  textSize(40);
  text("After eating so much he felt tired and took a nap. After his nap he awoken and became an amazing butterly. THE END ",24, 647,950);

  branch()
  catipillar()


function branch() {

  fill("SaddleBrown");
  beginShape();
  vertex(1, 398);
  vertex(933, -2);
  vertex(998, 0);
  vertex(999, 75);
  vertex(0, 520);
  endShape();
  beginShape();
  vertex(497, 290);
  vertex(666, 381);
  vertex(694, 542);
  vertex(711, 545);
  vertex(682, 383);
  vertex(884, 535);
  vertex(899, 532);
  vertex(689, 371);
  vertex(606, 326);
  vertex(771, 306);
  vertex(763, 290);
  vertex(597, 313);
  vertex(542, 278);
  endShape();

}

function catipillar() {
  fill("blue");
  beginShape();//wings
  vertex(475, 144);
  vertex(486, 113);
  vertex(498, 100);
  vertex(525, 72);
  vertex(537, 65);
  vertex(553, 58);
  vertex(575, 60);
  vertex(586, 71);
  vertex(584, 90);
  vertex(572, 93);
  vertex(578, 100);
  vertex(568, 108);
  vertex(573, 114);
  vertex(563, 121);
  vertex(567, 124);
  vertex(556, 137);
  vertex(554, 140);
  vertex(556, 145);
  vertex(550, 149);
  vertex(553, 154);
  vertex(542, 154);
  vertex(474, 145);
  endShape();
  beginShape();
  
  vertex(475, 145);
  vertex(522, 151);
  vertex(536, 162);
  vertex(545, 176);
  vertex(545, 190);
  vertex(533, 189);
  vertex(534, 193);
  vertex(536, 204);
  vertex(531, 214);
  vertex(526, 214);
  vertex(524, 223);
  vertex(523, 229);
  vertex(516, 231);
  vertex(505, 226);
  vertex(505, 242);
  vertex(487, 235);
  vertex(496, 244);
  vertex(479, 257);
  vertex(466, 260);
  vertex(452, 256);
  vertex(447, 244);
  vertex(447, 222);
  vertex(449, 180);
  vertex(474, 145);
  endShape();
  beginShape();
  vertex(424, 179);
  vertex(408, 147);
  vertex(346, 145);
  vertex(333, 169);
  vertex(341, 172);
  vertex(333, 181);
  vertex(322, 193);
  vertex(323, 196);
  vertex(334, 206);
  vertex(334, 221);
  vertex(325, 238);
  vertex(332, 252);
  vertex(349, 254);
  vertex(350, 259);
  vertex(359, 263);
  vertex(368, 266);
  vertex(382, 261);
  vertex(389, 252);
  vertex(401, 246);
  vertex(424, 177);
  endShape();
  beginShape();
  
  vertex(407, 147);
  vertex(417, 111);
  vertex(402, 61);
  vertex(385, 44);
  vertex(357, 43);
  vertex(339, 53);
  vertex(323, 72);
  vertex(332, 75);
  vertex(326, 80);
  vertex(334, 92);
  vertex(323, 104);
  vertex(326, 115);
  vertex(334, 123);
  vertex(323, 135);
  vertex(315, 143);
  vertex(312, 148);
  vertex(352, 145);
  vertex(406, 146);
  endShape();
  fill("black");
  beginShape();//head
  vertex(432, 103);
  vertex(457, 105);
  vertex(441, 222);
  vertex(417, 220);
  vertex(432, 102);
  endShape();
  beginShape();
  vertex(418, 189);
  vertex(457, 170);
  vertex(485, 86);
  vertex(514, 58);
  vertex(549, 43);
  vertex(580, 40);
  vertex(600, 52);
  vertex(605, 64);
  vertex(586, 73);
  vertex(576, 61);
  vertex(553, 58);
  vertex(527, 70);
  vertex(485, 114);
  vertex(476, 142);
  vertex(459, 164);
  endShape();
 
  beginShape();
  
  vertex(464, 147);
  vertex(452, 142);
  vertex(440, 220);
  vertex(446, 234);
  vertex(450, 177);
  vertex(469, 149);
  endShape();
  beginShape();

  vertex(428, 138);
  vertex(405, 146);
  vertex(422, 172);
  vertex(410, 220);
  vertex(422, 218);
  vertex(428, 140);
  endShape();
  beginShape();
  
  vertex(407, 146);
  vertex(416, 110);
  vertex(401, 61);
  vertex(384, 45);
  vertex(357, 44);
  vertex(339, 54);
  vertex(323, 71);
  vertex(310, 69);
  vertex(326, 47);
  vertex(350, 35);
  vertex(384, 32);
  vertex(409, 47);
  vertex(426, 100);
  vertex(421, 139);
  vertex(408, 144);
  endShape();
  beginShape();// intenas
  vertex(454, 105);
  vertex(449, 103);
  vertex(457, 65);
  vertex(480, 41);
  vertex(491, 37);
  vertex(492, 38);
  vertex(481, 42);
  vertex(458, 66);
  vertex(451, 104);
  endShape();
  beginShape();//intenas
 
  vertex(441, 104);
  vertex(441, 66);
  vertex(430, 41);
  vertex(419, 33);
  vertex(418, 35);
  vertex(427, 41);
  vertex(438, 67);
  vertex(438, 104);
  endShape();
  fill("yellow");
  circle(448, 113, 15)
  circle(436, 113, 15)
  fill("green");//eyes
  circle(436, 113, 10)
  circle(448, 113, 10)
  fill("red");
  beginShape();
  vertex(459, 138);
  vertex(450, 132);
  vertex(452, 135);
  vertex(449, 141);
  vertex(446, 142);
  vertex(439, 144);
  vertex(432, 142);
  vertex(428, 139);
  vertex(429, 136);
  vertex(431, 133);
  vertex(433, 135);
  vertex(440, 135);
  vertex(442, 135);
  vertex(447, 134);
  vertex(449, 132);
  endShape();
}
  
}