function drawPage0() {

  setColor(316,60,109,46);
  text("The ",385, 80);
  setColor(176, 203,117,50)
  
  text("Very ",246, 221);
  setColor(277, 405,197,60)
  text("Hungry ",387, 428);
  setColor(421, 586,280,62)
  text("caterpillar ",571, 610);
  setColor(619, 723,379,70)
  text("by Jack Alzina ",825, 757);

  branch()

  leaves()
  push()
translate(-200 ,100)
  catipillar()
  pop()

  function setColor(x, y, w, h) {
    if (mouseIsInRect(x, y, w, h)) { fill("black"); 
                                      }
    else fill("red")
  }
  function mouseIsInRect(x, y, w, h, showLines = true) {
  if(showLines) {
  stroke('black');
  noFill();
  rect(x, y, w, h);
  
  }
  
  return mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;
  }
  function leaves(){

    fill("forestGreen");
    ellipse(702, 544, 45,88);
     ellipse(917, 530, 85,48);
     ellipse(768, 295, 105,58);
    line(821, 293, 716, 301);
    line(787, 296, 800, 273);
    line(788, 297, 811, 312);
    line(775, 267,759, 299);
    line(759, 300,782, 324);
    line(723, 301,742, 269);
    line(723, 302,742, 321);
    line(696, 503,705, 588);
    line(703, 569,718, 577);
     line(689, 579,703, 570);
    line(723, 560,702, 553);
    line(702, 553,681, 564);
     line(700, 536,725, 545);
    line(700, 537,679, 547);
    line(698, 521,723, 527);
     line(698, 521,678, 533);
     line(960, 530,876, 526);
    line(903, 528,925, 507);
     line(915, 554,904, 528);
    line(946, 512,931, 529);
    line(945, 547,933, 530);
  }
}
