function drawPage2() {
  fill("black");
  textSize(40);
  text("Once the very hungry caterpillar found the leaves that he wanted to eat,he was so hungry that he ate all the leaves on the branch. ",24, 647,950);

  branch()
  catipillar()


function branch() {

  fill("SaddleBrown");
  beginShape();
  vertex(1, 398);
  vertex(933, -2);
  vertex(998, 0);
  vertex(999, 75);
  vertex(0, 520);
  endShape();
  beginShape();
  vertex(497, 290);
  vertex(666, 381);
  vertex(694, 542);
  vertex(711, 545);
  vertex(682, 383);
  vertex(884, 535);
  vertex(899, 532);
  vertex(689, 371);
  vertex(606, 326);
  vertex(771, 306);
  vertex(763, 290);
  vertex(597, 313);
  vertex(542, 278);
  endShape();

}

function catipillar() {
  fill("green");
  circle(578, 317, 80);//body
  
  circle(506, 276, 80);//body
  circle(534, 297, 80);//body
  fill("red");
  circle(612, 333, 50);//head
  fill("yellow");
  ellipse(605, 320, 10, 13);//eyes lids
  ellipse(626, 326, 10, 13);//eyes lids
  fill("green");
  ellipse(605, 320, 7, 10);//eyes
  ellipse(626, 326, 7, 10);//eyes
  circle(613, 341, 7);//mouth
  fill("black");
  line(603, 308, 605, 280);//intenas
  line(619, 310, 623, 281);//intenas
  line(476, 311, 492, 295);
  line(499, 297, 491, 302);
  line(551, 319,539, 337);
  line(548, 339, 555, 329);
  line(562, 337, 552, 354);
  line(574, 341, 573, 361);
}
}