function drawPage1() {

  if (mouseX > 275 && mouseX < 740) { fill("black"); 
                                    }


  textSize(40);
  text("Once upon a time the very hungry caterpillar was very hungry and wanted to eat some leaves. ", 24, 647, 950);
  branch()
  leaves()
  catipillar()

  function branch() {

    fill("SaddleBrown");
    beginShape();
    vertex(1, 398);
    vertex(933, -2);
    vertex(998, 0);
    vertex(999, 75);
    vertex(0, 520);
    endShape();
    beginShape();
    vertex(497, 290);
    vertex(666, 381);
    vertex(694, 542);
    vertex(711, 545);
    vertex(682, 383);
    vertex(884, 535);
    vertex(899, 532);
    vertex(689, 371);
    vertex(606, 326);
    vertex(771, 306);
    vertex(763, 290);
    vertex(597, 313);
    vertex(542, 278);
    endShape();

  }

  function catipillar() {
    fill("green");
    circle(381, 285, 50);//body
    circle(427, 264, 50);//body
    circle(334, 302, 50);//body
    fill("red");
    circle(447, 230, 50);//head
    fill("yellow");
    ellipse(439, 222, 10, 13);//eyes lids
    ellipse(459, 221, 10, 13);//eyes lids
    fill("green");
    ellipse(439, 222, 7, 10);//eyes
    ellipse(459, 221, 7, 10);//eyes
    circle(447, 241, 7);//mouth
    fill("black");
    line(428, 188, 433, 210);//intenas
    line(459, 209, 459, 186);//intenas
    line(327, 325, 325, 345);
    line(346, 343, 344, 324);
    line(420, 287, 421, 303);
    line(430, 302, 428, 288);
    line(436, 288, 440, 299);
    line(445, 283, 452, 296);
  }
  function leaves() {

    fill("forestGreen");
    ellipse(702, 544, 45, 88);
    ellipse(917, 530, 85, 48);
    ellipse(768, 295, 105, 58);
    line(821, 293, 716, 301);
    line(787, 296, 800, 273);
    line(788, 297, 811, 312);
    line(775, 267, 759, 299);
    line(759, 300, 782, 324);
    line(723, 301, 742, 269);
    line(723, 302, 742, 321);
    line(696, 503, 705, 588);
    line(703, 569, 718, 577);
    line(689, 579, 703, 570);
    line(723, 560, 702, 553);
    line(702, 553, 681, 564);
    line(700, 536, 725, 545);
    line(700, 537, 679, 547);
    line(698, 521, 723, 527);
    line(698, 521, 678, 533);
    line(960, 530, 876, 526);
    line(903, 528, 925, 507);
    line(915, 554, 904, 528);
    line(946, 512, 931, 529);
    line(945, 547, 933, 530);
  }
}