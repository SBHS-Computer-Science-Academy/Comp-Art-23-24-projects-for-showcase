 function drawPage2() {
   
   
   drawSaturn()
   drawUranus()
   drawNeptune()
fill('white')
   textSize(50)
   text("He saw Saturn and", 613, 108);
   textSize(20)
   text("Uranus" ,284, 410)
textSize(20)
   text("Neptune", 752, 759)
textSize(30)
   text("Before finally flying all the way home" ,280, 690)
textSize(30)
   text("And", 492, 540)
    drawRing()
 }



function drawSaturn() {
  circleGradient(205, 220,300, color('orange'), color('#a67130'), 10)

  circleGradient(205,227, 250, color('#c26608'), color("#965f27"))
}

function drawUranus() {
  circleGradient(284, 521, 200, color('#3073a6'), color('#7dc982'), 5)
}

function drawNeptune() {
  circleGradient(749, 651 ,190, color('#1350ba'), color('#1a335e'), 40)
}

function drawRing() {
  //fill("white");
  noFill();
  stroke('white')
  beginShape();
  curveVertex(49,280);
  curveVertex(49,280);
  curveVertex(12,327);
  curveVertex(397,185);
  curveVertex(351,164);
   curveVertex(351,164);
  endShape();
}

