 

 function drawPage1() {

   fill('white')
   textSize(45)
   text("He saw Earth", 184, 100);
   drawEarth()
   drawLand()
   drawLand2()
   drawLand3()
fill('white')
   text('He saw Mars', 336, 346);
   drawMars()

   drawBody()
   
   drawHead()
   
   drawRightWing()
   
   drawLeftWing()
   
   drawDetails()

   drawWindow()

   drawFire()
  
  fill("white")
   text("And Jupiter!", 717, 389)
   drawJupiter()

   
 }


function drawEarth() {
  fill('skyblue')
  circle(590, 148, 200)
}

function drawMars() {
 // fill(235, 46, 33)
  //circle(106,457, 150)
  circleGradient(106,457, 150, color('#ad8263'), color('#856752'), 5)
}

function drawBody() {
  fill("white");
  beginShape();
  vertex(217, 189);
  vertex(305, 248);
  vertex(286, 273);
  vertex(201, 215);
  vertex(219, 191);
  vertex(1, -178);
  endShape();
}

function drawHead() {
  fill("red");
  beginShape();
  vertex(286, 272);
  vertex(322, 281);
  vertex(304, 248);
  vertex(287, 272);
  endShape();
}

function drawRightWing() {
  fill("red");
  beginShape();
  vertex(219, 191);
  vertex(239, 165);
  vertex(261, 218);
  vertex(220, 190);
  endShape();
}
function drawLeftWing() {
  fill("red");
  beginShape();
  vertex(201, 216);
  vertex(185, 246);
  vertex(243, 244);
  endShape();
}

function drawDetails() {
  // fill("black");
  beginShape();
  vertex(227, 197);
  vertex(211, 221);
  vertex(202, 214);
  vertex(218, 190);
  vertex(227, 195);
  endShape();
}

function drawWindow() {
fill('black')
  
  circle(272,244,15)
}

function drawFire() {
  fill("orange");
  beginShape();
  vertex(215, 187);
  vertex(203, 158);
  vertex(199, 168);
  vertex(171, 144);
  vertex(180, 169);
  vertex(140, 169);
  vertex(178, 190);
  vertex(153, 196);
  vertex(202, 214);
  vertex(219, 190);
  endShape();
}

function drawLand() {
  fill("Green");
  beginShape();
  vertex(626, 57);
  vertex(608, 63);
  vertex(600, 71);
  vertex(591, 83);
  vertex(593, 100);
  vertex(596, 105);
  vertex(604, 108);
  vertex(615, 110);
  vertex(622, 110);
  vertex(623, 114);
  vertex(623, 119);
  vertex(623, 121);
  vertex(623, 126);
  vertex(624, 129);
  vertex(624, 130);
  vertex(633, 134);
  vertex(638, 133);
  vertex(643, 132);
  vertex(648, 133);
  vertex(653, 133);
  vertex(659, 133);
  vertex(665, 133);
  vertex(668, 134);
  vertex(672, 136);
  vertex(672, 136);
  vertex(672, 139);
  vertex(671, 142);
  vertex(670, 145);
  vertex(669, 147);
  vertex(669, 150);
  vertex(668, 154);
  vertex(672, 158);
  vertex(674, 160);
  vertex(677, 161);
  vertex(686, 163);
  vertex(690, 162);
  vertex(690, 157);
  vertex(689, 153);
  vertex(688, 148);
  vertex(689, 141);
  vertex(690, 139);
  vertex(689, 133);
  vertex(689, 129);
  vertex(687, 125);
  vertex(687, 123);
  vertex(685, 120);
  vertex(685, 117);
  vertex(684, 114);
  vertex(684, 113);
  vertex(676, 100);
  vertex(662, 79);
  vertex(655, 74);
  vertex(647, 66);
  vertex(632, 57);
  vertex(623, 57);

  endShape();
}

function drawLand2() {
  // fill("black");
  beginShape();
  vertex(491, 150);
  vertex(497, 141);
  vertex(507, 132);
  vertex(519, 137);
  vertex(529, 146);
  vertex(535, 164);
  vertex(549, 167);
  vertex(571, 177);
  vertex(572, 179);
  vertex(571, 182);
  vertex(563, 196);
  vertex(559, 200);
  vertex(562, 211);
  vertex(568, 216);
  vertex(575, 223);
  vertex(577, 231);
  vertex(577, 235);
  vertex(576, 238);
  vertex(566, 244);
  vertex(546, 238);
  vertex(538, 231);
  vertex(528, 227);
  vertex(520, 218);
  vertex(512, 211);
  vertex(507, 203);
  vertex(506, 200);
  vertex(503, 194);
  vertex(500, 189);
  vertex(499, 185);
  vertex(496, 180);
  vertex(495, 178);
  vertex(494, 173);
  vertex(493, 170);
  vertex(491, 164);
  vertex(490, 160);
  vertex(490, 152);
  endShape();
}

function drawLand3() {
  // fill("black");
  beginShape();
  vertex(626, 170);
  vertex(632, 170);
  vertex(640, 174);
  vertex(651, 179);
  vertex(658, 184);
  vertex(655, 192);
  vertex(649, 190);
  vertex(640, 179);
  vertex(634, 181);
  vertex(618, 185);
  vertex(610, 166);
  vertex(616, 154);
  vertex(620, 153);
  vertex(627, 153);
  vertex(629, 157);
  vertex(626, 168);
  vertex(625, 170);
  endShape();
}

function drawJupiter() {
  //circle(720, 605,380)

   circleGradient(720, 605,380, color('#a85b1e'), color('#8c7849'), 10)

  circleGradient(719,608,300, color('#b3541d'), color('#8c4616'))
}