function drawPage3() {
	

  drawbackground()
  drawpot()
  drawkid()

  fill("black");
  text("the kid looks for the eggs", 500,120)

}




function drawbackground() {
   fill("goldenrod");
  beginShape();
  vertex(0, 428);
  vertex(999, 427);
  vertex(997, 799);
  vertex(1, 799);
  vertex(0, 427);
  endShape();
  fill("skyblue");
  beginShape();
  vertex(1, 428);
  vertex(0, -1);
  vertex(996, 0);
  vertex(998, 426);
  vertex(1, 427);
  endShape();
}




function drawpot() {
   fill("black");
  beginShape();
  curveVertex(672, 525); // control point
  curveVertex(672, 525);
  curveVertex(635, 664);
  curveVertex(820, 672);
  curveVertex(786, 521);
  curveVertex(682, 505);
  curveVertex(633, 618);
  curveVertex(633, 618); // control point
  endShape();
  beginShape();
  vertex(665, 522);
  vertex(797, 526);
  vertex(796, 486);
  vertex(659, 487);
  vertex(659, 526);
  vertex(796, 526);
  endShape();
  fill("green");
  beginShape();
  curveVertex(673, 486); // control point
  curveVertex(673, 486);
  curveVertex(655, 442);
  curveVertex(681, 468);
  curveVertex(663, 391);
  curveVertex(698, 462);
  curveVertex(697, 396);
  curveVertex(712, 455);
  curveVertex(740, 397);
  curveVertex(728, 456);
  curveVertex(767, 395);
  curveVertex(755, 453);
  curveVertex(790, 416);
  curveVertex(766, 462);
  curveVertex(826, 437);
  curveVertex(772, 486);
  curveVertex(673, 487);
  curveVertex(673, 487); // control point
  endShape();
  fill("red")
  ellipse(669, 446,20,30)
  fill("yellow")
  ellipse(131,494,20,30)
  fill("orange")
  ellipse(306,613,20,30)
  fill("blue")
  ellipse(319,511,20,30)
}
function drawkid() {
   fill("tan");
  beginShape();
  curveVertex(497, 459); // control point
  curveVertex(497, 459);
  curveVertex(401, 518);
  curveVertex(499, 491);
  curveVertex(474, 530);
  curveVertex(450, 596);
  curveVertex(513, 527);
  curveVertex(535, 600);
  curveVertex(568, 482);
  curveVertex(658, 454);
  curveVertex(561, 446);
  curveVertex(497, 458);
  curveVertex(408, 511);
  curveVertex(408, 511); // control point
  endShape();
  fill("grey");
  beginShape();
  vertex(467, 473);
  vertex(470, 497);
  vertex(499, 491);
  vertex(494, 504);
  vertex(556, 509);
  vertex(574, 475);
  vertex(596, 467);
  vertex(592, 447);
  vertex(552, 445);
  vertex(547, 458);
  vertex(537, 461);
  vertex(528, 456);
  vertex(525, 449);
  vertex(496, 458);
  endShape();
  fill("brown");
  beginShape();
  vertex(494, 505);
  vertex(471, 533);
  vertex(501, 543);
  vertex(513, 533);
  vertex(519, 548);
  vertex(549, 546);
  vertex(556, 510);
  vertex(494, 504);
  endShape();
  fill("tan")
  circle(536,412,80)
  
}