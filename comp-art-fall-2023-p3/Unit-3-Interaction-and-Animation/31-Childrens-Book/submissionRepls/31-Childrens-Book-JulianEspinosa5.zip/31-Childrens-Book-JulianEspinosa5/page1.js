function drawPage1() {
  
  drawbackground()
  drawbed()
  fill("black");
  text("the easter bunny wakes up for easter", 500,127);

}

function drawbackground() {
  
}

function drawbed() {
  fill("red");
  beginShape();
  vertex(44, 429);
  vertex(42, 561);
  vertex(459, 560);
  vertex(457, 425);
  vertex(44, 428);
  endShape();
  fill("black");
  beginShape();
  vertex(43, 562);
  vertex(44, 667);
  vertex(87, 666);
  vertex(87, 562);
  vertex(43, 562);
  endShape();
  beginShape();
  vertex(415, 561);
  vertex(459, 561);
  vertex(458, 657);
  vertex(415, 657);
  vertex(415, 560);
  endShape();
  fill("blue");
  beginShape();
  vertex(149, 429);
  vertex(148, 561);
  vertex(459, 561);
  vertex(456, 424);
  vertex(149, 427);
  vertex(148, 560);
  endShape();
  fill("pink");
  beginShape();
  vertex(148, 474);
  vertex(144, 469);
  vertex(138, 467);
  vertex(131, 465);
  vertex(119, 466);
  vertex(103, 468);
  vertex(97, 474);
  vertex(90, 488);
  vertex(90, 497);
  vertex(99, 509);
  vertex(106, 510);
  vertex(121, 513);
  vertex(130, 513);
  vertex(140, 511);
  vertex(147, 507);
  vertex(148, 507);
  vertex(148, 475);
  endShape();
  beginShape();
  vertex(95, 479);
  vertex(64, 454);
  vertex(60, 447);
  vertex(60, 444);
  vertex(63, 440);
  vertex(69, 439);
  vertex(75, 441);
  vertex(83, 447);
  vertex(88, 453);
  vertex(96, 460);
  vertex(102, 465);
  vertex(105, 468);
  vertex(102, 468);
  vertex(95, 475);
  vertex(95, 479);
  endShape();
  beginShape();
  vertex(90, 499);
  vertex(61, 517);
  vertex(56, 523);
  vertex(57, 527);
  vertex(58, 529);
  vertex(64, 529);
  vertex(68, 530);
  vertex(99, 509);
  vertex(91, 499);
  endShape();


  if (mouseIsInRect(101, 477, 30, 30)) fill("white");
  else fill("pink")
  beginShape();
  vertex(103, 481);
  vertex(107, 478);
  vertex(114, 479);
  vertex(116, 482);
  vertex(111, 486);
  vertex(104, 486);
  vertex(104, 481);
  endShape();
  beginShape();
  vertex(105, 494);
  vertex(113, 494);
  vertex(115, 498);
  vertex(113, 503);
  vertex(106, 501);
  vertex(105, 495);
  endShape();
}

function mouseIsInRect(x, y, w, h, showLines = false) {
  if (showLines) {
    stroke('black');
    noFill();
    rect(x, y, w, h);
  }
  return mouseX > x && mouseX < x + w && mouseY > y && mouseY < y + h;
}