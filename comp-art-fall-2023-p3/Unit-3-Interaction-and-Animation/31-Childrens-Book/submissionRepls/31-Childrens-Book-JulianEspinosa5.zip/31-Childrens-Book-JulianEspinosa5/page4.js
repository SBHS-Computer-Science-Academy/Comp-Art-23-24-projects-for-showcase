function drawPage4() {
	fill("black");

  drawbackground()
  drawplant()
  drawbunny2()
  fill("black");
  text("the easter bunny is sad easter is over", 500,120)

  
}






function drawbackground() {
   fill("goldenrod");
  beginShape();
  vertex(0, 428);
  vertex(999, 427);
  vertex(997, 799);
  vertex(1, 799);
  vertex(0, 427);
  endShape();
  fill("skyblue");
  beginShape();
  vertex(1, 428);
  vertex(0, -1);
  vertex(996, 0);
  vertex(998, 426);
  vertex(1, 427);
  endShape();
}




function drawplant() {
   fill("black");
  beginShape();
  curveVertex(672, 525); // control point
  curveVertex(672, 525);
  curveVertex(635, 664);
  curveVertex(820, 672);
  curveVertex(786, 521);
  curveVertex(682, 505);
  curveVertex(633, 618);
  curveVertex(633, 618); // control point
  endShape();
  beginShape();
  vertex(665, 522);
  vertex(797, 526);
  vertex(796, 486);
  vertex(659, 487);
  vertex(659, 526);
  vertex(796, 526);
  endShape();
  fill("green");
  beginShape();
  curveVertex(673, 486); // control point
  curveVertex(673, 486);
  curveVertex(655, 442);
  curveVertex(681, 468);
  curveVertex(663, 391);
  curveVertex(698, 462);
  curveVertex(697, 396);
  curveVertex(712, 455);
  curveVertex(740, 397);
  curveVertex(728, 456);
  curveVertex(767, 395);
  curveVertex(755, 453);
  curveVertex(790, 416);
  curveVertex(766, 462);
  curveVertex(826, 437);
  curveVertex(772, 486);
  curveVertex(673, 487);
  curveVertex(673, 487); // control point
  endShape();
  
}
function drawbunny2() {
   fill("pink");
  beginShape();
  curveVertex(420, 427); // control point
  curveVertex(420, 427);
  curveVertex(355, 657);
  curveVertex(473, 494);
  curveVertex(490, 657);
  curveVertex(550, 378);
  curveVertex(660, 444);
  curveVertex(582, 322);
  curveVertex(441, 304);
  curveVertex(327, 444);
  curveVertex(436, 357);
  curveVertex(415, 443);
  curveVertex(415, 443); // control point
  endShape();
  fill("pink")
  circle(510,255,100)
  fill("white");
  beginShape();
  curveVertex(510, 365); // control point
  curveVertex(510, 365);
  curveVertex(510, 365);
  curveVertex(503, 341);
  curveVertex(489, 350);
  curveVertex(469, 453);
  curveVertex(492, 450);
  curveVertex(510, 367);
  curveVertex(510, 367); // control point
  endShape();
  fill("pink");
  beginShape();
  curveVertex(470, 225); // control point
  curveVertex(470, 225);
  curveVertex(431, 190);
  curveVertex(384, 248);
  curveVertex(426, 166);
  curveVertex(477, 205);
  curveVertex(470, 225);
  curveVertex(470, 225); // control point
  endShape();
  beginShape();
  curveVertex(550, 225); // control point
  curveVertex(550, 225);
  curveVertex(590, 188);
  curveVertex(628, 249);
  curveVertex(601, 162);
  curveVertex(542, 205);
  curveVertex(550, 224);
  curveVertex(550, 224); // control point
  endShape();
  fill("white");
  beginShape();
  curveVertex(409, 461); // control point
  curveVertex(409, 461);
  curveVertex(396, 461);
  curveVertex(405, 453);
  curveVertex(392, 452);
  curveVertex(400, 441);
  curveVertex(395, 432);
  curveVertex(406, 439);
  curveVertex(405, 420);
  curveVertex(412, 427);
  curveVertex(414, 413);
  curveVertex(421, 425);
  curveVertex(409, 462);
  curveVertex(409, 462); // control point
  endShape();
  fill("black");
  beginShape();
  curveVertex(487, 279); // control point
  curveVertex(487, 279);
  curveVertex(499, 270);
  curveVertex(516, 272);
  curveVertex(526, 284);
  curveVertex(519, 263);
  curveVertex(496, 262);
  curveVertex(486, 280);
  curveVertex(486, 280); // control point
  endShape();
  beginShape();
  curveVertex(518, 242); // control point
  curveVertex(518, 242);
  curveVertex(528, 240);
  curveVertex(536, 245);
  curveVertex(529, 235);
  curveVertex(517, 243);
  curveVertex(517, 243); // control point
  endShape();
  beginShape();
  curveVertex(481, 243); // control point
  curveVertex(481, 243);
  curveVertex(492, 237);
  curveVertex(503, 242);
  curveVertex(491, 233);
  curveVertex(481, 243);
  curveVertex(481, 243); // control point
  endShape();
}
