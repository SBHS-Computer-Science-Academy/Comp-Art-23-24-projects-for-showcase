function drawPage0() {

  drawback()
  fill("black")
text("the easter bunny",500,200)
  text("by julian e",500,300)
}


function drawback() {
   fill("yellow");
  beginShape();
  vertex(1, 0);
  vertex(1, 798);
  vertex(998, 798);
  vertex(997, 1);
  vertex(1, 0);
  endShape();
}