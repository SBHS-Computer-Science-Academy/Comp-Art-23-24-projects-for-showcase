function drawTitle(){

  color1 = color('purple')
  color2 = color('yellow')
  gradientHorizontal(color1, color2, 200)
  textSize(50)
  textFont("Comic Sans MS");
  text("The Pencil", 350, 350, 300, 100)
}



function gradientHorizontal(clrStart, clrEnd, steps ) {
  noStroke()
  let StepSiz = height/steps
  for ( let f = 0; f <=height; f+=StepSiz){
    fill(lerpColor(clrStart, clrEnd, f/width))
    rect(0, f, width, StepSiz)
  }
}