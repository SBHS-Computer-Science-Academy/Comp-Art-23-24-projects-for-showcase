let bgv = 1
function drawPage4() {



  if (bgv == 1) {
    fill(135, 206, 235)
    rect(0, 0, 1000, 800)

    fill(233, 227, 220)
    beginShape();
    vertex(-7, 563);
    vertex(331, 189);
    vertex(1007, 515);
    vertex(1030, 645);
    vertex(11, 664);
    endShape();
    background1()
    fill(0, 30)
    beginShape();
    vertex(334, 190);
    vertex(432, 585);
    vertex(4, 585);
    vertex(2, 558);
    vertex(331, 188);
    endShape();
    fill('white')
    beginShape();
    vertex(308, 213);
    vertex(338, 212);
    vertex(363, 205);
    vertex(331, 187);
    vertex(311, 210);
    endShape();
    fill('silver')
    beginShape();
    vertex(286, 554);
    vertex(546, 554);
    vertex(544, 421);
    vertex(298, 420);
    vertex(242, 482);
    vertex(242, 552);
    vertex(296, 554);
    endShape();
    fill(0)
    beginShape();
    vertex(242, 482);
    vertex(308, 483);
    vertex(311, 419);
    vertex(296, 421);
    vertex(243, 482);
    endShape();
    fill('black')
    ellipse(300, 555, 60, 60)
    fill("silver")
    ellipse(299, 555, 20, 20)
    fill('black')
    fill('black')
    ellipse(500, 555, 60, 60)
    fill("silver")
    ellipse(500, 555, 20, 20)
    fill('black')
    beginShape();
    fill(250, 230, 50)
    ellipse(908, 74, 100, 100)
    textFont("Comic Sans MS");
    fill('black')
    textSize(20);
    text("Pencil will soon embark on very long journey", 468, 84)
  }
  if (bgv == 0) {
    background2()
    fill('white')
    text("Travelling far and wide", 468, 84)

  }

}

function background1() {

  fill('grey')
  rect(0, 586, 1000, 214)
  fill('black')
  textSize(40)
  textFont("Comic Sans MS");

  text("Press up and down arrows", 400, 673)
}
function background2() {
  fill('black')
  rect(0, 0, 1000, 800)
  star()
  fill('silver')

  fill('grey')
  rect(0, 586, 1000, 214)
  text("Press up and down arrows", 400, 673)
  fill('silver')

  fill('silver')
  beginShape();
  vertex(286, 554);
  vertex(546, 554);
  vertex(544, 421);
  vertex(298, 420);
  vertex(242, 482);
  vertex(242, 552);
  vertex(296, 554);
  endShape();
  fill(0)
  beginShape();
  vertex(242, 482);
  vertex(308, 483);
  vertex(311, 419);
  vertex(296, 421);
  vertex(243, 482);
  endShape();
  fill('black')
  ellipse(300, 555, 60, 60)
  fill("silver")
  ellipse(299, 555, 20, 20)
  fill('black')
  fill('black')
  ellipse(500, 555, 60, 60)
  fill("silver")
  ellipse(500, 555, 20, 20)
  fill('black')
  fill('yellow')
  beginShape();
  beginShape();
  vertex(227, 500);
  vertex(0, 432);
  vertex(2, 579);
  vertex(229, 545);
  endShape();
}

function parameter() {
  numStar = random(30, 200)
  for (let v = 0; v <= numStar; v += 1) {
    starS.push(random(2, 5));
    starX.push(random(width));
    starY.push(random(height));
  }
}

function star() {
  for (let v = 0; v < numStar; v += 1) {
    fill('white')
    circle(starX[v], starY[v], starS[v])
  }
}
