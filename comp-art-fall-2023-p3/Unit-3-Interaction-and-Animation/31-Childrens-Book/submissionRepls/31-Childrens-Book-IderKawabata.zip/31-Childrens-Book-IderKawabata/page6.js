function drawPage6() {

  fill('tan')
  rect(0, 0, 1000, 800)
  textFont("Comic Sans MS");
  fill('black')
  textSize(25);
  text("And he will decide that his passion in life is art,", 500, 60)
   text("and create many drawings.", 500, 100)
  textSize(50)
  text("Click", 500, 720)
  fill('white')
  stroke('black')
  quad(492, 232, 754, 336, 593, 649, 334, 550)
  fill(219, 183, 187)
  beginShape();
  vertex(245, 541);
  vertex(273, 554);
  vertex(283, 537);
  vertex(253, 522);
  vertex(245, 541);
  endShape();
  fill(132, 135, 137)
  beginShape();
  vertex(254, 523);
  vertex(260, 511);
  vertex(285, 524);
  vertex(280, 536);
  vertex(255, 524);
  endShape();
  fill(221, 143, 14)
  beginShape();
  vertex(259, 510);
  vertex(353, 314);
  vertex(384, 328);
  vertex(288, 526);
  vertex(259, 510);
  endShape();
  fill(196, 164, 132)
  beginShape();
  vertex(353, 313);
  vertex(383, 282);
  vertex(384, 328);
  vertex(354, 314);
  endShape();
  fill(132, 135, 137)
  beginShape();
  vertex(370, 297);
  vertex(383, 303);
  vertex(384, 282);
  vertex(369, 297);
  endShape();
  if (changeDrawing == 0) {
    draw1()
  } else if (changeDrawing == 1) {
    draw2()
  }
}


function draw1() {
  fill('yellow')
  circle(550, 400, 70)
  fill(0)
  beginShape();
  vertex(549, 447);
  vertex(553, 488);
  endShape();
  beginShape();
  vertex(370, 453);
  vertex(513, 426);
 
  endShape();
  beginShape();
  vertex(507, 391);
  vertex(450, 386);
  endShape();
  beginShape()
  vertex(591, 412);
  vertex(648, 415);
  endShape();
  beginShape();
  vertex(592, 375);
  vertex(630, 344);
  endShape();
  beginShape();
  vertex(529, 354);
  vertex(514, 326);
  endShape();
}
function draw2() {
  fill('black')
  beginShape();
  vertex(492, 315);
  vertex(499, 287);
  vertex(493, 300);
  vertex(493, 307);
  vertex(493, 313);
  vertex(496, 319);
  vertex(497, 324);
  vertex(499, 334);
  vertex(502, 342);
  vertex(512, 348);
  vertex(519, 352);
  vertex(535, 357);
  vertex(545, 358);
  vertex(549, 356);
  vertex(555, 350);
  vertex(559, 346);
  vertex(561, 340);
  vertex(564, 339);
  vertex(572, 342);
  vertex(577, 346);
  vertex(581, 350);
  vertex(582, 360);
  vertex(582, 371);
  vertex(585, 379);
  vertex(593, 387);
  vertex(604, 395);
  vertex(643, 405);
  vertex(658, 405);
  vertex(666, 403);
  vertex(674, 392);
  vertex(676, 384);
  vertex(678, 378);
  vertex(670, 374);
  vertex(661, 370);
  vertex(654, 365);
  vertex(640, 359);
  vertex(629, 354);
  vertex(605, 342);
  vertex(589, 334);
  vertex(567, 324);
  vertex(547, 321);
  vertex(535, 317);
  vertex(522, 312);
  endShape();
  beginShape();
  vertex(445, 415);
  vertex(445, 416);
  vertex(443, 422);
  vertex(443, 429);
  vertex(446, 441);
  vertex(448, 451);
  vertex(452, 460);
  vertex(469, 479);
  vertex(478, 483);
  vertex(494, 491);
  vertex(520, 498);
  vertex(547, 501);
  vertex(576, 502);
  vertex(599, 499);
  vertex(616, 492);
  endShape();
}