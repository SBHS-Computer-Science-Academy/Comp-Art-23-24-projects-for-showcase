function drawPage5() {
  fill('tan')
  rect(0, 0, 1000, 800)
  fill("black");

  textFont("Comic Sans MS");
  textSize(36);
  textAlign(CENTER, CENTER);
  drawdoor()
  drawwindows()
  fill('black')
  text("But finally, pencil will arrive to his new home ", 550, 34);









}
function drawdoor() {
  fill(218, 188, 120);
  beginShape();
  vertex(207, 799);
  vertex(717, 799);
  vertex(718, -2);
  vertex(265, -7);
  vertex(258, 798);
  vertex(291, 798);
  vertex(335, 799);
  vertex(716, 800);
  endShape();
  fill("yellow");
  circle(659, 412, 50)
  fill(83, 53, 00)
  beginShape();
  vertex(318, 798);
  vertex(317, 664);
  vertex(439, 665);
  vertex(440, 798);
  vertex(319, 798);
  vertex(318, 728);
  endShape();
  fill("white")
  beginShape();
  vertex(349, 666);
  vertex(347, 710);
  vertex(403, 709);
  vertex(406, 666);
  vertex(348, 665);
  vertex(350, 677);
  endShape();
}
function drawwindows() {
  fill("skyblue");
  beginShape();
  vertex(844, -2);
  vertex(844, 304);
  vertex(1004, 305);
  vertex(1004, -2);
  vertex(843, -2);
  endShape()
}