function drawPage7(){
 if(changeD7==0){
   one()
 }else{
   
   two()


 }
}
function one(){
  fill('tan')
  rect(0, 0, 1000, 800)
  textFont("Comic Sans MS");
  fill('black')
  textSize(25);
  text("But, as a result, pencil will slowly fade away,", 271, 107)
  fill(221, 143, 14)
  beginShape();
  vertex(411, 347);
  vertex(417, 514);
  vertex(473, 513);
  vertex(461, 343);
  endShape();
  beginShape();
  vertex(411, 345);
  vertex(461, 344);
  vertex(429, 287);
  vertex(411, 345);
  endShape();
  fill(196, 164, 132)
  beginShape();
  vertex(411, 349);
  vertex(460, 344);
  vertex(428, 285);
  vertex(412, 347);
  endShape();
  fill(132,135,137)
  beginShape()
  vertex(423, 301);
  vertex(438, 303);
  vertex(429, 285);
  endShape()
  fill(219,183,187)
  beginShape();
  vertex(417, 514);
  vertex(417, 545);
  vertex(478, 540);
  vertex(472, 512);
  endShape();
  fill(132,135,137)
  beginShape();
  vertex(418, 528);
  vertex(476, 526);
  vertex(472, 511);
  vertex(417, 515);
  endShape();
  fill('black')
  text("Click", 500, 600)
}
function two(){
  fill('tan')
  rect(0,0, 1000, 800)
  fill('black')
  textSize(60)
  text("Until there is nothing",500, 400)
  
}
function three(){
  tint(255, 100); // Display at half opacity

  fill('tan')
  rect(0, 0, 1000, 800)
  textFont("Comic Sans MS");
  fill('black')
  textSize(25);
  text("But, as a result, pencil will slowly fade away,", 271, 107)
  fill(221, 143, 14)
  beginShape();
  vertex(411, 347);
  vertex(417, 514);
  vertex(473, 513);
  vertex(461, 343);
  endShape();
  beginShape();
  vertex(411, 345);
  vertex(461, 344);
  vertex(429, 287);
  vertex(411, 345);
  endShape();
  fill(196, 164, 132)
  beginShape();
  vertex(411, 349);
  vertex(460, 344);
  vertex(428, 285);
  vertex(412, 347);
  endShape();
  fill(132,135,137)
  beginShape()
  vertex(423, 301);
  vertex(438, 303);
  vertex(429, 285);
  endShape()
  fill(219,183,187)
  beginShape();
  vertex(417, 514);
  vertex(417, 545);
  vertex(478, 540);
  vertex(472, 512);
  endShape();
  fill(132,135,137)
  beginShape();
  vertex(418, 528);
  vertex(476, 526);
  vertex(472, 511);
  vertex(417, 515);
  endShape();
  fill('black')
  text("Click", 500, 600)
  tint(255, 100); // Display at half opacity

}