

function drawPage8() {
  fill(197, 236, 250)
  rect(0, 0, 1000, 800)


  fill('green')
  rect(0, 600, 1000, 400)
  windowsss()

  drawrandsuns()
  sssmoke()
  maine()
  factoryi()
  windowsss()
  text22()
}

function drawrandsuns() {
  noStroke()
  m += n
  fill('yellow')
  ellipse(0 + m, 100, 100)
  if (m > 1000) {
    n = -10
  } else if (m < 0) {
    n = 10
  }

}

function factoryi() {
  fill(173, 68, 29)
  beginShape();
  vertex(368, 599);
  vertex(362, 440);
  vertex(559, 438);
  vertex(564, 603);
  vertex(368, 601);
  endShape();
}
function maine() {
  fill(145, 79, 54)
  beginShape();
  vertex(563, 598);
  vertex(554, 291);
  vertex(996, 288);
  vertex(1001, 606);
  vertex(566, 607);
  vertex(566, 599);
  endShape();
}
function windowsss() {
  for (let v = 0; v < 8; v += 1) {
    for (let m = 0; m < 6; m += 1) {
      stroke('black')
      fill('white')
      rect(617 + v * 21, 350 + m * 20, 20, 20)
    }
  }
}
function sssmoke() {
  fill('grey')
  beginShape();
  vertex(913, 299);
  vertex(908, 30);
  vertex(969, 28);
  vertex(971, 297);
  vertex(913, 298);
  endShape();
}
function text22() {
  fill('black')
  textSize(50)
  textFont("Comic Sans MS");
  text("But when", 20, 107, 300, 100)
  text("One story ends", 15, 200, 300, 100)
  text("", 23, 263, 300, 100)
  text("Another begins", 23, 326, 300, 100)
}


