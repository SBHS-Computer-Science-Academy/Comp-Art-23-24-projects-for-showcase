
function drawPage2() {
  fill(197, 236, 250)
  rect(0, 0, 1000, 800)


  fill('green')
  rect(0, 600, 1000, 400)
  windows()

  drawrandsun()
  smoke()
  main()
  factory()
  windows()
  text2()
}

function drawrandsun() {
  noStroke()
  i += x
  fill('yellow')
  ellipse(0 + i, 100, 100)
  if (i > 1000) {
    x = -10
  } else if (i < 0) {
    x = 10
  }

}

function factory() {
  fill(173, 68, 29)
  beginShape();
  vertex(368, 599);
  vertex(362, 440);
  vertex(559, 438);
  vertex(564, 603);
  vertex(368, 601);
  endShape();
}
function main() {
  fill(145, 79, 54)
  beginShape();
  vertex(563, 598);
  vertex(554, 291);
  vertex(996, 288);
  vertex(1001, 606);
  vertex(566, 607);
  vertex(566, 599);
  endShape();
}
function windows() {
  for (let v = 0; v < 8; v += 1) {
    for (let m = 0; m < 6; m += 1) {
      stroke('black')
      fill('white')
      rect(617 + v * 21, 350 + m * 20, 20, 20)
    }
  }
}
function smoke() {
  fill('grey')
  beginShape();
  vertex(913, 299);
  vertex(908, 30);
  vertex(969, 28);
  vertex(971, 297);
  vertex(913, 298);
  endShape();
}
function text2() {
  fill('black')
  textSize(50)
  textFont("Comic Sans MS");
  text("Pencil's ", 44, 137, 300, 100)
  text("Story", 15, 200, 300, 100)
  text("Starts", 23, 263, 300, 100)
  text("Here", 23, 326, 300, 100)
}

