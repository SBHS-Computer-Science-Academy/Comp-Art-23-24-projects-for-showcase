function drawBackground() {
  background('pink');
}
function drawPage0() {
  drawBackground();
  if (mouseIsInRect(235,390,530,40, false)) {
    fill("black");
  } else fill("red");
  textSize(50);
  text("The Very Spoiled Boy", 500, height / 2);
  drawHead();
  drawNose();
  drawMouth();
  drawSkin();
  drawShirt();
  drawPants();
  drawBoyHair();
}
function mouseIsInRect(x, y, w, h, showLines = true) {
  if(showLines) {
  stroke('black')
  noFill()
  rect(x, y, w, h);
  }
  let rightX = x + w;
  let bottomY = y + h;
  return mouseX > x && mouseX < rightX && mouseY > y && mouseY < bottomY;
}
function drawHead() {
  fill('wheat');
  circle(475, 612, 80);
  fill('green');
  circle(460,600,15);
  circle(490,600,15);
  fill('black');
  circle(460,600,5);
  circle(490,600,5);
  fill('saddleBrown');
  bezier(454,588,470,593,470,590,454,585,453,589);
  bezier(492,584,495,587,482,592,481,589,492,584)
}
function drawNose() {
  noFill();
  beginShape();
  curveVertex(474, 608); // control point
  curveVertex(474, 608);
  curveVertex(475, 615);
  curveVertex(474, 618);
  curveVertex(473, 621);
  curveVertex(468, 622);
  curveVertex(467, 625);
  curveVertex(468, 629);
  curveVertex(471, 629);
  curveVertex(473, 629);
  curveVertex(476, 628);
  curveVertex(478, 626);
  curveVertex(479, 625);
  curveVertex(482, 626);
  curveVertex(482, 626); // control point
  endShape();
}
function drawMouth() {
  fill(201, 30, 62);
  beginShape();
  curveVertex(457, 645); // control point
  curveVertex(457, 645);
  curveVertex(459, 640);
  curveVertex(463, 637);
  curveVertex(468, 635);
  curveVertex(476, 634);
  curveVertex(487, 634);
  curveVertex(497, 642);
  curveVertex(487, 641);
  curveVertex(477, 641);
  curveVertex(467, 643);
  curveVertex(457, 645);
  curveVertex(457, 645); // control point
  endShape();
}
function drawSkin() {
  fill("Wheat");
  beginShape();
  vertex(490, 651);
  vertex(491, 658);
  vertex(492, 666);
  vertex(490, 671);
  vertex(486, 672);
  vertex(479, 672);
  vertex(471, 670);
  vertex(469, 667);
  vertex(467, 663);
  vertex(466, 659);
  vertex(466, 652);
  vertex(468, 652);
  vertex(477, 652);
  vertex(490, 649);
  endShape();
   beginShape();
    vertex(444, 696);
    vertex(439, 718);
    vertex(423, 721);
    vertex(417, 726);
    vertex(421, 730);
    vertex(434, 726);
    vertex(431, 730);
    vertex(427, 736);
    vertex(429, 739);
    vertex(440, 731);
    vertex(439, 738);
    vertex(439, 744);
    vertex(442, 744);
    vertex(446, 732);
    vertex(449, 739);
    vertex(454, 740);
    vertex(455, 735);
    vertex(449, 729);
    vertex(458, 731);
    vertex(462, 728);
    vertex(458, 725);
    vertex(448, 719);
    vertex(456, 697);
    endShape();
  beginShape();
  vertex(511, 696);
  vertex(513, 714);
  vertex(510, 720);
  vertex(506, 728);
  vertex(510, 730);
  vertex(514, 720);
  vertex(515, 731);
  vertex(518, 733);
  vertex(520, 731);
  vertex(518, 719);
  vertex(524, 726);
  vertex(527, 728);
  vertex(528, 726);
  vertex(523, 716);
  vertex(531, 722);
  vertex(533, 722);
  vertex(533, 719);
  vertex(527, 713);
  vertex(536, 718);
  vertex(537, 716);
  vertex(535, 711);
  vertex(525, 707);
  vertex(523, 695);
  endShape();
  }
function drawShirt() {
  fill("green");
  beginShape();
  vertex(470, 671);
  vertex(460, 677);
  vertex(449, 683);
  vertex(441, 694);
  vertex(455, 696);
  vertex(462, 696);
  vertex(468, 689);
  vertex(466, 737);
  vertex(503, 735);
  vertex(496, 686);
  vertex(507, 694);
  vertex(525, 694);
  vertex(514, 681);
  vertex(504, 676);
  vertex(490, 670);
  endShape();
}
function drawPants() {
  fill("blue");
  beginShape();
  vertex(467, 738);
  vertex(464, 800);
  vertex(481, 800);
  vertex(483, 764);
  vertex(493, 800);
  vertex(511, 799);
  vertex(502, 735);
  vertex(467, 738);
  endShape();
}
function drawBoyHair() {
  fill("SaddleBrown");
  beginShape();
  vertex(446, 586);
  vertex(442, 575);
  vertex(439, 569);
  vertex(433, 569);
  vertex(425, 570);
  vertex(424, 574);
  vertex(427, 575);
  vertex(428, 574);
  vertex(433, 573);
  vertex(437, 577);
  vertex(442, 588);
  vertex(447, 585);
  vertex(445, 576);
  vertex(445, 572);
  vertex(446, 566);
  vertex(450, 561);
  vertex(454, 563);
  vertex(450, 566);
  vertex(449, 571);
  vertex(449, 577);
  vertex(449, 582);
  vertex(447, 584);
  vertex(453, 579);
  vertex(455, 572);
  vertex(455, 567);
  vertex(455, 564);
  vertex(457, 561);
  vertex(460, 561);
  vertex(458, 566);
  vertex(460, 570);
  vertex(459, 574);
  vertex(453, 578);
  vertex(460, 575);
  vertex(464, 574);
  vertex(466, 570);
  vertex(466, 562);
  vertex(467, 558);
  vertex(470, 557);
  vertex(470, 558);
  vertex(470, 561);
  vertex(470, 564);
  vertex(470, 566);
  vertex(470, 569);
  vertex(469, 571);
  vertex(466, 574);
  vertex(475, 572);
  vertex(475, 568);
  vertex(476, 564);
  vertex(477, 560);
  vertex(479, 558);
  vertex(487, 557);
  vertex(487, 560);
  vertex(483, 560);
  vertex(479, 563);
  vertex(479, 566);
  vertex(478, 569);
  vertex(477, 572);
  vertex(475, 572);
  vertex(483, 573);
  vertex(484, 572);
  vertex(485, 570);
  vertex(485, 568);
  vertex(486, 566);
  vertex(488, 563);
  vertex(495, 560);
  vertex(497, 560);
  vertex(496, 564);
  vertex(491, 565);
  vertex(490, 566);
  vertex(486, 570);
  vertex(486, 573);
  vertex(484, 573);
  vertex(493, 577);
  vertex(497, 575);
  vertex(497, 574);
  vertex(499, 570);
  vertex(503, 566);
  vertex(507, 565);
  vertex(507, 568);
  vertex(503, 569);
  vertex(503, 572);
  vertex(501, 576);
  vertex(500, 578);
  vertex(499, 580);
  vertex(498, 581);
  vertex(493, 578);
  vertex(498, 581);
  vertex(503, 585);
  vertex(508, 583);
  vertex(511, 580);
  vertex(514, 575);
  vertex(514, 571);
  vertex(520, 575);
  vertex(517, 576);
  vertex(515, 579);
  vertex(514, 582);
  vertex(510, 587);
  vertex(510, 589);
  vertex(508, 590);
  vertex(503, 585);
  endShape();
}