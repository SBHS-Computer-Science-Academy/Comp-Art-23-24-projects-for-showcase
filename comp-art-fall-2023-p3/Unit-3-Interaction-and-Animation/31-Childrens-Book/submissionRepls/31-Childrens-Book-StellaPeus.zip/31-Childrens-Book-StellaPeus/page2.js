function drawPage2() {
	background(227, 222, 218,471);
  if (mouseIsInRect(716,49,263,309, false)) {
    fill("black");
  } else fill("red");
  text("So, the next day the boy's mother came home with a brand new pair of shoes. The boy was not happy with this. He said, 'I don't want shoes, I want something else!'", 716,49,263,309)
  drawFloor();
  drawFridge();
  drawStove();
  drawCup();
  drawPot();
  drawClock();
  drawNewshoes();
  drawTopshoe();
  drawDetails();
  drawhead();
  drawnose();
  drawmouth();
  drawhair();
  drawskin();
  drawshirt();
  drawpants();
  drawShoes();
  drawMomshirt();
  drawSkirt();

  function mouseIsInRect(x, y, w, h, showLines = true) {
    if(showLines) {
    stroke('black')
    noFill()
    rect(x, y, w, h);
    }
    let rightX = x + w;
    let bottomY = y + h;
    return mouseX > x && mouseX < rightX && mouseY > y && mouseY < bottomY;
  }
function drawFridge() {
  fill('lightblue');
  rect(29,258,160,411);
}
function drawStove() {
  fill(181, 181, 148);
  rect(189,434,311,31)
  fill('Saddlebrown');
  rect(189,465,311,205)
  fill('red');
  circle(201,452,5)
  fill('green');
  circle(214,452,5)
  fill('black');
  circle(227,452,5)
  fill('lightblue');
  rect(209,509,75,92)
  fill(181,181,148);
  rect(318,505,46,43)
  fill(181,181,148);
  rect(317,587,50,43)
  rect(389,506,38,154)
  rect(449,507,38,154)
}
function drawCup() {
  fill(222, 189, 89);
  beginShape();
  vertex(384, 399);
  vertex(386, 409);
  vertex(387, 416);
  vertex(390, 423);
  vertex(392, 428);
  vertex(397, 435);
  vertex(421, 435);
  vertex(426, 429);
  vertex(428, 422);
  vertex(429, 415);
  vertex(430, 398);
  vertex(383, 399);
  endShape();
  beginShape();
  vertex(386, 407);
  vertex(378, 407);
  vertex(375, 408);
  vertex(372, 413);
  vertex(371, 418);
  vertex(374, 422);
  vertex(380, 424);
  vertex(386, 424);
  vertex(391, 423);
  vertex(390, 419);
  vertex(386, 419);
  vertex(382, 419);
  vertex(379, 418);
  vertex(378, 416);
  vertex(380, 415);
  vertex(384, 413);
  vertex(387, 413);
  vertex(390, 414);
  endShape();

}
function drawPot() {
  fill("grey");
  beginShape();
  vertex(209, 381);
  vertex(209, 389);
  vertex(210, 401);
  vertex(213, 412);
  vertex(218, 424);
  vertex(226, 435);
  vertex(269, 435);
  vertex(278, 424);
  vertex(279, 418);
  vertex(285, 409);
  vertex(287, 402);
  vertex(288, 390);
  vertex(288, 379);
  vertex(207, 381);
  endShape();
  beginShape();
  vertex(285, 390);
  vertex(295, 385);
  vertex(295, 385);
  vertex(301, 379);
  vertex(304, 373);
  vertex(312, 371);
  vertex(311, 381);
  vertex(307, 389);
  vertex(302, 395);
  vertex(280, 402);
  endShape();
}
function drawClock() {
  fill("orange");
  circle(318,183,110);
  fill('black');
  circle(318,183,10)
}
function drawNewshoes() {
  fill('blue');
  stroke('black');
  ellipse(512,479,65,30)
  ellipse(510,495,65,30)
}
function drawTopshoe() {
  fill("white");
  beginShape();
  vertex(499, 467);
  vertex(500, 482);
  vertex(493, 483);
  vertex(486, 486);
  vertex(483, 488);
  vertex(482, 485);
  vertex(481, 481);
  vertex(481, 477);
  vertex(483, 472);
  vertex(487, 470);
  vertex(499, 465);
  endShape();
  beginShape();
  vertex(501, 484);
  vertex(500, 510);
  vertex(496, 510);
  vertex(490, 508);
  vertex(483, 504);
  vertex(480, 501);
  vertex(478, 498);
  vertex(478, 496);
  vertex(479, 493);
  vertex(482, 490);
  vertex(487, 487);
  vertex(501, 482);
  endShape();
}
function drawDetails() {
  strokeWeight(3);
  stroke('black');
  line(29,355,189,355)
  line(30,383,189,383)
  line(49,295,49,322)
  line(49,414,49,470)
  fill('blue');
  rect(30,358,158,24)
  stroke('black');
  line(84,373,135,373)
  line(211,491,285,491)
  line(305,435,305,672)
  line(319,490,361,490)
  line(307,558,378,558)
  line(317,572,369,572)
  line(378,467,378,671)
  line(440,466,440,670)
  line(390,489,426,489)
  line(450,489,487,489)
  fill('black');
  ellipse(247,375,80,20)
  strokeWeight(2);
  stroke('black');
  noFill();
  line(319,188,326,208)
  line(318,181,285,156)
  line(499,468,518,480)
  line(518,480,530,465)
  line(530,465,538,487)
}
function drawFloor() {
  fill(128, 70, 9);
  noStroke();
  rect(0, 667, 1000, 800);
}
function drawhead() {
  fill('Wheat');
  noStroke();
  circle(281,441,80);
  fill('green');
  circle(267,429,15);
  circle(296,429,15);
  fill('black');
  circle(267,429,5);
  circle(297,429,5);
  fill("Saddlebrown");
  quad(261,413,276,418,274,422,259,417,261,413);
  quad(296,411,283,418,286,421,299,414,296,411);
  fill("Wheat");
  circle(580,296,80);
  fill('green');
  circle(565,285,15);
  circle(594,285,15);
  fill('black');
  circle(565,285,5);
  circle(594,285,5);
  fill("Saddlebrown");
  quad(557,275,573,270,570,267,556,272,557,274);
  quad(584,269,602,275,603,271,585,265,584,270);
}
function drawnose() {
  stroke('black');
  strokeWeight(2);
  noFill();
  beginShape();
  vertex(281, 436);
  vertex(281, 442);
  vertex(279, 447);
  vertex(275, 448);
  vertex(272, 454);
  vertex(276, 457);
  vertex(280, 457);
  vertex(284, 455);
  vertex(287, 455);
  endShape();
  beginShape();
  vertex(579, 292);
  vertex(579, 298);
  vertex(576, 303);
  vertex(573, 305);
  vertex(570, 308);
  vertex(570, 311);
  vertex(575, 313);
  vertex(583, 312);
  endShape();
  }
function drawmouth() {
  fill(201, 30, 62);
  noStroke();
  beginShape();
  vertex(259, 470);
  vertex(261, 468);
  vertex(265, 466);
  vertex(271, 465);
  vertex(279, 464);
  vertex(284, 464);
  vertex(290, 464);
  vertex(296, 466);
  vertex(304, 471);
  vertex(295, 470);
  vertex(286, 469);
  vertex(278, 468);
  vertex(272, 468);
  vertex(266, 469);
  vertex(258, 470);
  endShape();
  beginShape();
  vertex(557, 313);
  vertex(566, 318);
  vertex(575, 319);
  vertex(584, 319);
  vertex(596, 312);
  vertex(596, 319);
  vertex(593, 326);
  vertex(586, 328);
  vertex(577, 329);
  vertex(567, 327);
  vertex(561, 321);
  vertex(557, 313);
  endShape();
  }
function drawhair() {
  fill("Saddlebrown");
  beginShape();
  vertex(252, 414);
  vertex(248, 411);
  vertex(239, 406);
  vertex(234, 409);
  vertex(228, 405);
  vertex(225, 402);
  vertex(225, 399);
  vertex(230, 403);
  vertex(236, 401);
  vertex(243, 401);
  vertex(255, 411);
  vertex(250, 415);
  endShape();
  beginShape();
  vertex(259, 407);
  vertex(255, 401);
  vertex(250, 399);
  vertex(244, 396);
  vertex(238, 395);
  vertex(235, 391);
  vertex(239, 391);
  vertex(241, 394);
  vertex(248, 394);
  vertex(256, 398);
  vertex(264, 404);
  vertex(259, 407);
  endShape();
  beginShape();
  vertex(269, 402);
  vertex(266, 398);
  vertex(261, 393);
  vertex(254, 388);
  vertex(254, 380);
  vertex(257, 379);
  vertex(259, 386);
  vertex(263, 390);
  vertex(271, 398);
  vertex(273, 401);
  vertex(268, 403);
  endShape();
  beginShape();
  vertex(268, 402);
  vertex(267, 397);
  vertex(267, 397);
  vertex(267, 397);
  vertex(262, 390);
  vertex(255, 387);
  vertex(252, 382);
  vertex(254, 380);
  vertex(259, 385);
  vertex(264, 388);
  vertex(272, 400);
  vertex(273, 402);
  vertex(267, 404);
  endShape();
  beginShape();
  vertex(279, 401);
  vertex(277, 397);
  vertex(274, 392);
  vertex(272, 388);
  vertex(266, 379);
  vertex(265, 374);
  vertex(269, 374);
  vertex(270, 379);
  vertex(274, 383);
  vertex(278, 391);
  vertex(284, 399);
  vertex(284, 402);
  vertex(279, 402);
  endShape();
  beginShape();
  vertex(289, 401);
  vertex(288, 397);
  vertex(288, 392);
  vertex(285, 385);
  vertex(285, 379);
  vertex(285, 372);
  vertex(290, 374);
  vertex(288, 380);
  vertex(292, 392);
  vertex(292, 404);
  vertex(288, 401);
  endShape();
  beginShape();
  vertex(287, 402);
  vertex(289, 395);
  vertex(289, 391);
  vertex(286, 386);
  vertex(286, 379);
  vertex(291, 371);
  vertex(293, 372);
  vertex(290, 377);
  vertex(290, 382);
  vertex(293, 389);
  vertex(290, 404);
  vertex(286, 402);
  endShape();
  beginShape();
  vertex(297, 405);
  vertex(300, 398);
  vertex(298, 393);
  vertex(300, 389);
  vertex(300, 381);
  vertex(305, 374);
  vertex(309, 376);
  vertex(304, 382);
  vertex(303, 390);
  vertex(303, 393);
  vertex(304, 401);
  vertex(300, 406);
  vertex(296, 406);
  endShape();
  beginShape();
  vertex(297, 404);
  vertex(303, 393);
  vertex(299, 386);
  vertex(303, 377);
  vertex(310, 375);
  vertex(311, 378);
  vertex(306, 381);
  vertex(303, 386);
  vertex(307, 394);
  vertex(300, 405);
  vertex(295, 404);
  endShape();
  beginShape();
  vertex(305, 410);
  vertex(312, 405);
  vertex(312, 396);
  vertex(312, 384);
  vertex(318, 379);
  vertex(321, 383);
  vertex(315, 386);
  vertex(316, 403);
  vertex(316, 407);
  vertex(308, 412);
  vertex(305, 410);
  endShape();
  beginShape();
  vertex(306, 410);
  vertex(312, 406);
  vertex(312, 399);
  vertex(312, 390);
  vertex(319, 381);
  vertex(323, 385);
  vertex(315, 392);
  vertex(315, 406);
  vertex(315, 410);
  vertex(307, 413);
  vertex(305, 410);
  endShape();
  beginShape();
  vertex(311, 417);
  vertex(318, 415);
  vertex(321, 407);
  vertex(321, 399);
  vertex(330, 389);
  vertex(331, 393);
  vertex(324, 401);
  vertex(323, 417);
  vertex(314, 420);
  vertex(311, 418);
  endShape();
  beginShape();
  vertex(311, 416);
  vertex(322, 416);
  vertex(322, 409);
  vertex(335, 396);
  vertex(340, 400);
  vertex(325, 411);
  vertex(325, 420);
  vertex(313, 420);
  vertex(310, 416);
  endShape();
  beginShape();
  vertex(576, 257);
  vertex(572, 250);
  vertex(561, 247);
  vertex(547, 249);
  vertex(538, 255);
  vertex(530, 274);
  vertex(527, 294);
  vertex(525, 305);
  vertex(520, 319);
  vertex(514, 326);
  vertex(505, 324);
  vertex(500, 313);
  vertex(494, 310);
  vertex(494, 325);
  vertex(500, 331);
  vertex(515, 336);
  vertex(523, 337);
  vertex(530, 336);
  vertex(540, 334);
  vertex(549, 323);
  vertex(544, 308);
  vertex(541, 296);
  vertex(543, 281);
  vertex(553, 267);
  vertex(576, 257);
  vertex(584, 246);
  vertex(590, 244);
  vertex(600, 245);
  vertex(605, 249);
  vertex(613, 258);
  vertex(620, 265);
  vertex(624, 274);
  vertex(626, 284);
  vertex(627, 291);
  vertex(629, 298);
  vertex(630, 303);
  vertex(634, 310);
  vertex(639, 311);
  vertex(648, 313);
  vertex(656, 312);
  vertex(659, 301);
  vertex(659, 297);
  vertex(661, 297);
  vertex(662, 309);
  vertex(662, 315);
  vertex(661, 320);
  vertex(655, 324);
  vertex(652, 325);
  vertex(643, 326);
  vertex(636, 326);
  vertex(630, 326);
  vertex(626, 324);
  vertex(621, 321);
  vertex(617, 318);
  vertex(615, 315);
  vertex(619, 307);
  vertex(619, 300);
  vertex(619, 291);
  vertex(618, 279);
  vertex(613, 272);
  vertex(604, 264);
  vertex(596, 260);
  vertex(582, 255);
  vertex(574, 257);
  endShape();
}
function drawskin() {
  fill("Wheat");
  beginShape();
  vertex(274, 480);
  vertex(274, 494);
  vertex(279, 499);
  vertex(283, 501);
  vertex(288, 501);
  vertex(292, 499);
  vertex(295, 493);
  vertex(295, 479);
  vertex(274, 481);
  endShape();
  beginShape();
  vertex(244, 521);
  vertex(226, 539);
  vertex(214, 537);
  vertex(207, 537);
  vertex(201, 540);
  vertex(201, 544);
  vertex(211, 543);
  vertex(201, 548);
  vertex(199, 552);
  vertex(199, 554);
  vertex(202, 555);
  vertex(212, 548);
  vertex(206, 555);
  vertex(205, 559);
  vertex(207, 562);
  vertex(208, 559);
  vertex(216, 550);
  vertex(212, 559);
  vertex(212, 566);
  vertex(214, 567);
  vertex(215, 561);
  vertex(221, 549);
  vertex(221, 561);
  vertex(223, 565);
  vertex(225, 565);
  vertex(225, 559);
  vertex(227, 547);
  vertex(251, 530);
  vertex(244, 522);
  endShape();
  beginShape();
  vertex(323, 526);
  vertex(336, 540);
  vertex(336, 549);
  vertex(336, 555);
  vertex(340, 556);
  vertex(341, 543);
  vertex(348, 554);
  vertex(350, 551);
  vertex(345, 542);
  vertex(353, 547);
  vertex(354, 544);
  vertex(346, 537);
  vertex(358, 538);
  vertex(358, 534);
  vertex(346, 533);
  vertex(356, 530);
  vertex(356, 528);
  vertex(341, 529);
  vertex(330, 520);
  endShape();
  beginShape();
  vertex(575, 337);
  vertex(574, 346);
  vertex(572, 351);
  vertex(574, 354);
  vertex(576, 356);
  vertex(582, 357);
  vertex(589, 356);
  vertex(592, 352);
  vertex(591, 345);
  vertex(590, 335);
  endShape();
  beginShape();
  vertex(524, 460);
  vertex(514, 462);
  vertex(508, 467);
  vertex(502, 475);
  vertex(504, 476);
  vertex(518, 471);
  vertex(515, 477);
  vertex(514, 484);
  vertex(522, 475);
  vertex(523, 486);
  vertex(529, 487);
  vertex(528, 476);
  vertex(535, 485);
  vertex(541, 484);
  vertex(536, 472);
  vertex(547, 480);
  vertex(552, 476);
  vertex(544, 458);
  vertex(528, 458);
  vertex(525, 459);
  endShape();
  beginShape();
  vertex(632, 452);
  vertex(630, 461);
  vertex(628, 466);
  vertex(631, 469);
  vertex(636, 460);
  vertex(636, 472);
  vertex(639, 473);
  vertex(640, 461);
  vertex(645, 473);
  vertex(649, 473);
  vertex(646, 462);
  vertex(656, 472);
  vertex(661, 472);
  vertex(652, 461);
  vertex(663, 467);
  vertex(665, 463);
  vertex(652, 451);
  vertex(634, 452);
  endShape();
}
function drawshirt() {
  fill('green');
  beginShape();
  vertex(273, 494);
  vertex(243, 518);
  vertex(254, 535);
  vertex(269, 519);
  vertex(269, 562);
  vertex(312, 561);
  vertex(303, 515);
  vertex(320, 528);
  vertex(334, 516);
  vertex(294, 493);
  vertex(292, 497);
  vertex(292, 500);
  vertex(287, 501);
  vertex(282, 502);
  vertex(274, 495);
  endShape();  
}
function drawpants() {
  fill("blue");
  beginShape();
  vertex(269, 563);
  vertex(262, 657);
  vertex(283, 657);
  vertex(291, 586);
  vertex(305, 657);
  vertex(328, 656);
  vertex(311, 561);
  vertex(268, 562);
  endShape();
}
function drawShoes() {
  fill("brown");
  beginShape();
  vertex(328, 656);
  vertex(340, 655);
  vertex(344, 657);
  vertex(348, 663);
  vertex(348, 668);
  vertex(305, 667);
  vertex(305, 658);
  endShape();
  beginShape();
  vertex(283, 657);
  vertex(283, 667);
  vertex(242, 667);
  vertex(241, 662);
  vertex(242, 659);
  vertex(247, 655);
  vertex(261, 655);
  endShape();
}
function drawMomshirt() {
  fill("pink");
  beginShape();
  vertex(573, 353);
  vertex(563, 356);
  vertex(555, 356);
  vertex(546, 365);
  vertex(536, 379);
  vertex(525, 433);
  vertex(523, 458);
  vertex(543, 457);
  vertex(547, 438);
  vertex(547, 428);
  vertex(549, 418);
  vertex(553, 408);
  vertex(557, 398);
  vertex(563, 391);
  vertex(567, 389);
  vertex(566, 465);
  vertex(612, 466);
  vertex(606, 389);
  vertex(614, 393);
  vertex(617, 401);
  vertex(620, 410);
  vertex(623, 418);
  vertex(625, 427);
  vertex(627, 439);
  vertex(629, 449);
  vertex(631, 452);
  vertex(652, 450);
  vertex(651, 433);
  vertex(647, 421);
  vertex(641, 403);
  vertex(637, 389);
  vertex(631, 378);
  vertex(624, 368);
  vertex(618, 360);
  vertex(610, 353);
  vertex(597, 351);
  vertex(591, 351);
  vertex(590, 357);
  vertex(580, 357);
  vertex(574, 354);
  endShape();
}
function drawSkirt() {
  fill("purple");
  beginShape();
  vertex(566, 466);
  vertex(560, 469);
  vertex(555, 481);
  vertex(550, 504);
  vertex(547, 538);
  vertex(545, 561);
  vertex(543, 602);
  vertex(542, 619);
  vertex(535, 668);
  vertex(675, 669);
  vertex(674, 643);
  vertex(673, 637);
  vertex(669, 619);
  vertex(667, 609);
  vertex(662, 578);
  vertex(656, 560);
  vertex(645, 536);
  vertex(640, 521);
  vertex(634, 492);
  vertex(621, 470);
  vertex(610, 466);
  vertex(564, 465);
  endShape();
}
}