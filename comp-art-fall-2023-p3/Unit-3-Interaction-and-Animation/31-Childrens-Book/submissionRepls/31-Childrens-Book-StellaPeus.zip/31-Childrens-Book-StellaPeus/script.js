let page = 0;
let numPages = 6; 
let myFont;
/* 
To change the starting page, change the page variable below.

To add new pages:

3. Create a new File under the File menu at left.
4. Add the new file to index.html
5. In each new page file, add function drawPageN() {}

*/

function preload() {
	myFont = loadFont('PlaypenSans.ttf');
}

function setup() {

  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
 
  
  //createConsole("lines");

	textFont(myFont);
	textSize(50);
	textAlign(CENTER, CENTER);


}

function draw() {
	background("white");

  if (page == 0) drawPage0();
	if (page == 1) drawPage1();
	if (page == 2) drawPage2();
	if (page == 3) drawPage3();
  if (page == 4) drawPage4();
  if (page == 5) drawPage5();
  if (page == 6) drawPage6();


  drawMouseLines("black");
}

function keyPressed() {
  // clear();
  // text(key, 500, 150);
  if (key == "ArrowRight" && page < numPages) page += 1
  if (key == "ArrowLeft" && page > 0) page -= 1
} 
function keyReleased() {
  //text("Released", 500, 200);
}