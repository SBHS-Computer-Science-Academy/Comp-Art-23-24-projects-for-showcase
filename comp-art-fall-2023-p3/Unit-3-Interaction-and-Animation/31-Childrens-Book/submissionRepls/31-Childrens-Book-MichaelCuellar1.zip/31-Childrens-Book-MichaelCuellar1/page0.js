function drawPage0() {
 if(mouseIsInRect(191,323,622,152,false)) fill("black");
  else fill('green')
  text("Michaels Football Story", 0, height / 2, width);
}