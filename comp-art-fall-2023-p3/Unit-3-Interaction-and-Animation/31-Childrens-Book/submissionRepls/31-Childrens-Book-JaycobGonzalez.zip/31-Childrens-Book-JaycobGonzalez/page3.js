function drawPage3() {
	fill("black");
	text("Page 3 goes here", 0, height / 2, width);
}