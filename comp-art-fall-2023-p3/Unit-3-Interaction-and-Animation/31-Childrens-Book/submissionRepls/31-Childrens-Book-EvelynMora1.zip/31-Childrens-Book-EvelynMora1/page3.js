function drawPage3() {
background("PowderBlue")
 
  
  if (mouseIsInRect(117, 64, 852,100, false)) textSize(20)
  else textSize(30)
	text("Soon enough he finishes and Invited his whole family to try it out!", 487, 77);

drawMouse(36, 58)
drawMouse(44, 130)
drawMouse(117, 161)
drawMouse(211, 160)
drawMouse(318, 177)
drawMouse(418, 196);
drawMouse(505, 210);
drawMouse(596, 246)
drawMouse(685, 289)
drawMouse(751, 359)
drawMouse(702, 425)
drawMouse(622, 466)
drawMouse(546, 505)
drawMouse(465, 536)
drawMouse(426, 630)

 fill("BurlyWood")
  rect(70, 560, 300, 300)

  drawRoof()

  fill("sienna")
  rect(170, 680, 100, 300)
  
  }



function drawMouse(x,y,s=0.1){
  push()
  translate(x,y)
scale (s)
  translate(-382, -506)
  drawOutline()
  drawCookie()
  drawOveralls()
  draw1()
  draw2()
  draw3()
  draw4()
  draw5()
  draw6()
  drawEye1()
  drawEye2()
  drawNoseMouth()
  drawLeftEar()


  drawRightEar()
  pop()
  
}
function drawRoof() {
 fill("Sienna");
  beginShape();
  vertex(70, 560);
  vertex(221, 409);
  vertex(369, 559);
  vertex(70, 561);
  endShape();
}
