function drawPage1() {
  //draw()
  //preload()
  background("White");
  drawOutline()
  drawCookie()
  drawOveralls()
  draw1()
  draw2()
  draw3()
  draw4()
  draw5()
  draw6()
  drawEye1()
  drawEye2()
  drawNoseMouth()
  drawLeftEar()
  drawRightEar()
 
  
  
  
  
  //function draw() {
  if (mouseIsInRect(8, 126, 991, 130, false)) textSize(60)
  else textSize(90)
  fill("black");
text("If you give a mouse a cookie...", 500, 160);
 //    img.resize(width, 0);
 //    image(kitchen, 100, 300)
}

//function preload(){
//kitchen = loadImage ( "kitchen.jpeg" );
