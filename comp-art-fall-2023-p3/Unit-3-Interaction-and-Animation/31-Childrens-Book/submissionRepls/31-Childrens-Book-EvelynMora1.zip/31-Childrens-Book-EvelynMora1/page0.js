function drawPage0(){
  drawPaper()
  drawOutline()
  drawCookie()
  drawOveralls()
  draw1()
  draw2()
  draw3()
  draw4()
  draw5()
  draw6()
  drawEye1()
  drawEye2()
  drawNoseMouth()
  drawLeftEar()
  drawRightEar()



  if (mouseIsInRect(6, 54, 510, 195, false )) textSize(60)
  else textSize(90)
  fill("black");
  text("If You Give A\n Mouse A Cookie", 250, 133);
img.resize(width, 0);
//image(img, 0, 0);

  }





function drawPaper() {
    fill("white");
  beginShape();
    vertex(543, 0);
    vertex(655, 458);
    vertex(-2, 522);
    vertex(-1, 2);
    vertex(540, -1);
    endShape();
  }
  function drawOutline() {
    fill("NavajoWhite");
 beginShape();
  curveVertex(253, 799); // control point
  curveVertex(253, 799);
  curveVertex(236, 743);
  curveVertex(101, 647);
  curveVertex(72, 626);
  curveVertex(129, 582);
  curveVertex(155, 629);
  curveVertex(218, 674);
  curveVertex(295, 662);
  curveVertex(297, 602);
  curveVertex(216, 542);
  curveVertex(200, 462);
  curveVertex(250, 412);
  curveVertex(341, 363);
  curveVertex(463, 400);
  curveVertex(502, 467);
  curveVertex(499, 516);
  curveVertex(453, 585);
  curveVertex(436, 620);
  curveVertex(437, 662);
  curveVertex(460, 671);
  curveVertex(513, 655);
  curveVertex(577, 606);
  curveVertex(608, 589);
  curveVertex(626, 587);
  curveVertex(631, 593);
  curveVertex(614, 603);
  curveVertex(603, 607);
  curveVertex(601, 635);
  curveVertex(586, 639);
  curveVertex(545, 664);
  curveVertex(502, 699);
  curveVertex(473, 727);
  curveVertex(480, 766);
  curveVertex(487, 798);
  curveVertex(487, 798); // control point
  endShape();
}

function drawCookie() {
  fill("BurlyWood");
  beginShape();
  curveVertex(604, 606); // control point
  curveVertex(604, 606);
  curveVertex(603, 638);
  curveVertex(620, 699);
  curveVertex(672, 738);
  curveVertex(770, 745);
  curveVertex(814, 732);
  curveVertex(841, 699);
  curveVertex(861, 643);
  curveVertex(861, 570);
  curveVertex(819, 507);
  curveVertex(735, 491);
  curveVertex(644, 519);
  curveVertex(605, 588);
  curveVertex(607, 587);
  curveVertex(607, 587); // control point
  endShape();
  fill ("SaddleBrown")
  circle (670,560,25)
  circle (733, 587, 30)
  circle (716, 524, 15)
  circle (676, 616, 20)
  circle(628, 592, 15)
  circle(625, 636, 30)
  circle(761, 538, 30)
  circle(788, 576, 15)
  circle(818, 544, 20)
  circle(797, 512, 10)
  circle(679, 519, 10)
  circle(642, 542, 10)
  circle(670, 664, 17)
  circle(721, 637, 21)
  circle(721, 637, 25)
  circle(650, 693, 17)
  circle(685, 715, 12)
  circle(705, 683, 24)
  circle(746, 722, 31)
  circle(757, 689, 15)
  circle(768, 653 ,10)
  circle(777, 620, 15)
  circle(817, 619, 17)
  circle(831, 587, 10)
  circle(808, 662, 32)
  circle(795, 705, 15)
}
function drawOveralls() {
  fill("SkyBlue");
  beginShape();
  vertex(262, 674);
  vertex(293, 728);
  vertex(295, 798);
  vertex(439, 798);
  vertex(432, 724);
  vertex(464, 672);
  vertex(447, 671);
  vertex(417, 717);
  vertex(304, 721);
  vertex(271, 671);
  vertex(263, 673);
  endShape();
}
function draw1() {
  noFill()
  beginShape();
  curveVertex(305, 483); // control point
  curveVertex(305, 483);
  curveVertex(292, 473);
  curveVertex(231, 465);
  curveVertex(190, 462);
  curveVertex(190, 462); // control point
  endShape();
}//left whiskers 
function draw2() {
  // fill("black");
  beginShape();
  curveVertex(306, 493); // control point
  curveVertex(306, 493);
  curveVertex(284, 486);
  curveVertex(223, 485);
  curveVertex(186, 495);
  curveVertex(186, 495); // control point
  endShape();
}
function draw3() {
  // fill("black");
  beginShape();
  curveVertex(309, 504); // control point
  curveVertex(309, 504);
  curveVertex(281, 502);
  curveVertex(234, 518);
  curveVertex(205, 532);
  curveVertex(205, 532); // control point
  endShape();
}
function draw4() {
  // fill("black");
  beginShape();
  curveVertex(477, 488); // control point
  curveVertex(477, 488);
  curveVertex(526, 462);
  curveVertex(598, 448);
  curveVertex(598, 448); // control point
  endShape();
}//right whiskers
function draw5() {
  // fill("black");
  beginShape();
  curveVertex(479, 500); // control point
  curveVertex(479, 500);
  curveVertex(526, 480);
  curveVertex(579, 471);
  curveVertex(614, 474);
  curveVertex(614, 474); // control point
  endShape();
}
function draw6() {
  // fill("black");
  beginShape();
  curveVertex(477, 510); // control point
  curveVertex(477, 510);
  curveVertex(517, 499);
  curveVertex(601, 502);
  curveVertex(601, 502); // control point
  endShape();
}
function drawEye1() {
  // fill("black");
  beginShape();
  curveVertex(344, 448); // control point
  curveVertex(344, 448);
  curveVertex(316, 443);
  curveVertex(292, 454);
  curveVertex(292, 454); // control point
  endShape();
}
function drawEye2() {
  // fill("black");
  beginShape();
  curveVertex(414, 446); // control point
  curveVertex(414, 446);
  curveVertex(430, 439);
  curveVertex(454, 436);
  curveVertex(454, 436); // control point
  endShape();
}
function drawNoseMouth() {
  fill("Pink");
  beginShape();
  curveVertex(397, 504); // control point
  curveVertex(397, 504);
  curveVertex(391, 500);
  curveVertex(370, 501);
  curveVertex(356, 490);
  curveVertex(359, 474);
  curveVertex(388, 461);
  curveVertex(410, 461);
  curveVertex(429, 470);
  curveVertex(434, 486);
  curveVertex(421, 500);
  curveVertex(403, 504);
  curveVertex(399, 519);
  curveVertex(400, 549);
  curveVertex(407, 562);
  curveVertex(418, 571);
  curveVertex(432, 569);
  curveVertex(418, 572);
  curveVertex(419, 576);
  curveVertex(418, 599);
  curveVertex(409, 608);
  curveVertex(389, 601);
  curveVertex(382, 568);
  curveVertex(369, 569);
  curveVertex(378, 565);
  curveVertex(389, 562);
  curveVertex(399, 549);
  curveVertex(397, 505);
  curveVertex(397, 505); // control point
  endShape();
}
function drawLeftEar() {
 fill("NavajoWhite");
  beginShape();
  curveVertex(200, 466); // control point
  curveVertex(200, 466);
  curveVertex(170, 452);
  curveVertex(146, 427);
  curveVertex(132, 402);
  curveVertex(125, 363);
  curveVertex(130, 327);
  curveVertex(146, 294);
  curveVertex(169, 286);
  curveVertex(195, 303);
  curveVertex(237, 320);
  curveVertex(257, 327);
  curveVertex(278, 346);
  curveVertex(289, 381);
  curveVertex(289, 381); // control point
  endShape();
}
function drawRightEar() {
  fill("NavajoWhite");
  beginShape();
  curveVertex(405, 373); // control point
  curveVertex(405, 373);
  curveVertex(435, 373);
  curveVertex(464, 343);
  curveVertex(495, 302);
  curveVertex(578, 253);
  curveVertex(585, 284);
  curveVertex(593, 314);
  curveVertex(595, 342);
  curveVertex(584, 380);
  curveVertex(557, 429);
  curveVertex(532, 452);
  curveVertex(495, 448);
  curveVertex(495, 448); // control point
  endShape();
}