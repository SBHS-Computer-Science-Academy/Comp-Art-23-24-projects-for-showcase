function drawPage2() {
	
  
background("SkyBlue");
  if (mouseIsInRect(40, 133, 952, 90, false)) textSize(50)
  else textSize(80)
  fill("black");
  
	text("Then he will ask for a glass of milk", 500, 160);
 
  drawOutline()
  drawGlass()
  drawMilk()
  drawOveralls()
  draw1()
  draw2()
  draw3()
  draw4()
  draw5()
  draw6()
  drawEye1()
  drawEye2()
  drawNoseMouth()
  drawLeftEar()
  drawRightEar()

}
function drawGlass() {
 noFill();
  beginShape();
  vertex(603, 607);
  vertex(602, 638);
  vertex(619, 742);
  vertex(762, 742);
  vertex(800, 512);
  vertex(579, 513);
  vertex(607, 671);
  vertex(590, 573);
  endShape();
}
function drawMilk() {
  fill("White");
  beginShape();
  vertex(590, 576);
  vertex(789, 576);
  vertex(762, 742);
  vertex(619, 742);
  vertex(590, 575);
  endShape();
}