function drawPage2() {
	fill("black");
 
drawBackground()
 
drawSpace()
drawStars()
  if(mouseX > 40&& mouseX < 864 && mouseY > 40 && mouseY < 140) fill("white");
  else fill("green")
  text("the red balloon flew into \n space and then poped then fell fast into the water", 0,   82, width);
drawOcean()
drawWHitecaps()
drawCaps()
fill("red")
circle(432,235,50)
drawString()
drawPop()
drawString2()
  


}
function drawBackground(){
background("lightskyblue")




}

function drawSpace() {
   fill("black");
  beginShape();
  vertex(0, 278);
  vertex(899, 282);
  vertex(899, -1);
  vertex(-2, 1);
  vertex(0, 277);
  endShape();
}

function drawOcean() {
   fill("blue");
  beginShape();
  vertex(-1, 697);
  vertex(900, 697);
  vertex(901, 800);
  vertex(0, 800);
  vertex(0, 696);
  endShape();
}

 function drawWHitecaps() {
   noFill();
   stroke("white")
   beginShape();
   curveVertex(14, 728); // control point
   curveVertex(14, 728);
   curveVertex(44, 761);
   curveVertex(71, 732);
   curveVertex(104, 766);
   curveVertex(128, 728);
   curveVertex(158, 763);
   curveVertex(193, 727);
   curveVertex(225, 763);
   curveVertex(246, 729);
   curveVertex(276, 763);
   curveVertex(294, 724);
   curveVertex(330, 763);
   curveVertex(354, 729);
   curveVertex(382, 759);
   curveVertex(402, 724);
   curveVertex(439, 757);
   curveVertex(466, 717);
   curveVertex(500, 752);
   curveVertex(523, 718);
   curveVertex(556, 743);
   curveVertex(581, 711);
   curveVertex(630, 749);
   curveVertex(647, 713);
   curveVertex(697, 744);
   curveVertex(708, 712);
   curveVertex(746, 746);
   curveVertex(762, 715);
   curveVertex(800, 740);
   curveVertex(826, 710);
   curveVertex(856, 742);
   curveVertex(882, 707);
   curveVertex(900, 727);
   curveVertex(900, 727); // control point
   endShape();
 }

function drawCaps() {
   noFill();
  stroke("white")
  beginShape();
  curveVertex(12, 723); // control point
  curveVertex(12, 723);
  curveVertex(36, 706);
  curveVertex(59, 724);
  curveVertex(82, 704);
  curveVertex(105, 727);
  curveVertex(137, 709);
  curveVertex(161, 729);
  curveVertex(181, 711);
  curveVertex(205, 728);
  curveVertex(224, 713);
  curveVertex(237, 729);
  curveVertex(255, 707);
  curveVertex(270, 727);
  curveVertex(289, 711);
  curveVertex(314, 728);
  curveVertex(336, 709);
  curveVertex(351, 724);
  curveVertex(366, 711);
  curveVertex(376, 730);
  curveVertex(394, 709);
  curveVertex(414, 721);
  curveVertex(433, 713);
  curveVertex(439, 722);
  curveVertex(458, 709);
  curveVertex(467, 716);
  curveVertex(477, 710);
  curveVertex(485, 720);
  curveVertex(494, 725);
  curveVertex(505, 706);
  curveVertex(522, 714);
  curveVertex(536, 704);
  curveVertex(547, 724);
  curveVertex(562, 706);
  curveVertex(574, 711);
  curveVertex(591, 702);
  curveVertex(614, 724);
  curveVertex(626, 706);
  curveVertex(634, 715);
  curveVertex(650, 703);
  curveVertex(669, 720);
  curveVertex(683, 701);
  curveVertex(696, 723);
  curveVertex(709, 704);
  curveVertex(736, 727);
  curveVertex(751, 701);
  curveVertex(789, 722);
  curveVertex(811, 703);
  curveVertex(817, 713);
  curveVertex(824, 702);
  curveVertex(850, 729);
  curveVertex(863, 702);
  curveVertex(871, 718);
  curveVertex(886, 696);
  curveVertex(896, 716);
  curveVertex(896, 716); // control point
  endShape();
}
function makeStars() {
  for (let i = 0; i < numStars; i += 1) {
    starX.push(random(width));
    starY.push(random(277))// push adds new number to end
    starD.push(random(3, 10));
  }
}
function drawStars() {
  for (let i = 0; i < numStars; i += 1) {
    fill("white")
    circle(starX[i], starY[i], starD[i]);



  }

}



function drawPop() {
  fill("red");
  beginShape();
  curveVertex(629, 440); // control point
  curveVertex(629, 440);
  curveVertex(630, 463);
  curveVertex(611, 466);
  curveVertex(606, 443);
  curveVertex(613, 444);
  curveVertex(618, 439);
  curveVertex(622, 442);
  curveVertex(629, 439);
  curveVertex(629, 439); // control point
  endShape();
}
function drawString2() {
   noFill("black");
  beginShape();
  curveVertex(620, 468); // control point
  curveVertex(620, 468);
  curveVertex(629, 475);
  curveVertex(623, 490);
  curveVertex(642, 494);
  curveVertex(632, 517);
  curveVertex(632, 517); // control point
  endShape();
}