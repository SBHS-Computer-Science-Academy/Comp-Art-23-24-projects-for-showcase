function drawPage0() {
  fill("black");
  drawBackround()
   if(mouseX > 335&& mouseX < 573 && mouseY > 40 && mouseY < 69) fill("black");
  else fill("green")
  text("The red balloon", 0, 52, width);


  drawString()
  drawSun()

  drawtop()
  drawtop2()
  drawSmoke()
  
  //stroke("black")
  drawTree()
  drawStar()
  drawStar2()
  fill("red")
  circle(414, 224, 50)
  drawDirt()

}
function drawSun() {
  fill("yellow");
  beginShape();
  curveVertex(-7, 131); // control point
  curveVertex(-7, 131);
  curveVertex(13, 130);
  curveVertex(59, 126);
  curveVertex(97, 98);
  curveVertex(118, 54);
  curveVertex(128, -8);
  curveVertex(128, -8); // control point
  endShape();

  fill("yellow");
  beginShape();
  vertex(127, -3);
  vertex(4, 1);
  vertex(1, 124);
  endShape();
}
function drawSmoke() {
  fill(0, 60)
  noStroke()
  circle(218, 612, 40);
  circle(208, 600, 40)
  circle(197, 608, 40)
}
function drawtop() {
  fill("gray");
  beginShape();
  vertex(69, 795);
  vertex(159, 632);
  vertex(240, 800);
  endShape();
}

function drawtop2() {
  fill("black");
  beginShape();
  vertex(194, 703);
  vertex(194, 642);
  vertex(218, 642);
  vertex(222, 760);
  endShape();
}

function drawTree() {
  fill("green");
  beginShape();
  vertex(458, 798);
  vertex(457, 771);
  vertex(432, 771);
  vertex(451, 745);
  vertex(427, 744);
  vertex(448, 716);
  vertex(422, 715);
  vertex(452, 685);
  vertex(423, 684);
  vertex(459, 644);
  vertex(496, 681);
  vertex(470, 682);
  vertex(496, 714);
  vertex(473, 714);
  vertex(495, 743);
  vertex(473, 743);
  vertex(496, 769);
  vertex(468, 770);
  vertex(471, 800);
  endShape();
}

function drawStar() {
  fill("gold");
  beginShape();
  vertex(447, 652);
  vertex(466, 625);
  vertex(442, 626);
  vertex(470, 644);
  vertex(447, 616);
  vertex(448, 648);
  endShape();
}
function drawStar2() {// part of star
  fill("gold");
  beginShape();
  vertex(447, 626);
  vertex(435, 626);
  vertex(449, 632);
  endShape();
}
function drawBackround() {
  background("lightskyblue");

}

function drawString() {
  noFill();
  noStroke();
  stroke("black")
  strokeWeight(2)
  beginShape();
  curveVertex(409, 249); // control point
  curveVertex(409, 249);
  curveVertex(390, 281);
  curveVertex(417, 319);
  curveVertex(368, 358);
  curveVertex(368, 358); // control point
  endShape();
}


function drawDirt() {
  fill("brown");
  beginShape();
  vertex(2, 782);
  vertex(897, 779);
  vertex(898, 800);
  vertex(1, 799);
  vertex(2, 782);
  endShape();
}

