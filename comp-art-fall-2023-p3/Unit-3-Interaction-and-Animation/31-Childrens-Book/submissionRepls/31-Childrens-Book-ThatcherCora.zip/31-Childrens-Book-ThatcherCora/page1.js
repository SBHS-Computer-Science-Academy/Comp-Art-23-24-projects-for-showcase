
function drawPage1() {
	fill("black");
	text("Page 1 goes here", 0, 50, width);
  drawBackround()
  fill("red")
  circle(815, 409, 45);
  if(mouseX > 39&& mouseX <876 && mouseY > 11 && mouseY < 123) fill("black");
  else fill("green")
  text("once upon a time there was a red balloon that was released it flewover santa barbara", 0, 53, width);

  drawBuilding()
  drawRoad()
  drawdash()
  drawDash2()
drawDash3()
drawDash4()
drawDash5()
drawDash6()
drawDash7()
drawDash8()
drawDash9()
drawDash10()
drawDash11()
circle(295,729,50)
circle(427,729,50)
drawCar()
circle(383,669,30)
  drawSurf()
drawSeat()
drawBoard()
drawStringl()
  
}



function drawBackround() {
  background("lightSkyBlue");
}
function drawBuilding() {
   fill("gray");
  beginShape();
  vertex(61, 445);
  vertex(52, 748);
  vertex(117, 751);
  vertex(127, 365);
  vertex(64, 361);
  vertex(59, 496);
  vertex(65, 327);
  vertex(159, 334);
  vertex(147, 744);
  vertex(117, 750);
  vertex(127, 365);
  vertex(158, 336);
  vertex(126, 365);
  vertex(63, 327);
  vertex(73, 359);
  endShape();
}
function drawRoad() {
   fill("black");
  beginShape();
  vertex(-7, 747);
  vertex(901, 749);
  vertex(900, 798);
  vertex(-3, 799);
  vertex(1, 746);
  endShape();
}
function drawdash() {
   fill("white");
  beginShape();
  vertex(1, 770);
  vertex(39, 770);
  vertex(37, 783);
  vertex(2, 781);
  vertex(2, 768);
  endShape();
}

function drawDash2() {
   fill("white");
  beginShape();
  vertex(90, 772);
  vertex(132, 772);
  vertex(131, 786);
  vertex(75, 784);
  vertex(75, 767);
  endShape();
}
function drawDash3() {
  fill("white");
  beginShape();
  vertex(176, 770);
  vertex(224, 771);
  vertex(223, 785);
  vertex(179, 786);
  vertex(178, 770);
  endShape();
}
function drawDash4() {
  fill("white");
  beginShape();
  vertex(257, 774);
  vertex(312, 774);
  vertex(311, 790);
  vertex(259, 788);
  vertex(259, 773);
  endShape();
}

function drawDash5() {
   fill("white");
  beginShape();
  vertex(355, 774);
  vertex(406, 772);
  vertex(405, 789);
  vertex(353, 792);
  vertex(355, 775);
  endShape();
}

function drawDash6() {
   fill("white");
  beginShape();
  vertex(436, 776);
  vertex(489, 776);
  vertex(489, 790);
  vertex(438, 789);
  vertex(437, 774);
  endShape();
}

function drawDash7() {
   fill("white");
  beginShape();
  vertex(514, 789);
  vertex(563, 789);
  vertex(558, 775);
  vertex(510, 774);
  vertex(514, 788);
  endShape();
}

function drawDash8() {
   fill("white");
  beginShape();
  vertex(601, 777);
  vertex(636, 777);
  vertex(636, 790);
  vertex(599, 790);
  vertex(601, 772);
  endShape();
}

function drawDash9() {
   fill("white");
  beginShape();
  vertex(672, 777);
  vertex(737, 777);
  vertex(738, 793);
  vertex(671, 792);
  vertex(671, 778);
  endShape();
}

function drawDash10() {
   fill("white");
  beginShape();
  vertex(672, 777);
  vertex(737, 777);
  vertex(738, 793);
  vertex(671, 792);
  vertex(671, 778);
  endShape();
}

function drawDash11() {
  fill("white");
  beginShape();
  vertex(807, 773);
  vertex(807, 793);
  vertex(866, 791);
  vertex(864, 769);
  vertex(810, 772);
  vertex(807, 773);
  endShape();
}

function drawCar() {
 noStroke() 
  fill("tan");
  beginShape();
  curveVertex(311, 710); // control point
  curveVertex(311, 710);
  curveVertex(405, 715);
  curveVertex(402, 728);
  curveVertex(309, 724);
  curveVertex(309, 650);
  curveVertex(407, 652);
  curveVertex(407, 711);
  curveVertex(407, 711); // control point
  endShape();



  fill("tan");
  beginShape();
  vertex(405, 706);
  vertex(409, 716);
  vertex(328, 711);
  vertex(405, 709);
  vertex(408, 718);
  endShape();
  fill("white")
}


function drawSurf() {
  fill("black");
  beginShape();
  vertex(314, 642);
  vertex(390, 643);
  vertex(390, 626);
  vertex(381, 640);
  vertex(302, 639);
  vertex(311, 641);
  endShape();
}

function drawSeat() {
   fill("black");
  beginShape();
  vertex(381, 680);
  vertex(379, 701);
  vertex(393, 702);
  vertex(393, 710);
  endShape();
}
function drawBoard() {
  fill("silver");
  beginShape();
  vertex(616, 749);
  vertex(620, 629);
  vertex(533, 629);
  vertex(538, 508);
  vertex(837, 512);
  vertex(835, 635);
  vertex(683, 630);
  vertex(680, 745);
  vertex(616, 745);
  endShape();
  fill("black");
  text("leaving \nsanta barbara", 670,571)
}

function drawStringl() {
   noFill("black");
  stroke("black");
  strokeWeight(2)
  beginShape();
  vertex(806, 431);
  vertex(754, 484);
  endShape();

}
