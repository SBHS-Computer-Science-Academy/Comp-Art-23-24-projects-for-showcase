function drawPage3() {
	fill("black");
  drawBackround()
  if(mouseX > 60&& mouseX < 890 && mouseY > 13 && mouseY <127) fill("green");
	text("fisherman grabs the balloon from water shark does not eat the balloon the end", 0,  50, width);
  text("arrow pointing to cloud ",342,372)
drawBlue()
drawShip()
circle(590,585,20)
drawLine()
  fill("red")
circle(453,666,30)
  fill("black")
drawShark()
  drawStarmm()
  noStroke()
  fill(125,231,255,100)
  circle(205,256,70,100)
  circle(250,220,70,150)
  circle(207,199,70,100)
  drawarrow()
}

function drawBlue() {
  fill("blue");
  beginShape();
  vertex(-5, 643);
  vertex(901, 644);
  vertex(900, 800);
  vertex(-5, 799);
  vertex(-1, 641);
  endShape();
}

function drawShip() {
   fill("black");
  beginShape();
  vertex(567, 642);
  vertex(540, 624);
  vertex(664, 624);
  vertex(664, 641);
  vertex(652, 645);
  vertex(563, 642);
  endShape();
}
function drawLine() {
  fill("black");
  beginShape();
  vertex(589, 601);
  vertex(589, 613);
  vertex(600, 629);
  vertex(588, 613);
  vertex(580, 627);
  endShape();

  
     fill("black");
    beginShape();
    vertex(589, 604);
    vertex(588, 592);
    endShape();
  fill("black");
  beginShape();
  vertex(582, 602);
  vertex(604, 600);
  endShape();
  noFill("");
  beginShape();
  vertex(582, 601);
  vertex(514, 569);
  vertex(465, 641);
  endShape();
  }

function drawShark() {
   fill("black");
  beginShape();
  vertex(432, 692);
  vertex(448, 706);
  vertex(464, 693);
  vertex(462, 720);
  vertex(488, 719);
  vertex(463, 733);
  vertex(462, 755);
  vertex(475, 776);
  vertex(402, 773);
  vertex(434, 756);
  vertex(432, 730);
  vertex(400, 733);
  vertex(425, 721);
  vertex(432, 694);
  vertex(441, 694);
  vertex(439, 700);
  vertex(446, 698);
  vertex(444, 704);
  vertex(450, 700);
  vertex(448, 705);
  vertex(451, 695);
  vertex(454, 700);
  vertex(455, 690);
  vertex(461, 695);
  endShape();
}
function drawBackround() {
  background("lightSkyBlue");
}

function drawStarmm() {
   fill("black");
  beginShape();
  vertex(52, 87);
  vertex(61, 104);
  vertex(66, 86);
  vertex(46, 98);
  vertex(71, 97);
  vertex(48, 87);
  endShape();
}

function drawarrow() {
   fill("black");
  beginShape();
  vertex(266, 276);
  vertex(361, 360);
  vertex(266, 274);
  vertex(253, 312);
  vertex(264, 274);
  vertex(346, 278);
  endShape();
}