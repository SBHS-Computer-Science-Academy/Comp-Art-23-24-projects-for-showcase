function setup() {
	let myCanvas = createCanvas(800, 600);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
	strokeWeight(1);
	background('orange');
  strokeWeight(0);
  fill(165);
  triangle(0, 400, 200, 100, 399, 350); //mountain1fill
  triangle(280, 200, 340, 275, 429, 206); //mountain2fill
  triangle(340, 275, 500, 152, 660, 293); //mountain3filltop
  triangle(340, 275, 488, 460, 660, 293); //mountain3fillbottom
  triangle(600, 351, 800, 160, 800, 600); //mountain4fill
  fill(255);
  triangle(145, 183, 200, 100, 263, 180); //mountain1snow
  triangle(280, 200, 350, 140, 429, 206); //mountain2snow
	triangle(413, 220, 500, 152, 577, 221); //mountain3snow
  fill('green');
  rect(0, 400, 800, 200);
  triangle(0, 400, 400, 350, 800, 400);
  triangle(400, 350, 800, 410, 800, 379); //grass fillings
  strokeWeight(1);
  beginShape();
	curveVertex(0, 600);
	curveVertex(0, 400);
	curveVertex(400, 350);
	curveVertex(800, 600);
	endShape(); //groundL
	beginShape();
	curveVertex(400, 350);
	curveVertex(400, 350);
	curveVertex(800, 380);
	curveVertex(800, 600);
	endShape(); //groundR
  fill('saddlebrown');
  square(180, 490, 40); //tree1trunk
  rect(480, 498, 35, 80); //tree2trunk
  fill('orchid');
  circle(200, 440, 140); //tree1leaves
  ellipse(500, 440, 180, 140); //tree2leaves
	noFill();
	line(0, 400, 200, 100); //mountain1L
	line(200, 100, 399, 350); //mountain1R
	fill(255);
  line(280, 200, 350, 140); //mountain2L
  line(350, 140, 429, 206); //mountain2R
  line(340, 275, 500, 152); //mountain3L
  line(500, 152, 660, 293); //mountain3R
	line(600, 351, 800, 160); //mountain4
  line(772, 251, 774, 249); //legL
  line(774, 249, 776, 252); //legR
  line(774, 249, 775, 246); //body
  line(775, 246, 778, 244); //armR
  line(775, 246, 772, 243); //armL
  circle(775, 245, 3); //head
}