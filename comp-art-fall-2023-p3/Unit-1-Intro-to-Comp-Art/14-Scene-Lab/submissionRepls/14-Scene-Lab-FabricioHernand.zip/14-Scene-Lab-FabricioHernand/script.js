function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("black");





  
  fill("grey");
  rect(0, 600, 1000, 200); // ground

  fill("yellow")
  quad(449,202,379,594,585, 593)//shadp

  
  noStroke();
  fill('Gainsboro')
  rect(230,135,30,600-135)
  ellipse(245,590,60,30)
circle(245,128,30)
square(429,170,485-429,5)
fill('black')
  circle(462,452,50)
  stroke('black')
  strokeWeight(4)
  line(460,545,431,580) //left leg
  line(462,545,495,576)// right leg
  line(462,478,462,543)// body 
  line(433,506,497,506)
  
  // quad(428, 174,438, 174,492, 200,492, 171)
  
  fill("black");
  stroke("gainsboro")
  strokeWeight(10)
  triangle(259, 137,455, 188,263, 251)
  

  
  // text("Make a Scene.  \nYou need at least a square, a circle, an ellipse, a rectangle, a triangle, and a stick figure.", 500, 400);
  
}