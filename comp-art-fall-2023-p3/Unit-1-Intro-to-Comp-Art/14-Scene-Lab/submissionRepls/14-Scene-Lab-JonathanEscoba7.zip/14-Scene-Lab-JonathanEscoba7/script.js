function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
background("skyblue");
fill("green")
  triangle(720,242,488,645,957,644)
  triangle(813,644,1003,316,1002,642)
  rect(2,644,1000,300)
fill("gold")
circle(26,28,200 );
  strokeWeight(10);
  stroke("gold")
line(94,131,212,256)
  line(276,154,140,76)
line(41,165,81,289)
  stroke(92, 64, 51)
  fill(92, 64, 51)
  rect(42,401,300,240)
  
  
  stroke("black")
  
  rect(148,515,70,125)
  rect(84,411,50,50)
  rect(266,411,50,50)
  triangle(391,398,1,398,176,291)
  fill(255,200)
noStroke()
  ellipse(503,148,150,60)
 
  ellipse(600,148,150,60)
  ellipse(551,120,150,60)
 
  ellipse(785,148,150,60)
  ellipse(875,148,150,60)
  ellipse(831,120,150,60)
  stroke("black")
  drawPerson(749, 476);
//stroke("black")
  
}

function drawPerson(x, y) {

  push()
  translate(x, y)
  scale(0.25)
  translate(-374,-396)
  fill("red")
  strokeWeight(100);
  line(359,1032,252,1229)
  line(404,1030,515,1229)
  line(433,759,608,868)
  line(332,759,138,868)
  strokeWeight(10);
 fill("black")
  rect(336,632,100,400)  
  fill("red");
  strokeWeight(20);
  circle(374,396,500 );
  strokeWeight(10);
  fill("white");
circle(240,329,100 );
circle(468,329,100 );
fill("black");
  circle(237,332,50 );
circle(470,333,50 );
circle(344,429,90 )
  strokeWeight(10);
line(315,331,227,242)
line(383,335,490,242)
  fill("white");
  ellipse(361,565,300,60)
  fill("black");
  rect(132,150,500,70)
  rect(230,100,300,50)
  pop();

  
  

}