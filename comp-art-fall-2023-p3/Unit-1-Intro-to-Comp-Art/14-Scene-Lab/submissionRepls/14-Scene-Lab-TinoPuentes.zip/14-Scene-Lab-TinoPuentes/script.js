function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("DeepskyBlue");
  
  fill("yellowGreen");
  rect(0, 600, 4000, 500); // ground
  fill('yellow')
ellipse(112, 100, 200, 200)
fill('grey')
triangle(3, 800, 375, 363, 584, 800, 1046, 237, 1044, 566)
triangle(550, 800, 997, 246, 1090, 800, 1049, 620)
fill('white')
ellipse(650, 240, 300, 100)
  fill('white')
ellipse(160, 350, 300, 100)
fill('DodgerBlue')
ellipse(500, 1030, 600, 300)
line(229, 49, 333, 46, 1077, 251)
line(230, 113, 319, 131, 1075, 425)
line(202, 173, 282, 214, 1081, 276)
line(147, 211, 162, 296, 1077, 540)
line(77, 216, 59, 294, 1071, 279)
line(17, 181, -3, 219, -3, 212, 0, 206, 1075, 339)
line(188, 15, 214, 6, 1081, 391)
line(31, 29, 2, 7, 1082, 203)
line(10, 91, 2, 89, 1082, 350)//sunrays
  fill('sienna')
  rect(774, 740, 807-774, 799-740)
  fill('green')
  circle(792, 693, 100, 100)
  fill('sienna')
  rect(259, 700, 40, 100)
  fill('green')
  circle(277, 700, 100, 100)
  fill('sienna')
  rect(530, 700, 40, 100)
  fill('green')
  circle(550, 680, 100, 100)
  fill('white')
  circle(403, 672, 30, 500)
  line(402, 687, 404, 728)
  line(387, 705, 420, 704)
  line(404, 729, 394, 763)
  line(405, 730, 424, 758)
  fill('sienna')
  rect(93, 765, 40, 799)
  fill('green')
  rect(75, 706, 80, 75)
  
  
  
  
  


  


  











  }