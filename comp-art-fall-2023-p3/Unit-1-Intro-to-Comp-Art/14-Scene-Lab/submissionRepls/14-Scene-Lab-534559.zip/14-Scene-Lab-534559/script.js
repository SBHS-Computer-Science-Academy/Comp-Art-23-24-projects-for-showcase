function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("skyblue");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  fill("SaddleBrown");
  triangle(15, 600,146, 239,324, 600)
triangle(223,600,516,53,712,600)
triangle(275,127,31,600,651,600)
 fill("white")
  rect(198,475,186,600-475)
 fill("black")
  triangle(198,474,292,379,383,475)
  fill("black")
  circle(466,567,67)
  fill("black")
  line(465,601,466,674)
fill("black")
line(466,674,445,695)
line(447,627,490,628)
  line(466,674,484,696)
rect(58,637,61,695)
  
}

