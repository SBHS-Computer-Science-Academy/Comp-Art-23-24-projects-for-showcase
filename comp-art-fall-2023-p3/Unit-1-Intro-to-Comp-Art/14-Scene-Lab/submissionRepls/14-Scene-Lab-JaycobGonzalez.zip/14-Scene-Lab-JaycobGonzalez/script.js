function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("MidnightBlue");
  
  fill("limeGreen");
    // ground
  rect(0, 600, 1000, 200); 
   //moon
  fill("Gainsboro");
  circle(0,60,300);
 
  fill('DarkGray');
  ellipse(50,150,60,30);
  circle(60,60,100);
  ellipse(100,125,30,40);
  //stars
  fill('snow');
  circle(170,200,10);
  circle(260,80,10);
  circle(186,23,10);
  circle(191,141,10);
  circle(266,172,10);
  circle(90,254,10);
  circle(199,249,10);
  circle(114,192,10);
  circle(32,225,10);
  circle(182,80,10);
  circle(77, 338,10);
  circle(219, 348,10);
  circle(333, 283,10);
  circle(153, 309,10);
  circle(243, 290,10);
  circle(159, 367,10);
  circle(33,300,10);
  circle(261, 227,10);
  circle(319, 27,10);
  circle(360, 134,10);
  circle(298, 124,10);
  circle(385, 249,10);
  circle(307, 313,10);
  circle(316, 198,10);
  circle(249, 42,10);
  circle(46, 394,10);
  circle(293, 364,10);
  circle(451,352,10);
  circle(642, 367,10);
  circle(877, 370,10);
  circle(984, 388,10);
  circle(745, 378,10);
  circle(721, 318,10);
  circle(581, 308,10);
  circle(397, 330,10);
  circle(397, 330,10);
  circle(367, 379,10);
  circle(541, 364,10);
  circle(488, 285,10);
  circle(413, 191,10);
  circle(370, 90,10);
  circle(410, 14,10);
  circle(462, 252,10);
  circle(545, 245,10);
  circle(504, 196,10);
  circle(420, 130,10);
  circle(529, 88,10);
  circle(482, 28,10);
  circle(454, 66,10);
  circle(561, 181,10);
  circle(664, 264,10);
  circle(631, 217,10);
  circle(515, 137,10);
  circle(602, 121,10);
  circle(539, 27,10);
  circle(602, 63,10);
  circle(654, 31,10);
  circle(803, 330,10);
  circle(731, 254,10);
  circle(668, 162,10);
  circle(735, 41,10);
  circle(682, 102,10);
  circle(736, 171,10);
  circle( 656, 167,10);
  circle(700, 215,10);
  circle(780, 273,10);
  circle(857, 305,10);
  circle(915, 338,10);
  circle(960, 326,10);
  circle(950, 273,10);
  circle(937, 186,10);
  circle(778, 168,10);
  circle(878, 192,10);
  circle(865, 236,10);
  circle(799, 233,10);
  circle(717, 114,10);
  circle(750, 62,10);
  circle(774, 20,10);
  circle(733, 39,10);
  circle(698, 85,10);
  circle(864, 50,10);
  circle(917, 42,10);
  circle(935, 76,10);
  circle(804, 93,10);
  circle(855, 125,10);
  circle(812, 113,10);
  circle(922, 137,10);
  circle(867, 156,10);


  //cloud
  noStroke();
  fill(255,150);
  ellipse(90,160,400,50);
  ellipse(258, 129 ,300,50);
  ellipse(419, 162,400,50);

  //house
  fill('SaddleBrown');
  rect(180,400,200,200);
 triangle( 181, 401,379, 402,279, 237)
  fill('Peru');
  rect(245, 500,50,100);
  fill('yellow');
  circle(287, 564,10,10);
  fill(135, 206, 250,140);
  rect(310, 440,60,100);

  //stickman
  fill('black');
  stroke('black');
  strokeWeight(10);
  circle(544,500,40);
  line(544, 524, 542, 570);
  line(542, 571, 511, 625);
  line(543, 571, 577, 624);
  line(543, 539, 501, 566);
  line(544, 542, 585, 566)
  
  


}