function setup() {
  let myCanvas = createCanvas(700, 700);
  myCanvas.parent("myCanvas");

  createConsole("dots");
  noLoop();

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background(135, 206, 235)
  fill('yellow')
  circle(0, 125, 150)



  fill(145, 145, 145)
  triangle(500, 200, 1000, 600, 300, 600)
  fill('white')
  triangle(500, 200, 541, 233, 500, 237)
  triangle(500, 200, 499, 237, 482, 236)
  fill(0, 40)
  triangle(500, 200, 500, 600, 1000, 600)
  fill(120, 69, 18)
  rect(0, 320, 40, 90)

  fill('green')
  arc(0, 650, 700, 500, 180, 0)
  rect(0, 650, 1000, 10)
  fill(14, 135, 204)
  rect(0, 600, 1000, 150)
  // fill(4, 89, 138, 255)
  // rect(0,650, 300, 200)

  fill(0, 40)
  ellipse(0, 650, 700, 500)
  fill('green')
  rect(0, 600, 700, 10)
  fill(0, 40)
  rect(350, 610, 700, 10)
  fill(120, 69, 18)

  quad(40, 321, 40, 403, 50, 401, 47, 316)
  triangle(40, 320, 2, 299, 0, 320)
  quad(0, 300, 9, 295, 49, 317, 41, 321)
  fill(135, 206, 235)
  rect(9, 373, 20, 20)
  stroke(120, 69, 18)
  line(18, 394, 18, 374)
  line(10, 384, 30, 384)
  rect(9, 340, 20, 20)
  stroke(120, 69, 18)
  line(9, 349, 29, 349)
  line(19, 340, 19, 362)
  fill(0, 40)
  quad(0, 320, 40, 321, 40, 403, 0, 401)
  triangle(38, 323, 0, 301, 0, 320)
  fill(0, 40)
  noStroke();
  quad(3, 402, 56, 421, 82, 410, 51, 404)
  triangle(55, 420, 77, 411, 70, 424)


  stroke('black');
  strokeWeight(3);
  line(58, 405, 63, 393)
  line(68, 405, 63, 393)
  line(63, 393, 62, 379)
  line(62, 379, 69, 386)
  line(62, 379, 57, 386)
  fill('white')
  circle(62, 369, 15)
  noStroke();
  fill(255, 200);
  ellipse(283, 119, 150, 80)
  ellipse(377, 114, 70, 60)
  stroke(0, 60)
  line(58, 405, 73, 413)
  line(68, 405, 73, 413)
  line(73, 413, 83, 420)
  line(83, 420, 82, 413)
  line(82, 420, 70, 416)
  fill(0, 60)
  noStroke();
  ellipse(86, 424, 10, 10)
}