   function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("midnightblue");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  strokeWeight(3)
  fill("silver")
  triangle(0,600,270,600,125,285)
  fill("white")
  triangle(95,360,160,360,125,285)
  fill("Gainsboro")
  circle(45,50,200)
  fill("Gray")
  ellipse(65,110,50,25)
  fill("darkgrey")
  circle(70,50,60)
  fill("dimgrey")
  ellipse(20,75,25,40)
  fill("SaddleBrown")
  strokeWeight(5)
  rect(400,470,200,200)
  strokeWeight(5)
  rect(475,600,50,70)
  strokeWeight(3)
  rect(400,430,200,39)
  rect(420,390,160,39)
  rect(440,350,120,39)
  fill("LightSlateGray")
  ellipse(480,710,50,40)
  ellipse(450,760,50,40)
  fill("skyblue")
  rect(423,510,40,40)
  rect(540,510,40,40)
  strokeWeight(2)
  line(442,510,442,549)
  line(424,530,462,530)
  line(560,510,560,550)
  line(540,530,580,530)
  strokeWeight(6)
  line(310,700,310,605)
  fill("black")
  circle(310,605,50)
  line(309, 659, 273, 637)
  line(310, 658,347, 639)
  line(311, 700, 288, 733)
  line(312, 701, 334, 731)
  //text("Make a Scene.  \nYou need at least a square, a circle, an ellipse, a rectangle, a triangle, and a stick figure.", 500, 400);
}