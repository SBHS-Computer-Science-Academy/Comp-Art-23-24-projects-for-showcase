function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("LightSteelBlue");
  rectGradient(0,0,800,800,"steelblue","lightsteelblue")
  fill('CornflowerBlue');
  rect(0,630,800,200); //water
  
  fill("silver");
  rect(0, 550, 800, 200); // ground
  fill('black');
  rect(100,580,600,150); //gutter
  
  fill('white');
  arc(205,760,80,60,0,180); //boat base
  triangle(205,726,179,761,233,761); //boat hat
  line(205,727,205,761);
  stroke('white');
  line(554,678,590,651);
  line(590,651,612,599);
  line(612,599,612,305);
  stroke('DarkRed')
  fill('red');
  circle(612,295,120); //balloon
  triangle(601,369,624,369,612,355); //balloon tie
  stroke('black');
  fill('white');
  circle(410,655,100); //head
  stroke('white');
  strokeWeight(11);
  line(552,679,434,720); //arm
  fill('white');
  stroke('red');
  strokeWeight(3);
  arc(410,674,55,35,0,180); //smile
  line(434,668,441,675);
  line(384,668,379,675);
  
  strokeWeight(0);
  fill('red');
  circle(410,667,27); //nose
  
  stroke('red');
  strokeWeight(4);
  line(380,624,380,660); //left eyeliner
  line(440,624,440,660); //right eyeliner
  
  stroke('black');
  strokeWeight(3);
  fill('black');
  circle(440,642,16); //right eye
  circle(380,642,16); //left eye
  
  stroke('Darkgray');
  fill('DarkGray');
  square(391,700,40); //neck
  stroke('GhostWhite');
  fill('GhostWhite');
  triangle(392,698,397,715,370,711); //1
  triangle(429,698,451,709,424,717); //2
  triangle(394,713,424,713,410,727); //3
  stroke('lightgray');
  strokeWeight(0);
  fill('lightgray');
  triangle(391,697,397,712,424,713);
  triangle(427,697,397,713,424,712);

  fill('red');
  strokeWeight(2);
  stroke('DarkRed');
  triangle(386,610,334,600,358,647); //left hair
  triangle(438,610,460,647,491,600); //right hair
  textSize(11);
  stroke('black');
  strokeWeight(0);
  fill('black');
  text("S.S Georgie",205,770);
  fill(255,240);
  stroke('white');
  ellipse(76,89,100,60); //cloud 1
  ellipse(93,84,90,80);
  ellipse(148,80,100,60)

  ellipse(596,120,120,80); //cloud 2
  ellipse(547,140,90,70); 
  ellipse(641,139,150,70);

  ellipse(235,241,110,60); //cloud 3
  ellipse(177,225,86,100);
  ellipse(146,238,100,80);
  ellipse(150,241,180,60);

  fill('silver');
  stroke('silver');
  rect(389,730,44,19);

  fill('Cornflowerblue');
  strokeWeight(2);
  stroke("navy");
  arc(205,795,60,30,180,0); //waves
  arc(366,774,70,20,180,0);
  arc(526,786,70,30,180,0);
  arc(25,773,70,30,180,0);
  arc(718,770,70,30,180,0);

  fill(255,140);
  strokeWeight(7);
  stroke('white');
  line(636,254,649,266);
  line(649,266,655,283);
  circle(642,327,4);
}