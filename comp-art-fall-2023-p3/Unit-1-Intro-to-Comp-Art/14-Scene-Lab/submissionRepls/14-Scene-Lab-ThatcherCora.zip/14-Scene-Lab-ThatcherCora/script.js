function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("LightSkyBlue");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  fill("black");

  fill("tan")
  
  circle(169, 455, 50)
  fill("white")
line(168,480,170,538)
  line(170,538,191,571)
line(169,541,146,565)
  stroke("white");
  fill("black");
  circle(155, 449, 5);
  stroke("white");
  fill("black");
  circle(178, 448, 5);
  line(156,463,181,463)
  fill("yellow")
  ellipse(633,70,200,170)
  stroke("black");
  line(133,501,216,500)
  line(217,499,264,433)
  noFill()
  bezier(266, 433,274, 398,233, 383,209, 387)
  line(263,434,266,432)
  bezier(209, 387,174, 349,206, 302,273, 317)
  fill("blue")
  rect(440,600,400,200)
  fill("black")
  triangle(277, 311,272, 320,278, 324 )
  line(134,568,202,572)
  line(134,569,132,594)
  line(200,573,197,592)
  line(133,595,198,597)
  fill("black")
strokeWeight(4)
  rect(110,560,90,50)
  line(111,561,108,500)
 triangle(576,636,564,653,588,654)
  strokeWeight(1)
  stroke("white")
  line(576,635,576,646)
  stroke("black")
  square(560,656,30)
  triangle(572, 688,571, 704,544, 694)
  triangle(574, 689,574, 704,607, 698)
  strokeWeight(4)
  line(560,689,591,689)
}