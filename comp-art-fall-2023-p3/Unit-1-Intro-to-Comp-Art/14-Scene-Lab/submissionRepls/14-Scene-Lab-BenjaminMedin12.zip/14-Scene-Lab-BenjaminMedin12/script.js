function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("MidnightBlue");
  
  fill("green");
  rect(0, 600, 1000, 200); // ground
  fill("maroon");
  strokeWeight(6);
  square(456,200,400);//house
  fill("white");

  rect(518,457,90,90,20)//window
  rect(725,361,90,90,20)//window
  strokeWeight(6);
  line(770,363,770,452)
  line(726,409,816,409)
  strokeWeight(6);
  line(564,547,564,458)//window frame
  line(519,504,609,504)//window frame
  fill("gray")
  triangle(180,601,0,276,0,600)//big moUTQAIN
  fill("DimGray")
    triangle( 143,388,39,600,264,600)
  fill("peru")
  triangle(456,200,855,200,644,19)//roof
  ellipse(151,540,30,30)//head
  fill("DarkGrey")
  circle(0,0,200)
  fill("DimGrey");
  ellipse(35,55,20,20)
  ellipse(49,19,35,35)
  strokeWeight(3);  
  line(151,557,151,580)//body
  line(151,583,146,598)//left leg
  line(151,584,160,599)//right leg
  line(153,567,166,576)//right arm
  line(150,568,145,581)//left arm
 
  
}