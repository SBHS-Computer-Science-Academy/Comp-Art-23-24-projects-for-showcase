function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");

  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("white");
  rectGradient(0, 0, width, 560, "OrangeRed", "crimson"); // sky with sunset
  
  fill("grey");
  rect(0, 560, 1000, 600); // ground
  fill("DeepSkyBlue");
rect(175,379,500,180)
    fill("DeepSkyBlue");
  rect(675,380,200,180)
  fill("black")
  quad(250,559,287,500,371, 500,377,559)
  fill("DimGray")
  circle(320,544,80)
  fill("black")
quad(676, 559,709, 500,799, 500,807, 559)
  fill("dimgrey")
  circle(745,544,80)
  fill("yellow")
  rect(40,560,110,35)
  rect(484,560,110,35)
  rect(876,560,110,35)
  line(875,380,912,380)
  line(912,380,923,395)
   drawbubber() 
  drawtump()
drawMouseLines()
  drawwindow()
  drawwindow2()
  drawstickman()


}
function drawbubber() {
  fill("deepskyblue");
  beginShape();
  vertex(876, 380);
  vertex(913, 381);
  vertex(921, 393);
  vertex(901, 560);
  vertex(876, 560);
  vertex(876, 380);
  endShape();
  fill("white")
    ellipse(896,480,15,40)
  fill("Gold")
  ellipse(893,515,10,17)
  fill("skyBlue")
  rect(890,525,23, 40, 20, 15, 10, 5)
  rect(165,525,23, 40, 20, 15, 10, 5)
  fill("deepskyblue")
  rect(175,200,500,180)
  rect(675,200,200,180)
 
}

function drawtump() {
  fill("YellowGreen");
  beginShape();
  vertex(922, 393);
  vertex(945, 393);
  vertex(928, 497);
  vertex(909, 494);
  vertex(921, 395);
  endShape();

  }

function drawwindow() {
  fill("black")
  beginShape();
  vertex(875, 381);
  vertex(852, 198);
  endShape();
}

function drawwindow2() {
  fill("LightGray")
  beginShape();
  vertex(836, 236);
  vertex(818, 217);
  vertex(695, 215);
  vertex(687, 232);
  vertex(689, 364);
  vertex(838, 364);
  vertex(836, 237);
  endShape();
}

function drawstickman() {
strokeWeight(3)
  beginShape();
  line(760,365,760,325);
  circle(760,310,45);
  endShape();
}