function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("white");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  fill("black");
  text("Make a Scene.  \nYou need at least a square, a circle, an ellipse, a rectangle, a triangle, and a stick figure.", 500, 400);
}