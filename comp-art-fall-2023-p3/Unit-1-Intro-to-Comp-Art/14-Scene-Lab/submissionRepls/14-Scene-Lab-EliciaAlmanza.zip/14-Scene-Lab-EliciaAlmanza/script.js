function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  
  background("LightSkyBlue");
  fill('#f8fc86')
  circle(644,174,150)//sun

  fill("limegreen");
  rect(0, 600, 1000, 200); // ground
  fill("black");



  stroke('pink')
  strokeWeight(5)
    fill('pink')
  circle(116,512,50)
  ellipse(141,515,20,15)
  line(115,538,113,581)
  fill('pink')
  line(116,554,136,553)
  fill('pink')
  line(115,555,95,549)
  fill('pink')
  line(113,582,100,594)
  fill('pink')
  line(113,538,121,594)
  
    strokeWeight(1)
    stroke('black')
  fill('LightGoldenrodYellow')//house
  rect(278,300,250,300)
fill('SaddleBrown')
  ellipse(646,648,150,40)

  fill('black')
  circle(105,504,5)  


  fill('black')
  circle(125,504,5)  
  
  fill('LightGoldenrodYellow')
  rect(231,300,50,300)

        
  fill('LightGoldenrodYellow')
  triangle(391,181,527,300,278,300)//triangel


  quad(391, 182,279, 300,231, 300,337, 178)

    fill('salmon')
  quad(391, 182,279, 300,231, 300,337, 178)
  
     stroke('LightGoldenrodYellow')
  strokeWeight(2)
  line(525,300,282,300)
  
  
    
  noStroke()
  
  fill('white')
  rect(428,339,70,70)//rightopww
  
   
 fill('LightSkyBlue')
  rect(435,347,55,55)
  line(339,349,341,401)
  
  fill('white')
  rect(428,473,70,70)//rightbottww

  
  fill('lightskyblue')
  rect(435,482,55,55)
  
  fill('white')
  rect(306,473,70,70)//leftbottww
  fill('lightskyblue')
  rect(313,482,55,55)
  
  fill('white')
  rect(306,339,70,70)//leftopwww
  fill('lightskyblue')
  rect(313,347,55,55)

  
    }

