function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("SkyBlue");

  //balloons 
  
  fill("black")
  line(200, 200, 400 ,400)//start of left side 
  fill("DarkSalmon")
  circle(200,200, 100)

  fill("black")
  line(230, 300, 400, 400)
  fill("DarkOrange")
  circle(230, 300, 100)

  fill("black")
  line(290, 70, 400 ,400)
  fill("DarkSeaGreen")
  circle(290, 70, 100)

  fill("black")
  line(220, 120, 400 ,400)
  fill("PaleVioletRed")
  circle(220, 120, 100)

  fill("black")
  line(350, 120, 400 ,400)
  fill("yellow")
  circle(350, 120, 100)
  
  fill("black")
  line(310, 200, 400 ,400)
  fill("Firebrick")
  circle(310, 200, 100)//end of left side 

fill("black")
  line(420, 62, 440 ,440)//start of middle 
  fill("Tomato")
  circle(420, 62, 100)

  fill("black")
  line(500, 80, 440 ,440)
  fill("MistyRose")
  circle(500, 80, 100)

  fill("black")
  line(400 , 190, 440 ,440)
  fill("LightSteelBlue")
  circle(400, 190, 100)//end of middle

  fill("black")
  line(630, 85, 480 ,480)//start of right side 
  fill("Gold")
  circle(630, 85, 100)

  fill("black")
  line(570, 150, 480 ,480)
  fill("Maroon")
  circle(570, 150, 100)
  
  fill("black")
  line(480 , 175, 480 ,480)
  fill("WhiteSmoke")
  circle(480, 175, 100)
  
  fill("black")
  line(700, 170, 480 ,480)
  fill("MediumPurple")
  circle(700, 170, 100)
  
  fill("black")
  line(600, 230, 480 ,480)
  fill("DarkOliveGreen")
  circle(600, 230, 100)

  fill("black")
  line(800, 170, 480 ,480)
  fill("Pink")
  circle(800, 170, 100)

  fill("black")
  line(705, 260, 480 ,480)
  fill("Navy")
  circle(705, 260, 100)//end of right side 

  //house 
  
  fill("LightGreen");
  rect(300, 400, 350, 300);//base of house 

  fill("SkyBlue")
  square(320, 430, 100);//left window 

  fill("SkyBlue")
  square(530, 430, 100);//right window 
  
  fill("Peru");
  rect(410, 550, 115, 150);//door

  fill("CornflowerBlue")
  triangle(300, 400, 465, 250, 650, 400)//roof

  fill("SaddleBrown")
  circle(500, 630, 15)//door handle                
  fill("black")
  line(370, 530, 370, 470 )//body
  
  fill("black")
  circle(370, 470, 20)//head

  fill("black")
  line(370, 500, 338, 480)
  
  fill("black")
  line(370, 500, 400, 480)//right hand 


  
  fill("black")
  line(580, 430, 580 ,530 )//right window 
  fill("black")
  line(530, 480, 630, 480)



  
  
}