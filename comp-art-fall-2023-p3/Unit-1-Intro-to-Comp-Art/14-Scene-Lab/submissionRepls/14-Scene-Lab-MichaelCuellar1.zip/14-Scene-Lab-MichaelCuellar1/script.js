function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("midnightblue");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  fill("black");
  text("Make a Scene.  \nYou need at least a square, a rectangle, a triangle, and a stick figure.", 500, 400);
fill('whitesmoke')
  circle(63, 65, 250)

fill('AliceBlue')
ellipse(97, 67, 180, 215)
  fill('SaddleBrown')
square(750, 390, 210)
  triangle(736, 393, 972, 390, 856, 315)
fill('black')
  square(100, 520, 80)
  strokeWeight(7)
line(103,460,103,525)

line(195,561,197,513)
line(197,513,145,511)
line(145,511,147,457)
line(150,460,156,490)
  line(157,492,170,510)
  fill('black')
 strokeWeight(1)
  circle(140,445,30)
fill('Silver')
square(305,100,23)
  square(331,100,23)
  fill('red')
  triangle(303, 100,303,125,271, 115)
}