function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("skyblue");
  
  fill("black");
  rect(0, 600, 1000, 200); // ground
  fill("grey");
  rect(50,410,20,190)
fill("silver");
quad(13, 355,12, 422,101, 408,117, 345)
fill("red")
  quad(24, 362,24, 408,90, 398,97, 355)
  fill("silver")
  quad(31, 367,32, 399,82, 392,88, 361)
  fill("white")
  triangle(59, 403,141, 399,104, 461)
  triangle(146, 407,116, 392,124, 455)
  triangle(58, 406,84, 393,77, 452)
  fill("red")
ellipse(103, 406,100,40)
fill("white")
ellipse(103,406,90,30)
fill("orange")
circle(413, 335,45,45)
strokeWeight(5)
line(338, 354,352, 424)
line(350, 426,314, 459)//
line(353, 425,392, 448)
line(341, 363,395, 365)
line(338, 365,278, 385)
line(396, 365,424, 355)
fill("black")
  circle(335, 337,30,30) 
line(392, 448,417, 434)//right leg
line(313, 459,350, 473)

line(227, 380,262, 443)
line(262, 444,297, 448)
line(300, 449,309, 486)
line(260, 444,278, 470)
  line(279, 471,259, 513)
line(237, 399,265, 381)
line(265, 378,274, 341)
line(236, 397,250, 369)
  line(250, 368,247, 335)
  circle(221, 364,28,28)
strokeWeight(1) 
  noFill()
bezier(394, 325,404, 326,412, 325,422, 316)
bezier(406, 357,412, 350,421, 348,429, 349)
bezier(404, 315,411, 325,415, 333,417, 355)
  bezier(393, 343,404, 335,417, 331,435, 334)
}