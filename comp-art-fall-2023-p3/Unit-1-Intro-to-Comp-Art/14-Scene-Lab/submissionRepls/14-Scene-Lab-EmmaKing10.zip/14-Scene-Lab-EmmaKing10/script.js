function setup() {
  let myCanvas = createCanvas(650, 650);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}
function draw() {
fill("yellow")
rect(2,357,650,400)
  fill("limeGreen");
  rect(0, 600, 650, 200); // ground
fill("coral")
  rect(3, 1, 650, 50)
fill("orange")
rect(3,103,650,50)
fill("LightSalmon")
rect(4,53,650,50)
fill("LightGoldenrodYellow")
rect(3,204,650,50)
fill("yellow")
rect(3,154,650,50)
fill("HotPink")
rect(1,254,650,50)
fill("pink")
rect(2,306,650,50)



fill("yellow")
circle(154,108, 150)
triangle(160,191,191,179,184,204)
fill("Gold")
triangle(199,174,218,155,223,175)
fill("yellow")
triangle(223,150,233,114,248,138)
fill("Gold")
triangle(233,104,226,73,249,85)
fill("yellow")
triangle(205,42,221,62,228,40)
fill("Gold")
triangle(170,27,194,37,194,12)
fill("yellow")
triangle(149,3,137,25,159,24)
fill("Gold")
triangle(104,34,103,5,125,24)
fill("yellow")
triangle(95,42,80,55,73,26)
fill("Gold")
triangle(73,65,66,86,41,58)
fill("yellow")
triangle(68,97,71,118,47,108)
fill("Gold")
triangle(71,130,83,152,54,152)
fill("yellow")
triangle(91,161,109,175,85,185)
fill("Gold")
triangle(117,180,149,188,125,203)
ellipse(150,109,100)
fill("burlywood")
triangle(0,596,207,243,394,593)
fill("green")
triangle(155,334,253,330,207,244)
strokeWeight(4)
line(571,590,569,484)
fill("black")
circle(568,480,50)
line(571,537,601,508)
line(526,508,571,537)
line(568,566,551,583)
line(570,567,591,581)
strokeWeight(1)
fill("green")

fill("yellow")
circle(147,107,70)
fill("Gold")
circle(146,108,45)
fill("yellow")
circle(146,108,25)
fill("LimeGreen")
triangle(206,244,165,317,242,311)
fill("green")
triange(189,299,205,269,218,298)


}