function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("white");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  fill("black");
  

//house

noStroke()
fill(0,100)
ellipse(353, 279,30)  
ellipse(365, 271,30)
ellipse(368, 283,25)
ellipse(360, 253,20)
ellipse(350, 261,30)
ellipse(355, 242,20,25)
ellipse(343, 243,35)
ellipse(362, 228,40,30)
ellipse(347, 209,40)
ellipse()
ellipse()
ellipse()
ellipse()







strokeWeight(3)
  stroke(0)
  
fill(138, 22, 18)
    rect(340, 283,40,70)


  
  fill(255, 128, 0)
rect(200, 400,200,200,0,0)


  //roof
    fill(79, 79, 79)
triangle(290, 290,450, 400,150, 400)


  //door
  fill(207, 177, 103)
rect(267, 478,60,122)


  //door nob
  fill(0)
ellipse(320, 549,10)








  
}