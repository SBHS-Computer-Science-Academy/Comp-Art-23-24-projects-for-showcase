function setup() {
  let myCanvas = createCanvas(1000,800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("midnightBlue");
  //ground
  fill("saddlebrown");
  rect(0, 600, 1000, 200);
  fill("LawnGreen")
  rect(0,600,1000,40)
  //stepping stones
  fill("silver")
  ellipse(0,640,100,60)
  ellipse(100,700,100,60)
  ellipse(200,640,100,60)
  ellipse(300,700,100,60)
  ellipse(400,640,100,60)
  ellipse(500,700,100,60)
  ellipse(600,640,100,60)
  //moon
  noStroke()
  fill("yellow")
  circle(100,80,150)
  //moon cover
  fill("midnightBlue")
  circle(110,80,135)
  //stickman
  stroke("darkGrey")
  strokeWeight(3)
  line(78,137,96,112)
  line(106,146,96,112)
  line(100,90,96,112)
  line(98,100,86,100)
  line(86,100,78,95)
  line(98,100,110,109)
  line(110,109,120,105)
  circle(102,83,20)
  //house
  noStroke()
  fill("darkGrey")
  rect(593,450,152,150)
  //bricks
  fill("Chocolate")
  rect(600,460,40,10)
  rect(650,460,40,10)
  rect(700,460,40,10)
  rect(600,475,20,10)
  rect(630,475,20,10)
  rect(660,475,20,10)
  rect(690,475,20,10)
  rect(720,475,20,10)
  rect(600,490,40,10)
  rect(650,490,40,10)
  rect(700,490,40,10)
  rect(600,505,20,10)
  rect(630,505,20,10)
  rect(660,505,20,10)
  rect(690,505,20,10)
  rect(720,505,20,10)
  rect(600,520,40,10)
  rect(650,520,40,10)
  rect(700,520,40,10)
  rect(600,535,20,10)
  rect(630,535,20,10)
  rect(660,535,20,10)
  rect(690,535,20,10)
  rect(720,535,20,10)
  rect(650,550,40,10)
  rect(700,550,40,10)
  rect(660,565,20,10)
  rect(690,565,20,10)
  rect(720,565,20,10)
  rect(650,580,40,10)
  rect(700,580,40,10)
  //door
  fill("sienna")
  rect(605,550,30,50)
  triangle(580,450,765,450,665,370)
}
  //You need at least a square, a circle, an ellipse, a rectangle, a triangle, and a stick figure.