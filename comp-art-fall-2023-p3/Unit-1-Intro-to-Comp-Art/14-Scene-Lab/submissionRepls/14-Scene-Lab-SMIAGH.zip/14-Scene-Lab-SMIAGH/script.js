function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
//   textSize(20);
}

function draw() {
  background("grey");
rectGradient(0, 0, width, 800, "black", "Gray");

  
  stroke('black')
  strokeWeight(3)
  fill('dimgrey')
  quad(0,599,1,564, 999,564, 999,599)

  noStroke();
  fill('OrangeRed')
  rectGradient(0, 600, 1000, 200, "orange", "red");
  
// noSroke()
  stroke('black')
  fill('black')
  quad(194, 599, 210, 505, 243, 505, 251, 600)
 
  stroke('black')
  fill('Dimgray')
  quad(210,505, 207,460, 266,460, 268,505)

  quad(207,460, 206,418, 225,418, 225,460)
 fill('black')
  
  stroke('black')
  
  line(267,476, 239,476)
stroke('black')

  line(267,492, 240,491)
stroke('black')

  line(999,187, 657,178)
stroke('black')

  triangle(998,185, 998,237, 695,179)
  
  line(693,181, 999,237)
noStroke();
  fill('white')
ellipse(705,106,45)
stroke('white');
  fill('white')
 line(708,174, 706,132)

  line(708,173, 737,175)

  line(705,146, 674,135)

  line(672,134, 696,108)


 noStroke()
  fill(0,40)
  triangle(197,601, 261,636, 253,601)

  fill(0)
  quad(260,655, 314,679, 273,703, 212,694)

  triangle(118,604, 147,628, 89,622)

  quad(322,613, 341,604, 333,645, 381,610)
}





//You need at least a square, a circle, an ellipse, a rectangle, a triangle, and a stick figure.