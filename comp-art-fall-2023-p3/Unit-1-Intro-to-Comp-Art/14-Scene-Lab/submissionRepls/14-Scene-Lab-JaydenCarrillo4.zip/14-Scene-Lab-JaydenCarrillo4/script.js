function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
}

function draw() {
  background("LightSkyBlue");
  
  fill("limeGreen");
  rect(0, 600, 1000, 200); // ground
  fill("Gold")
  circle(750,0,400,400)
   fill("Moccasin")
  rect(677, 599, -300, -300)
  fill("LightSteelBlue")
  square(400, 396,50,50)
  square(610,396,50,50)
   fill("RoyalBlue")
  triangle(377,300,524, 190,676, 299)
  rect(570,599,-100,-100)
  line(186, 450,186, 550)
  line(186, 550,210, 599)
  line(186, 550,167,599)
  line(186, 450,250, 530)
  line(186, 450, 130, 530)
  fill("Moccasin")
  circle(186, 425,50)
}