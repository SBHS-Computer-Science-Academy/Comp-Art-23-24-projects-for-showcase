function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  textSize(20);
}

function draw() {
  background("lightgrey");
  
  fill("SaddleBrown");
  rect(0, 600, 1000, 200); // ground
  strokeWeight(5);
  stroke('black');
  line(730,531,730,597)
  line(677,531,677,597)
  fill('red');
  strokeWeight(3);
  stroke('black');
  ellipse(700,515,80,30)
  ellipse(731,471,30,80)
  line(637,598,637,482)
  line(579,598,579,481)
  fill('yellow');
  strokeWeight(3);
  stroke('black');
  rect(576,460,60,20)
  strokeWeight(5);
  stroke('black');
  line(543,598,543,523)
  line(496,598,495,523)
  fill('red')
  strokeWeight(3);
  stroke('black');
  ellipse(516,513,80,30)
  strokeWeight(3);
  stroke('black');
  line(799,598,799,484)
  line(861,599,861,483)
  fill('yellow');
  rect(799,462,62,20)
  strokeWeight(5);
  stroke('black');
  line(903,533,903,600)
  line(948,600,948,528)
  strokeWeight(3);
  stroke('black');
  fill('red')
  ellipse(923,518,80,30)
  ellipse(958,479,30,80)
  ellipse(552,470,30,80)
  strokeWeight(3);
  stroke('black');
  line(452,600,452,484)
  line(395,598,395,485)
  strokeWeight(3);
  stroke('black');
  fill('yellow');
  rect(394,462,62,20)
  strokeWeight(3);
  stroke('black');
  fill('white');
  circle(183,123,100)
  fill('black');
  circle(182,120,3)
  strokeWeight(1);
  stroke('black');
  strokeWeight(1);
  line(184,124,201,160)
  strokeWeight(1);
  stroke('black');
  line(182,118,182,93)
  strokeWeight(5);
  line(21,600,21,440)
  line(224,600,224,440)
  line(69,328,69,494)
  line(69,497,109,594)
  line(69,500,38,598)
  line(66,350,16,397)
  line(71,350,116,393)
  strokeWeight(5);
  stroke('black');
  fill('tan');
  rect(20,412,205,28)
  fill('green');
  square(190,384,30)
  stroke('blue');
  line(189,383,182,367)
  stroke('red');
  line(193,383,185,365)
  stroke('purple');
  line(198,382,193,363)
  stroke('orange');
  line(220,383,225,362)
  stroke('cyan');
  line(215,382,219,360)
  stroke('yellow');
  line(205,383,204,361)
  stroke('black');
  fill('lightblue');
  rect(407,130,500,250)
  fill('green');
  triangle(420,378,479,208,557,378)
  fill('lightgreen');
  triangle(512,377,598,269,695,378)
  fill('green');
  triangle(656,376,690,200,740,376)
  fill('SaddleBrown');
  rect(806,273,30,105)
  fill('green');
  circle(817,240,70)
  strokeWeight(8);
  stroke('black');
  line(654,133,654,377)
  line(407,254,907,254)
  strokeWeight(3);
  stroke('black');
  fill('wheat');
  circle(67,291,70)
  fill('black');
  circle(54,285,2)
  circle(76,285,2)
  fill('pink');
  ellipse(65,303,20,10)
  strokeWeight(3);
  stroke('orange')
  line(41,268,18,239)
  line(47,262,28,234)
  line(56,256,47,228)
  line(65,254,66,226)
  line(76,255,81,229)
  line(83,257,95,235)
  line(90,262,108,248)
  strokeWeight(3);
  stroke('black');
  fill('wheat');
  circle(507,420,60)
  line(506, 451,508,495)
  line(508, 496,481,528)
  line(481, 530,477,566)
  line(506,498,467,514)
  line(465, 514,457,549)
  line(506, 468,470,479)
  line(506, 469,528,497)
  stroke('black');
  fill('black');
  circle(496,413,2)
  circle(513, 413,2)
  fill('pink');
  ellipse(504, 429,20,10)
  
  strokeWeight(3);
  stroke('black');
  fill('wheat');
  circle(686,422,60)
  line(686, 451,686,499)
  line(686, 499,668,529)
  line(668, 531,665,562)
  line(686, 502,651,512)
  line(649, 512,644,550)
  line(686, 475,704,497)
  line(686, 476,650,484)
  stroke('black');
  fill('black');
  circle(674, 416,2)
  circle(691, 416,2)
  fill('pink');
  ellipse(683, 431,20,10)
  
  
}
