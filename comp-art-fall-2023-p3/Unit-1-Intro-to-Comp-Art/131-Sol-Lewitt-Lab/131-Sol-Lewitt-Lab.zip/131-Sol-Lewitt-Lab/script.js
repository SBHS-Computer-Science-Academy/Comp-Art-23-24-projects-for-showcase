function setup() {
  let myCanvas = createCanvas(500, 500);
  myCanvas.parent("myCanvas");

  createConsole("dots");
  noLoop();

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("yellow");
  fill('SkyBlue');
  circle(0, 0, 1400);
  fill('DarkViolet');
  circle(0, 0, 1300);
}