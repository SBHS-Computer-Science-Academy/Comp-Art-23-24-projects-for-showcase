function setup() {
  let myCanvas = createCanvas(800, 800);
  noLoop();
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  strokeWeight(4);
  colorMode(HSB);
}

function draw() {
  line(400, 0, 400, 800)
  line(325, 0, 325, 800)
  line(475, 0, 475, 800)
  for (x = 3; x < (width / 2) - 140; x += width / 20) { //starting x; until where it goes; interval 
    fill(random(0, 360), 100, 100)
    rect(x, -4, 20, height + 8) //y values here make the top and bottom stroke offscreen (invisible)
  } //left v lines ^
  for (x = (width / 2) + 136; x < width; x += width / 20) {
    fill(random(0, 360), 100, 100)
    rect(x, -4, 20, height + 8)
  } //right v lines ^
  for (y = (height / 2) - 150; y < (height / 2) + 150; y += height / 20) {
    fill(random(0, 360), 100, 100)
    rect((width / 2) - 137, y, 273, 20)
  } //center h lines ^
}
