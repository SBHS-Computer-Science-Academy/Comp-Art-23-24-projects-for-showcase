function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  noStroke()
  //gem and circle thing
   fill("red")
  triangle(202,194,173,254,236,254)
  triangle(144,194,173,254,115,254)
  triangle(115,254,202,314,173,254)
  circle(100,600,120)
  rect(400,100,100,100)
  fill("orange")
  triangle(202,194,264,194,236,254)
  triangle(173,254,236,254,202,314)
  triangle(236,254,202,314,296,254)
  circle(100,600,100)
  rect(400,100,95,95)
  fill("yellow")
  triangle(202,194,264,194,236,134)
  triangle(264,194,236,254,296,254)
  triangle(264,194,296,254,296,134)
  circle(100,600,80)
  rect(400,100,90,90)
  fill("green")
  triangle(173,134,236,134,202,194)
  triangle(264,194,236,134,296,134)
  triangle(296,134,236,134,202,74)
  circle(100,600,60)
  rect(400,100,85,85)
  fill("blue")
  triangle(144,194,202,194,173,134)
  triangle(236,134,173,134,202,74)
  triangle(202,74,173,134,115,134)
  circle(100,600,40)
  rect(400,100,80,80)
  fill("purple")
  triangle(173,254,202,194,144,194)
  triangle(144,194,173,134,115,134)
  triangle(115,134,115,254,144,194)
  circle(100,600,20)
  rect(400,100,75,75)
  //square illusion
  fill("red")
  rect(400,100,70,70)
  fill("orange")
  rect(400,100,65,65)
  fill("yellow")
  rect(400,100,60,60)
  fill("green")
  rect(400,100,55,55)
  fill("blue")
  rect(400,100,50,50)
  fill("purple")
  rect(400,100,45,45)
  fill("red")
  rect(400,100,40,40)
  fill("orange")
  rect(400,100,35,35)
  fill("yellow")
  rect(400,100,30,30)
  fill("green")
  rect(400,100,25,25)
  fill("blue")
  rect(400,100,20,20)
  fill("purple")
  rect(400,100,15,15)
  fill("red")
  rect(400,100,10,10)
  fill("bob was here")//better than writing "white" it's also the "exit" to the illusion tunnel
  rect(400,100,5,5)
}
//reminder, triangles Y coordinates must be 60 apart to keep it even and nice. :)