function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("HotPink");
  fill('LimeGreen');
  circle(412,380,800)
  fill('DodgerBlue');
  circle(412,380,700)
  fill('Crimson')
  circle(412,380,600)
  fill('LimeGreen')
  circle(412,380,500)
  fill('DodgerBlue')
  circle(412,380,400)
  fill('crimson')
    circle(412,380,300)
  fill('limegreen')
   circle(412,380,200)
  fill('DodgerBlue')
  circle(412,380,100)
  fill('crimson')
  circle(412,380,50)
  fill('limegreen')
  circle(412,380,10)
  
  
  
  
  
  
  
  
  
  
 

  

}