 function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("purple");
  fill("hotpink")
  circle(272,254,400)
  fill("HotPink");
  circle(272,254,500)
  fill("lightpink");
  circle(272,254,250)
  fill("Fuchsia");
  circle(586,450,750)
  fill('MediumOrchid');
  circle(586,450,650)
  fill("Lime");
  circle(586,450,550)
  fill("Cyan");
  circle(586,450,450)
  
  fill('yellow');
  circle(1,800,615)
  fill('PaleGreen');
  circle(1,800,500)
  fill('Violet');
  circle(1,800,350)
  fill("Coral");
  circle(586,450,350)
  fill("PowderBlue");
  circle(586,450,250)
  fill('MediumVioletRed');
  circle(1,800,250)
  fill("Indigo");
  circle(6,343,300)
  fill("GreenYellow")
  circle(6,343,200)
  fill("gold")
  circle(6,343,100)
  fill("SkyBlue");
  circle(841,48,200)
  fill("BLUE");
  circle(841,48,140)
  fill("Aquamarine");
  circle(841,48,70)
  
  fill("brown");
  ellipse(22,27,250,400);
  fill('purple');
  ellipse(22,27,160,300);
  fill("pink");
  ellipse(22,27,120,180);
}