function setup() {
  let myCanvas = createCanvas(600, 800);

}

function draw() {
  //examples of starter code

  background("purple");
  
 

  //startcircle
  fill('rgb(187,54,175)');
  circle(326,261,300)
   
 fill('rgb(182,96,195)');
  circle(326,261,270)
   
  fill('rgb(128,72,184)')
  circle(326,261,240)
  
  fill('black')
  circle(326,261,210)
  
  fill('rgb(127,14,105)');
  circle(326,261,180)
  
 fill('rgb(243,76,252)');
  circle(326,261,150)
   
   fill('rgb(113,19,114)');
  circle(326,261,120)
  
  fill('black');
  circle(326,261,90)
  
  fill('rgb(79,146,201)');
  circle(326,261,60)
//endcircle


  
  fill('rgb(101,121,189)')
  

  fill('red');
  arc(600,1,300,300, 180, 90, PIE);
 
  
  
  //startcircle
fill('Indigo');
  circle(136,438,400)
fill('Purple');
 circle(136,438,350)
fill('DarkMagenta');
   circle(136,438,300)
fill('DarkViolet');
   circle(136,438,250)
fill('BlueViolet');
   circle(136,438,200)
fill('DarkOrchid');
   circle(136,438,150)
fill('Fuchsia');
   circle(136,438,100)
fill('Magenta');
   circle(136,438,50)
//endcircle
  
    
//startcircle
  fill('rgb(224,132,224)');
   circle(600, 800,1000)
    fill('purple');
   circle(600, 800,900)
    fill('rgb(206,129,185)');
   circle(600, 800,800)
     fill('rgb(153,105,172)');
   circle(600, 800,700)
    fill('rgb(163,10,250)');
   circle(600, 800,600)
    fill('purple');
   circle(600, 800,400)
//endcircle

//startcircle
   fill('rgb(163,10,250)');
   circle(7,703 ,550)
  
  fill('rgb(230,10,250)')
   circle(7,703,500)
  
  fill('Plum')
   circle(7,703,400)
  
  fill('Thistle')
   circle(7,703,300)
  
  fill('lavender')
   circle(7,703,100)
//endcircle

  //startcircle
    fill('rgb(153,105,172)');
  circle(209,41 ,300)
  fill('indigo')
  circle(209,41,200)
  fill('DarkMagenta')
  circle(209,41,100)
//endcircle

  //startcircle
   fill('DarkOrchid');
  circle(30,185,300)
   fill('DarkViolet');
  circle(30,185,250)
   fill('MediumOrchid');
  circle(30,185,200)
 fill('Fuchsia');
  circle(30,185,150)
  //endcircle
}

  function mousePressed() {
  print(mouseX +","+ mouseY)
  }
