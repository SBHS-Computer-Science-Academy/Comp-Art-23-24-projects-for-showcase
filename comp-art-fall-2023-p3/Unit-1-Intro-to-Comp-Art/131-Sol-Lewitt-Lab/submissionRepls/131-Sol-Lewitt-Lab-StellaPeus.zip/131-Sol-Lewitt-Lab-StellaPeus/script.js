function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("white");
 
  stroke('magenta');
  strokeWeight(15);
  fill('none');
  circle(57,53,200)
  strokeWeight(15)
  stroke('purple');
  circle(57,53,165)
  stroke('red');
  strokeWeight(15);
  fill('none');
  circle(57,53,150)
  stroke('green');
  circle(57,53,140)
  stroke('orange');
  circle(57,53,130)
  stroke('lavender');
  circle(57,53,120)
  stroke('brown');
  circle(57,53,110)
  stroke('lightgreen');
  circle(57,53,100)
  stroke('yellow');
  circle(57,53,90)
  stroke('cyan');
  circle(57,53,80)
  stroke('teal');
  circle(57,53,70)
  stroke('magenta');
  circle(57,53,60)
  stroke('purple');
  circle(57,53,50)
  stroke('red');
  circle(57,53,40)
  stroke('green');
  circle(57,53,20)
  fill('orange');
  circle(57,53,40)
  
  stroke('magenta');
  strokeWeight(15);
  fill('none');
  circle(56,216,180)
  strokeWeight(15)
  stroke('purple');
  circle(56,216,165)
  stroke('red');
  strokeWeight(15);
  fill('none');
  circle(56,216,150)
  stroke('green');
  circle(56,216,140)
  stroke('orange');
  circle(56,216,130)
  stroke('lavender');
  circle(56,216,120)
  stroke('brown');
  circle(56,216,110)
  stroke('lightgreen');
  circle(56,216,100)
  stroke('yellow');
  circle(56,216,90)
  stroke('cyan');
  circle(56,216,80)
  stroke('teal');
  circle(56,216,70)
  stroke('magenta');
  circle(56,216,60)
  stroke('purple');
  circle(56,216,50)
  stroke('red');
  circle(56,216,40)
  stroke('green');
  circle(56,216,20)
  fill('orange');
  circle(56,216,40)
  
  stroke('magenta');
  strokeWeight(15);
  fill('none');
  circle(64,379,180)
  strokeWeight(15)
  stroke('purple');
  circle(64,379,165)
  stroke('red');
  strokeWeight(15);
  fill('none');
  circle(64,379,150)
  stroke('green');
  circle(64,379,140)
  stroke('orange');
  circle(64,379,130)
  stroke('lavender');
  circle(64,379,120)
  stroke('brown');
  circle(64,379,110)
  stroke('lightgreen');
  circle(64,379,100)
  stroke('yellow');
  circle(64,379,90)
  stroke('cyan');
  circle(64,379,80)
  stroke('teal');
  circle(64,379,70)
  stroke('magenta');
  circle(64,379,60)
  stroke('purple');
  circle(64,379,50)
  stroke('red');
  circle(64,379,40)
  stroke('green');
  circle(64,379,20)
  fill('orange');
  circle(64,379,40)
  
  stroke('magenta');
  strokeWeight(15);
  fill('none');
  circle(219,60,180)
  strokeWeight(15)
  stroke('purple');
  circle(219,60,165)
  stroke('red');
  strokeWeight(15);
  fill('none');
  circle(219,60,150)
  stroke('green');
  circle(219,60,140)
  stroke('orange');
  circle(219,60,130)
  stroke('lavender');
  circle(219,60,120)
  stroke('brown');
  circle(219,60,110)
  stroke('lightgreen');
  circle(219,60,100)
  stroke('yellow');
  circle(219,60,90)
  stroke('cyan');
  circle(219,60,80)
  stroke('teal');
  circle(219,60,70)
  stroke('magenta');
  circle(219,60,60)
  stroke('purple');
  circle(219,60,50)
  stroke('red');
  circle(219,60,40)
  stroke('green');
  circle(219,60,20)
  fill('orange');
  circle(219,60,40)
  
  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(204,340,200)
  strokeWeight(10)
  stroke('purple');
  circle(204,340,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(204,340,150)
  stroke('green');
  circle(204,340,140)
  stroke('orange');
  circle(204,340,130)
  stroke('lavender');
  circle(204,340,120)
  stroke('brown');
  circle(204,340,110)
  stroke('lightgreen');
  circle(204,340,100)
  stroke('yellow');
  circle(204,340,90)
  stroke('cyan');
  circle(204,340,80)
  stroke('teal');
  circle(204,340,70)
  stroke('magenta');
  circle(204,340,60)
  stroke('purple');
  circle(204,340,50)
  stroke('red');
  circle(204,340,40)
  stroke('green');
  circle(204,340,20)
  fill('orange');
  circle(204,340,40)
    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(215,192,200)
  strokeWeight(10)
  stroke('purple');
  circle(215,192,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(215,192,150)
  stroke('green');
  circle(215,192,140)
  stroke('orange');
  circle(215,192,130)
  stroke('lavender');
  circle(215,192,120)
  stroke('brown');
  circle(215,192,110)
  stroke('lightgreen');
  circle(215,192,100)
  stroke('yellow');
  circle(215,192,90)
  stroke('cyan');
  circle(215,192,80)
  stroke('teal');
  circle(215,192,70)
  stroke('magenta');
  circle(215,192,60)
  stroke('purple');
  circle(215,192,50)
  stroke('red');
  circle(215,192,40)
  stroke('green');
  circle(215,192,20)
  fill('orange');
  circle(215,192,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(38,539,200)
  strokeWeight(10)
  stroke('purple');
  circle(38,539,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(38,539,150)
  stroke('green');
  circle(38,539,140)
  stroke('orange');
  circle(38,539,130)
  stroke('lavender');
  circle(38,539,120)
  stroke('brown');
  circle(38,539,110)
  stroke('lightgreen');
  circle(38,539,100)
  stroke('yellow');
  circle(38,539,90)
  stroke('cyan');
  circle(38,539,80)
  stroke('teal');
  circle(38,539,70)
  stroke('magenta');
  circle(38,539,60)
  stroke('purple');
  circle(38,539,50)
  stroke('red');
  circle(38,539,40)
  stroke('green');
  circle(38,539,20)
  fill('orange');
  circle(38,539,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(202,510,200)
  strokeWeight(10)
  stroke('purple');
  circle(202,510,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(202,510,150)
  stroke('green');
  circle(202,510,140)
  stroke('orange');
  circle(202,510,130)
  stroke('lavender');
  circle(202,510,120)
  stroke('brown');
  circle(202,510,110)
  stroke('lightgreen');
  circle(202,510,100)
  stroke('yellow');
  circle(202,510,90)
  stroke('cyan');
  circle(202,510,80)
  stroke('teal');
  circle(202,510,70)
  stroke('magenta');
  circle(202,510,60)
  stroke('purple');
  circle(202,510,50)
  stroke('red');
  circle(202,510,40)
  stroke('green');
  circle(202,510,20)
  fill('orange');
  circle(202,510,40)

  
  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(39,720,200)
  strokeWeight(10)
  stroke('purple');
  circle(39,720,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(39,720,150)
  stroke('green');
  circle(39,720,140)
  stroke('orange');
  circle(39,720,130)
  stroke('lavender');
  circle(39,720,120)
  stroke('brown');
  circle(39,720,110)
  stroke('lightgreen');
  circle(39,720,100)
  stroke('yellow');
  circle(39,720,90)
  stroke('cyan');
  circle(39,720,80)
  stroke('teal');
  circle(39,720,70)
  stroke('magenta');
  circle(39,720,60)
  stroke('purple');
  circle(39,720,50)
  stroke('red');
  circle(39,720,40)
  stroke('green');
  circle(39,720,20)
  fill('orange');
  circle(39,720,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(178,663,200)
  strokeWeight(10)
  stroke('purple');
  circle(178,663,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(178,663,150)
  stroke('green');
  circle(178,663,140)
  stroke('orange');
  circle(178,663,130)
  stroke('lavender');
  circle(178,663,120)
  stroke('brown');
  circle(178,663,110)
  stroke('lightgreen');
  circle(178,663,100)
  stroke('yellow');
  circle(178,663,90)
  stroke('cyan');
  circle(178,663,80)
  stroke('teal');
  circle(178,663,70)
  stroke('magenta');
  circle(178,663,60)
  stroke('purple');
  circle(178,663,50)
  stroke('red');
  circle(178,663,40)
  stroke('green');
  circle(178,663,20)
  fill('orange');
  circle(178,663,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(393,61,200)
  strokeWeight(10)
  stroke('purple');
  circle(393,61,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(393,61,150)
  stroke('green');
  circle(393,61,140)
  stroke('orange');
  circle(393,61,130)
  stroke('lavender');
  circle(393,61,120)
  stroke('brown');
  circle(393,61,110)
  stroke('lightgreen');
  circle(393,61,100)
  stroke('yellow');
  circle(393,61,90)
  stroke('cyan');
  circle(393,61,80)
  stroke('teal');
  circle(393,61,70)
  stroke('magenta');
  circle(393,61,60)
  stroke('purple');
  circle(393,61,50)
  stroke('red');
  circle(393,61,40)
  stroke('green');
  circle(393,61,20)
  fill('orange');
  circle(393,61,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(370,200,200)
  strokeWeight(10)
  stroke('purple');
  circle(370,200,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(370,200,150)
  stroke('green');
  circle(370,200,140)
  stroke('orange');
  circle(370,200,130)
  stroke('lavender');
  circle(370,200,120)
  stroke('brown');
  circle(370,200,110)
  stroke('lightgreen');
  circle(370,200,100)
  stroke('yellow');
  circle(370,200,90)
  stroke('cyan');
  circle(370,200,80)
  stroke('teal');
  circle(370,200,70)
  stroke('magenta');
  circle(370,200,60)
  stroke('purple');
  circle(370,200,50)
  stroke('red');
  circle(370,200,40)
  stroke('green');
  circle(370,200,20)
  fill('orange');
  circle(370,200,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(365,357,200)
  strokeWeight(10)
  stroke('purple');
  circle(365,357,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(365,357,150)
  stroke('green');
  circle(365,357,140)
  stroke('orange');
  circle(365,357,130)
  stroke('lavender');
  circle(365,357,120)
  stroke('brown');
  circle(365,357,110)
  stroke('lightgreen');
  circle(365,357,100)
  stroke('yellow');
  circle(365,357,90)
  stroke('cyan');
  circle(365,357,80)
  stroke('teal');
  circle(365,357,70)
  stroke('magenta');
  circle(365,357,60)
  stroke('purple');
  circle(365,357,50)
  stroke('red');
  circle(365,357,40)
  stroke('green');
  circle(365,357,20)
  fill('orange');
  circle(365,357,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(339,494,200)
  strokeWeight(10)
  stroke('purple');
  circle(339,494,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(339,494,150)
  stroke('green');
  circle(339,494,140)
  stroke('orange');
  circle(339,494,130)
  stroke('lavender');
  circle(339,494,120)
  stroke('brown');
  circle(339,494,110)
  stroke('lightgreen');
  circle(339,494,100)
  stroke('yellow');
  circle(339,494,90)
  stroke('cyan');
  circle(339,494,80)
  stroke('teal');
  circle(339,494,70)
  stroke('magenta');
  circle(339,494,60)
  stroke('purple');
  circle(339,494,50)
  stroke('red');
  circle(339,494,40)
  stroke('green');
  circle(339,494,20)
  fill('orange');
  circle(339,494,40)

    stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(335,657,200)
  strokeWeight(10)
  stroke('purple');
  circle(335,657,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(335,657,150)
  stroke('green');
  circle(335,657,140)
  stroke('orange');
  circle(335,657,130)
  stroke('lavender');
  circle(335,657,120)
  stroke('brown');
  circle(335,657,110)
  stroke('lightgreen');
  circle(335,657,100)
  stroke('yellow');
  circle(335,657,90)
  stroke('cyan');
  circle(335,657,80)
  stroke('teal');
  circle(335,657,70)
  stroke('magenta');
  circle(335,657,60)
  stroke('purple');
  circle(335,657,50)
  stroke('red');
  circle(335,657,40)
  stroke('green');
  circle(335,657,20)
  fill('orange');
  circle(335,657,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(159,793,200)
  strokeWeight(10)
  stroke('purple');
  circle(159,793,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(159,793,150)
  stroke('green');
  circle(159,793,140)
  stroke('orange');
  circle(159,793,130)
  stroke('lavender');
  circle(159,793,120)
  stroke('brown');
  circle(159,793,110)
  stroke('lightgreen');
  circle(159,793,100)
  stroke('yellow');
  circle(159793,90)
  stroke('cyan');
  circle(159,793,80)
  stroke('teal');
  circle(159,793,70)
  stroke('magenta');
  circle(159,793,60)
  stroke('purple');
  circle(159,793,50)
  stroke('red');
  circle(159,793,40)
  stroke('green');
  circle(159,793,20)
  fill('orange');
  circle(159,793,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(321,792,200)
  strokeWeight(10)
  stroke('purple');
  circle(321,792,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(321,792,150)
  stroke('green');
  circle(321,792,140)
  stroke('orange');
  circle(321,792,130)
  stroke('lavender');
  circle(321,792,120)
  stroke('brown');
  circle(321,792,110)
  stroke('lightgreen');
  circle(321,792,100)
  stroke('yellow');
  circle(321,792,90)
  stroke('cyan');
  circle(321,792,80)
  stroke('teal');
  circle(321,792,70)
  stroke('magenta');
  circle(321,792,60)
  stroke('purple');
  circle(321,792,50)
  stroke('red');
  circle(321,792,40)
  stroke('green');
  circle(321,792,20)
  fill('orange');
  circle(321,792,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(574,64,200)
  strokeWeight(10)
  stroke('purple');
  circle(574,64,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(574,64,150)
  stroke('green');
  circle(574,64,140)
  stroke('orange');
  circle(574,64,130)
  stroke('lavender');
  circle(574,64,120)
  stroke('brown');
  circle(574,64,110)
  stroke('lightgreen');
  circle(574,64,100)
  stroke('yellow');
  circle(574,64,90)
  stroke('cyan');
  circle(574,64,80)
  stroke('teal');
  circle(574,64,70)
  stroke('magenta');
  circle(574,64,60)
  stroke('purple');
  circle(574,64,50)
  stroke('red');
  circle(574,64,40)
  stroke('green');
  circle(574,64,20)
  fill('orange');
  circle(574,64,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(523,201,200)
  strokeWeight(10)
  stroke('purple');
  circle(523,201,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(523,201,150)
  stroke('green');
  circle(523,201,140)
  stroke('orange');
  circle(523,201,130)
  stroke('lavender');
  circle(523,201,120)
  stroke('brown');
  circle(523,201,110)
  stroke('lightgreen');
  circle(523,201,100)
  stroke('yellow');
  circle(523,201,90)
  stroke('cyan');
  circle(523,201,80)
  stroke('teal');
  circle(523,201,70)
  stroke('magenta');
  circle(523,201,60)
  stroke('purple');
  circle(523,201,50)
  stroke('red');
  circle(523,201,40)
  stroke('green');
  circle(523,201,20)
  fill('orange');
  circle(523,201,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(496, 328,200)
  strokeWeight(10)
  stroke('purple');
  circle(496, 328,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(496, 328,150)
  stroke('green');
  circle(496, 328,140)
  stroke('orange');
  circle(496, 328,130)
  stroke('lavender');
  circle(496, 328,120)
  stroke('brown');
  circle(496, 328,110)
  stroke('lightgreen');
  circle(496, 328,100)
  stroke('yellow');
  circle(496, 328,90)
  stroke('cyan');
  circle(496, 328,80)
  stroke('teal');
  circle(496, 328,70)
  stroke('magenta');
  circle(496, 328,60)
  stroke('purple');
  circle(496, 328,50)
  stroke('red');
  circle(496, 328,40)
  stroke('green');
  circle(496, 328,20)
  fill('orange');
  circle(496, 328,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(499,498,200)
  strokeWeight(10)
  stroke('purple');
  circle(499, 498,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(499, 498,150)
  stroke('green');
  circle(499, 498,140)
  stroke('orange');
  circle(499, 498,130)
  stroke('lavender');
  circle(499, 498,120)
  stroke('brown');
  circle(499, 498,110)
  stroke('lightgreen');
  circle(499, 498,100)
  stroke('yellow');
  circle(499, 498,90)
  stroke('cyan');
  circle(499, 498,80)
  stroke('teal');
  circle(499, 498,70)
  stroke('magenta');
  circle(499, 498,60)
  stroke('purple');
  circle(499, 498,50)
  stroke('red');
  circle(499, 498,40)
  stroke('green');
  circle(499, 498,20)
  fill('orange');
  circle(499, 498,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(467, 627,200)
  strokeWeight(10)
  stroke('purple');
  circle(467, 627,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(467, 627,150)
  stroke('green');
  circle(467, 627,140)
  stroke('orange');
  circle(467, 627,130)
  stroke('lavender');
  circle(467, 627,120)
  stroke('brown');
  circle(467, 627,110)
  stroke('lightgreen');
  circle(467, 627,100)
  stroke('yellow');
  circle(467, 627,90)
  stroke('cyan');
  circle(467, 627,80)
  stroke('teal');
  circle(467, 627,70)
  stroke('magenta');
  circle(467, 627,60)
  stroke('purple');
  circle(467, 627,50)
  stroke('red');
  circle(467, 627,40)
  stroke('green');
  circle(467, 627,20)
  fill('orange');
  circle(467, 627,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(473, 778,200)
  strokeWeight(10)
  stroke('purple');
  circle(473, 778,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(473, 778473, 778,150)
  stroke('green');
  circle(473, 778,140)
  stroke('orange');
  circle(473, 778,130)
  stroke('lavender');
  circle(473, 778,120)
  stroke('brown');
  circle(473, 778,110)
  stroke('lightgreen');
  circle(473, 778,100)
  stroke('yellow');
  circle(473, 778,90)
  stroke('cyan');
  circle(473, 778,80)
  stroke('teal');
  circle(473, 778,70)
  stroke('magenta');
  circle(473, 778,60)
  stroke('purple');
  circle(473, 778,50)
  stroke('red');
  circle(473, 778,40)
  stroke('green');
  circle(473, 778,20)
  fill('orange');
  circle(473, 778,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(734, 62,200)
  strokeWeight(10)
  stroke('purple');
  circle(734, 62,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(734, 62,150)
  stroke('green');
  circle(734, 62,140)
  stroke('orange');
  circle(734, 62,130)
  stroke('lavender');
  circle(734, 62,120)
  stroke('brown');
  circle(734, 62,110)
  stroke('lightgreen');
  circle(734, 62,100)
  stroke('yellow');
  circle(734, 62,90)
  stroke('cyan');
  circle(734, 62,80)
  stroke('teal');
  circle(734, 62,70)
  stroke('magenta');
  circle(734, 62,60)
  stroke('purple');
  circle(734, 62,50)
  stroke('red');
  circle(734, 62,40)
  stroke('green');
  circle(734, 62,20)
  fill('orange');
  circle(734, 62,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(687, 213,200)
  strokeWeight(10)
  stroke('purple');
  circle(687, 213,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(687, 213,150)
  stroke('green');
  circle(687, 213,140)
  stroke('orange');
  circle(687, 213,130)
  stroke('lavender');
  circle(687, 213,120)
  stroke('brown');
  circle(687, 213,110)
  stroke('lightgreen');
  circle(687, 213,100)
  stroke('yellow');
  circle(687, 213,90)
  stroke('cyan');
  circle(687, 213,80)
  stroke('teal');
  circle(687, 213,70)
  stroke('magenta');
  circle(687, 213,60)
  stroke('purple');
  circle(687, 213,50)
  stroke('red');
  circle(687, 213,40)
  stroke('green');
  circle(687, 213,20)
  fill('orange');
  circle(687, 213,40)

   stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(640, 344,200)
  strokeWeight(10)
  stroke('purple');
  circle(640, 344,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(640, 344,150)
  stroke('green');
  circle(640, 344,140)
  stroke('orange');
  circle(640, 344,130)
  stroke('lavender');
  circle(640, 344,120)
  stroke('brown');
  circle(640, 344,110)
  stroke('lightgreen');
  circle(640, 344,100)
  stroke('yellow');
  circle(640, 344,90)
  stroke('cyan');
  circle(640, 344,80)
  stroke('teal');
  circle(640, 344,70)
  stroke('magenta');
  circle(640, 344,60)
  stroke('purple');
  circle(640, 344,50)
  stroke('red');
  circle(640, 344,40)
  stroke('green');
  circle(640, 344,20)
  fill('orange');
  circle(640, 344,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(656, 503,200)
  strokeWeight(10)
  stroke('purple');
  circle(656, 503,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(656, 503,150)
  stroke('green');
  circle(656, 503,140)
  stroke('orange');
  circle(656, 503,130)
  stroke('lavender');
  circle(656, 503,120)
  stroke('brown');
  circle(656, 503,110)
  stroke('lightgreen');
  circle(656, 503,100)
  stroke('yellow');
  circle(656, 503,90)
  stroke('cyan');
  circle(656, 503,80)
  stroke('teal');
  circle(656, 503,70)
  stroke('magenta');
  circle(656, 503,60)
  stroke('purple');
  circle(656, 503,50)
  stroke('red');
  circle(656, 503,40)
  stroke('green');
  circle(656, 503,20)
  fill('orange');
  circle(656, 503,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(636, 666,200)
  strokeWeight(10)
  stroke('purple');
  circle(636, 666,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(636, 666,150)
  stroke('green');
  circle(636, 666,140)
  stroke('orange');
  circle(636, 666,130)
  stroke('lavender');
  circle(636, 666,120)
  stroke('brown');
  circle(636, 666,110)
  stroke('lightgreen');
  circle(636, 666,100)
  stroke('yellow');
  circle(636, 666,90)
  stroke('cyan');
  circle(636, 666,80)
  stroke('teal');
  circle(636, 666,70)
  stroke('magenta');
  circle(636, 666,60)
  stroke('purple');
  circle(636, 666,50)
  stroke('red');
  circle(636, 666,40)
  stroke('green');
  circle(636, 666,20)
  fill('orange');
  circle(636, 666,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(633, 798,200)
  strokeWeight(10)
  stroke('purple');
  circle(633, 798,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(633, 798,150)
  stroke('green');
  circle(633, 798,140)
  stroke('orange');
  circle(633, 798,130)
  stroke('lavender');
  circle(633, 798,120)
  stroke('brown');
  circle(633, 798,110)
  stroke('lightgreen');
  circle(633, 798,100)
  stroke('yellow');
  circle(633, 798,90)
  stroke('cyan');
  circle(633, 798,80)
  stroke('teal');
  circle(633, 798,70)
  stroke('magenta');
  circle(633, 798,60)
  stroke('purple');
  circle(633, 798,50)
  stroke('red');
  circle(633, 798,40)
  stroke('green');
  circle(633, 798,20)
  fill('orange');
  circle(633, 798,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(898, 59,200)
  strokeWeight(10)
  stroke('purple');
  circle(898, 59,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(898, 59,150)
  stroke('green');
  circle(898, 59,140)
  stroke('orange');
  circle(898, 59,130)
  stroke('lavender');
  circle(898, 59,120)
  stroke('brown');
  circle(898, 59,110)
  stroke('lightgreen');
  circle(898, 59,100)
  stroke('yellow');
  circle(898, 59,90)
  stroke('cyan');
  circle(898, 59,80)
  stroke('teal');
  circle(898, 59,70)
  stroke('magenta');
  circle(898, 59,60)
  stroke('purple');
  circle(898, 59,50)
  stroke('red');
  circle(898, 59,40)
  stroke('green');
  circle(898, 59,20)
  fill('orange');
  circle(898, 59,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(852, 205,200)
  strokeWeight(10)
  stroke('purple');
  circle(852, 205,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(852, 205,150)
  stroke('green');
  circle(852, 205,140)
  stroke('orange');
  circle(852, 205,130)
  stroke('lavender');
  circle(852, 205,120)
  stroke('brown');
  circle(852, 205,110)
  stroke('lightgreen');
  circle(852, 205,100)
  stroke('yellow');
  circle(852, 205,90)
  stroke('cyan');
  circle(852, 205,80)
  stroke('teal');
  circle(852, 205,70)
  stroke('magenta');
  circle(852, 205,60)
  stroke('purple');
  circle(852, 205,50)
  stroke('red');
  circle(852, 205,40)
  stroke('green');
  circle(852, 205,20)
  fill('orange');
  circle(852, 205,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(808, 511,200)
  strokeWeight(10)
  stroke('purple');
  circle(808, 511,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(808, 511,150)
  stroke('green');
  circle(808, 511,140)
  stroke('orange');
  circle(808, 511,130)
  stroke('lavender');
  circle(808, 511,120)
  stroke('brown');
  circle(808, 511,110)
  stroke('lightgreen');
  circle(808, 511,100)
  stroke('yellow');
  circle(808, 511,90)
  stroke('cyan');
  circle(808, 511,80)
  stroke('teal');
  circle(808, 511,70)
  stroke('magenta');
  circle(808, 511,60)
  stroke('purple');
  circle(808, 511,50)
  stroke('red');
  circle(808, 511,40)
  stroke('green');
  circle(808, 511,20)
  fill('orange');
  circle(808, 511,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(808, 359,200)
  strokeWeight(10)
  stroke('purple');
  circle(808, 359,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(808, 359,150)
  stroke('green');
  circle(808, 359,140)
  stroke('orange');
  circle(808, 359,130)
  stroke('lavender');
  circle(808, 359,120)
  stroke('brown');
  circle(808, 359,110)
  stroke('lightgreen');
  circle(808, 359,100)
  stroke('yellow');
  circle(808, 359,90)
  stroke('cyan');
  circle(808, 359,80)
  stroke('teal');
  circle(808, 359,70)
  stroke('magenta');
  circle(808, 359,60)
  stroke('purple');
  circle(808, 359,50)
  stroke('red');
  circle(808, 359,40)
  stroke('green');
  circle(808, 359,20)
  fill('orange');
  circle(808, 359,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(775, 655,200)
  strokeWeight(10)
  stroke('purple');
  circle(775, 655,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(775, 655,150)
  stroke('green');
  circle(775, 655,140)
  stroke('orange');
  circle(775, 655,130)
  stroke('lavender');
  circle(775, 655,120)
  stroke('brown');
  circle(775, 655,110)
  stroke('lightgreen');
  circle(775, 655,100)
  stroke('yellow');
  circle(775, 655,90)
  stroke('cyan');
  circle(775, 655,80)
  stroke('teal');
  circle(775, 655,70)
  stroke('magenta');
  circle(775, 655,60)
  stroke('purple');
  circle(775, 655,50)
  stroke('red');
  circle(775, 655,40)
  stroke('green');
  circle(775, 655,20)
  fill('orange');
  circle(775, 655,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(792, 796,200)
  strokeWeight(10)
  stroke('purple');
  circle(792, 796,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(792, 796,150)
  stroke('green');
  circle(792, 796,140)
  stroke('orange');
  circle(792, 796,130)
  stroke('lavender');
  circle(792, 796,120)
  stroke('brown');
  circle(792, 796,110)
  stroke('lightgreen');
  circle(792, 796,100)
  stroke('yellow');
  circle(792, 796,90)
  stroke('cyan');
  circle(792, 796,80)
  stroke('teal');
  circle(792, 796,70)
  stroke('magenta');
  circle(792, 796,60)
  stroke('purple');
  circle(792, 796,50)
  stroke('red');
  circle(792, 796,40)
  stroke('green');
  circle(792, 796,20)
  fill('orange');
  circle(792, 796,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(994, 159,200)
  strokeWeight(10)
  stroke('purple');
  circle(994, 159,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(994, 159,150)
  stroke('green');
  circle(994, 159,140)
  stroke('orange');
  circle(994, 159,130)
  stroke('lavender');
  circle(994, 159,120)
  stroke('brown');
  circle(994, 159,110)
  stroke('lightgreen');
  circle(994, 159,100)
  stroke('yellow');
  circle(994, 159,90)
  stroke('cyan');
  circle(994, 159,80)
  stroke('teal');
  circle(994, 159,70)
  stroke('magenta');
  circle(994, 159,60)
  stroke('purple');
  circle(994, 159,50)
  stroke('red');
  circle(994, 159,40)
  stroke('green');
  circle(994, 159,20)
  fill('orange');
  circle(994, 159,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(961, 319,200)
  strokeWeight(10)
  stroke('purple');
  circle(961, 319,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(961, 319,150)
  stroke('green');
  circle(961, 319,140)
  stroke('orange');
  circle(961, 319,130)
  stroke('lavender');
  circle(961, 319,120)
  stroke('brown');
  circle(961, 319,110)
  stroke('lightgreen');
  circle(961, 319,100)
  stroke('yellow');
  circle(961, 319,90)
  stroke('cyan');
  circle(961, 319,80)
  stroke('teal');
  circle(961, 319,70)
  stroke('magenta');
  circle(961, 319,60)
  stroke('purple');
  circle(961, 319,50)
  stroke('red');
  circle(961, 319,40)
  stroke('green');
  circle(961, 319,20)
  fill('orange');
  circle(961, 319,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(951, 468,200)
  strokeWeight(10)
  stroke('purple');
  circle(951, 468,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(951, 468,150)
  stroke('green');
  circle(951, 468,140)
  stroke('orange');
  circle(951, 468,130)
  stroke('lavender');
  circle(951, 468,120)
  stroke('brown');
  circle(951, 468,110)
  stroke('lightgreen');
  circle(951, 468,100)
  stroke('yellow');
  circle(951, 468,90)
  stroke('cyan');
  circle(951, 468,80)
  stroke('teal');
  circle(951, 468,70)
  stroke('magenta');
  circle(951, 468,60)
  stroke('purple');
  circle(951, 468,50)
  stroke('red');
  circle(951, 468,40)
  stroke('green');
  circle(951, 468,20)
  fill('orange');
  circle(951, 468,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(938, 626,200)
  strokeWeight(10)
  stroke('purple');
  circle(938, 626,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(938, 626,150)
  stroke('green');
  circle(938, 626,140)
  stroke('orange');
  circle(938, 626,130)
  stroke('lavender');
  circle(938, 626,120)
  stroke('brown');
  circle(938, 626,110)
  stroke('lightgreen');
  circle(938, 626,100)
  stroke('yellow');
  circle(938, 626,90)
  stroke('cyan');
  circle(938, 626,80)
  stroke('teal');
  circle(938, 626,70)
  stroke('magenta');
  circle(938, 626,60)
  stroke('purple');
  circle(938, 626,50)
  stroke('red');
  circle(938, 626,40)
  stroke('green');
  circle(938, 626,20)
  fill('orange');
  circle(938, 626,40)

  stroke('magenta');
  strokeWeight(10);
  fill('none');
  circle(929, 761,200)
  strokeWeight(10)
  stroke('purple');
  circle(929, 761,165)
  stroke('red');
  strokeWeight(10);
  fill('none');
  circle(929, 761,150)
  stroke('green');
  circle(929, 761,140)
  stroke('orange');
  circle(929, 761,130)
  stroke('lavender');
  circle(929, 761,120)
  stroke('brown');
  circle(929, 761,110)
  stroke('lightgreen');
  circle(929, 761,100)
  stroke('yellow');
  circle(929, 761,90)
  stroke('cyan');
  circle(929, 761,80)
  stroke('teal');
  circle(929, 761,70)
  stroke('magenta');
  circle(929, 761,60)
  stroke('purple');
  circle(929, 761,50)
  stroke('red');
  circle(929, 761,40)
  stroke('green');
  circle(929, 761,20)
  fill('orange');
  circle(929, 761,40)
  
}