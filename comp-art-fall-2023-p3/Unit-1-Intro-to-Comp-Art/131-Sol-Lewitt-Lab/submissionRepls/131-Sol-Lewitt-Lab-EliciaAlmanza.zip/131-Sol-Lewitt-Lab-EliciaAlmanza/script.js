function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("black");
  

  
 fill('pink')
ellipse(0,0,340,340)

  fill('DarkGreen');
  ellipse(0,0,840,840);//lefttop
 
  fill('black');
  ellipse(0,0,740,740);//lefttop
  
  fill('DarkGreen');
  ellipse(0,0,640,640);//lefttop
  
  fill('black');
  ellipse(0,0,540,540);//lefttop
  
  fill('DarkGreen');
  ellipse(0,0,440,440);//lefttop

  fill('black');
  ellipse(0,0,340,340);//lefttop
  
  fill('DarkGreen');
  ellipse(0,0,240,240);//lefttop
 
  fill('black');
  ellipse(0,0,140,140);//lefttop
 
  fill('DarkGreen')/
  ellipse(0,0,60,60);//lefttop

 
  
  
  fill('Darkred');
  ellipse(800,4,840,840);//righttop
 
  fill('black');
  ellipse(800,4,740,740);//righttop
  
  fill('Darkred');
  ellipse(800,4,640,640);//rightttop
  
  fill('black');
  ellipse(800,4,540,540);//righttop
  
  fill('Darkred');
  ellipse(800,4,440,440);//rightttop

  fill('black');
  ellipse(800,4,340,340);//ttop
  
  fill('Darkred');
  ellipse(800,4,240,240);//lefttop
 
  fill('black');
  ellipse(800,4,140,140);//lefttop
 
  fill('Darkred')/
  ellipse(800,4,60,60);//lefttop



  
  
  fill('Indigo');
  ellipse(0,798,840,840);//bottomleft
  
  fill('black');
  ellipse(0,798,740,740);//bottomleft
  
  fill('Indigo');
  ellipse(0,798,640,640);//bottomleft
  
  fill('black');
  ellipse(0,798,540,540);//bottomleft
  
  fill('Indigo');
  ellipse(0,798,440,440);//bottomleft
  
  fill('black')
  ellipse(0,798,340,340)//bottomleft

  fill('Indigo')
  ellipse(0,798,240,240)//bottomleft

  fill('black')
  ellipse(0,798,140,140)//bottomleft

  fill('Indigo')
  ellipse(0,798,60,60)//bottomleft


  fill('Yellow')
  ellipse(800,795,840,840)//bottomright
  
  fill('black');
  ellipse(800,795,740,740);//bottomright
  
  fill('Yellow');
  ellipse(800,795,640,640);//bottomright
  
  fill('black');
  ellipse(800,795,540,540);//bottomright
  
  fill('Yellow');
  ellipse(800,795,440,440);//bottomright
  
  fill('black')
  ellipse(800,795,340,340)//bottomright

  fill('Yellow')
  ellipse(800,795,240,240)//bottomright

  fill('black')
  ellipse(800,795,140,140)//bottomright

  fill('Yellow')
  ellipse(800,795,60,60)//bottomright

  
  
  fill('black');
  circle(400,402,440);//MIDDLE

  fill('MediumVioletRed');
  circle(400,402,340);//MIDDLE

  fill('black')
  circle(400,402,240)//MIDDLE

  fill('MediumVioletRed')
  circle(400,402,140)//MIDDLE

  fill('black')
  circle(400,402,40)//MIDDLE

}