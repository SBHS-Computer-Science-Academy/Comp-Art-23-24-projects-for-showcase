function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("white");
  
  fill('royalblue');
  ellipse(0,0,1000);
  fill('green');
  ellipse(0,0,900);
  fill('hotpink');
  ellipse(0, 0, 800);
  fill('maroon');
  ellipse(0,0,720);
  fill('indigo')
  ellipse(0,0,650);
  fill('steelblue')
  ellipse(0,0,500)
  fill('navy')
  ellipse(770,690,1000)
  fill('midnightblue')
  ellipse(770,690,900)
  fill('navy')
  ellipse(770,690,800)
  fill('midnightblue')
  ellipse(770,690,700)
  fill('navy')
  ellipse(770,690,600)
  fill('midnightblue')
  ellipse(770,690,500)
  fill('navy')
  ellipse(770,690,400)
  fill('midnightblue')
  ellipse(770,690,300)
  fill('navy')
  ellipse(770,690,200)
  fill('midnightblue')
  ellipse(790,700,150)
  // arc(300,300,300,300, 0, 45, PIE);
  // fill('black');
  // ellipse(200,200,240,240);
  // fill('blue');
  // ellipse(200,200,140,140);
  // ellipse(149,535,300)
  // fill('black')
  // ellipse(156,535,200)
}