function setup() {
  let myCanvas = createCanvas(1000, 800);
//   myCanvas.parent("myCanvas");
  
//   createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("white");
fill("red")
  triangle(27,21,618,18,326,702)
   fill("orange")
  triangle(62,39,587,35,324,661)
fill("yellow")
triangle(93,58,560,54,323,626)
fill("green")
triangle(119,75,526,73,322,592)
fill("blue")
triangle(143,94,500,92,320,551)
fill("indigo")
triangle(170,117,474,116,318,506)
fill("pink")
triangle(189,133,451,133,317,463)
fill("hotpink")
triangle(211,148,424,148,317,420)


}

function mousePressed() {
  print(mouseX + ", " + mouseY)
  circle(mouseX, mouseY, 5)
}
