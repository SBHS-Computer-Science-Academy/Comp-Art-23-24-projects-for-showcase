function setup() {
  let myCanvas = createCanvas(2000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("Firebrick");


  fill("Firebrick")
  circle(160, 200, 1,000)//start of top left cirlce 
  fill("OrangeRed")
  circle(160,200, 920)
  fill("DarkOrange")
  circle(160, 200, 840)
  fill("orange")
  circle(160, 200, 760);
  fill("Maroon");
  circle(160, 200, 680); 
  fill("DarkRed")
  circle(160, 200, 600);
  fill("Firebrick")
  circle(160, 200, 520)
  fill("OrangeRed")
  circle(160, 200, 440)
  fill("DarkOrange")
  circle(160, 200, 360)
  fill("Orange")
  circle(160, 200, 280)
  fill("Maroon")
  circle(160, 200, 200)
  fill("DarkRed")
  circle(160, 200, 120)
  fill("Firebrick")
  circle(160, 200, 40)//end of top left circle 

  fill("Firebrick")
  circle(700, 600, 920)//start of bottom right circle 
  fill("DarkRed")
  circle(700, 600, 840)
  fill("Maroon")
  circle(700, 600, 760)
  fill("orange")
  circle(700, 600, 680)
  fill("DarkOrange")
  circle(700, 600, 600)
  fill("OrangeRed")
  circle(700, 600, 520)
  fill("Firebrick")
  circle(700, 600, 440)
  fill("DarkRed")
  circle(700, 600, 360)
  fill("Maroon");
  circle(700, 600, 280)
  fill("orange")
  circle(700, 600, 200)
  fill("DarkOrange")
  circle(700, 600, 120)
  fill("OrangeRed")
  circle(700, 600, 40)//end of bottom right circle 

  fill("Firebrick")
  circle(150, 700, 440)//start of bottom left circle 
  fill("OrangeRed")
  circle(150, 700, 360)
  fill("DarkOrange")
  circle(150,700, 280)
  fill("orange")
  circle(150,700, 200)
  fill("Maroon")
  circle(150,700, 120)
  fill("DarkRed")
  circle(150,700, 40)//end of bottom left circle 

  fill("OrangeRed")
  circle(800, 50, 600)//start of top right circle 
  fill("DarkOrange")
  circle(800, 50, 520)
  fill("orange")
  circle(800, 50, 440)
  fill("Maroon")
  circle(800, 50, 360)
  fill("DarkRed")
  circle(800, 50, 280)
  fill("Firebrick")
  circle(800, 50, 200)
  fill("OrangeRed")
  circle(800, 50, 120)
  fill("DarkOrange")
  circle(800, 50, 40)//end of top right circle  
  
}