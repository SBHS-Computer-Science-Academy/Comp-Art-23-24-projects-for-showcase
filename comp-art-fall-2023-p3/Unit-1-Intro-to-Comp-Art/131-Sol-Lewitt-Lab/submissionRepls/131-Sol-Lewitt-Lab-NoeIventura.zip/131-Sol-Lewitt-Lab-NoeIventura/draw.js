function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}
function draw() {
    fill("red"); rect(0, 0, 50, 800);
    fill("limegreen"); rect(50, 0, 50, 800);
    fill("orange"); rect(100, 0, 50, 800);
    fill("dodgerblue"); rect(150, 0, 50, 800);
    fill("magenta"); rect(200, 0, 50, 800);
    fill("yellow"); rect(250, 0, 50, 800);
    fill("red"); rect(300, 0, 50, 800);
    fill("limegreen"); rect(350, 0, 50, 800);
    fill("orange"); rect(400, 0, 50, 800);
    fill("dodgerblue"); rect(450, 0, 50, 800);
    fill("magenta"); rect(500, 0, 50, 800);
    fill("yellow"); rect(550, 0, 50, 800);
    fill("red"); rect(600, 0, 50, 800);
    fill("limegreen"); rect(650, 0, 50, 800);
    fill("orange"); rect(700, 0, 50, 800);
    fill("dodgerblue"); rect(750, 0, 50, 800);
    fill("magenta"); rect(800, 0, 50, 800);
    fill("yellow"); rect(850, 0, 50, 800);
    fill("red"); rect(900, 0, 50, 800);
    fill("limegreen"); rect(950, 0, 50, 800);
    fill("orange"); rect(1000, 0, 50, 800);
}