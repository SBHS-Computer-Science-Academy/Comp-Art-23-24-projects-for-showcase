function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("grey");
  fill('Gainsboro');
  ellipse(400,400,800);
  circle(300,500,400)
  fill('cyan');
  ellipse(400,400,760);
  fill('lime');
  ellipse(400,400,730);
  fill('yellow');
  ellipse(400,400,680);
  fill('purple');
  ellipse(400,400,650);
  fill('maroon');
  ellipse(400,400,630);
  fill('crimson');
  ellipse(400,400,610);
  fill('DeepPink');
  ellipse(400,400,590);
  fill('magenta');
  ellipse(400,400,560);
  fill('violet');
  ellipse(400,400,530);
  fill('plum');
  ellipse(400,400,500);
  fill('thistle');
  ellipse(400,400,470);
  fill('Lavender');
  ellipse(400,400,410);
  fill('snow');
  ellipse(400,400,380);

  //second circle
  fill('brown');
  ellipse(800,800,400);
  fill('OrangeRed');
  ellipse(800,800,370);
  fill('DarkOrange');
  ellipse(800,800,340);
  fill('Gold');
  ellipse(800,800,310);
  fill('yellow');
  ellipse(800,800,280);
  fill('LightGoldenrodYellow');
  ellipse(800,800,240);
 
  //third cirle
  fill('DarkBlue');
  ellipse(-20,0,400);
  fill('blue');
  ellipse(-20,0,370);
  fill('DodgerBlue');
  ellipse(-20,0,340);
  fill('DeepSkyBlue');
  ellipse(-20,0,310);
  fill('Aqua');
  ellipse(-20,0,280);
  fill('Aquamarine');
  ellipse(-20,0,250);
  fill('PaleTurquoise');
  ellipse(-20,0,210);
  fill('LightCyan');
  ellipse(-20,0,180);
  
}