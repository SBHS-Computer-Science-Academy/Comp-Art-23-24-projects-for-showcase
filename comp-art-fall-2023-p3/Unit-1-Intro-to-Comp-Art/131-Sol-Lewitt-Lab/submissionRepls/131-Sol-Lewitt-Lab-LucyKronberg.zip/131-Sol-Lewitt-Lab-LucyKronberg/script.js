

  
function setup() {
  let myCanvas = createCanvas(800, 800);
  // myCanvas.parent("myCanvas");
  
//   createConsole("dots");
//   noLoop();
  
//   textAlign(CENTER, CENTER);
//   angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("white");

  fill('Indigo');
  circle(0,0,1550);
  circle(800,800,1550);
  
  fill('BlueViolet');
  circle(0,0,1450);
  circle(800,800,1450);

  fill('MediumSlateBlue');
  circle(0,0,1400);
  circle(800,800,1400);
  
  fill('lavender');
  circle(0,0,1300);
  circle(800,800,1300);
  
  fill('Indigo');
  circle(0,0,1160); //1 1
  circle(800,800,1160); //1 2
  
  fill('BlueViolet');
  circle(0,0,1000); //2 1
  circle(800,800,1000); //2 2
  
  fill('MediumSlateBlue');
  circle(0,0,900); //3 1
  circle(800,800,900); //3 2
  
  fill('Lavender');
  circle(0,0,780); //4 1
  circle(800,800,780); //4 2
  
  fill('Indigo');
  circle(0,0,600); //5 1
  circle(800,800,600); //5 2
  
  fill('BlueViolet');
  circle(0,0,550); //6 1
  circle(800,800,550); //6 2
  
  fill('MediumSlateBlue');
  circle(0,0,520); //7 1
  
  fill('MediumSlateBlue');
  circle(800,800,520); //7 2
  fill('Lavender');
  
  circle(0,0,420); //8 1
  circle(800,800,420); //8 2
  
  fill('Indigo');
  circle(0,0,310); //9 1
  circle(800,800,310); //9 2
  
  fill('BlueViolet');
  circle(0,0,260); //10 1
  circle(800,800,260); //10 2
  
  fill('MediumSlateBlue');
  circle(800,800,210); //11 1
  circle(0,0,210); //11 2
  
  fill('lavender');
  circle(0,0,80); //12 1
  circle(800,800,80); //12 2
  
  strokeWeight(0);
 
}