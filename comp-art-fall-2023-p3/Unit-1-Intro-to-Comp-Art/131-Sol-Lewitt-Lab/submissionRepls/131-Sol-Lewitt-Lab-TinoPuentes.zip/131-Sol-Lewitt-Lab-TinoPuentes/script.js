function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("blue");
  fill('orange');
  ellipse(0,0,240,240);
  fill('blue');
  fill('green');
  ellipse(200,200,240,240);
  fill('red');
  ellipse(200,200,140,140);
  fill('red')
  ellipse(350, 435, 240, 240)
    fill('green')
  ellipse(350, 435, 140, 140)
  fill('yellow')
  ellipse(500, 670, 240, 240)
  fill('red')
  ellipse(500, 190, 240, 240)
  fill('green')
  ellipse(45, 440, 240, 240)
  fill('red')
  ellipse(177, 670, 240, 240)
  fill("yellow")
  ellipse(618, 430, 240, 240)
  fill('orange')
  ellipse(500, 668, 140, 140)
  fill('red')
  ellipse(715, 1, 240, 240)
  fill('yellow')
  ellipse(350, 430, 85, 85)
  fill('red')
  ellipse(500, 668, 85, 85)
  fill('blue')
  ellipse(198, 204, 85, 85)
  fill('yellow')
  ellipse(197, 205, 50, 50)
  fill('blue')
  ellipse(350, 430, 50, 50)
  fill('purple')
  ellipse(500, 670, 50, 50)
  fill('blue')
  ellipse(500, 180, 99, 99)
  fill('blue')
  ellipse(175, 670, 99, 99)
  fill('blue')
  ellipse(620, 430, 99, 99)
  fill('green')
  ellipse(793, 670, 240, 240)
  fill('yellow')
  ellipse(790, 230, 240, 240)
  fill('red')
  ellipse(36, 430, 99, 99)
  fill('green')
  ellipse(940, 430, 240, 240)
  fill('blue')
  ellipse(790, 220, 99, 99)
  fill('yellow')
  ellipse(788, 670, 99, 99)
  fill('blue')
  ellipse(935, 430, 99, 99,)
  fill('green')
  ellipse(177, 670, 70, 70)
  fill('purple')
  ellipse(176, 670, 40, 40)
  fill('green')
  ellipse(500, 179, 70, 70)
  fill('orange')
  ellipse(500, 178, 40, 40)
  fill('orange')
  ellipse(35, 430, 70, 70)
  fill('yellow')
  ellipse(35, 430, 40, 40)
  fill('purple')
  ellipse(617, 428, 70, 70)
  fill('pink')
  ellipse(617, 425, 40, 40)
  fill('orange')
  ellipse(787, 668, 70, 70)
  fill('red')
  ellipse(786, 665, 40, 40)
  fill('green')
  ellipse(788, 218, 70, 70)
  fill('sienna')
  ellipse(787, 215, 40, 40)
  fill('teal')
  ellipse(935, 425, 70, 70)
  fill('purple')
  ellipse(934, 425, 40, 40)


  
} 