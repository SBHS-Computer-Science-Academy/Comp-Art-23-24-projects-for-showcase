function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {

noStroke()
  
  fill(255, 17, 0)
  ellipse(400,400,400,400)
  fill(252, 61, 3)
  ellipse(400,400,398,398)
  fill(252, 61, 3)
  ellipse(400,400,396,396)
  fill(252, 90, 3)
  ellipse(400,400,394,394)
  fill(252, 61, 3)
  ellipse(400,400,392,392)
  fill(252, 98, 3)
  ellipse(400,400,389,389)
  fill()
  ellipse(400,400,387,387)
  fill()
  ellipse(400,400,385,385)
  fill()
  ellipse(400,400,383,383)
  fill()
  ellipse(400,400,381,381)
  fill()
  ellipse(400,400,379,379)
}