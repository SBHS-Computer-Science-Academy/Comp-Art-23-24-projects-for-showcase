function setup() {
  let myCanvas = createCanvas(550, 550);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("gold");
  fill('yellow');
  circle(0,0,300);
  fill('green');
  ellipse(0,0,140,140);
  fill('ForestGreen');
  arc(300,300,300,300, 0, 45, PIE);
  fill('DarkGreen');
  circle(200,200,950);
  fill('green');
  circle(200,200,900);
  fill('ForestGreen');
  circle(200,200,850);
fill('SeaGreen');
  circle(200,200,800);
fill('LimeGreen');
  circle(200,200,750);
fill('Lime');
  circle(200,200,700);
fill('SpringGreen');
  circle(200,200,650);
fill('lawngreen');
  circle(200,200,600);
fill('Indigo');
  circle(200,200,550);
fill('Purple');
  circle(200,200,500);
fill('DarkViolet');
  circle(200,200,450);
fill('BlueViolet');
  circle(200,200,400);
fill('DarkOrchid');
  circle(200,200,400);
fill('Fuchsia');
  circle(200,200,350);
fill('Orchid');
  circle(200,200,300);
fill('Violet');
  circle(200,200,250);
fill('Plum');
  circle(200,200,200);
fill('Thistle');
  circle(200,200,150);
fill('Lavender');
  circle(200,200,100);

  
  fill('MistyRose');
  circle(200,200,50,50);
}