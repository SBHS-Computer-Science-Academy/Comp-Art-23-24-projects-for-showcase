let detailY;
// slide to see how detailY works
function setup() {
  createCanvas(1000, 1000, WEBGL);
  detailY = createSlider(3, 16, 3);
  detailY.position(10, height + 5);
  detailY.style('width', '80px');
  
}

function draw() {
  background("black");
  rotateY(millis() / 1000);

  sphere(50, 10, detailY.value());
  detailY.position(10, height + 5);
  detailY.style('width', '80px');
  describe(
    'a rotating white torus with limited Y detail, with a slider that adjusts detailY'
  );
  rotateY(millis() / 1000);

  torus(60, 20, 16, detailY.value());
 rotateX(frameCount * 0.01);
  rotateY(frameCount * 0.01);
normalMaterial();
 
  torus(250, 30, ); 
  rotateY(millis() / 1000);
  
  torus(300, 20, 20, detailY.value());
rotateX(frameCount * 0.01);
   rotateY(frameCount * 0.01);

  torus(200, 30);
 
torus(100, 20,20)
  torus(150, 20, 20, detailY.value());

}
