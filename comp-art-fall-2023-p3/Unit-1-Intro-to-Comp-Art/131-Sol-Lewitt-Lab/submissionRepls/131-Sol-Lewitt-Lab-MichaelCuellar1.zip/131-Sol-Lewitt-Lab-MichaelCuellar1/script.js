function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("dots");
  noLoop();

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("white");
  fill('yellow');
  ellipse(0, 0, 240, 240);
  fill('green');
  ellipse(0, 0, 140, 140);
  fill('red');
  arc(300, 300, 300, 300, 0, 45, PIE);
  fill('black');
  ellipse(200, 200, 240, 240);
  fill('blue');
  ellipse(200, 200, 140, 140);
  fill('purple');
  ellipse(190, 200, 140, 140)
  fill('red')
  ellipse(180, 200, 140, 140)
  fill('OrangeRed')
  ellipse(170, 200, 140, 140)
  fill('Orange')
  ellipse(160, 200, 140, 140)
  fill('yellow')
  ellipse(150, 200, 140, 140)
  fill('YellowGreen')
  ellipse(140, 200, 140, 140)
  fill('green')
  ellipse(130, 200, 140, 140)
  fill('OliveDrab')
  ellipse(130, 210, 140, 140)
  fill('Olive')
  ellipse(130, 220, 140, 140)
  fill('peru')
  ellipse(130, 230, 140, 140)
  fill('Sienna')
  ellipse(130, 240, 140, 140)
  fill('saddleBrown')
  ellipse(130, 250, 140, 140)
  fill('brown')
  ellipse(130, 260, 140, 140)
  fill('darkred')
  ellipse(130, 270, 140, 140)
  fill('firebrick')
  ellipse(130, 280, 140, 140)
  fill('red')
  ellipse(130, 290, 140, 140)
  fill('Orangered')
  ellipse(130, 300, 140, 140)
  fill('Orange')
  ellipse(130, 310, 140, 140)
  fill('yellow')
  ellipse(130, 320, 140, 140)
  fill('YellowGreen')
  ellipse(130, 330, 140, 140)
  fill('green')
  ellipse(130, 340, 140, 140)
  fill('OliveDrab')
  ellipse(130, 350, 140, 140)
  fill('Olive')
  ellipse(130, 360, 140, 140)
  fill('peru')
  ellipse(130, 370, 140, 140)
  fill('Sienna')
  ellipse(130, 380, 140, 140)
  fill('saddleBrown')
  ellipse(130, 390, 140, 140)
  fill('brown')
  ellipse(130, 400, 140, 140)
  fill('darkred')
  ellipse(130, 410, 140, 140)
  fill('firebrick')
  ellipse(130, 420, 140, 140)
  fill('red')
  ellipse(130, 430, 140, 140)
  fill('Orangered')
  ellipse(130, 440, 140, 140)
  fill('Orange')
  ellipse(130, 450, 140, 140)
  fill('yellow')
  ellipse(130, 460, 140, 140)
  fill('YellowGreen')
  ellipse(130, 470, 140, 140)
  fill('green')
  ellipse(130, 480, 140, 140)
  fill('OliveDrab')
  ellipse(130, 490, 140, 140)
  fill('Olive')
  ellipse(130, 500, 140, 140)

  fill('peru')
  ellipse(160, 230, 140, 140)
  fill('Sienna')
  ellipse(160, 240, 140, 140)
  fill('saddleBrown')
  ellipse(160, 250, 140, 140)
  fill('brown')
  ellipse(160, 260, 140, 140)
  fill('darkred')
  ellipse(160, 270, 140, 140)
  fill('firebrick')
  ellipse(160, 280, 140, 140)
  fill('red')
  ellipse(160, 290, 140, 140)
  fill('Orangered')
  ellipse(160, 300, 140, 140)
  fill('Orange')
  ellipse(160, 310, 140, 140)
  fill('yellow')
  ellipse(160, 320, 140, 140)
  fill('YellowGreen')
  ellipse(160, 330, 140, 140)
  fill('green')
  ellipse(160, 340, 140, 140)
  fill('OliveDrab')
  ellipse(160, 350, 140, 140)
  fill('Olive')
  ellipse(160, 360, 140, 140)
  fill('peru')
  ellipse(160, 370, 140, 140)
  fill('Sienna')
  ellipse(160, 380, 140, 140)
  fill('saddleBrown')
  ellipse(160, 390, 140, 140)
  fill('brown')
  ellipse(160, 400, 140, 140)
  fill('darkred')
  ellipse(160, 410, 140, 140)
  fill('firebrick')
  ellipse(160, 420, 140, 140)
  fill('red')
  ellipse(160, 430, 140, 140)
  fill('Orangered')
  ellipse(160, 440, 140, 140)
  fill('Orange')
  ellipse(160, 450, 140, 140)
  fill('yellow')
  ellipse(160, 460, 140, 140)
  fill('YellowGreen')
  ellipse(160, 470, 140, 140)
  fill('green')
  ellipse(160, 480, 140, 140)
  fill('OliveDrab')
  ellipse(160, 490, 140, 140)
  fill('Olive')
  ellipse(160, 500, 140, 140)

  fill('peru')
  ellipse(190, 230, 140, 140)
  fill('Sienna')
  ellipse(190, 240, 140, 140)
  fill('saddleBrown')
  ellipse(190, 250, 140, 140)
  fill('brown')
  ellipse(190, 260, 140, 140)
  fill('darkred')
  ellipse(190, 270, 140, 140)
  fill('firebrick')
  ellipse(190, 280, 140, 140)
  fill('red')
  ellipse(190, 290, 140, 140)
  fill('Orangered')
  ellipse(190, 300, 140, 140)
  fill('Orange')
  ellipse(190, 310, 140, 140)
  fill('yellow')
  ellipse(190, 320, 140, 140)
  fill('YellowGreen')
  ellipse(190, 330, 140, 140)
  fill('green')
  ellipse(190, 340, 140, 140)
  fill('OliveDrab')
  ellipse(190, 350, 140, 140)
  fill('Olive')
  ellipse(190, 360, 140, 140)
  fill('peru')
  ellipse(190, 370, 140, 140)
  fill('Sienna')
  ellipse(190, 380, 140, 140)
  fill('saddleBrown')
  ellipse(190, 390, 140, 140)
  fill('brown')
  ellipse(190, 400, 140, 140)
  fill('darkred')
  ellipse(190, 410, 140, 140)
  fill('firebrick')
  ellipse(190, 420, 140, 140)
  fill('red')
  ellipse(190, 430, 140, 140)
  fill('Orangered')
  ellipse(190, 440, 140, 140)
  fill('Orange')
  ellipse(190, 450, 140, 140)
  fill('yellow')
  ellipse(190, 460, 140, 140)
  fill('YellowGreen')
  ellipse(190, 470, 140, 140)
  fill('green')
  ellipse(190, 480, 140, 140)
  fill('OliveDrab')
  ellipse(190, 490, 140, 140)
  fill('Olive')
  ellipse(190, 500, 140, 140)

  fill('peru')
  ellipse(210, 230, 140, 140)
  fill('Sienna')
  ellipse(210, 240, 140, 140)
  fill('saddleBrown')
  ellipse(210, 250, 140, 140)
  fill('brown')
  ellipse(210, 260, 140, 140)
  fill('darkred')
  ellipse(210, 270, 140, 140)
  fill('firebrick')
  ellipse(210, 280, 140, 140)
  fill('red')
  ellipse(210, 290, 140, 140)
  fill('Orangered')
  ellipse(210, 300, 140, 140)
  fill('Orange')
  ellipse(210, 310, 140, 140)
  fill('yellow')
  ellipse(210, 320, 140, 140)
  fill('YellowGreen')
  ellipse(210, 330, 140, 140)
  fill('green')
  ellipse(210, 340, 140, 140)
  fill('OliveDrab')
  ellipse(210, 350, 140, 140)
  fill('Olive')
  ellipse(210, 360, 140, 140)
  fill('peru')
  ellipse(210, 370, 140, 140)
  fill('Sienna')
  ellipse(210, 380, 140, 140)
  fill('saddleBrown')
  ellipse(210, 390, 140, 140)
  fill('brown')
  ellipse(210, 400, 140, 140)
  fill('darkred')
  ellipse(210, 410, 140, 140)
  fill('firebrick')
  ellipse(210, 420, 140, 140)
  fill('red')
  ellipse(210, 430, 140, 140)
  fill('Orangered')
  ellipse(210, 440, 140, 140)
  fill('Orange')
  ellipse(210, 450, 140, 140)
  fill('yellow')
  ellipse(210, 460, 140, 140)
  fill('YellowGreen')
  ellipse(210, 470, 140, 140)
  fill('green')
  ellipse(210, 480, 140, 140)
  fill('OliveDrab')
  ellipse(210, 490, 140, 140)
  fill('Olive')
  ellipse(210, 500, 140, 140)

 fill('peru')
  ellipse(210, 230, 140, 140)
  fill('Sienna')
  ellipse(210, 240, 140, 140)
  fill('saddleBrown')
  ellipse(210, 250, 140, 140)
  fill('brown')
  ellipse(210, 260, 140, 140)
  fill('darkred')
  ellipse(210, 270, 140, 140)
  fill('firebrick')
  ellipse(210, 280, 140, 140)
  fill('red')
  ellipse(210, 290, 140, 140)
  fill('Orangered')
  ellipse(210, 300, 140, 140)
  fill('Orange')
  ellipse(210, 310, 140, 140)
  fill('yellow')
  ellipse(210, 320, 140, 140)
  fill('YellowGreen')
  ellipse(210, 330, 140, 140)
  fill('green')
  ellipse(210, 340, 140, 140)
  fill('OliveDrab')
  ellipse(210, 350, 140, 140)
  fill('Olive')
  ellipse(210, 360, 140, 140)
  fill('peru')
  ellipse(210, 370, 140, 140)
  fill('Sienna')
  ellipse(210, 380, 140, 140)
  fill('saddleBrown')
  ellipse(210, 390, 140, 140)
  fill('brown')
  ellipse(210, 400, 140, 140)
  fill('darkred')
  ellipse(210, 410, 140, 140)
  fill('firebrick')
  ellipse(210, 420, 140, 140)
  fill('red')
  ellipse(210, 430, 140, 140)
  fill('Orangered')
  ellipse(210, 440, 140, 140)
  fill('Orange')
  ellipse(210, 450, 140, 140)
  fill('yellow')
  ellipse(210, 460, 140, 140)
  fill('YellowGreen')
  ellipse(210, 470, 140, 140)
  fill('green')
  ellipse(210, 480, 140, 140)
  fill('OliveDrab')
  ellipse(210, 490, 140, 140)
  fill('Olive')
  ellipse(210, 500, 140, 140)































































































}