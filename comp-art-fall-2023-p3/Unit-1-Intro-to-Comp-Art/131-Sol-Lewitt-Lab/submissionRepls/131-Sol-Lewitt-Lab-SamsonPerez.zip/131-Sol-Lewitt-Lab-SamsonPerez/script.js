function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  //examples of starter code

  background("white");
  fill('yellow');
  ellipse(0,0,240,240);
  fill('green');
  ellipse(0,0,140,140);
  fill('red');
  arc(300,300,300,300, 0, 45, PIE);
  fill('black');
  ellipse(200,200,240,240);
  fill('blue');
  ellipse(200,200,140,140);
  ellipse(200,300,100,200)
  arc(400,100,200,150,500,50,400)
  ellipse(500,600,300,100)
  fill('indianred')
  circle(200,200,1500)
  fill('gold')
  circle(200,200,1000)
  fill('aqua')
  circle(200,200,900)
  fill('crimson')
  circle(200,200,800)
  fill('deepskyblue')
  circle(200,200,700)
  fill('chocolate')
  circle(200,200,600)
  fill('darkviolet')
  circle(200,200,500)
  fill('darkslategrey')
  circle(200,200,400)
  fill('lawngreen')
  circle(200,200,300)
fill('dodgerblue')
  circle(200,200,200)
  fill('red')
  circle(200,200,150)
  fill('coral')
  circle(200,200,120)
  fill('magenta')
  circle(200,200,50)
  fill('peachpuff')
  circle(200,200,30)
}