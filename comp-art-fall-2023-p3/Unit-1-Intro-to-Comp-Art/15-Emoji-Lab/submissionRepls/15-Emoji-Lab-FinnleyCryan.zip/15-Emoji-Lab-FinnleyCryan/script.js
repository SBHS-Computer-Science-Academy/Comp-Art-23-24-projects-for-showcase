function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  createConsole("dots");
  noLoop();
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
	strokeWeight(0);
}

function draw() {
  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("#7977ff");
  square(0, 0, 400); // upper left background
	fill("#fdff77");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  arc(200, 260, 120, 80, 0, 180); //smile
	fill("#fdff77");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	
}

function drawTopRightEmoji() {
	fill('#79b1ff');
  square(400, 0, 400); // upper right background
	fill("#ffc779");
  circle(600, 200, 300); // head
  fill(0)
  circle(540, 140, 60)
  circle(660, 140, 60)
  strokeWeight(10);
  line(533, 273, 658, 229)
  strokeWeight(0)
}

function drawBottomLeftEmoji() {	
	fill('#9575ff');
  square(0, 400, 400); // lower left background
	fill("#bfff11");
  circle(200, 600, 300); // head
  fill(0)
  arc(140, 540, 60, 60, -40, 180, OPEN); // eyeL
  arc(260, 540, 60, 60, 0, 220, OPEN); // eyeR
  arc(200, 670, 120, 80, 180, 0); //smile
}

function drawBottomRightEmoji() {
	fill('#76e1ff');
  square(400, 400, 400); // lower right background
	fill("#ff9476");
  circle(600, 600, 300); // head
  fill(0)
  arc(540, 540, 60, 60, 0, 225, OPEN); // eyeL
  arc(660, 540, 60, 60, -45, 180, OPEN); // eyeR
  arc(600, 660, 120, 50, 0, 180); //smile
  strokeWeight(6);
  line(525, 500, 580, 540); //eyebrowL
  line(675, 500, 620, 540); //eyebrowR
}
