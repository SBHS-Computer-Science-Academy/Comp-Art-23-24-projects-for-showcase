 function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("yellow");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Gold");
  circle(200, 200, 300); // head
  	
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  rect(135, 267, 90, 10);
  rect(109, 121,60, 10);
  rect(238, 98,60, 10);
		fill("White");
  circle(136, 162, 60); //left eye
 	circle(264, 162, 60); //right eye
		fill("LightSkyBlue");
  circle(264, 162, 30); //right eye
    circle(136, 162, 30); //left eye
  	fill("black");
  circle(136, 162, 10); //left eye
  circle(264, 162, 10); //right eye
  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  //triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('grey');
  square(400, 0, 400); // upper right background
	fill("red");
  circle(631, 179, 300); // head
  circle(558, 132, 30); //left eye
	circle(708, 138, 30); //right eye
	fill("black");
	circle(558, 132, 60); //left eye
	circle(708, 138, 60); //right eye
	arc(623, 234, 180,120, 0, 180); // mouth
 stroke("black")
  line(531, 76,584, 96);// mouth 
  line(732, 76,687, 96);// mouth 
  triangle(502, 102, 554, 67, 479, 11);
   triangle(697, 59, 769, 13, 755, 97);
  fill("red");
  circle(558, 132, 30); //left eye
	circle(708, 138, 30); //right eye
   fill("black");
   circle(558, 132, 10); //left eye
	circle(708, 138, 10); //right eye
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background
	fill("Yellow");
  circle(180, 590, 300); // head
	fill("black");
	arc(123, 540, 100,100, 0, 180); // mouth
  arc(253, 540, 100,100, 0, 180); // mouth
  arc(174, 651, 180,120, 0, 180); // mouth
 line(205, 540,169, 538);// mouth 
   line(204, 542, 172, 542); //glasses
    rect(150, 541,60, 10);
  stroke("black")
  line(73, 541,45, 526);// mouth 
  line(303, 541,312, 523);// mouth 
}

function drawBottomRightEmoji() {
	fill('DarkOliveGreen');
  square(400, 400, 400); // lower right background
fill("GreenYellow");
  circle(614, 603, 300); // head
  fill("black");
ellipse(554, 546,50, 80);
  ellipse(690, 546,50, 80);
    circle(610, 655, 100);
  rect(529, 479,60, 10);
  rect(645, 479,60, 10);
   fill("white");
  circle(553, 561, 30);
  circle(688, 561, 30);
}
