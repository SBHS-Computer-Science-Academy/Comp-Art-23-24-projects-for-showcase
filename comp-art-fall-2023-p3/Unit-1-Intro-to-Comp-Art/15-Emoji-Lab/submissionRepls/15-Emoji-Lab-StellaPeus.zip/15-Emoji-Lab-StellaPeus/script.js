function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("lavender");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("yellow");
  circle(200, 200, 300); // head
	fill("SaddleBrown");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye

  
	
	fill("yellow");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley
  strokeWeight(5);
  noFill
  stroke('SaddleBrown');
  arc(200,243,120,80,0,180)
  strokeWeight(0);
  noStroke
  fill('lightpink')
  quad(225,284,255,264,278,284,248,308)
  circle(267,301,40)
  strokeWeight(3);
  stroke('black');
  line(241,275,280,315)
  




  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('lightgreen');
  square(400, 0, 400); // upper right background
  fill('red');
  strokeWeight(0);
  stroke('none');
  circle(604,199,300)
  fill('SaddleBrown');
  ellipse(565,172,40,55)
  ellipse(634,172,40,55)
  strokeWeight(5);
  stroke('SaddleBrown');
  line(543,111,584,138)
  line(612,139,648,113)
  circle(599,252,50)
  stroke('red');
  fill('red');
  circle(600,264,50)
  
}

function drawBottomLeftEmoji() {	
	fill('lightblue');
  square(0, 400, 400); // lower left background

  strokeWeight(0);
  stroke('none');
  fill('lightyellow');
  circle(195,597,300)
  fill('lightblue')
  ellipse(148,554,50,80)
  ellipse(233,554,50,80)
  fill('white');
  ellipse(147,554,30,60)
  ellipse(232,554,30,60)
  fill('black');
  ellipse(147,554,10,40)
  ellipse(231,554,10,40)
  fill('red');
  circle(192,618,60)
  fill('lightpink');
  circle(101,610,50)
  circle(279,610,50)
  fill('red');
  circle(84,497,60)
  circle(119,468,60)
  circle(87,466,60)
  circle(262,463,60)
  circle(299,489,60)
  circle(290,460,60)
  ellipse(192,681,100,25)

  
}

function drawBottomRightEmoji() {
	fill('lightpink');
  square(400, 400, 400); // lower right background
  fill(147,112,219)
  circle(599,594,300)
  fill(128,0,128);
  triangle(489,494,529,463,474,431)
  triangle(671,463,718,430,709,492)
  ellipse(563,561,40,50)
  ellipse(629,559,40,50)
  strokeWeight(7);
  stroke(128,0,128);
  bezier(527,506,550,508,570,516,581,525)
  translate(599,0)
  scale(-1,1)
  translate(-599,0)
  bezier(527,506,550,508,570,516,581,525)
  resetMatrix()
  ellipse(598,644,90,40)
  strokeWeight(0);
  stroke('none');
  fill(147,112,219);
  ellipse(598,630,90,40)
  
}
