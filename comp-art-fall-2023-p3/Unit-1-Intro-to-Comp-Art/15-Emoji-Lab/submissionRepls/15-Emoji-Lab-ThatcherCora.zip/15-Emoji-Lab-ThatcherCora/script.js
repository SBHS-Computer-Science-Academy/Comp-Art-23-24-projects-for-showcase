function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("yellow");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("green");
  circle(180, 200, 300); // head
	fill("white");
	circle(175, 130, 100); //right eye
  fill("green")
  circle(169, 126,50)
  fill("white")
  circle(170,126,20)
  fill("black")
  arc(175, 250, 100, 50, 0, 180)
	
	

  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background

  
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background

  
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background
  circle(600,200,300)
  fill("black")
  
  circle(525,150, 60)//eye
  circle(650,150,60)//eye
  fill("blue")
  circle(525,130,60)
  circle(650,130,60)
  strokeWeight(4)
  noFill()
  stroke("black")
  
  
  
  arc(600, 250,100,100,180,0)//mouth
  noStroke()
  fill("green")
   circle(200,600,300)
  fill("black")
circle(136, 550, 60)
  circle(264, 550, 60)
  fill("green")
  circle(110,570,60)
  circle(275,570,60)
  fill("black")
  arc(200,650,120,50,0,180)
  stroke("black")
  line(107,503,202,498)
  line(204,500,294,496)
  noStroke()
  fill("yellow")
  circle(600,600,300)
  fill("black")
  circle(525,570,60)
  circle(650,570,60)
  arc(600,650,100,100,0,180)
  fill("white")
  triangle(481, 209,513, 209,499, 185)
  circle(497,220,40)
}
