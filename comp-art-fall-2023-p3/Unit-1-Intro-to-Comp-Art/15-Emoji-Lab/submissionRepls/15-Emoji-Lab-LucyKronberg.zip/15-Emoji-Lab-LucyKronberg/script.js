function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("lavender");
  square(0, 0, 400); // upper left background

  // top left emoji: mike wazowski
	fill("GreenYellow");
  circle(200, 200, 300); // head
	fill("white");
  stroke('black');
  strokeWeight(2);
	circle(199,156,140); //eye white
  fill('seagreen');
  circle(199,156,100); //eye color
  fill('black');
  circle(199,156,60); //pupil
  fill('white');
  circle(180,135,25); //sparkle
  
  
  arc(200, 266, 160, 90, 0, 180) //smile
  line(121,266,280,266); //top of smile
  fill('tan');
  triangle(285,77,328,75,325,118); //right horn
  triangle(109,80,65,78,73,119); //left horn
  strokeWeight(0);
  fill('black');
  triangle(328,75,309,77,326,93); //right horn tip
  triangle(65,79,68,95,82,80); //left horn tip
}


function drawTopRightEmoji() {
	fill('lightblue');
  square(400, 0, 400); // upper right background
  fill('yellow');
  circle(600,200,300); //head
  fill('black');
  ellipse(519,147,50,80); //left eye
  ellipse(676,147,50,80); //right eye
  fill('yellow');
  stroke('black');
  strokeWeight(8);
  arc(600,230,200,160,0,180); //smile
  line(476,224,524,224); //left
  line(674,224,723,224); //right
  strokeWeight(0);
  
}

function drawBottomLeftEmoji() {	
	fill('mistyrose');
  square(0, 400, 400); // lower left background
  fill('red');
  circle(200,600,300);
  fill('black')
  circle(117,555,50);
  circle(277,554,50);
  strokeWeight(10);
  line(90,500,146,549);
  line(308,497,248,547);
  fill('red');
  strokeWeight(8);
  arc(200,683,200,160,180,0);
  strokeWeight(0);

  
}

function drawBottomRightEmoji() {
	fill('lightyellow');
  square(400, 400, 400); // lower right background
  fill('royalblue');
  circle(600,600,300); //head
  stroke('black');
  strokeWeight(6);
  arc(510,561,100,50,0,180); //left eye
  arc(686,561,100,50,0,180); //right eye
  arc(599,695,190,120,180,0); //frown
  strokeWeight(10);
  stroke('lightskyblue');
  line(455,574,447,581); //tears
  line(433,599,422,617);
  line(738,575,751,585);
  line(763,600,775,623);
  line(420,655,420,676);
  line(777,656,777,685);
  stroke('black');
  strokeWeight(6);
  line(493,700,514,700);
  line(685,700,703,700);
  
}
