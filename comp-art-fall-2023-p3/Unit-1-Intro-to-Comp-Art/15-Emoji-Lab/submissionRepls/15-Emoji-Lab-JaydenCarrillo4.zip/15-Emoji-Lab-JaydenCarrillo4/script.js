function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("yellow");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Gold");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
	arc(200, 222, 120, 80, 0, 180); // mouth
	
  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background
  // top left emoji: joy
	fill("Gold");
  circle(600, 200, 300); // head
	fill("black");
	circle(530, 162, 60); //left eye
	circle(670, 162, 60); //right eye
  arc(600, 270, 120, 120, 544, 360); // mouth


  
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background
  // top left emoji: joy
	fill("Gold");
  circle(200, 600, 300); // head
	fill("black");
	circle(130, 570, 60); //left eye
	circle(250, 570, 60); //right eye
  rect(110, 630,200,50)
  

  
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background
  fill("Firebrick");
  circle(600, 600, 300); // head
	fill("black");
	circle(530, 570, 60); //left eye
	circle(670, 570, 60); //right eye
  rect(500, 488,200,50)
  arc(600, 680, 120, 120, 544, 360)

  
}
