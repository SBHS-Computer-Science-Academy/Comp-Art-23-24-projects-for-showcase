let colorlist = ['red', 'blue', 'chocolate']


function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");

  createConsole("dots");

  noLoop()

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);

  noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();

  fill(random(colorlist))
  fill('red')
  ellipse(600, 600, 200, 200)
  stroke('black')
  line(530, 552, 573, 568)
  line(635, 564, 659, 543)
  noStroke()
  fill('black')
  ellipse(547, 601, 40, 40)
  ellipse(649, 600, 50, 50)

  arc(652, 632, 50, 10, 0, 180)
  arc(597, 664, 100, 100, 180, 0, OPEN)

}

function drawTopLeftEmoji() {
  fill(random(colorlist))
  ellipse(200, 200, 150, 150)
  fill('black')
  bezier(152, 188
    , 168, 205
    , 192, 204
    , 199, 185)
  arc(205, 233, 50, 50, 0, 180)


  bezier(216, 173
    , 228, 191
    , 243, 191
    , 253, 170)
  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
  fill('green');
  square(400, 0, 400); // upper right background


  fill('blue');
  ellipse(600, 200, 200, 200)
  fill('black')
  bezier(533, 182, 551, 166, 572, 165, 584, 179)
  bezier(620, 180,
    634, 168,
    656, 166,
    669, 180)
  arc(600, 237, 80, 80, 180, 0, OPEN)
  stroke('black')
  strokeWeight(5)
  line(524, 175, 561, 149)
  line(638, 145, 676, 177)
}

function drawBottomLeftEmoji() {
  noStroke()
  fill('purple');
  square(0, 400, 400); // lower left background
  fill('yellow')
  ellipse(200, 600, 200, 200)
  fill('black')
  arc(160, 564, 80, 40, 0, 180)
  arc(240, 564, 80, 40, 0, 180)
  stroke('black')
  strokeWeight(5)
  line(120, 563, 110, 558)
  line(280, 564, 287, 551)
  strokeWeight(10)
  line(160, 640, 240, 640)
  noStroke();
}

function drawBottomRightEmoji() {
  fill('white');
  square(400, 400, 400); // lower right background


}
function drawSunGlass() {
  fill('red');
  square(400, 400, 400); // lower right background

  fill('black')
  arc(560, 564, 80, 40, 0, 180)
  arc(640, 564, 80, 40, 0, 180)
  stroke('black')
  strokeWeight(5)
  line(520, 563, 510, 558)
  //line(580, 564, 620, 551)
  strokeWeight(10)
  line(160, 640, 240, 640)
  noStroke();

}

function drawEyeSad() {
  fill('blue');
  square(400, 400, 400); // lower right background
  bezier(533, 582, 551, 566, 572, 565, 584, 579)
  bezier(620, 580,
    634, 568,
    656, 566,
    669, 580)
}

function drawEyeHappy() {
  fill('yellow');
  square(400, 400, 400); // lower right background
  fill('red')

  line(500, 600, 700, 600)
}

function drawCirc() {

  fill(random(colorlist))
  ellipse(600, 600, 200, 200)


}

//function mousePressed() {


  //draw()
  // let num3 = random(4)
  // let num2 = random(4)
  // let num = random(4)
  // if (num < 1) {

  //   drawSunGlass()

  // }
  // if (num < 2  ) {

  //   drawEyeSad()

  // }

  // else if (num2 < 3){

  //   drawEyeHappy()

  // }


  //let array = [drawEyeSad, drawSunGlass]

  //let index = int(random(array.length));

  //array[index]();


//}


