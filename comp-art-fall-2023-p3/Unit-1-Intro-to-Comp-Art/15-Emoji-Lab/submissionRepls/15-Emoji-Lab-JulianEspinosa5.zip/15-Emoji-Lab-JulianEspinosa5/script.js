function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("purple");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("yellow");
  circle(200, 200, 300); // head
	fill("peru")
	rect(80, 159,90,15)
	rect(221, 159,90,15)
  rect(95, 263,200,15)
	
  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background
fill("white")
  circle(580, 200,300)
fill("red")
ellipse(575, 270,200,80)
  fill("white")
ellipse(572, 248,170,50)
  
fill("black")
  ellipse(509, 153,60,30)
ellipse(636,153,60,30)
fill("green")
circle(508, 153,30)
circle(636, 153,30)
fill("blue")
triangle(493, 139,521, 139,506, 118)
triangle(495, 167,520, 168,507, 189)
triangle(625, 138,651, 139,636, 117)
triangle(624, 168,649, 167,635, 187)
fill("red")
circle(573, 207,40)
  noFill()
  strokeWeight(10)
  stroke("red")
  bezier(475, 116,490, 103,512, 100,530, 115)
  bezier(607, 115,626, 104,649, 102,667, 117)
  //bezier()

noStroke()
  strokeWeight(1)
  noStroke()
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background
fill("black")
circle(195, 582,300)
triangle(66, 508,104, 403,123, 453)
triangle(326, 509,288, 407,268, 452)
  fill("lightsalmon")
circle(190, 647,169)
  
  fill("black")
  rect(95, 560,200,70)
  fill("white")
circle(128, 538,80)
circle(255,538,80)
fill("black")
triangle(100, 498,171, 547,168, 484)
triangle(209, 547,288, 504,219, 484)
strokeWeight(5)
  stroke("black")
line(151, 675,209, 661)
  line(209, 661,229, 669)
}

function drawBottomRightEmoji() {
	noStroke()
  fill('blue');
  square(400, 400, 400); // lower right background
fill("lime")
circle(588, 588,300)
  fill("black")
circle(529, 565,100)
circle(646, 565,100)
triangle(495, 602,574, 587,554, 642)
triangle(482, 548,556, 523,497, 480)
triangle(598, 578,674, 606,608, 643)
triangle(617, 524,692, 546,677, 480)
  ellipse(580, 685,60,40)
fill("limegreen")
ellipse(536, 470,15,7)
ellipse(613, 462,30,15)
ellipse(707, 618,21,8)
ellipse(475, 648,26,16)
  ellipse(657, 680,10,4)
  ellipse(554, 505,7,2)
}
