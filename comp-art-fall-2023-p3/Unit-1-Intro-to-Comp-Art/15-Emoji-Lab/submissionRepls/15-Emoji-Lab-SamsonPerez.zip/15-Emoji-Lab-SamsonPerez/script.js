function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("yellow");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Chocolate");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  arc(200, 266, 120, 50, 0, 180)
	
	fill("Chocolate");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	

  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background

  
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background

  
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background

  circle(579, 200,300)
  line(502, 110,564, 131)
}
