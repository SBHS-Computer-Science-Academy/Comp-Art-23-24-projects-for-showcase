function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("Maroon");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("blue");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 70); //left eye
	circle(264, 162, 70); //right eye
  arc(200, 266, 120, 50, 180, 0)
	
	fill("blue");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	

  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background
fill('yellow')
  circle(600,200,300)
  fill('black')
circle(552,170,80)
  circle(648,170,80)
fill('yellow')
circle(550,185,60)
  circle(650,185,60)
fill('black')
arc(600,270,130,70,0,180)
  
}

function drawBottomLeftEmoji() {	
	fill('yellow');
  square(0, 400, 400); // lower left background
fill ('green')
  circle(190,590,300)
  fill('black')
  arc(195,650,120, 10, 180, 0)
  circle(150,555,70)
 circle(225,555,70)
  
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background
fill('maroon')
  circle(605,605,300)
fill('black')
  circle(555,566,30)
circle (650,566,30)
  arc(605,660,120, 10, 190, 10)
}
