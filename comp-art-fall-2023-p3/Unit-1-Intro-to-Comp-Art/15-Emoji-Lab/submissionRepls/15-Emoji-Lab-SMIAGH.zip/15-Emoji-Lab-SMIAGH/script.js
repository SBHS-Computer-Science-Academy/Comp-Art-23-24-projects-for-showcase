function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("lavender");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Gold");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  arc(200, 266, 120, 50, 0, 180)
	
	fill("Gold");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	

}

function drawTopRightEmoji() {
	fill('ForestGreen');
  square(400, 0, 400); // upper right background

  fill('lightblue')
  circle(600,200,300)//head

  fill('black')
  circle(538,142,60)//left eye
fill('lightblue')
circle(538,173,60)//left eye
  
fill('black')
  circle(650,142,60)//right eye
fill('lightblue')
circle(650,170,60)//right eye

fill('black')
  ellipse(599,251,140,60)//mouth
  fill('lightblue')
  ellipse(601,276,140,60)//mouth
  
}

function drawBottomLeftEmoji() {	
	fill('Coral');
  square(0, 400, 400); // lower left background

  fill('white')
  circle(189,587,300)//head

fill('black')
  circle(129,536,60)//left eye

  circle(244,533,60)//right eye

  stroke('black')
  strokeWeight(5)
  line(227,475,286,507)//left eyebrow

line(130,478, 85,523)//right eyebrow
  
  circle(187,640,100)//mouth
  
}

function drawBottomRightEmoji() {
	noStroke();
  fill('RoyalBlue');
  square(400, 400, 400); // lower right background
noStroke();

fill('black')
  circle(600,600,300)

  fill('white')
  circle(535,557,60)
fill('black')

circle(532,529,60)
stroke('white')
 line(503,530, 556,530)
  line(652,518, 697,511)
  
    fill('white')
  circle(680,557,60)

  arc(598, 664, 120, 50, 0, 180)
}
