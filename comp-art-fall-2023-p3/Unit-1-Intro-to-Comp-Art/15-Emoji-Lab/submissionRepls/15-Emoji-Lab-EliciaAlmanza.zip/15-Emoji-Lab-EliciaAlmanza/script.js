function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("lines");

  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();

  drawMouseLines()
}

function drawTopLeftEmoji() {
  fill("MistyRose");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("gold");
  circle(200, 200, 300); // head
	fill("black");
	
  circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  arc(200, 266, 120, 50, 0, 180)

  
	fill("Sienna");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	

   fill('black');
   stroke('black');
   strokeWeight(14);
   triangle(196, 196, 172, 227, 220, 228) // nose

   noStroke();  
}

function drawTopRightEmoji() {
	fill('GhostWhite');
  square(400, 0, 400); // upper right background
  fill("gold");
  circle(600, 200, 300); // head
  
  fill('Sienna')
  ellipse(543,142,40,70)
  fill('Sienna')
  ellipse(646,142,40,70)
  stroke('black')
  strokeWeight(12)
  stroke('Sienna')
  line(690,209,527,278)
  noStroke()
}

function drawBottomLeftEmoji() {	
	fill('GhostWhite');
  square(0, 400, 400); // lower left background
  fill('gold')
  circle(200,600,300)
  fill('sienna')
  ellipse(151,666,40,70)
  fill('sienna')
  ellipse(242,666,40,70)
  arc(150, 550, 120, 50, 0, 180)
  
}

function drawBottomRightEmoji() {
	fill('MistyRose');
  square(400, 400, 400); // lower right background
  fill('gold')
  circle(600,600,300)
  fill('sienna')
  ellipse(548,522,50,90)
  fill('sienna')
  ellipse(633,520,50,90)
  drawmouth()


}

function drawmouth() {
  // fill("black");
  beginShape();
  curveVertex(599, 616); // control point
  curveVertex(599, 616);
  curveVertex(640, 634);
  curveVertex(601, 655);
  curveVertex(632, 681);
  curveVertex(592, 698);
  curveVertex(620, 681);
  curveVertex(595, 662);
  curveVertex(598, 645);
  curveVertex(627, 635);
  curveVertex(601, 616);
  curveVertex(601, 616); // control point
  endShape();
}
