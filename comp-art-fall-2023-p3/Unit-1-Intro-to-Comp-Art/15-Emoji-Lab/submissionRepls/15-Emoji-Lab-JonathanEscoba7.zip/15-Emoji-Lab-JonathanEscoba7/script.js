function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("yellow");
  
 
  square(0, 0, 400); // upper left background
fill("blue");
  circle(198,215,300)
  fill("black")
  circle(129,160,30)
  circle(260,160,30)
  circle(197,299,50) 
  fill('black');
  stroke('black');
  strokeWeight(14);
triangle(196, 196, 172, 227, 220, 228) // nose
}
noStroke()
function drawTopRightEmoji() {
	fill('white');
  square(400,400, 400); // upper right background
 fill("black")
  circle(591,200,300)
  fill("white")
  circle(528,148,50)
  circle(652,148,50)
  noFill()
  strokeWeight(10)
  stroke("white")
  bezier(508,301,563, 254,609, 252,661,301)
}

function drawBottomLeftEmoji() {	
	  noStroke()
  fill('red');
  square(0, 400, 400); // lower left background
fill("black")
  circle(178,596,300)
  
  
}

function drawBottomRightEmoji() {
	fill('blue');
  noStroke()
  square(400, 400, 400); // lower right background
noStroke()
  
  arc(115,547, 100, 49, 0, 180)
  arc(237,547,100,49,0,180)
 bezier( 111, 645
,150, 681
,206, 679
,231, 638)

  stroke("blue")
  
  strokeWeight(10)
  line(132, 505,164, 535)
  line( 186, 535
,206, 505)
  fill("red")
 circle(599, 599,300)
fill("white")
  noStroke()
  circle(543, 554,50)
circle(653, 554,50)
fill("black")
  circle(543, 553,20)
  circle(653, 553,20)
stroke ("black")
  line(531, 515,581, 546)
  line(660, 515,617, 546)
  line(534, 656,648, 654)
}

