function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("curves");

  
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
  drawMouseLines()
}                       

function drawTopLeftEmoji() {
  fill("gold");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Chocolate");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  arc(200, 266, 120, 100, 0, 180)
	
	fill("Chocolate");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	

  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('darkgreen');
  square(400, 0, 400); // upper right background
fill('tan')
  circle(600,200,300)

  drawlefteye()
  drawRighteye()
  drawMouth()
  function drawlefteye() {
  stroke("black");
  beginShape();
  curveVertex(535, 159); // control point
  curveVertex(535, 159);
  curveVertex(542, 145);
  curveVertex(550, 154);
  curveVertex(547, 174);
  curveVertex(524, 174);
  curveVertex(513, 146);
  curveVertex(547, 132);
  curveVertex(567, 168);
  curveVertex(547, 196);
  curveVertex(547, 196); // control point
  endShape();
  }
    function drawRighteye() {
  
  beginShape();
  vertex(654, 199);
  vertex(667, 174);
  vertex(649, 155);
  vertex(639, 148);
  vertex(628, 145);
  vertex(624, 147);
  vertex(619, 152);
  vertex(618, 162);
  vertex(621, 181);
  vertex(631, 185);
  vertex(644, 181);
  vertex(652, 177);
  vertex(652, 169);
  vertex(646, 162);
  vertex(637, 163);
  vertex(633, 167);
  vertex(633, 174);
  endShape();

}
  function drawMouth() {
  // fill("black");
  beginShape();
  curveVertex(506, 257); // control point
  curveVertex(506, 257);
  curveVertex(561, 243);
  curveVertex(579, 271);
  curveVertex(634, 248);
  curveVertex(656, 273);
  curveVertex(681, 248);
  curveVertex(681, 248); // control point
  endShape();
}
}

function drawBottomLeftEmoji() {	
	fill('darkred');
  square(0, 400, 400); // lower left background
  fill('yellow')
circle(200,600,300)
  fill("red")
  ellipse(151,666,40,100)

  drawGlasses()
  function drawGlasses() {
  fill("black");
  beginShape();
  curveVertex(282, 515); // control point
  curveVertex(282, 515);
  curveVertex(100, 511);
  curveVertex(108, 563);
  curveVertex(115, 565);
  curveVertex(125, 567);
  curveVertex(138, 568);
  curveVertex(144, 568);
  curveVertex(148, 568);
  curveVertex(157, 565);
  curveVertex(160, 562);
  curveVertex(163, 559);
  curveVertex(167, 557);
  curveVertex(174, 552);
  curveVertex(177, 547);
  curveVertex(180, 540);
  curveVertex(183, 536);
  curveVertex(184, 536);
  curveVertex(189, 536);
  curveVertex(192, 537);
  curveVertex(196, 539);
  curveVertex(196, 544);
  curveVertex(199, 555);
  curveVertex(200, 559);
  curveVertex(212, 568);
  curveVertex(226, 571);
  curveVertex(242, 573);
  curveVertex(257, 573);
  curveVertex(268, 568);
  curveVertex(276, 557);
  curveVertex(284, 541);
  curveVertex(285, 516);
  curveVertex(232, 512);
  curveVertex(232, 512); // control point
  endShape();
  }
}

function drawBottomRightEmoji() {
	fill('navy');
  square(400, 400, 400); // lower right background
  fill("purple")
  ellipse(605,580,300,300)
  
drawHorn()
function drawHorn() {
  fill("purple");
  beginShape();
  curveVertex(553, 457); // control point
  curveVertex(553, 457);
  curveVertex(502, 426);
  curveVertex(489, 403);
  curveVertex(481, 421);
  curveVertex(479, 434);
  curveVertex(481, 446);
  curveVertex(483, 464);
  curveVertex(499, 496);
  curveVertex(499, 496); // control point
  endShape();

  drawRighthorn()
function drawRighthorn() {
  fill("purple");
  beginShape();
  curveVertex(648, 463); // control point
  curveVertex(648, 463);
  curveVertex(679, 452);
  curveVertex(699, 421);
  curveVertex(706, 390);
  curveVertex(725, 443);
  curveVertex(729, 472);
  curveVertex(701, 504);
  curveVertex(687, 509);
  curveVertex(687, 509); // control point
  endShape();

  drawGrin()
function drawGrin() {
  fill("black");
  beginShape();
  curveVertex(503, 621); // control point
  curveVertex(503, 621);
  curveVertex(544, 660);
  curveVertex(600, 682);
  curveVertex(650, 678);
  curveVertex(696, 609);
  curveVertex(696, 609); // control point
  endShape();

 drawLeftE()
function drawLeftE() {
  fill("black");
  beginShape();
  curveVertex(509, 525); // control point
  curveVertex(509, 525);
  curveVertex(572, 554);
  curveVertex(523, 557);
  curveVertex(514, 529);
  curveVertex(511, 527);
  curveVertex(511, 527); // control point
  endShape();
}
  
}
}
}
  
}
