function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
 //top left emoji
  fill("yellow")
  square(0, 0, 400)
	fill("gold")
  circle(200, 200, 300)
	fill("black")
	circle(136, 162, 60)
	circle(264, 162, 60)
  circle(200,270,50)
  
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400);

  //top right emoji
	fill("green")
  square(400, 0, 400)
  fill("gold")
  circle(600,200,300)
  fill("skyBlue")
  rect(510,190,50,300)
  rect(645,190,50,300)
  fill("black")
  arc(535,195,100,100,180,0)
  arc(670,195,100,100,180,0)
  arc(600,280,100,100,180,0)
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400);
  fill("gold")
  circle(200,600,300)
  fill("black")
  arc(200,650,100,100,0,180)
  circle(110,630,70)
  circle(288,630,70)
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400);
  fill("gold")
  circle(600,600,300)
  fill("black")
  arc(620,700,100,100,180,0)
  circle(550,580,60,60)
  circle(700,580,60,60)
  
}