function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("yellow");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("gold");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 60); //left eye
	circle(264, 162, 60); //right eye
  arc(200, 266, 120, 50, 0, 180)
	
	fill("gold");
  circle(136, 182, 60); // left eye smiley
  //circle(264, 182, 60); // right eye smiley	

}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background
  fill("darkgreen")
  circle(620,200,300)
  fill("black")
  circle(560,160,60)
  circle(680,160,60)
  fill("lime")
  ellipse(620,280,70,30)
  rect(605,285,30)
  ellipse(620,325,90,30)
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background
  fill("darkred")
  circle(200,615,300)
  fill('black')
  circle(140,575,60)
  circle(260,575,60)
  arc(200, 675, 120, 50, 180, 360)
  strokeWeight(6)
  stroke("black")
  line(145,520,185,565)
  line(245,520,215,565)
  strokeWeight(1)
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background
  fill("darkblue")
  circle(620,615,300)
  fill("black")
  circle(560,575,60)
  circle(685,575,60)
  fill("white")
  translate(550,565)
  rotate(135)
  ellipse(0,0,40,20)
  resetMatrix()
  translate(675,560)
  rotate(135)
  ellipse(0,0,40,20)
  resetMatrix()
  circle(565,585,10)
  circle(695,580,10)
  fill("black")
  ellipse(625,685,80,60)
  noStroke()
  fill("darkblue")
  circle(625,700,60)
}
