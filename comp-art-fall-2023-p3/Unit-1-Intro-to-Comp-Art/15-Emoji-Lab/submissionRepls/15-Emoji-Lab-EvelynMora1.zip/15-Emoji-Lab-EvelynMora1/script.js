function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("black");
  square(0, 0, 400); // upper left background

  // top left emoji: dead
	fill("DimGray");
  circle(200, 200, 300); // head
	
  strokeWeight(7)
  stroke("black");
  line(117, 146, 175, 204)
  line(167, 142, 125, 204)// left eye 
  line(238, 143, 289, 195)
	line(284, 143, 244, 193)// right eye
  line(142, 267, 260, 265)// mouth

  
  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji(blushing) {
	fill('green');
  square(400, 0, 400); // upper right background

  //top right emoji 
 strokeWeight(0);
  fill("yellow")
  circle(600, 200, 300)// head 
  fill("Peru") 
  circle(550, 170, 85)//left eye 
  circle(650, 170, 85)//right eye 
  circle(600, 270, 90)//mouth 
  
  fill("yellow")
  circle(550, 200, 85)//left eye 
  circle(650, 200, 85)//right eye 
  circle(600, 250, 90)//mouth 
  
  fill("Pink")
  circle(520, 230, 50)//left cheek 
  circle(680, 230, 50)//right cheek 
}

function drawBottomLeftEmoji()//(clown ) 	
  { 
    
  fill("red")
  square(0, 400, 400); // lower left background

  fill("maroon")
  circle(100, 490, 100)//left hair, middle one 
  circle(80, 540, 100)//left hair, bottom one  
  circle(140, 470, 100)//left hair, top one 
  circle(300, 490, 100)//right hair, middle one 
  circle(320, 540, 100)//right hair, bottom one 
  circle(260, 470, 100)//right hair, top one 
    
  fill("white")
  circle(200, 600 ,320)//head 
  
  fill("SteelBlue")
  circle(130, 570, 100)//left eye 
  circle(270, 570, 100)//right eye 
  fill("white")
  circle(130, 570, 70)//left eye 
  circle(270, 570, 70)//right eye 
  fill("black")
  circle(130, 570, 40)//left eye 
  circle(270, 570, 40)//right eye 
  
  fill("red")
  circle(200, 630, 50)//nose 
  
  fill("Maroon")
  ellipse(200, 695, 140, 40)//mouth 
  fill("white")
  ellipse(200, 695, 100, 20)//mouth 

  fill("Tomato")
  circle(100, 640, 40)//left cheek 
  circle(300, 640, 40)//right cheek
    
  }

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background

  
  fill("yellow")
  circle(600, 590, 300)// head 
  fill('Peru')
  circle(530, 570, 100)//left eye 
  circle(670, 570, 100)//right eye 

  fill("yellow")
  circle(530, 540, 100)//left eye 
  circle(670, 540, 100)//right eye 

  fill("Peru")
  circle(600, 670, 80)//mouth
  fill("yellow")
  circle(600, 690, 80)//mouth 
  
}
