function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("lavender");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Pink");
  circle(200, 200, 300); // head
	fill("black");
	circle(136, 162, 70); //left eye
	circle(264, 162, 70); //right eye
	arc(200, 253, 100, 80, 0, 360); // mouth
	
	fill("pink");
  circle(136, 182, 60); // left eye smiley
  circle(264, 182, 60); // right eye smiley	

  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  //triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('green');
  square(400, 0, 400); // upper right background
  fill("SkyBlue");
  circle(617,200,300);//face
  fill("black");
  circle(554,159,60);//left eye
  circle(694,159,60);//right eye
   stroke('black');
  strokeWeight(3);
  line(546,272,699,271)//mouth


  
  
}

function drawBottomLeftEmoji() {	
	fill('red');
  square(0, 400, 400); // lower left background
  fill("black");
  circle(180,607,300)//face
  fill("white")
  circle(112,568,60)//left eye
  circle(257,568,60)//right eye
  circle(187,684,100)//mouth
  fill("black")
  ellipse(187,705,70,70)
  
  

  
}

function drawBottomRightEmoji() {
	fill('blue');
  square(400, 400, 400); // lower right background
  strokeWeight(0)
  fill("DarkGreen")
  circle(624,608,300)
  fill("lightcyan")
  circle(568,565,60)
  circle(704,565,60)
  circle(634,676,100)
  fill("DarkGreen")
  circle(634,637,129)
  

  
}
