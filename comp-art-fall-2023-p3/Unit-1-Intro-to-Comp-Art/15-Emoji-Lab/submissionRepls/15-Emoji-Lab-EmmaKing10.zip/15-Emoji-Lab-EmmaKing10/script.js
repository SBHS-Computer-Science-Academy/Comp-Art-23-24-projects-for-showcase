function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");

  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
  
	noStroke();  // to turn stroke back on, use stroke('black')
}

function draw() {
  background("white");

  drawTopLeftEmoji();
  drawTopRightEmoji();
  drawBottomLeftEmoji();
  drawBottomRightEmoji();
}

function drawTopLeftEmoji() {
  fill("LightSkyBlue");
  square(0, 0, 400); // upper left background

  // top left emoji: joy
	fill("Blue");
  circle(200, 200, 300); // head


  // fill('black');
  // stroke('black');
  // strokeWeight(14);
  // triangle(196, 196, 172, 227, 220, 228) // nose
  // quad(105, 141,84, 139,122, 87, 136, 104) // left eyebrow
  // line(84, 155, 132, 90); //left eyebrow
  // noStroke(); // turn off stroke lines
}

function drawTopRightEmoji() {
	fill('DeepSkyBlue');
  square(400, 0, 400); // upper right background

  
}
function drawBottomLeftEmoji(){
	fill('DeepSkyBlue');
  square(0, 400, 400); // lower left background
}
function drawBottomRightEmoji() {
	fill('LightSkyBlue');
  square(400, 400, 400); // lower rightbackground
fill("Blue")
circle(175,603,310)
circle(596,608,310)
circle(599,202,310)
fill("black")
circle(109,159,90)

fill("black")
circle(260,154,90)
fill("White")
circle(103,157,55)
fill("White")
circle(257,153,55)
fill("black")
circle(256,152,30)
circle(101,154,30)
circle(520,155,90)
circle(665,150,90)
circle(85,547,90)
circle(240,539,90)
circle(524,556,90)
circle(655,550,90)
fill("White")
circle(517,154,55)
circle(664,149,55)
circle(80,547,55)
circle(241,538,55)
circle(521,557,55)
circle(654,551,55)
fill("Black")
circle(187,270,130)
fill("Blue")
triangle(93,289,181,152,305,281)
fill("Black")

triangle(520,231,665,223,593,318)
fill("Blue")
triangle(528,243,657,236,593,323)
fill("Black")
circle(162,674,100)
fill("Blue")
triangle(91,674,158,750,243,667)

fill("black")
circle(665,147,35)
circle(514,152,35)
circle(77,547,35)
circle(240,536,35)
circle(520,557,35)
circle(652,552,35)
arc(582,675,100,100,180,0)

stroke('Black')
strokeWeight(10)
line(543,482,571,503)
line(607,506,640,480)
noStroke()
fill("DeepSkyBlue")
triangle(486,620,499,610,507,624)
fill("LightSkyBlue")
triangle(482,649,492,639,496,653)
fill("DeepSkyBlue")
triangle(470,670,480,661,487,674)
triangle(685,611,698,593,711,610)
fill("LightSkyBlue")
triangle(701,641,708,625,719,642)
fill("DeepSkyBlue")
triangle(709,672,717,658,728,672)
stroke('Black')
strokeWeight(10)
line(194,192,169,227)
line(172,225,207,236)
line(597,180,583,200)
line(586,199,606,208)
line(164,565,146,593)
line(146,592,176,606)
line(589,581,576,601)
line(576,600,597,611)
}
