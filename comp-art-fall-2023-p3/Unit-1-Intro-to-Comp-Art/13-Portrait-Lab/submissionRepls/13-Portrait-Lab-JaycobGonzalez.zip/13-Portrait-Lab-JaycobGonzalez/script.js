function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("green");
  
 stroke("black")
  fill("yellow");
  circle(500, 400, 600);
  fill("white");
  circle(370, 250, 120);
  circle(610, 250, 120);
  noStroke();
  fill("black");
  circle(370, 250, 100);
  circle(610, 250, 100);
  fill('pink');
  ellipse(499,532, 200,400);
  fill("red");
  ellipse(500, 610, 150, 250)

  stroke("black");
  strokeWeight(20);
  line(400, 150, 310, 200);
  line(600, 150, 670, 200);

  
}