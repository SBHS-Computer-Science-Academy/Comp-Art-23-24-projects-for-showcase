function setup() {
  createCanvas(1500, 1500);
}

function draw() {
  fill("wheat"); ellipse(800, 750, 500, 500)//face
  fill("white"); ellipse(900, 700, 100, 100);//right eye
  ellipse(700, 700, 100, 100);//left eye
  fill("navajowhite"); triangle(750, 800, 800, 730, 850, 800);//nose
  fill("black"); ellipse(700, 700, 60, 100);//left pupil
  ellipse(900, 700, 60, 100);//right pupil
  rect(530, 500, 550, 100);//tophat
  rect(600, 300, 400, 200)//tophat
  fill("darkred"); ellipse(800, 900, 200, 100);//mouth
  fill("pink"); ellipse(800, 915, 170, 70)//tounge
  strokeWeight(4);
  line(850, 620, 950, 620);//right eyebrow
  line(650, 620, 750, 620);//left eyebrow
  fill("black");circle(775,790, 10)
    circle(825,790, 10)

}
 