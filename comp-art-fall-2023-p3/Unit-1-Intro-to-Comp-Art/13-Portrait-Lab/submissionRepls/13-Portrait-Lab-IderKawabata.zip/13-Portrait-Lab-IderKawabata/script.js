let value = 0;
let colors=['red','black','white','blue','green','purple']


function setup() {
  let myCanvas = createCanvas(1000, 1000);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  
  //face
  background(random(colors));
  fill(219, 179, 127)
  ellipse(500,450, 550,800)
  //hat
  fill('orange')
  
  ellipse(500, 100, 320,160)
  ellipse(500,150,600,60)
  fill('black')
  triangle(500,60, 470, 80, 530, 80)
  //face
  fill('white')
  circle(400, 350, 100)
  circle(600, 350, 100)
  fill('black')
  circle(400, 350, 15)
  circle(600, 350, 15)
  //mouth 
  arc(500,700,100,60,360,180)
  
  //eyebrow
  line(321,320, 409, 281)
  line(602,278,680,308)
  //nose
  fill(219, 179, 127)
  triangle(500,463,540,550,460,550)


  
}


  



