function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  
  fill("tan");
  circle(400, 350, 600)
  fill(" SaddleBrown")
  circle(260, 280, 80)//left eye
  circle(514, 280,80)//right eye
  fill("black")
  circle(260, 280, 40)//eye
  circle(514,280,40)//eye
  fill("white")
  circle(270, 265, 30)
  circle(524,267, 30)
  fill("tan")
  stroke("black");
  strokeWeight(5);
  arc(400,500,450,350,0,180)//CHIN
  fill("white")
  line(186, 209, 302, 197)//brow
  line(450, 188, 605, 183)// brow
  fill("tan")
  arc(380, 540, 200, 200,1,180)//mouth
   fill("Sienna")
  noStroke()
  triangle(350, 318, 419,321,375, 382)// nose


  
 

  fill("gold");
  //text("Hello World!", 500, 400);
} 