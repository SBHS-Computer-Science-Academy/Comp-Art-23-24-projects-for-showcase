function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("navy");
  noStroke();
  fill("tan");
  circle(500, 400, 600);
   
  fill("green");
circle(356, 308, 50);
  circle(685, 316, 50);
   fill("red");
   circle(500, 394, 100);
  circle(364, 130, 250);
  circle(546, 83, 250);
  circle(715, 116, 250);
  circle(237, 179, 250);
  circle(849, 199, 250);
  fill("Salmon");
 circle(498, 550, 200);
  fill("LightCoral");
  circle(498, 550, 100);
  text("Hello World!", 500, 400);
}