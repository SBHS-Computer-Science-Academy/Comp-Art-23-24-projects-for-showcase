function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("pink");

fill("tan")//face
 circle(400,400,400);

 fill("SaddleBrown");
circle(350,370,80)//left eye
  circle(464, 372, 80)//right eye
  fill("black")
  circle(346,370,35)//pupil
  circle(465,375,35)//pupil
  fill("white")
  circle(350,363,15)// glint in eye
  circle(456,368,15)// glint in eye
  fill("red")
  arc(400,459,130,60,0,180)//smile
  strokeWeight(7);
  
  line(375,303,286,307)//left eyebrow
line(433,302,527,305)//right eyebrow
  strokeWeight(0);
  fill("SaddleBrown");
  triangle(404,387,382,416,429,415)
  fill("white")
  square(379,458,20)//tooth
  square(410,458,20)//tooth
                                                                                                                            
}
