function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("blue");
  
  fill("orange");
  circle(500, 500, 500);
  fill("black");
  text(".", 500, 400);
 strokeWeight(10); 
line(340, 378, 457, 376)
line(511, 375, 626, 374)
line(373, 569, 604, 563)
  arc(397, 380, 80, 80, 0, 180)
  arc(570, 380, 80, 80, 0, 188)
  line(479, 446, 436, 504, 436, 505)
  line(480, 447, 507, 502, 507, 503)
  line(439, 508, 509, 504, 505, 510)
  
}



