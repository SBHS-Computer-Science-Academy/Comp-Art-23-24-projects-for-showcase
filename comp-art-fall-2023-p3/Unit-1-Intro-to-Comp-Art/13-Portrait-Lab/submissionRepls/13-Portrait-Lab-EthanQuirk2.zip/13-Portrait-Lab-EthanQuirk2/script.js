function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  strokeWeight(6);
  fill("red");
  circle(500, 400, 400); 
  fill("black")
  circle(421, 325, 75) //left eye
  fill("black")
  circle(568, 325, 75) //right eye
  fill("black")
  strokeWeight(6);
  line(406, 262, 483, 330); //left eyebrow
  fill("black")
  line(573, 262, 514, 330) //right eyebrow
  fill("white")
  circle(433, 325, 50) //left eyes pupil
  fill("white")
  circle(579, 325, 50) //right eyes pupil
ellipse(505, 482, 100, 50) //mouth
  fill("blue")
  circle(157, 144, 150)
  fill("black")
  circle(130, 114, 20)
  circle(186, 114, 20)
  fill("blue")
  arc(157, 184, 80, 60, 180, 360)
  fill("yellow")
  circle(157, 510, 150)
  fill("black")
  circle(130, 483, 20)
  //fill("black")
  circle(186, 483, 20)
  fill("yellow")
  arc(157, 529, 80, 60, 0, 180)
  //fill('yellow');
  //text("Hello World!", 500, 400);
}