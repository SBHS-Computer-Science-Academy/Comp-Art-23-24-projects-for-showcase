function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}
function draw() {
  background("white");
  
   
  fill("NavajoWhite")
  circle(360,360,360)
  
    fill("SeaGreen")
  circle(260,330,100) // left eye
  circle(468,330,100) // right eye
  
  fill("black")
  arc(360,460,100,80,0,180) // mouth
  circle(260,330,60)
  circle(468,330,60)

  fill("white")
  circle(280,310,30)
  circle(480,310,30)
  //text("hello world!", 500,400)

  fill("Wheat")
  triangle(400,400,300,400,360,330)

}