function setup() {
  let myCanvas = createCanvas(1000, 1000);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("white");
  fill("wheat")
  circle(400,400,650)//face
  fill("black");
ellipse(300,200, 80, 80)//eye 
ellipse(500, 200, 80, 80)//eye
  fill("blue")
rect(300,200,20,20)//iris 
rect(500,200,20,20)//iris 
  fill("blue")
strokeWeight(5)
triangle(398,298, 443, 394, 353, 390)
  fill("blue")
ellipse(396,526, 300, 50)
fill("blue")
circle(224, 248, 20, 50) 
circle(213, 288, 20, 50)
circle(200, 320, 20, 50)
circle(187, 347, 20, 50)
line(278, 129, 346, 154)
line(433, 152, 513, 129)
fill("blue")
circle(560,233,20,50)
circle(582,259,20,50)
circle(603,291,20,50)
circle(617,321,20,50)
}