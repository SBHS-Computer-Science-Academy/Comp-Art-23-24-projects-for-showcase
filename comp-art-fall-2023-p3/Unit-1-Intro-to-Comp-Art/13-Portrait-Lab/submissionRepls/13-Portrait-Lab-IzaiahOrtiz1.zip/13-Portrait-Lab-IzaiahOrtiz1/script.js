function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  

  fill("darkblue");
  circle(360, 360, 300);
  
  fill("white");
  
  circle(298, 322, 80);   
  circle(411, 328, 80);    
  circle(355, 444, 10);    
  line(387, 289, 448, 255);   
  line(30, 20, 85, 75);   
       text("Hello World!", 500, 400);
}fill
