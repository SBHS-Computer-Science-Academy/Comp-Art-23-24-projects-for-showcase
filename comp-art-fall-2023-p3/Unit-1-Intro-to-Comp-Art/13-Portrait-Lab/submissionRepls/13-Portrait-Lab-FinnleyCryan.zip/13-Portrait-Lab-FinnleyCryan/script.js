let cls = ['#00f', '#07f', '#0bf', '#0ff', '#0fb', '#0f7', '#af0', '#cf0', '#ef0', '#ff0'];
let val = 9

function setup() {
  createCanvas(600, 900);
  textAlign(CENTER, CENTER);
}

function keyPressed() {
  if (keyCode === UP_ARROW && val < 9) {
    val = val + 1;				//increase happiness
  } else if (keyCode === DOWN_ARROW && val > 0) {
    val = val - 1;				//decrease happiness
  }
}

function draw() {
  background(28.3 * (9 - val)); //background color as a function of the happiness value from 255 - 0
  fill(cls[val]) //face color from cls array
  ellipse(300, 450, 600, 700); //face
  strokeWeight(7)
  curve(170, 111 * (9 - val), 170, 580, 430, 580, 430, 111 * (9 - val)) //smile
  strokeWeight(4)
  fill(255)
  ellipse(190, 320, 130, 145); //L eye
  ellipse(410, 320, 140, 145); //R eye
  fill(0)
  circle(200, 300, 100); //L pupil
  circle(400, 300, 100); //R pupil
  fill(255)
  circle(220, 310, 25); //L glisten
  ellipse(200, 272, 70, 40);
  circle(420, 310, 25); //R glisten
  ellipse(400, 272, 70, 40);

  text("Up Arrow to gladden.  Down Array to sadden.", width/2, height - 30)
}