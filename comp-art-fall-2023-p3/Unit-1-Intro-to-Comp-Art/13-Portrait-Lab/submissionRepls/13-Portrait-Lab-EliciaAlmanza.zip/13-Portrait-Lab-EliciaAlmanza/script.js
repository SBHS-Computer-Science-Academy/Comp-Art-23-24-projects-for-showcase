function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("lightgreen");
  
  
  fill('grey')
  circle(363,170,130)//left ear
 fill('white')
  circle(358,170,95)//inside left ear
  
  fill('grey')
  circle(659,170,130)//right ear
  fill('white')
  circle(660,170,95)//inside right ear
  
  fill('lightgrey')
  circle(509,308,450)//bigcircle
 
  fill("SaddleBrown");
  circle(419, 234, 100);//left eye 
  fill('black')
  circle(419,234,75)//insidelefteye
  fill('Cornsilk')
  circle(441,216,30)
  
  fill('SaddleBrown')
  circle(590,234,100);//rigth eye 
  fill('black')
  circle(590,234,75)//insiderighteye
  fill('Cornsilk')
  circle(568,251,30)
  
  fill('black')
  ellipse(509,324,95,150)//nose

  fill('MistyRose')
  circle(490,368,20)//leftnorsrol

  fill('MistyRose')
  circle(528,368,20)//rightnostrel
  
  fill('LightPink')
  arc(509,405,120,180,0,180)//mouth 
   
  stroke('HotPink')
  line(508,493,510,407)



}
