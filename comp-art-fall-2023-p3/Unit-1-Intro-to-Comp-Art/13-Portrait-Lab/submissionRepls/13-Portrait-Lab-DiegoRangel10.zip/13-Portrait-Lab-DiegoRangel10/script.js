let eyelid=10
let eyelidSpeed = 1

function setup() {
  let myCanvas = createCanvas(800, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  // noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
 
  
  background(100);
  fill('#FFC107')
 
  
  
  
  ellipse()
  
 ellipse(400,400,300,300)
  
  //head
  fill(0)
  ellipse(400,400,280,280)
  
// eyes
  fill(235, 235, 235)
  

  ellipse(350,360,80,80)
    ellipse(450,360,80,80)




  


    fill(0)
 ellipse(350,360,50,50)
    ellipse(450,360,50,50)
  






  
  fill(0)
  //eyelid
//let(X,Y)
  
  eyelid += eyelidSpeed
  
    rect(310,295,80,eyelid)
  rect(410,295,80,eyelid)
 
  if (eyelid > 105) eyelidSpeed = -1.5
  if (eyelid < 1) eyelidSpeed = 1.5
 
  
  
  //bottome lip 
  fill('#FFC107')
  ellipse(400,459,130,100)
  
  
  //top lip
  fill(0)
  ellipse(400,440,200,80)
  
  
  
  
  
  
  fill('#FFC107')
  ellipse(400,420,36,50)
 noStroke()
  ellipse(400,430,60,40)
  
  
  fill(0)
  rect(375,445,50,10)
  ellipse(413,445,20,20)
  ellipse(387,445,20,20)
  
  
  fill(255,255,255)
  
  strokeWeight(20)
  stroke(255)
  
  stroke('#815D50')
  
  line(310,320,390,320)
  
  line(415,310,490,290)
  
  
  
  
  //hat 
  
   noStroke()
  
  //arc(400,300, 80, 80, 0,180)

  
}