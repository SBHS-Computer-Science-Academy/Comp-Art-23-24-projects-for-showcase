function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("Beige");

  fill("Burlywood")
  circle(300, 300, 450)   
 
  fill("SaddleBrown");
  circle(200, 250, 100);//left eye
  fill("SaddleBrown")
  circle(400, 250, 100)//right eye

  fill("black")
  circle(200, 250, 50)//left pupil 
  fill("black")
  circle(400, 250, 50)//right pupil 

  fill("white")
  circle(215, 230, 20)//left eye part
  fill("white")
  circle(415, 230, 20)//right eye part

  fill("IndianRed")
  arc(300, 400, 150, 80, 0, 180)//smile

  strokeWeight(2)
  fill("black")
  line(140, 180, 270, 180)//left eyebrow
  strokeWeight(2)
  fill("black")
  line(320, 180, 450, 180)//right eyebrow

  fill("Burlywood")
  triangle (300, 270, 270, 350, 330, 350)//nose 

  fill("black")
  circle(345, 315, 4)//birthmark
}