function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
 
  fill("tan");
  ellipse(500, 400, 200, 300);
  fill("black");
  text("0", 500, 420);
  fill("white");
  ellipse(450, 370, 50, 80);
  ellipse(550, 370, 50, 80);
  fill("blue");
  ellipse(450, 370, 30, 60);
  ellipse(550, 370, 30, 60);
  fill("black");
  triangle(500, , 550, 550, 600, 600);
}