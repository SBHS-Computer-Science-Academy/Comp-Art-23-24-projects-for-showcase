function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop()
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background(100);

  fill('tan');
  circle (418,372,700)

  
  fill('green'); 
  circle(293,236,100) // left eye
  fill('green');
  circle(521,236,100) // right eye
  fill('wheat');
  triangle(411,281,378,402,443,402) // nose
  fill('black');
  circle(292,238,30) // left pupil
  circle(520,237,30) // right pupil
  fill('white');
  circle(302,227,30) // left pupil
  circle(531,227,30) // right pupil
  fill('red');
  arc(419,467,300,200,0,180) // frown
  fill('white');
  rect(315,468,33) // tooth
  rect(372,468,33) // tooth
  rect(444,468,33) // tooth
  rect(503,468,33) // tooth
  fill('pink');
  arc(430,569,100,80,150) // tongue
  stroke('SaddleBrown');
  strokeWeight(10);
  line(219,112,360,160) // left eyebrow
  line(458,162,585,104) // right eyebrow
  fill('Brown');
  circle(146,304,1) // freckle
  circle(182,301,1) // freckle
  circle(169,328,1) // freckle
  circle(626,299,1) // freckle
  circle(665,297,1) // freckle
  circle(646,325,1) // freckle
  fill('pink');
  strokeWeight(0);
  arc(416,643,100,200,290,250,CHORD) // tongue
  stroke('black');
  strokeWeight(2);
  line(415,563,416,743)
  stroke('black');
  strokeWeight(2);
  line(257,205,231,176)
  line(284,188,273,157)
  line(310,188,314,159)
  line(558,201,578,165)
  line(525,186,528,149)
  line(496,192,480,164)
  fill('black');
  triangle(245,219,183,231,241,242)
  triangle(568,217,572,239,632,222)
  fill('blue');

}