function setup() {
  let myCanvas = createCanvas(600, 600);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("teal");
  fill("blanchedalmond");
  circle(265,280,500);
  fill("steelblue");
  circle(120, 220, 100); //left eye
  circle(400,220,100); //right eye
  
  fill("black");
  circle(120,220,70); //pupil
  circle(400,220,70); //pupil
  
  fill('white');
  circle(110,200,40); //left eye sparkle b
  circle(390,200,40); //right eye sparkle b
  circle(130,220,10); //left eye sparkle s
  circle(410,220,10); //right eye sparkle s
  
  fill("black");
  quad(140,320,380,320,300,430,220,430); //mouth
  
  fill("white");
  quad(140,320,380,320,360,350,160,350); //teeth
  
  fill("crimson");
  quad(199,401,321,401,300,431,221,431); //tongue
  
  stroke("black")
  strokeWeight(7);
  line(57,166,111,123); //left eyebrow p1
  line(111,123,176,123); //left eyebrow p2
  line(461,166,400,123); //right eyebrow p1
  line(400,123,335,123); //right eyebrow p2

  stroke("blanchedalmond");
  fill('blanchedalmond');
  arc(120,300,90,90,180,0); //happy left
  arc(400,300,90,90,180,0); //happy right

  stroke('black');
  noFill();
  arc(120,213,100,90,180,0); //left eyelid
  arc(400,213,100,90,180,0); //rigt eyelid
  
  stroke('blanchedalmond');
  fill("pink");
  ellipse(120,290,90,50); //left blush
  ellipse(400,290,90,50); //right blush
  
  stroke('black');
  fill('black');
  triangle(69,214,69,228,48,219); //left eyeliner
  triangle(451,216,451,229,472,219); //right eyeliner
  
  
}