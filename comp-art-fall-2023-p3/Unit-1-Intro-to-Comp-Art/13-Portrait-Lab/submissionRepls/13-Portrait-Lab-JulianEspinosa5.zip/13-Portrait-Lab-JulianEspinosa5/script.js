function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}
function draw() {
  background("yellow");
  fill("SandyBrown");
  circle(400,400,650);
  fill("moccasin");
square(166,250,100)
square(500,250,100)
circle(319,555,150)
fill("green")
  circle(208,294,50)
circle(545,294,50)
fill("red")
arc(300,600,60,300,0,180)
fill("black")
fill("orange")
triangle(377, 500, 321, 356, 435, 363, 40)

  strokeWeight(20)
line(472, 211, 623, 216)
 line(172,201,285,196) 
fill("black")
circle(208,293,10)
circle(544,293,10)


  
}