function setup() {
  let myCanvas = createCanvas(1000, 1000);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("green");
strokeWeight(30);
  fill("wheat");
  circle(500, 400, 600);
  strokeWeight(7);
  fill("white")
  circle(386,309,150)
fill("white")
  circle(637,309,150)
  fill("black")
  circle(384,301,50)
    fill("black")
  circle(639,301,50)
  fill("red")
  ellipse(495, 533, 250, 150)
  fill("pink")
  circle(529,576,125)
  fill("black")
  circle(244,44,300)
    fill("black")
  circle(699,20,300)
  strokeWeight(30);
line(317,208,451,205)
  line(558,208,692,205)
  fill("brown")
  triangle(504,353,444,418,557,416,100)
  
  
  
  

  
  
  
  
  fill("gold");

}