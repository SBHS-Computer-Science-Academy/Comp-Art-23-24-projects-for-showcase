function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  fill("yellow")
  ellipse(200,200,300,300)//head
  fill("black")
  ellipse (100, 200, 80, 80)//left eye
  ellipse (300, 200, 80 ,80)//right eye
  fill("red")
  ellipse (200, 300, 200, 80)//mouth
  fill("pink")
  ellipse(250,330,80,100)//tongue
  ellipse(250,330,1,100)//tongue line
  fill("black")
  rect(183,350,30,75)//neck
  rect(150,400,100,100)//body
  rect(120,400,30,60)//left arm
  rect(250,400,30,60)//right arm
  fill("yellow")
  rect(120,460,30,40)//left arm
  rect(250,460,30,40)//right arm
  rect(150,550,40,50)//left leg
  rect(210,550,40,50)//right leg
  fill("black")
  rect(150,500,40,50)//left thigh
  rect(210,500,40,50)//right thigh
  fill("red")
  noStroke()
    rect(188,279,100,30)//invisible tongue cover
  fill("white")
  ellipse(75,200,20,20)//left eye pupil
  ellipse(325,200,20,20)//right eye pupil
}