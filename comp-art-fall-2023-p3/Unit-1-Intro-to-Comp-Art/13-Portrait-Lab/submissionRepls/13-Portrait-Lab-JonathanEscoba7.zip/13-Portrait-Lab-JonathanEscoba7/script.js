function setup() {
  let myCanvas = createCanvas(1000, 1500);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("blue");
  fill("red")
  strokeWeight(100);
  line(359,1032,252,1229)
  line(404,1030,515,1229)
  line(433,759,608,868)
  line(332,759,138,868)
  strokeWeight(10);
 fill("black")
  rect(336,632,100,400)  
  fill("red");
  strokeWeight(20);
  circle(374,396,500 );
  strokeWeight(10);
  fill("white");
circle(240,329,100 );
circle(468,329,100 );
fill("black");
  circle(237,332,50 );
circle(470,333,50 );
circle(344,429,90 )
  strokeWeight(10);
line(315,331,227,242)
line(383,335,490,242)
  fill("white");
  ellipse(361,565,300,60)
  fill("black");
  rect(132,150,500,70)
  rect(230,100,300,50)
}