function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");

  createConsole("dots");
  noLoop();

  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background('DimGray');

  fill("midnightblue");
  circle(500, 400, 666);
  fill("DarkRed");
  circle(360, 282, 190)//left eye
circle(637, 282, 190)
  rect(315,480,360,110)
}
