function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("whitesmoke");
  
  fill("Burlywood");
  circle(400, 350, 600);
  fill("SaddleBrown");
  circle(260, 280, 80); // left eye
  circle(490, 280, 80) //right eye

  fill("black")
circle(260, 280, 40)
circle(490, 280, 40)

  fill("white")
  circle(270,265,25)
circle(500, 265, 25)
fill("Firebrick")
arc(380,460,200, 100, 0, 180)  //smile
fill("burlywood")
  triangle(375, 345, 340, 390, 415, 390)

  
}