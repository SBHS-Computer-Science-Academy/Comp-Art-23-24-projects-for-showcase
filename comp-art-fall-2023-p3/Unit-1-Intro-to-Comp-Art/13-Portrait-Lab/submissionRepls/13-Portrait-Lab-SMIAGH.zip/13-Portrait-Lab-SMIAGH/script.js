function setup() {
  createCanvas(1000, 1000);
}

function draw() {
  background(105, 105, 105);

  noStroke();
  fill('yellow')
  circle(584,347,150)//moon

  fill('gold')
  circle(545, 315, 30)//circle on moon
  circle(567, 366, 10)//circle on moon
  circle(612, 325, 50)//circle on moon
  circle(604, 392, 30)//circle on moon
  //fill('rgb(,229,173)')
 

  // fill('lightgrey')
  // rect(28, 246, 60, 218);
  // rect(305,259,60,218);

  fill('255, 240, 245')
  circle(200,150,400)//head
  
  // fill('rgb(41,31,41)')
  // ellipse(mouseX, mouseY, 40, 40)
  
  fill('black')
  ellipse(100,200,80,80)//left eye
  ellipse(300,200,80, 80)//right eye
  
  fill('red')
  ellipse(100,210,30,60)// left pupil
  ellipse(300,210,30, 60)// right pupil
 
  stroke('black')
  line(312,87,93,86); //mouth

   fill('white')
  stroke('black')
  triangle(93, 86, 106, 49, 123, 86);//left fang
  triangle(313,86,291,49,278,86);//right fang

  stroke('black')
  strokeWeight(5);
   line(60,272,133,254);//left eyebrow
   line(262,247,329,268);//right eyebrow

  fill('black')
  triangle(300,-1, 405,105, 390,-1);//right part of coat
  triangle(97,-3, 1,94, 1,-1);// left part of coat

  ellipse(200,297,300,50);//bottom part of hat
  quad(87,314, 314,312, 314,404, 87,406);//top part of hat


  fill('white')
  noStroke();
  circle(663, 405, 80)//cloud1
  circle(696, 382, 70)//cloud1
  circle(708, 436, 80)//cloud1
  circle(749, 415, 90)//cloud1
  circle(776, 396, 80)//cloud1
  circle(738, 369, 50)//cloud1

  circle(538, 466, 80)//cloud2
  circle(521, 507, 60)//cloud2
  circle(482, 487, 70)//cloud2
  circle(563, 514, 60)//cloud2

  stroke('black')
  strokeWeight(5)
  fill('lightgrey')
  quad(0, 999, 0, 809, 248, 809, 244, 1000)//building1
  quad(244, 1000, 244, 605, 459, 651, 459, 1000)//building2
  quad(459, 1000, 459, 857, 553, 848, 553, 1000)//building3

  quad(789, 1000, 805, 791, 877, 735, 877, 1000)//building4
  
  quad(877, 1000, 885, 478, 999, 603, 999, 997)//building5
  circle(885, 458, 60)//building5
  triangle(883, 644, 756, 606, 883, 606)//building5

  
}

function mousePressed() {
  print(mouseX +","+ mouseY)
}


