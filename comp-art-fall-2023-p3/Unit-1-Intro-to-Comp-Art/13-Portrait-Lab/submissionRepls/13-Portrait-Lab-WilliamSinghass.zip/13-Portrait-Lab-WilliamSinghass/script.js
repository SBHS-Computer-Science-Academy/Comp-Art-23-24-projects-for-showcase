
function setup() {
  createCanvas(500, 500);
  background(255);
  fill(255, 199, 42)
  ellipse(250, 250, 400, 400);
  fill(0)
  ellipse(175, 200, 50, 100);
  ellipse(325, 200, 50, 100);
  rect(150, 325, 200, 40);
  fill(255);
  rect(155, 330, 190, 10);
}