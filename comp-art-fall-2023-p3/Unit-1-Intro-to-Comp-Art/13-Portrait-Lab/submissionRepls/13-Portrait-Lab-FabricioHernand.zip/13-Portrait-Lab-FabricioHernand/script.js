function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("navy");
  fill('black')
  circle(356,81,100)
  circle(534,77,100)
  fill("white");
  circle(451,267,400);
  
  fill("black");
  circle(600, 200, 100);
  
  circle(300,200,100);
  
  ellipse(443,341,100);
  
  arc(422,414,100,89,0,180)
  
}