function setup() {
  let myCanvas = createCanvas(1000, 1000);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  
  fill("yellow");
  circle(500, 400, 500);
    fill("white");
  circle(411,312,100)
circle (575,310,100)
  fill("red")
ellipse(499,532,200, 100)
  fill("pink")
  rect(501,548,50,100)
  fill("black")
  ellipse(409,313,50)
  ellipse(572,308,50)
  fill("red")
  triangle(491,376,345,430,492,447)
}