function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);

}

function draw() {
  background(220);
 fill("linen");
 ellipse(250,250,500,500);
 fill(0,0,0);
 ellipse(150,150,50,100);
 ellipse(325,150,50,100);
 arc (250,320,200,150,0,PI) 
fill("red")
triangle (80,437,244,502,94,567)
triangle (242,502,383,458,384,526)
strokeWeight(50)
line(106,86,359,75)
strokeWeight(5)
fill("pink")
  ellipse(288, 377, 50, 100)
}
