function setup() {
  let myCanvas = createCanvas(1000, 800);
  myCanvas.parent("myCanvas");
  
  createConsole("dots");
  noLoop();
  
  textAlign(CENTER, CENTER);
  angleMode(DEGREES);
}

function draw() {
  background("black");
  
  fill("olive");
  circle(500, 400, 100);
  fill("gold");
  text("Hello World!", 500, 400);
}